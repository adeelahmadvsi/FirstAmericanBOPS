﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimiosFirstAmericanBOPSSimulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Users\azhar.majeed\Source\Workspaces\FirstAMTimiosBOPS\FirstAMTimiosBOPS\bin\Debug\FirstAMTimiosBOPSSimulator.exe";
            p.StartInfo.Arguments = txtGatorOrderNo.Text;
            p.Start();
            p.WaitForExit();
            switch (p.ExitCode)
            {
                case 100:
                    MessageBox.Show("Processed successfully!");
                    break;
                case 0:
                    MessageBox.Show("Invalid Gator Order No!");
                    break;
                case 1:
                    MessageBox.Show("Gator Order Not Loaded!");
                    break;
                case 2:
                    MessageBox.Show("BOP Search Failed!");
                    break;
            }
            p.WaitForExit();
        }
    }
}

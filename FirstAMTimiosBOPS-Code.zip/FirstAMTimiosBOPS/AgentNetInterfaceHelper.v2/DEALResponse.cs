﻿using System;
using System.Collections.Generic;
using System.IO;
#if MISMO32
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
using www.firstam.com._2011._03.datacontract.agentnet;
namespace AgentNetInterfaceHelper.v1
#endif

{
    public class DEALResponse
    {
        public const string RETURN_CODE_SUCCESS = "F4100";
        public const string RETURN_CODE_WARNING = "W10190";//mocpl
        private static string s_DocumentsFolder = "c:\\temp\\thirdpartysimulation";
        private MESSAGE m_Message = null;
        private DEAL m_Response = null;
        static DEALResponse() 
        {
            s_DocumentsFolder = ANUtils.GetConfig("TempDocsFolder");
        }
        public DEALResponse()
        {
        }
        public DEALResponse(MESSAGE message)
        {
            m_Message = message;
            m_Response = DEALResponse.GetDEAL(message);
        }
        public static string DocumentFolder
        {
            get { return s_DocumentsFolder; }
        }
        public MESSAGE MESSAGE
        {
            get { return m_Message; }
            set 
            { 
                m_Message = value;
                m_Response = DEALResponse.GetDEAL(m_Message);
            }
        }
        public DEAL DEAL
        {
            get { return m_Response; }
        }
        #region Accessors
        public AGENTNET_RESPONSE AGENTNET_RESPONSE
        {
            get
            {
#if MISMO32
                return m_Response.EXTENSION.OTHER.AGENTNET_RESPONSE;
#else
                return m_Response.EXTENSION.AGENTNET_RESPONSE;
#endif
            }
            set
            {
#if MISMO32
                m_Response.EXTENSION.OTHER.AGENTNET_RESPONSE = value;
#else
                m_Response.EXTENSION.AGENTNET_RESPONSE = value;
#endif
            }
        }
        public string FileNumber
        {
            get { return this.AGENTNET_RESPONSE.FileNumber; }
        }
        public string ClientRequestId
        {
            get { return this.AGENTNET_RESPONSE.ClientRequestId; }
        }
        public string FileId
        {
            get { return this.AGENTNET_RESPONSE.FileId; }
        }
        public string LoginId
        {
            get { return this.AGENTNET_RESPONSE.LoginId; }
        }
        public string AccountNumber
        {
            get { return this.AGENTNET_RESPONSE.AccountNumber; }
        }
        public string UnderwriterCode
        {
            get { return this.AGENTNET_RESPONSE.UnderwriterCode; }
        }
        public string UnderwriterName
        {
            get { return this.AGENTNET_RESPONSE.UnderwriterName; }
        }
        public string OfficeId
        {
            get { return this.AGENTNET_RESPONSE.OfficeId; }
        }
        public string SessionId
        {
            get { return this.AGENTNET_RESPONSE.SessionId; }
        }
        public bool IsAutoReportOnHold
        {
            get { return this.AGENTNET_RESPONSE.IsAutoReportOnHold; }
        }
        #endregion
        public bool IsResponseSuccess
        {
            get
            {
                if (GetStatuses().Length == 0)
                    return false;
                //if (GetStatuses()[0].StatusCode == RETURN_CODE_SUCCESS)
                //    return true;
                return DEALResponse.CheckForSuccessStatus(GetStatuses());
            }
        }
        public bool HasWarning()
        {
            if (GetStatuses().Length == 0)
                return false;
            //if (GetStatuses()[0].StatusCode == RETURN_CODE_SUCCESS)
            //    return true;
            return DEALResponse.CheckForWarning(GetStatuses());
        }
        public string GenerateXML()
        {
            string responseXml = ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Message);
            return ANUtils.FormatXML(responseXml);
        }

        public void SaveResponse()
        {
            // save the response file as MISMO 3.x XML
            string responseXml = ANUtils.FormatXML(ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Message));
            string respFileName = this.LoginId.ToLower() + "_" + this.FileNumber.ToLower() + "_Response.xml";
            ANUtils.StringToFile(ANUtils.FileDataPath + "\\" + respFileName, responseXml);
        }
        public void DeleteResponseFile()
        {
            string respFileName = this.LoginId.ToLower() + "_" + this.FileNumber.ToLower() + "_Response.xml";
            ANUtils.DeleteFile(ANUtils.FileDataPath + "\\" + respFileName);
        }
        public List<SERVICE> GetServices()
        {
            if (m_Response == null)
                return null;
            List<SERVICE> services = new List<SERVICE>();
            if (m_Response.SERVICES != null && m_Response.SERVICES.SERVICE != null)
                services.AddRange(m_Response.SERVICES.SERVICE);
            return services;
        }
        public STATUS[] GetStatuses()
        {
#if MISMO32
            return m_Response.EXTENSION.OTHER.STATUSES.STATUS;



            
#else
            return m_Response.EXTENSION.STATUSES.STATUS;
#endif
        }
        public void UpdateStatuses(STATUS[] sts)
        {
#if MISMO32
            m_Response.EXTENSION.OTHER.STATUSES.STATUS = sts;
#else
            m_Response.EXTENSION.STATUSES.STATUS = sts;
#endif
        }


        public List<TimiosAPI> CreateDocFile_CPL(SERVICE ss, string sFileNumber)
        {
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_ffff");

            ServiceHelper s = new ServiceHelper(ss);

            s_DocumentsFolder = ANUtils.GetConfig("BOPSFolder");
            if (!Directory.Exists(s_DocumentsFolder))
            {
                Directory.CreateDirectory(s_DocumentsFolder);
            }

            List<TimiosAPI> ret = new List<TimiosAPI>();
            //if (s.AGENTNET_PRODUCT_RESPONSE.AgentNetServiceType == ANUtils.C_ServiceType_CPL)
            if (s.AGENTNET_PRODUCT_RESPONSE.AgentNetServiceType == AgentNetProductTypeEnum.BOPSDynamic)
            {
                AGENTNET_CPL_DETAIL cpl = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_CPL_DETAIL;
                //AGENTNET_TITLE_SERVICE_DETAIL boService = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_TITLE_SERVICE_DETAIL;
                string FileServiceCPLId = cpl.FileServiceCPLId;
                //string FileServiceCPLId = boService.BOServiceAgentnetId;
                foreach (AGENTNET_CPL_COVERRED_PARTY cp in cpl.AGENTNET_CPL_COVERRED_PARTIES.AGENTNET_CPL_COVERRED_PARTY)
                {
                    TimiosAPI obj = new TimiosAPI();
                    FOREIGN_OBJECT doc = cp.DOCUMENT;
                    if (doc != null)
                    {
                        string pdf = doc.EmbeddedContentXML;
                        byte[] bytes = Convert.FromBase64String(pdf);

                        string desc = doc.ObjectDescription.Replace("(", "").Replace(")", "").Replace("/", "").Trim().Replace(" ", "");
                        string tempFileName = s_DocumentsFolder + timestamp  + "_" + "CPL_" + sFileNumber.Replace("-", "") + "_"  + FileServiceCPLId + "_" + desc + "_" + doc.ObjectName + "." + doc.MIMETypeIdentifier;
                        FileStream file = new FileStream(tempFileName, FileMode.Create);
                        file.Write(bytes, 0, bytes.Length);
                        file.Close();

                        obj.ResponseId = FileServiceCPLId;
                        obj.CoveredPartyType = desc;
                        obj.DocName = doc.ObjectName;
                        obj.ImageLocation = tempFileName;

                        ret.Add(obj);
                    }
                }
            }

            return ret;
        }

        public List<TimiosAPI> CreateDocFile_BackTitle(SERVICE ss, string sFileNumber, string docType)
        {
            List<TimiosAPI> ret = new List<TimiosAPI>();

            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_ffff");

            ServiceHelper s = new ServiceHelper(ss);
            s_DocumentsFolder = ANUtils.GetConfig("TempDocsFolder");
            if (!Directory.Exists(s_DocumentsFolder))
            {
                Directory.CreateDirectory(s_DocumentsFolder);
            }

            FOREIGN_OBJECT doc = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.DOCUMENT;
            if (doc != null)
            {
                TimiosAPI obj = new TimiosAPI();

                string docData = doc.EmbeddedContentXML;
                byte[] bytes = Convert.FromBase64String(docData);

                string tempFileName = s_DocumentsFolder + timestamp + "_" + docType.Replace(" ","") + "_" + sFileNumber.Replace("-","") + "_"+ doc.ObjectName + "." + doc.MIMETypeIdentifier;

                FileStream file = new FileStream(tempFileName, FileMode.Create);
                file.Write(bytes, 0, bytes.Length);
                file.Close();

                obj.ResponseId = doc.ObjectURI;
                obj.CoveredPartyType = doc.MIMETypeIdentifier;  //use CoveredPartyType for file type
                obj.DocName = doc.ObjectName;
                obj.ImageLocation = tempFileName;

                ret.Add(obj);
            }

            return ret;
        }

        public List<string> CreateDocFile(SERVICE ss)
        {
            ServiceHelper s = new ServiceHelper(ss);
            //Moved from DEALResponse ctr as it was causing problem  
            //for ASC suppport page in AN2.0
            s_DocumentsFolder = ANUtils.GetConfig("TempDocsFolder");
            if (!Directory.Exists(s_DocumentsFolder))
            {
                Directory.CreateDirectory(s_DocumentsFolder);
            }
            // now process response data
            List<string> docname = new List<string>();
            if (s.AGENTNET_PRODUCT_RESPONSE.AgentNetServiceType == ANUtils.C_ServiceType_CPL)
            {
                AGENTNET_CPL_DETAIL cpl = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_CPL_DETAIL;
                string FileServiceCPLId = cpl.FileServiceCPLId;
                foreach (AGENTNET_CPL_COVERRED_PARTY cp in cpl.AGENTNET_CPL_COVERRED_PARTIES.AGENTNET_CPL_COVERRED_PARTY)
                {
                    FOREIGN_OBJECT doc = cp.DOCUMENT;

                    try
                    {
                        if (doc != null)
                        {
                            string pdf = doc.EmbeddedContentXML;
                            byte[] bytes = Convert.FromBase64String(pdf);

                            string desc = doc.ObjectDescription.Replace("(", "").Replace(")", "").Replace("/", "").Trim().Replace(" ", "");
                            string tempFileName = s_DocumentsFolder + "CPL_" + FileServiceCPLId + "_" + desc + "_" + doc.ObjectName + "." + doc.MIMETypeIdentifier;
                            FileStream file = new FileStream(tempFileName, FileMode.Create);
                            file.Write(bytes, 0, bytes.Length);
                            file.Close();
                            docname.Add(tempFileName);
                        }
                    }
                    catch(Exception ex)
                    {
                        //zzzzz
                        //error
                        //08-01482012, 15947543, pdf is null

                        //08-01314707
                        //used by another program
                    }
                }
            }
            else
            {
                FOREIGN_OBJECT doc = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.DOCUMENT;
                if (doc != null)
                {
                    string docData = doc.EmbeddedContentXML;
                    byte[] bytes = Convert.FromBase64String(docData);
                    string tempFileName = s_DocumentsFolder + "\\document_" + doc.ObjectName + ".pdf";
                    if (doc.MIMETypeIdentifier == "txt")
                        tempFileName = s_DocumentsFolder + "\\document_" + doc.ObjectName + ".txt";
                    FileStream file = new FileStream(tempFileName, FileMode.Create);
                    file.Write(bytes, 0, bytes.Length);
                    file.Close();
                    docname.Add(tempFileName);
                }
            }
            return docname;
        }
        #region statis_Helper_functions
        public static bool CheckForSuccessStatus(STATUS[] statuses)
        {
            foreach (STATUS s in statuses)
            {
                if (s.StatusCode[0] == 'F')
                    return true;
            }
            return false;
        }

        public static bool CheckForWarning(STATUS[] statuses)
        {
            foreach (STATUS s in statuses)
            {
                if (s.StatusCode[0] == 'W')
                    return true;
            }
            return false;
        }

        public static bool IsErrorsReturnedFromService(STATUS[] statuses)
        {
            foreach (STATUS s in statuses)
            {
                if (s.StatusCode[0] == 'S')
                    return true;
            }
            return false;
        }
        public static AGENTNET_TYPE_DATA[] GetAgentNetTypeDatas(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA;
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA;
#endif
            }
            catch (Exception) { }
            return null;
        }

        public static AGENTNET_TYPE_DATA GetSpecialMessage(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA[0];
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA[0];
#endif
            }
            catch (Exception) { }
            return null;
        }
#if MISMO32
        public static AGENTNET_SERVICE_ORDER_GROUP[] GetServiceOrderDisclaimer(MESSAGE msg)
        {
            try
            {
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_SERVICE_ORDER_GROUPS.AGENTNET_SERVICE_ORDER_GROUP;
            }
            catch (Exception) { }
            return null;
        }
#endif

#if MISMO32
        public static AGENTNET_TYPE_DATAS_MULTI GetAgentNetTypeDatasMulti(MESSAGE msg)
        {
            try
            {
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TYPE_DATAS_MULTI;
            }
            catch (Exception) { }
            return null;
        }
#else
      //  
#endif
#if MISMO32
        public static AGENTNET_TITLE_SERVICE_DETAIL GetAgentNetTitleServiceDetail(MESSAGE msg)
        {
            try
            {
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TITLE_SERVICE_DETAIL;
            }
            catch (Exception) { }
            return null;
        }
#else
      //  
#endif

#if MISMO32
        public static AGENTNET_TITLE_SERVICE_UPDATE_DETAILS GetAgentNetTitleServiceUpdateDetail(MESSAGE msg)
        {
            try
            {
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TITLE_SERVICE_UPDATE_DETAILS;
            }
            catch (Exception) { }
            return null;
        }
#else
      //  
#endif
#if MISMO32
        public static AGENTNET_TITLE_SERVICE_COMPL[] GetAgentNetTitleServiceCompls(MESSAGE msg)
        {
            try
            {
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TITLE_SERVICE_COMPLS.AGENTNET_TITLE_SERVICE_COMPL;
            }
            catch (Exception) { }
            return null;
        }
#else
      //  
#endif
#if MISMO32
        public static AGENTNET_TITLE_SERVICE_DOCS GetAgentNetTitleServiceDocs(MESSAGE msg)
        {
            try
            {
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_TITLE_SERVICE_DOCS;
            }
            catch (Exception) { }
            return null;
        }
#else
      //  
#endif


        public static AGENTNET_JACKET_ENDORSEMENT[] GetJacketEndorsements(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_JACKET_ENDORSEMENTS.AGENTNET_JACKET_ENDORSEMENT;
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_JACKET_ENDORSEMENTS.AGENTNET_JACKET_ENDORSEMENT;
#endif
            }
            catch (Exception) { }
            return null;
        }

        public static AGENTNET_ACCOUNT[] GetAccounts(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_ACCOUNTS.AGENTNET_ACCOUNT;
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_ACCOUNTS.AGENTNET_ACCOUNT;
#endif
            }
            catch (Exception) { }
            return null;
        }
        public static AGENTNET_PRODUCT_SERVICE_FIELD[] GetJacketTypeFields(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_PRODUCT_SERVICE_FIELDS.AGENTNET_PRODUCT_SERVICE_FIELD;
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_PRODUCT_SERVICE_FIELDS.AGENTNET_PRODUCT_SERVICE_FIELD;
#endif
            }
            catch (Exception) { }
            return null;
        }

        public static AGENTNET_PARTY[] GetParties(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_PARTIES.AGENTNET_PARTY;
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_PARTIES.AGENTNET_PARTY;
#endif
            }
            catch (Exception) { }
            return null;
        }
        public static DEAL GetDEAL(MESSAGE msg)
        {
            try
            {
                return msg.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0];
            }
            catch (Exception) { }
            return null;

        }
        public static SERVICE GetSERVICE(MESSAGE msg, int idx)
        {
            DEAL deal = GetDEAL(msg);
            if (deal.SERVICES != null)
            {
                if (deal.SERVICES.SERVICE.Length > idx)
                    return deal.SERVICES.SERVICE[idx];
            }
            return null;
        }
        public static bool IsServiceProcessed(SERVICE s)
        {
            if (s.STATUSES != null && s.STATUSES.STATUS != null && s.STATUSES.STATUS.Length > 0)
            {// if there is any status record, that means the SERVICE previously failed
                return false;
            }
            if (s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE != null &&
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION != null &&
#if MISMO32
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE != null)
#else
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE != null)
#endif
            {// This means it did get previously processed
                return true;
            }
            return false;
        }
        public static AGENTNET_PRODUCT_DETAIL_RESPONSE GetResponseDetail(MESSAGE message)
        {
            try
            {
#if MISMO32
                return DEALResponse.GetDEAL(message).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE;
#else
                return DEALResponse.GetDEAL(message).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE;
#endif
            }
            catch (Exception) { }
            return null;


        }

        public static AGENTNET_GET_DATA_RESPONSE GetAgentNetGetDataResponse(MESSAGE msg)
        {
            try
            {
#if MISMO32
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE;
#else
                return GetDEAL(msg).SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE;
#endif
            }
            catch (Exception) { }
            return null;
        }


        #endregion

        public void DeleteService(SERVICE s)
        {
            List<SERVICE> services = GetServices();
            services.Remove(s);
            // remove all the relations for this SERVICE
            //this.RemovRelationships(s.xlinklabel);
            m_Response.SERVICES.SERVICE = services.ToArray();
           
        }

        public STATUS[] getAllStatus_ZZ()
        {
            try
            {
                STATUS[] s1 = GetStatuses();
                STATUS[] s2 = null;


                try
                {
                    s2 = m_Response.SERVICES.SERVICE[0].STATUSES.STATUS;
                }
                catch (Exception)
                {
                    s2 = null;
                }

                int n1 = (s1 == null || s1.Length == 0) ? 0 : s1.Length;
                int n2 = (s2 == null || s2.Length == 0) ? 0 : s2.Length;

                int n = n1 + n2;

                if (n == 0) { return null; }

                STATUS[] s = new STATUS[n];

                for (int i = 0; i < n1; i++)
                {
                    s[i] = s1[i];
                }

                for (int i = 0; i < n2; i++)
                {
                    s[i + n1] = s2[i];
                }

                return s;
            }
            catch(Exception)
            {

            }

            return null;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
#if MISMO32
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
using System.Text;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
using www.firstam.com._2011._03.datacontract.agentnet;
namespace AgentNetInterfaceHelper.v1
#endif
{
    public class AgentNetHelper
    {
        private string m_UserId = null;
        private string m_Password = null;
        private List<STATUS> m_Status = new List<STATUS>();

        public string m_xml1 = "";
        public string m_xml2 = "";

        public AgentNetHelper(string agentnetUserId, string agentnetPassword)
        {
            m_xml1 = "";
            m_xml2 = "";

            m_UserId = agentnetUserId;
            m_Password = agentnetPassword;
        }
        #region Static helper properties and function
        public static string JACKET_FIELD_TO_MISMO_CONFIG
        {
#if MISMO32
            get { return "JacketFieldToMismo"; }
#else
            get { return "JacketFieldToMismo31"; }
#endif
        }

        #endregion

        public List<STATUS> GetStatuses()
        {
            return m_Status;
        }

        public List<AGENTNET_TYPE_DATA> GetJacketTypes(string stateCode, string underwriterCode, string officeId, string vendorSystemName) 
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetJacketTypes(m_UserId, m_Password, stateCode, underwriterCode, officeId, vendorSystemName);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketTypes failed: " + ex.ToString());
            }
            return null;
        }
        public List<AGENTNET_TYPE_DATA> GetJacketTypesPost(string stateCode, string underwriterCode, string officeId, string vendorSystemName) 
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketTypes(stateCode, underwriterCode, vendorSystemName));
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetJacketTypesPost");
                if (CheckStatus(resp, "GetJacketTypesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
              
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetRecordingFees_Cities_By_CountyID(int countyId)
        {
            try
            {
#if MISMO32
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();

                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetRecordingFees_Cities_By_CountyID(m_UserId, m_Password, countyId);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetDocumentTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetRecordingFees_Cities_By_CountyIDPost(int countyId)
        {
            try
            {
#if MISMO32
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetRecordingFees_Cities_By_CountyID(countyId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetUnderwritingDocumentTypesPost");
                if (CheckStatus(resp, "GetUnderwritingDocumentTypesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUnderwritingDocumentTypes failed: " + ex.ToString());
            }
            return null;
        }

        public AGENTNET_GET_DATA_RESPONSE GetRecordingFeesDocument()
        {
            try
            {
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();


                AgentNetGetDataResponse resp = null;
                resp = service.GetRecordingFeesDocument(m_UserId, m_Password);
                if (resp != null)
                    return resp.AGENTNET_GET_DATA_RESPONSE;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUWBRequestByTransactionId failed: " + ex.ToString());
            }
            return null;
        }
        public AGENTNET_GET_DATA_RESPONSE GetRecordingFeesDocumentPost()
        {
            try
            {
#if MISMO32
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetRecordingFeesDocument());

                MESSAGE resp = Invoke(message.MESSAGE, "GetRecordingFeesDocument");
                if (CheckStatus(resp, "GetRecordingFeesDocument"))
                {
                    return DEALResponse.GetAgentNetGetDataResponse(resp);
                }
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPolicySimulCountByState failed: " + ex.ToString());
            }
            return null;
        }




        public FOREIGN_OBJECT GetUWBDocumentByDocumentId(int DocumentId)
        {
            try
            {
#if MISMO32
                FOREIGN_OBJECT Document = new FOREIGN_OBJECT();
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetGetDataResponse resp = null;
                resp = service.GetUWBDocumentByDocumentId(m_UserId, m_Password, DocumentId.ToString());
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_DOCUMENT_OBJECTS == null || resp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_DOCUMENT_OBJECTS.FOREIGN_OBJECT.Length == 0)
                        return null;
                    Document = resp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_DOCUMENT_OBJECTS.FOREIGN_OBJECT[0];
                }
                return Document;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetDocumentTypes failed: " + ex.ToString());
            }
            return null;
        }

        public FOREIGN_OBJECT GetUWBDocumentByDocumentIdPost(int DocumentId)
        {
            try
            {
#if MISMO32
                FOREIGN_OBJECT Document = new FOREIGN_OBJECT();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetUWBDocumentByDocumentId(DocumentId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetUWBDocumentByDocumentIdPost");
                if (CheckStatus(resp, "GetUWBDocumentByDocumentIdPost"))
                {
                    AGENTNET_GET_DATA_RESPONSE getDataResp = DEALResponse.GetAgentNetGetDataResponse(resp);

                    if (getDataResp.AGENTNET_DOCUMENT_OBJECTS == null || getDataResp.AGENTNET_DOCUMENT_OBJECTS.FOREIGN_OBJECT.Length == 0)
                        return null;
                    Document = getDataResp.AGENTNET_DOCUMENT_OBJECTS.FOREIGN_OBJECT[0];                    
                }
                return Document;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUnderwritingDocumentTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetUnderwritingDocumentTypes()
        {
            try
            {
#if MISMO32
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();

                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetUnderwritingDocumentTypes(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetDocumentTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetUnderwritingDocumentTypesPost()
        {
            try
            {
#if MISMO32
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetUWBDocumentTypes());
                MESSAGE resp = Invoke(message.MESSAGE, "GetUnderwritingDocumentTypesPost");
                if (CheckStatus(resp, "GetUnderwritingDocumentTypesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUnderwritingDocumentTypes failed: " + ex.ToString());
            }
            return null;
        }

        public AGENTNET_GET_DATA_RESPONSE GetUWBRequestByTransactionId(int requestId)
        {
            try
            {
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();


                AgentNetGetDataResponse resp = null;
                resp = service.GetUWBRequestByTransactionId(m_UserId, m_Password, requestId);
                if (resp != null)
                    return resp.AGENTNET_GET_DATA_RESPONSE;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUWBRequestByTransactionId failed: " + ex.ToString());
            }
            return null;
        }
        public AGENTNET_GET_DATA_RESPONSE GetUWBRequestByTransactionIdPost(int requestId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetUWBRequestByTransactionId(requestId));

                MESSAGE resp = Invoke(message.MESSAGE, "GetUWBRequestByTransactionId");
                if (CheckStatus(resp, "GetUWBRequestByTransactionId"))
                {
                    return DEALResponse.GetAgentNetGetDataResponse(resp);
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPolicySimulCountByState failed: " + ex.ToString());
            }
            return null;
        }
  
        public List<AGENTNET_TYPE_DATA> GetPropertyTypes()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetPropertyTypes(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPropertyTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetPropertyTypesPost()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetPropertyTypes());
                MESSAGE resp = Invoke(message.MESSAGE, "GetPropertyTypesPost");
                if (CheckStatus(resp, "GetPropertyTypesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetRecordingDocumentNames()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();


                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetRecordingDocumentNames(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPropertyTypes failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetRecordingDocumentNamesPost()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetRecordingDocumentNames());
                MESSAGE resp = Invoke(message.MESSAGE, "GetRecordingDocumentNamesPost");
                if (CheckStatus(resp, "GetRecordingDocumentNamesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetRecordingDocumentNamesPost failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetGenericServiceTypes()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetGenericServiceTypes(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPropertyTypes failed: " + ex.ToString());
            }
            return null;
        }
        public List<AGENTNET_TYPE_DATA> GetGenericServiceTypesPost()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGenericService());
                MESSAGE resp = Invoke(message.MESSAGE, "GetGenericServiceTypes");
                if (CheckStatus(resp, "GetGenericServiceTypes"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetGenericServiceTypes failed: " + ex.ToString());
            }
            return null;
        }

        public AGENTNET_GET_DATA_RESPONSE GetPolicySimulCountByState(string stateCode, string MinEffDate, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetGetDataResponse resp = null;
                resp = service.GetPolicySimulCountByState(m_UserId, m_Password, stateCode, MinEffDate, officeId);
                if(resp != null)
                    return resp.AGENTNET_GET_DATA_RESPONSE;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketTypes failed: " + ex.ToString());
            }
            return null;
        }
        public AGENTNET_GET_DATA_RESPONSE GetPolicySimulCountByStatePost(string stateCode, string MinEffDate, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetPolicySimulCountByState(stateCode, MinEffDate));
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetPolicySimulCountByState");
                if (CheckStatus(resp, "GetPolicySimulCountByState"))
                {
                    return DEALResponse.GetAgentNetGetDataResponse(resp);
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPolicySimulCountByState failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> ValidateLogin()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.ValidateLogin(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if(resp.AGENTNET_TYPE_DATA != null)
                        types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "ValidateLogin failed: " + ex.ToString());
            }
            return null;

        }
        public List<AGENTNET_TYPE_DATA> ValidateLoginPost()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();

                MessageHelper message = new MessageHelper(dealReq.ValidateLogin(m_UserId, m_Password));
                MESSAGE resp = Invoke(message.MESSAGE, "ValidateLoginPost");
                if (CheckStatus(resp, "ValidateLoginPost"))
                {
                    types.AddRange(DEALResponse.GetAgentNetTypeDatas(resp));
                    return types;
                }
                if (types != null)
                {
                    return types;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "ValidateLoginPost failed: " + ex.ToString());
            }
            return null;
        }
        public STATUS ChangePassword(string newPassword)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetStatusResponse resp = null;
                resp = service.ChangePassword(m_UserId, m_Password, newPassword);
                if(resp!=null)
                    return resp.STATUS;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "ChangePassword failed: " + ex.ToString());
            }
            return null;
        }
        public STATUS ChangePasswordPost(string newPassword)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();

                MessageHelper message = new MessageHelper(dealReq.ChangePassword(m_UserId, m_Password, newPassword));
                MESSAGE resp = Invoke(message.MESSAGE, "ChangePasswordPost");
                if (CheckStatus(resp, "ChangePasswordPost"))
                {
                    return m_Status[0];
                }
                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "ChangePasswordPost failed: " + ex.ToString());
            }
            return null;
        }

#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetProductTypes(String StateCode, string County, String UnderwriterCode, String PropertyType)
        {
            try
            {
                AGENTNET_TYPE_DATAS_MULTI types = null;
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetMultiTypeDatasResponse resp = null;
                resp = service.GetProductTypes(m_UserId, m_Password, DEALRequest.ClientSystemName, StateCode, County, UnderwriterCode, PropertyType);
                if (resp != null)
                {
                    types = resp.AGENTNET_TYPE_DATAS_MULTI;
                }
#endif
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetTitleProducts failed: " + ex.ToString());
            }
            return null;
        }

        public AGENTNET_TYPE_DATAS_MULTI GetProductTypesPost(String StateCode, string county, String UnderwriterCode, String PropertyType)
        {
            try
            {
                AGENTNET_TYPE_DATAS_MULTI types = null;
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetProductTypes(DEALRequest.ClientSystemName, StateCode, county, UnderwriterCode, PropertyType));
                MESSAGE resp = Invoke(message.MESSAGE, "GetProductTypesPost");
                if (CheckStatus(resp, "GetProductTypesPost"))
                {
                    types = DEALResponse.GetAgentNetTypeDatasMulti(resp);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetProductTypesPost failed: " + ex.ToString());
            }
            return null;
        }
#endif
        /// <summary>
        /// GetCPLTypes method Returns a list of CPL Types. OfficeId is an optional parameter.
        /// AgentNet CPLId from this list is required when requesting a CPL Service.
        /// </summary>
        /// <param name="stateCode"></param>
        /// <param name="underwriterCode"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetCPLTypes(string stateCode, string underwriterCode, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                string[] optionalParams = new string[1];
                if ((!string.IsNullOrEmpty(officeId)) && officeId.Length > 0)
                {
                    optionalParams[0] = officeId;
                }
                resp = service.GetCPLTypes(m_UserId, m_Password, stateCode, underwriterCode, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCPLTypes failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// OfficeId is an optional parameter.Returns a list of CPL Types.
        /// AgentNet CPLId from this list is required when requesting a CPL Service.
        /// </summary>
        /// <param name="stateCode"></param>
        /// <param name="underwriterCode"></param>
        /// <param name="officeId">officeId</param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetCPLTypesPost(string stateCode, string underwriterCode, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetCPLTypes(stateCode, underwriterCode));
                if ((!string.IsNullOrEmpty(officeId) && officeId.Length > 0))
                    message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCPLTypesPost");
                if (CheckStatus(resp, "GetCPLTypesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCPLTypesPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns a list of required fields to complete a Jacket Service. 
        /// </summary>
        /// <param name="jacketTypeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underwriterCode"></param>
        /// <returns></returns>
        public ProductServiceFieldItemsResponse GetJacketTypeFields(string jacketTypeId, string stateCode, string underwriterCode, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
				//TFS 324997 - pass officeid as optional parameter
                string[] optionalParams = new string[1];
                if ((!string.IsNullOrEmpty(officeId)) && officeId.Length > 0)
                {
                    optionalParams[0] = officeId;
                }
                ProductServiceFieldItemsResponse jacketEndorsementsResponse = service.GetJacketTypeFields(m_UserId, m_Password, jacketTypeId, stateCode, underwriterCode, optionalParams);
                if (jacketEndorsementsResponse != null)
                {
                    m_Status.Add(jacketEndorsementsResponse.STATUS);
                }

                return jacketEndorsementsResponse;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketTypeFields failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns a list of required fields to complete a Jacket Service. 
        /// </summary>
        /// <param name="jacketTypeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underwriterCode"></param>
        /// <returns></returns>
        public ProductServiceFieldItemsResponse GetJacketTypeFieldsPost(string jacketTypeId, string stateCode, string underwriterCode, string officeId=null)
        {
            try
            {
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketTypeFields(jacketTypeId, stateCode, underwriterCode,officeId));
                if ((!string.IsNullOrEmpty(officeId) && officeId.Length > 0))
                    message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetJacketTypeFieldsPost");
                if (CheckStatus(resp, "GetJacketTypeFieldsPost"))
                {
                    MessageHelper msg = new MessageHelper(resp);
                    ServiceHelper srv = new ServiceHelper(msg.DEAL.SERVICES.SERVICE[0]);
                    AGENTNET_PRODUCT_SERVICE_FIELDS fields = srv.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_PRODUCT_SERVICE_FIELDS;
                    AGENTNET_JACKET_ENDORSEMENTS endrs = srv.AGENTNET_PRODUCT_RESPONSE.AGENTNET_GET_DATA_RESPONSE.AGENTNET_JACKET_ENDORSEMENTS;
                    ProductServiceFieldItemsResponse newResp = new ProductServiceFieldItemsResponse();
                    newResp.AGENTNET_JACKET_ENDORSEMENT = endrs.AGENTNET_JACKET_ENDORSEMENT;
                    newResp.AGENTNET_PRODUCT_SERVICE_FIELD = fields.AGENTNET_PRODUCT_SERVICE_FIELD;
                    newResp.STATUS = msg.STATUSes[0];
                    return newResp;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketTypeFieldsPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns a list of Endorsements for the jacketTypeId,stateCode, underwriterCode.
        /// </summary>
        /// <param name="jacketTypeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underwriterCode"></param>
        /// <returns></returns>
        public List<AGENTNET_JACKET_ENDORSEMENT> GetJacketEndorsements(string jacketTypeId, string stateCode, string underwriterCode)
        {
            try
            {
                List<AGENTNET_JACKET_ENDORSEMENT> jacketEndorsements = new List<AGENTNET_JACKET_ENDORSEMENT>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                JacketEndorsementsResponse jacketEndorsementsResponse = service.GetJacketTypeEndorsements(m_UserId, m_Password, jacketTypeId, stateCode, underwriterCode);
                if (jacketEndorsementsResponse != null)
                {
                    m_Status.Add(jacketEndorsementsResponse.STATUS);
                    jacketEndorsements.AddRange(jacketEndorsementsResponse.AGENTNET_JACKET_ENDORSEMENT);
                }
                return jacketEndorsements;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketEndorsements failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns a list of Endorsements for the jacketTypeId,stateCode, underwriterCode.
        /// </summary>
        /// <param name="jacketTypeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underwriterCode"></param>
        /// <returns></returns>
        public List<AGENTNET_JACKET_ENDORSEMENT> GetJacketEndorsementsPost(string jacketTypeId, string stateCode, string underwriterCode)
        {
            try
            {
                List<AGENTNET_JACKET_ENDORSEMENT> types = new List<AGENTNET_JACKET_ENDORSEMENT>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketEndorsements(jacketTypeId,stateCode, underwriterCode));
                MESSAGE resp = Invoke(message.MESSAGE, "GetJacketEndorsementsPost");
                if (CheckStatus(resp, "GetJacketEndorsementsPost"))
                {
                    AGENTNET_JACKET_ENDORSEMENT[] list = DEALResponse.GetJacketEndorsements(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(DEALResponse.GetJacketEndorsements(resp));
                    return types;
                }
                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetJacketEndorsementsPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns a list of approved attorneys' for the firm based on the parameters supplied.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="propertyState"></param>
        /// <param name="attorneyName"></param>
        /// <param name="attorneycity"></param>
        /// <param name="attorneystate"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetApprovedAttorneyPost(string partyType, string propertyState, string attorneyName, string attorneycity, string attorneystate)
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[4];
                optionalParams[0] = propertyState;
                optionalParams[1] = attorneyName;
                optionalParams[2] = attorneycity;
                optionalParams[3] = attorneystate;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(partyType, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetDefaultApprovedAttorneyPost");
                if (CheckStatus(resp, "GetDefaultApprovedAttorneyPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                    return partyCollection;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetApprovedAttorneyPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns a list of approved attorneys' for the firm based on the parameters supplied.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="propertyState"></param>
        /// <param name="attorneyName"></param>
        /// <param name="attorneycity"></param>
        /// <param name="attorneystate"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetApprovedAttorney(string partyType, string propertyState, string attorneyName, string attorneycity, string attorneystate)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[4];
                optionalParams[0] = propertyState;
                optionalParams[1] = attorneyName;
                optionalParams[2] = attorneycity;
                optionalParams[3] = attorneystate;
                resp = service.GetParties(m_UserId, m_Password, partyType, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetApprovedAttorney) failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_PARTY> GetSecondParty(string partyType, string secondPartyRole, string propertyOfficeId, string propertyStateCode, string officeName, string city, string county, string zip, string officStateCode, string licenseStateCode)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[9];
                optionalParams[0] = secondPartyRole;
                optionalParams[1] = propertyOfficeId;
                optionalParams[2] = propertyStateCode;
                optionalParams[3] = officeName;
                optionalParams[4] = city;
                optionalParams[5] = county;
                optionalParams[6] = zip;
                optionalParams[7] = officStateCode;
                optionalParams[8] = licenseStateCode;
               
                resp = service.GetParties(m_UserId, m_Password, partyType, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetApprovedAttorney) failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_PARTY> GetSecondPartyPost(string partyType, string secondPartyRole, string propertyOfficeId, string propertyStateCode, string officeName, string city, string county, string zip, string officStateCode, string licenseStateCode)
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[9];
                optionalParams[0] = secondPartyRole;
                optionalParams[1] = propertyOfficeId;
                optionalParams[2] = propertyStateCode;
                optionalParams[3] = officeName;
                optionalParams[4] = city;
                optionalParams[5] = county;
                optionalParams[6] = zip;
                optionalParams[7] = officStateCode;
                optionalParams[8] = licenseStateCode;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(partyType, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetSecondPartyPost");
                if (CheckStatus(resp, "GetSecondPartyPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                    return partyCollection;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSecondPartyPost failed: " + ex.ToString());
            }
            return null;
        }
        
        public List<AGENTNET_TYPE_DATA> GetSecondPartyState(string stateCode, string secondPartyRole)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
               
                resp = service.GetSecondPartyOfficeLicenseStateByPropertyStateCode(m_UserId, m_Password, stateCode, secondPartyRole);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSecondPartyState failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_TYPE_DATA> GetSecondPartyStatePost(string stateCode, string secondPartyRole)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                //dealReq.CreateSubmittingParty(m_UserId, m_Password);
                MessageHelper message = new MessageHelper(dealReq.CreateGetSecondPartyState(stateCode, secondPartyRole));
                MESSAGE resp = Invoke(message.MESSAGE, "GetSecondPartyStatePost");
                if (CheckStatus(resp, "GetSecondPartyStatePost"))
                {
                    types.AddRange(DEALResponse.GetAgentNetTypeDatas(resp));
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSecondPartyStatePost failed: " + ex.ToString());
            }
            return null;
        }
        
        /// <summary>
        /// Get default approved attorney. officeId is an optional parameter.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="propertyState"></param>
        /// <param name="attorneyName"></param>
        /// <param name="attorneycity"></param>
        /// <param name="attorneystate"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetDefaultApprovedAttorney(string partyType, string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[1];
                optionalParams[0] = officeId;
                resp = service.GetParties(m_UserId, m_Password, partyType, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetDefaultApprovedAttorney) failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional parameter.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetDefaultApprovedAttorneyPost(string partyType, string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[1];
                optionalParams[0] = officeId;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(partyType, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetDefaultApprovedAttorneyPost");
                if (CheckStatus(resp, "GetDefaultApprovedAttorneyPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                    return partyCollection;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetDefaultApprovedAttorneyPost failed: " + ex.ToString());
            }
            return null;
        }

      
        /// <summary>
        /// officeId is an optional parameter. 
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetMyClosingAttorney(string partyType, string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[1];
                optionalParams[0] = officeId;
                resp = service.GetParties(m_UserId, m_Password, partyType, optionalParams);

                if(resp!=null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }

                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetMyClosingAttorney) failed: " + ex.ToString());
            }
            return null;
        }



        /// <summary>
        /// officeId is an optional parameter.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetMyClosingAttorneyPost(string partyType, string officeId)
        {
            
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[1];
                optionalParams[0] = officeId;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(partyType, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetMyClosingAttorneyPost");
                if (CheckStatus(resp, "GetMyClosingAttorneyPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                }
                return partyCollection;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetMyClosingAttorneyPost failed: " + ex.ToString());
            }
            return null;
        }
        /// <summary>
        /// Returns list of firms for the logged in user. 
        /// HQ users will call this method to see the list of the firms they have the access to.
        /// </summary>
        /// <param name="partyType"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetFirms()
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                resp = service.GetParties(m_UserId, m_Password, AgentNetPartyTypeEnum.FIRM, null);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetFirm) failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns list of firms for the logged in user. 
        /// HQ users will call this method to see the list of the firms they have the access to.
        /// </summary>
        /// <param name="partyType"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetFirmsPost()
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(AgentNetPartyTypeEnum.FIRM));
                MESSAGE resp = Invoke(message.MESSAGE, "GetFirmPost");
                if (CheckStatus(resp, "GetFirmPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                   
                }
                return partyCollection;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFirmPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// firmId is an optional parameter and used for HQ user.
        /// For an HQ user, if the user is working in a Firm different the user’s default Firm, the FirmId has to be provided as the optional parameter. 
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="firmId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetOffices(string firmId)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[1];
                optionalParams[0] = firmId;
                resp = service.GetParties(m_UserId, m_Password, AgentNetPartyTypeEnum.OFFICE, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetDefaultApprovedAttorney) failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// firmId is an optional parameter and used for HQ user.
        /// For an HQ user, if the user is working in a Firm different the user’s default Firm, the FirmId has to be provided as the optional parameter. 
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="firmId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetOfficesPost(string firmId)
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[1];
                optionalParams[0] = firmId;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(AgentNetPartyTypeEnum.OFFICE, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetOfficePost");
                if (CheckStatus(resp, "GetOfficePost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                }
                return partyCollection;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetOfficePost failed: " + ex.ToString());
            }
            return null;
        }

       /// <summary>
        /// officeId is an optional parameter.
       /// </summary>
       /// <param name="partyType"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
       /// <returns></returns>
        public List<AGENTNET_PARTY> GetClosingAttorney(string partyType,string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[1];
                optionalParams[0] = officeId;

                resp = service.GetParties(m_UserId, m_Password, partyType, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetClosingAttorney) failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional parameter.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetClosingAttorneyPost(string partyType, string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[1];
                optionalParams[0] = officeId;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(partyType, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetClosingAttorneyPost");
                if (CheckStatus(resp, "GetClosingAttorneyPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                }
                return partyCollection;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetClosingAttorneyPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Lender is MyLender” has an optional parameter of Lender Name where, 
        /// if provided, the system will return lenders with lender name that start with the lender name parameter value.
        /// Also, “OfficeId” is an optional.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="lenderName">lenderName is an optional</param>
        /// <param name="officeId">officeId is an optional parameters</param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetMyLenders(string lenderName, string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                PartiesResponse resp = null;
                string[] optionalParams = new string[2];
                optionalParams[0] = lenderName;
                optionalParams[1] = officeId;

                resp = service.GetParties(m_UserId, m_Password, AgentNetPartyTypeEnum.MY_LENDER, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                        types.AddRange(resp.AGENTNET_PARTIES);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetParties(GetClosingAttorney) failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Lender is MyLender” has an optional parameter of Lender Name where, 
        /// if provided, the system will return lenders with lender name that start with the lender name parameter value.
        /// Also, “OfficeId” is an optional.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="lenderName"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public List<AGENTNET_PARTY> GetMyLendersPost(string lenderName, string officeId)
        {
            try
            {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[2];
                optionalParams[0] = lenderName;
                optionalParams[1] = officeId;

                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(AgentNetPartyTypeEnum.MY_LENDER, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetMyLendersPost");
                if (CheckStatus(resp, "GetMyLendersPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                }
                return partyCollection;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetMyLendersPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// firmlocationId,firmId are optonal parameters. firmId added for HQ users.
        /// </summary>
        /// <param name="firmLocationId">firmLocationId is an optional parameter</param>
        /// <param name="firmId">firmId is an optional prameter</param>
        /// <returns></returns>
        public List<AGENTNET_ACCOUNT> GetAccounts(string firmLocationId, string firmId)
        {
            try
            {
                List<AGENTNET_ACCOUNT> accounts = new List<AGENTNET_ACCOUNT>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AccountsResponse accountsResponse = service.GetAccounts(m_UserId, m_Password, firmLocationId, firmId);
                if (accountsResponse != null)
                {
                    m_Status.Add(accountsResponse.STATUS);
                    if (accountsResponse.AGENTNET_ACCOUNTS != null && accountsResponse.AGENTNET_ACCOUNTS.Length > 0)
                        accounts.AddRange(accountsResponse.AGENTNET_ACCOUNTS);
                }
                return accounts;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetAccounts failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// firmlocationId,firmId are optonal parameters. firmId added for HQ users.
        /// </summary>
        /// <param name="firmLocationId">firmLocationId is an optional parameter</param>
        /// <param name="firmId">firmId is an optional parameter</param>
        /// <returns></returns>
        public List<AGENTNET_ACCOUNT> GetAccountsPost(string firmLocationId, string firmId)
        {
            try
            {
                List<AGENTNET_ACCOUNT> accounts = new List<AGENTNET_ACCOUNT>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetAccount(firmLocationId, firmId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetAccountsPost");
                if (CheckStatus(resp, "GetAccountsPost"))
                {
                    AGENTNET_ACCOUNT[] list = DEALResponse.GetAccounts(resp);
                    if (list != null && list.Length > 0)
                        accounts.AddRange(list);                   
                }
                return accounts;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetAccountsPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional.This is only required if the File is not in the user’s default office
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsByFileNumber(string fileNumber, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedJackets(m_UserId, m_Password, fileNumber, officeId);

                if (message != null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }
                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsByFileNumber failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional.This is only required if the File is not in the user’s default office
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsByFileNumberPost(string fileNumber, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketsByFileNumber(fileNumber));
                message.AGENTNET_REQUEST.FileNumber = fileNumber;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedJacketsByFileNumberPost");
                if (CheckStatus(resp, "GetCreatedJacketsByFileNumberPost"))
                {
                    return resp;
                }               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsByFileNumberPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional/not required here as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsAndCPLsByFileId(string fileId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedJacketsAndCPLsByFileId(m_UserId, m_Password, fileId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }
                
                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsAndCPLsByFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional/not required here as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsAndCPLsByFileNumber(string fileNumber,string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedJacketsAndCPLsByFileNumber(m_UserId, m_Password, fileNumber, officeId);
                if (message != null)
                {
                    MessageHelper m = new MessageHelper(message);
                    m_Status.AddRange(m.STATUSes);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsAndCPLsByFileNumber failed: " + ex.ToString());
            }
            return null;
        }

        public String GetEndpointByService(string fileNumber, string fileId, string ServiceName)
        {
            try
            {
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                String Endpoint = String.Empty;
                AgentNetGetDataResponse getDataResp = service.GetEndpointByService(m_UserId, m_Password, fileNumber, fileId, ServiceName);
                if (getDataResp != null &&
                        getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES != null &&
                        getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null &&
                        getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
                    Endpoint = getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[0].Value;
                return Endpoint;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetEndpointByService failed: " + ex.ToString());
            }
            return null;
        }

        public String GetEndpointByServicePost(string fileNumber, string fileId, string serviceName)
        {
            try
            {
                String Endpoint = String.Empty;
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetEndpointByService(m_UserId, m_Password, fileNumber, fileId, serviceName));
                MESSAGE resp = Invoke(message.MESSAGE, "GetEndpointByService");
                if (CheckStatus(resp, "GetEndpointByService"))
                {
                    AGENTNET_GET_DATA_RESPONSE getDataResp = DEALResponse.GetAgentNetGetDataResponse(resp);
                    if (getDataResp != null && 
                        getDataResp.AGENTNET_NAME_VALUES != null && 
                        getDataResp.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null &&
                        getDataResp.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
                            Endpoint = getDataResp.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[0].Value;
                    return Endpoint;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetEndpointByService failed: " + ex.ToString());
            }
            return null;
        }

        public AGENTNET_NAME_VALUE[] GetTitleSearchOrderData(string FileId, string OrderId, string StateCode)
        {
            AGENTNET_NAME_VALUE[] orderData = new AGENTNET_NAME_VALUE[0];
            try
            {
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();

                AgentNetGetDataResponse getDataResp = service.GetTitleSearchOrderData(m_UserId, m_Password, FileId, OrderId, StateCode);
                if (getDataResp != null &&
                        getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES != null &&
                        getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null &&
                        getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
                    orderData = getDataResp.AGENTNET_GET_DATA_RESPONSE.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE; 
#endif
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetTitleSearchOrderData failed: " + ex.ToString());
            }
            return orderData;
        }

        public AGENTNET_NAME_VALUE[] GetTitleSearchOrderDataPost(string FileId, string OrderId, string StateCode)
        {
            try
            {
                String Endpoint = String.Empty;
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                AGENTNET_NAME_VALUE[] orderData = new AGENTNET_NAME_VALUE[0];
                MessageHelper message = new MessageHelper(dealReq.CreateGetTitleSearchOrderData(m_UserId, m_Password, FileId, OrderId, StateCode));
                MESSAGE resp = Invoke(message.MESSAGE, "GetTitleSearchOrderData");
                if (CheckStatus(resp, "GetTitleSearchOrderData"))
                {
                    AGENTNET_GET_DATA_RESPONSE getDataResp = DEALResponse.GetAgentNetGetDataResponse(resp);
                    if (getDataResp != null &&
                        getDataResp.AGENTNET_NAME_VALUES != null &&
                        getDataResp.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null &&
                        getDataResp.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
                        orderData = getDataResp.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE;
                    return orderData;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetTitleSearchOrderData failed: " + ex.ToString());
            }
            return null;
        }
        
        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional/not required here as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsAndCPLsByClientFileId(string clientFileId,string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedJacketsAndCPLsByClientFileId(m_UserId, m_Password, clientFileId, officeId);

                if (message != null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsAndCPLsByClientFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional/not required here as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsByFileId(string fileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedJacketsByFileId(m_UserId, m_Password, fileId, officeId);

                if (message != null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsByFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsByFileIdPost(string fileId, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketsByFileId(fileId));
                message.AGENTNET_REQUEST.FileId = fileId;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedJacketsByFileIdPost");
                if (CheckStatus(resp, "GetCreatedJacketsByFileIdPost"))
                {
                    return resp;
                }               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }


        /// <summary>
        /// officeId is an optional as fileId is unique identifier here.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsAndCPLsByFileIdPost(string fileId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketsAndCplsByFileId(fileId));
                message.AGENTNET_REQUEST.FileNumber = fileId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedJacketsAndCPLsByFileIdPost");
                if (CheckStatus(resp, "GetCreatedJacketsAndCPLsByFileIdPost"))
                {
                    return resp;
                }               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsAndCPLsByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }


        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsAndCPLsByFileNumberPost(string fileNumber,string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketsAndCplsByFileNumber(fileNumber));
                message.AGENTNET_REQUEST.FileNumber = fileNumber;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedJacketsAndCPLsByFileNumberPost");
                if (CheckStatus(resp, "GetCreatedJacketsAndCPLsByFileNumberPost"))
                {
                    return resp;
                }
               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsAndCPLsByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }


        /// <summary>
        /// officeId is an optional as fileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsAndCPLsByClientFileIdPost(string clientFileId, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketsAndCplsByClientFileId(clientFileId));
                message.AGENTNET_REQUEST.ClientFileId = clientFileId;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedJacketsAndCPLsByClientFileIdPost");
                if (CheckStatus(resp, "GetCreatedJacketsAndCPLsByClientFileIdPost"))
                {
                    return resp;
                }
                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsAndCPLsByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional.This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId">officeId is an optional parameter.</param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsByClientFileId(string clientFileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedJacketsByClientFileId(m_UserId, m_Password, clientFileId, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsByClientFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional.This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedJacketsByClientFileIdPost(string clientFileId, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetJacketsByClientFileId(clientFileId));
                message.AGENTNET_REQUEST.ClientFileId = clientFileId;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedJacketsByClientFileIdPost");
                if (CheckStatus(resp, "GetCreatedJacketsByClientFileIdPost"))
                {
                    return resp;
                }
              
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedJacketsByClientFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional.This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
        /// <returns></returns>
        public MESSAGE GetCreatedCPLsByFileNumber(string fileNumber, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedCPLs(m_UserId, m_Password, fileNumber, officeId);

                if (message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedCPLsByFileNumber failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional.This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedCPLsByFileNumberPost(string fileNumber, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetCPLsByFileNumber(fileNumber));
                message.AGENTNET_REQUEST.FileNumber = fileNumber;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedCPLsByFileNumberPost");
                if (CheckStatus(resp, "GetCreatedCPLsByFileNumberPost"))
                {
                    return resp;
                }               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedCPLsByFileNumberPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as FileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetCreatedCPLsByFileId(string fileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedCPLsByFileId(m_UserId, m_Password, fileId, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.Add(resp.STATUSes[0]);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedCPLsByFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as FileId is unique identifier.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedCPLsByFileIdPost(string fileId, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetCPLsByFileId(fileId));
                message.AGENTNET_REQUEST.FileId = fileId;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedCPLsByFileIdPost");
                if (CheckStatus(resp, "GetCreatedCPLsByFileIdPost"))
                {
                    return resp;
                }
               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedCPLsByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional parameter. this is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
        /// <returns></returns>
        public MESSAGE GetCreatedCPLsByClientFileId(string clientFileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetCreatedCPLsByClientFileId(m_UserId, m_Password, clientFileId, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }

                return message;

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedCPLsByClientFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional parameter. this is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetCreatedCPLsByClientFileIdPost(string clientFileId, string officeId)
        {
            try
            {
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetCPLsByClientFileId(clientFileId));
                message.AGENTNET_REQUEST.ClientFileId = clientFileId;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetCreatedCPLsByClientFileIdPost");
                if (CheckStatus(resp, "GetCreatedCPLsByClientFileIdPost"))
                {
                    return resp;
                }
                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCreatedCPLsByClientFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// firmId is an optional paramenter here.
        /// </summary>
        /// <param name="firmId">firmId is an optional paramenter here.used for HQ.</param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetUnderwriters(string firmId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                string[] optionalParams = new string[1];
                optionalParams[0] = firmId;
                resp = service.GetUnderwriters(m_UserId, m_Password, optionalParams);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_TYPE_DATA != null && resp.AGENTNET_TYPE_DATA.Length > 0)
                        types.AddRange(resp.AGENTNET_TYPE_DATA);
                    
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUnderwriters failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// FirmId is an optional. if firmId not supplied, it returns list of First American Underwriters for the User Id Firm. 
        /// </summary>
        /// <param name="firmId">optional parameter</param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetUnderwritersPost(string firmId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                //dealReq.CreateSubmittingParty(m_UserId, m_Password);
                MessageHelper message = new MessageHelper(dealReq.CreateGetUnderwriters(firmId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetUnderwritersPost");
                if (CheckStatus(resp, "GetUnderwritersPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetUnderwritersPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns previous Response Data if found for the “Client Request Id”
        /// </summary>
        /// <param name="clientRequestId"></param>
        /// <returns></returns>
        public MESSAGE GetLastResponse(string clientRequestId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetLastResponse(m_UserId, m_Password, clientRequestId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetLastResponse failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns previous Response Data if found for the “Client Request Id”
        /// </summary>
        /// <param name="clientRequestId"></param>
        /// <returns></returns>
        public MESSAGE GetLastResponsePost(string clientRequestId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetLastResponse(clientRequestId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetLastResponsePost");
                if (CheckStatus(resp, "GetLastResponsePost"))
                    return resp;
                return resp;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetLastResponsePost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId">Office Id is an optional</param>
        public MESSAGE GetFileStatusByFileNumber(string fileNumber, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetFileStatusByFileNumber(m_UserId, m_Password, fileNumber, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFileStatusByFileNumber failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetFileStatusByFileNumberPost(string fileNumber, string officeId)
        {
            try
            {
                string[] parm = new string[2];
                parm[0] = fileNumber;
                parm[1] = officeId;
                

                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateFileStatus(parm));
                message.AGENTNET_REQUEST.FileNumber = fileNumber;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetFileStatusByFileNumberPost");
                if (CheckStatus(resp, "GetFileStatusByFileNumberPost"))
                    return resp;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFileStatusByFileNumberPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional paramter</param>
        public MESSAGE GetFileStatusByFileID(string fileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetFileStatusByFileID(m_UserId, m_Password, fileId, officeId);
                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFileStatusByFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetFileStatusByFileIdPost(string fileId, string officeId)
        {
            try
            {
                string[] parm = new string[2];
                parm[0] = fileId;
                parm[1] = officeId;

                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                MessageHelper message = new MessageHelper(dealReq.CreateFileStatus(parm));
                message.AGENTNET_REQUEST.FileId = fileId;
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetFileStatusByClientFileIdPost");
                if (CheckStatus(resp, "GetFileStatusByClientFileIdPost"))
                    return resp;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFileStatusByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetFileStatusByClientFileIdPost(string clientFileId, string officeId)
        {
            try
            {
                string[] parm = new string[2];
                parm[0] = clientFileId;
                parm[1] = officeId;
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                MessageHelper message = new MessageHelper(dealReq.CreateFileStatus(parm));
                message.AGENTNET_REQUEST.ClientFileId = clientFileId; 
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetFileStatusByClientFileIdPost");
                if (CheckStatus(resp, "GetFileStatusByClientFileIdPost"))
                    return resp;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFileStatusByClientFileIdPost failed: " + ex.ToString());
            }
            return null;
        }
       
        /// <summary>
        /// officeId is an optional This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
        /// <returns></returns>
        public MESSAGE GetFileStatusByClientFileID(string clientFileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetFileStatusByClientFileID(m_UserId, m_Password, clientFileId, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes.ToArray());
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetFileStatusByClientFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId">officeId is an optional parameter</param>
        /// <returns></returns>
        public MESSAGE GetPreviousFileDataByFileNumber(string fileNumber,string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetPreviousFileDataByFileNumber(m_UserId, m_Password, fileNumber, officeId);

                if (message != null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }
                
                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPreviousFileDataByFileNumber failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office.
        /// </summary>
        /// <param name="fileNumber"></param>
        /// <param name="officeId">optional as FileId is unique.</param>
        /// <returns></returns>
        public MESSAGE GetPreviousFileDataByFileNumberPost(string fileNumber, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetPreviousFileData(fileNumber, officeId);
                MESSAGE resp = Invoke(message, "GetPreviousFileDataByFileNumberPost");
                if (CheckStatus(resp, "GetPreviousFileDataByFileNumberPost"))
                    return resp;               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPreviousFileDataByFileNumberPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as FileId is unique. 
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetPreviousFileDataByFileID(string fileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetPreviousFileDataByFileID(m_UserId, m_Password, fileId, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }

                return message;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPreviousFileDataByFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional as FileId is unique
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="officeId">officeId is an optional as FileId is unique</param>
        /// <returns></returns>
        public MESSAGE GetPreviousFileDataByFileIdPost(string fileId, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetPreviousFileData(fileId, officeId);
                MESSAGE resp = Invoke(message, "GetPreviousFileDataByFileIdPost");
                if (CheckStatus(resp, "GetPreviousFileDataByFileIdPost"))
                    return resp;                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPreviousFileDataByFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office. 
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetPreviousFileDataByClientFileID(string clientFileId, string officeId)
        {
            try
            {
#if MISMO32
                AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                MESSAGE message = service.GetPreviousFileDataByClientFileID(m_UserId, m_Password, clientFileId, officeId);

                if(message!=null)
                {
                    MessageHelper resp = new MessageHelper(message);
                    m_Status.AddRange(resp.STATUSes);
                }

                return message;

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPreviousFileDataByClientFileId failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// officeId is an optional. This is only required if the File is not in the user’s default office. 
        /// </summary>
        /// <param name="clientFileId"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public MESSAGE GetPreviousFileDataByClientFileIdPost(string clientFileId, string officeId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetPreviousFileData(clientFileId, officeId);
                MESSAGE resp = Invoke(message, "GetPreviousFileDataByClientFileIdPost");
                if (CheckStatus(resp, "GetPreviousFileDataByClientFileIdPost"))
                    return resp;               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetPreviousFileDataByClientFileIdPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns list of counties for the supplied state code
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetCounties(string stateCode)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetCounties(m_UserId, m_Password, stateCode);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_TYPE_DATA != null && resp.AGENTNET_TYPE_DATA.Length > 0)
                        types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCounties failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns list of counties for the supplied state code
        /// </summary>
        /// <param name="stateCode"></param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetCountiesPost(string stateCode)
        { 
            try
             {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetCounties(stateCode);
                MESSAGE resp = Invoke(message, "GetCountiesPost");
                if (CheckStatus(resp, "GetCountiesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
               
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCountiesPost failed: " + ex.ToString());
            }
            return null;
        }


#if MISMO32
        /// <summary>
     /// 
     /// </summary>
     /// <param name="messageType"></param>
     /// <returns></returns>

        public AGENTNET_TYPE_DATA GetSpecialMessage(string messageType)
        {
            try
            {

                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetSpecialMessageResponse resp = null;

                resp = service.GetSpecialMessage(m_UserId, m_Password, messageType);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    return resp.AGENTNET_TYPE_DATA;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSpecialMessage failed: " + ex.ToString());
            }
            return null;
        }


        /// <summary>
        /// officeId is an optional parameter.
        /// </summary>
        /// <param name="partyType"></param>
        /// <param name="officeId"></param>
        /// <returns></returns>
        public AGENTNET_TYPE_DATA GetSpecialMessagePost(string messageType)
        {
            try
            {
                AGENTNET_TYPE_DATA specialMessage = new AGENTNET_TYPE_DATA();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                MessageHelper message = new MessageHelper(dealReq.CreateGetSpecialMessage(messageType));
                MESSAGE resp = Invoke(message.MESSAGE, "GetSpecialMessagePost");
                if (CheckStatus(resp, "GetSpecialMessagePost"))
                {
                    specialMessage = DEALResponse.GetSpecialMessage(resp);
                    return specialMessage;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSpecialMessagePost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

#if MISMO32
        public AGENTNET_SERVICE_ORDER_GROUP GetServiceOrderDisclaimer(string messageType, string ProductId, string ProductName, string FileId = null, string OrderNumber = null, bool IsRequestUpdate = false)
        {
            try
            {
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetServiceOrderDisclaimerResponse resp = null;

                resp = service.GetServiceOrderDisclaimer(m_UserId, m_Password, messageType, ProductId, ProductName, FileId, OrderNumber, IsRequestUpdate.ToString());
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    return resp.AGENTNET_SERVICE_ORDER_GROUPS.Length == 0 ? null : resp.AGENTNET_SERVICE_ORDER_GROUPS[0];
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSpecialMessage failed: " + ex.ToString());
            }
            return null;
        }

        public AGENTNET_SERVICE_ORDER_GROUP GetServiceOrderDisclaimerPost(string messageType, string ProductId, string ProductName, string FileId = null, string OrderNumber = null, bool IsRequestUpdate = false)
        {
            try
            {
                AGENTNET_SERVICE_ORDER_GROUP[] specialMessage = new AGENTNET_SERVICE_ORDER_GROUP[0];
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetServiceOrderDisclaimer(messageType, ProductId, ProductName, FileId, OrderNumber, IsRequestUpdate));
                MESSAGE resp = Invoke(message.MESSAGE, "GetServiceOrderDisclaimerPost");
                if (CheckStatus(resp, "GetServiceOrderDisclaimerPost"))
                {
                    specialMessage = DEALResponse.GetServiceOrderDisclaimer(resp);
                    return specialMessage.Length == 0 ? null : specialMessage[0];
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetServiceOrderDisclaimerPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// ValidateCounty being called to validate county for the supplied state code and county name.
        /// </summary>
        /// <param name="stateCode"></param>
        /// <param name="countyName"></param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> ValidateCounty(string stateCode, string countyName)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.ValidateCounty(m_UserId, m_Password, stateCode, countyName);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                }
                if (resp.AGENTNET_TYPE_DATA != null && resp.AGENTNET_TYPE_DATA.Length > 0)
                    types.AddRange(resp.AGENTNET_TYPE_DATA);
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "ValidateCounty failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// ValidateCounty being called to validate county for the supplied state code and county name.
        /// </summary>
        /// <param name="stateCode"></param>
        /// <param name="countyName"></param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> ValidateCountyPost(string stateCode, string countyName)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                                
                MESSAGE message = null;
                message = dealReq.ValidateCounty(stateCode, countyName);
                MESSAGE resp = Invoke(message, "ValidateCountyPost");
                if (CheckStatus(resp, "ValidateCountyPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }              
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "ValidateCountyPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// GetOverrideReasons returns override reasons. 
        /// </summary>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetOverrideReasons()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetOverrideReasons(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_TYPE_DATA != null && resp.AGENTNET_TYPE_DATA.Length > 0)
                        types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetOverrideReasons failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// GetOverrideReasons returns override reasons. 
        /// </summary>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetOverrideReasonsPost()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateOverrideReasons();
                MESSAGE resp = Invoke(message, "GetOverrideReasonsPost");
                if (CheckStatus(resp, "GetOverrideReasonsPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
              
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetOverrideReasonsPost failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// Returns the list of rate types for the product supplied. OfficeId and  agentNetProductServiceId are optional parameters.
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="isExtendedCoverage"></param>
        /// <param name="vendorName"></param>
        /// <param name="officeId"></param>
        /// <param name="agentNetProductServiceId"></param>
        /// <returns></returns>
        private static Dictionary<string, AGENTNET_GET_DATA_RESPONSE> sCashedRateTypes = new Dictionary<string, AGENTNET_GET_DATA_RESPONSE>();
        public AGENTNET_GET_DATA_RESPONSE GetRateTypes(string productId, string stateCode, string underWriterCode, string effectiveDate, bool isExtendedCoverage, string vendorName, string officeId, string agentNetProductServiceId, string County, string accountNumuber, string businessSegment)
        {
            try
            {
                string casheKey = productId + "/" + stateCode + "/" + underWriterCode + "/" + effectiveDate + "/" + isExtendedCoverage.ToString() + "/" + vendorName + "/" + officeId + "/" + agentNetProductServiceId + "/" + County + "/" + accountNumuber + "/" + businessSegment;
                if (sCashedRateTypes.ContainsKey(casheKey))
                    return sCashedRateTypes[casheKey];

                m_Status = new List<STATUS>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif                
                AgentNetGetDataResponse response = null;

                string[] optionalParams = new string[2];
                optionalParams[0] = officeId;
                optionalParams[1] = agentNetProductServiceId;

                response = service.GetRateTypes(m_UserId, m_Password, productId, stateCode, underWriterCode, effectiveDate, isExtendedCoverage, vendorName, County, accountNumuber, businessSegment, optionalParams);
                if (response != null)
                {
                    m_Status.Add(response.STATUS);
                    sCashedRateTypes.Add(casheKey, response.AGENTNET_GET_DATA_RESPONSE);
                    return response.AGENTNET_GET_DATA_RESPONSE;
                }                                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetRateTypes failed: " + ex.ToString());
            }
            return null;
        }


        /// <summary>
        /// Returns prodocuts and property types along with email addresses (user preference email address.)
        /// </summary>
        /// <param name="officeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="transactionType"></param>
        /// <param name="businessSegment"></param>
        /// <param name="county"></param>
        /// <param name="zip"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetBOProductsAndPropertyTypes(string officeId, string stateCode, string underWriterCode, string transactionType, string businessSegment, string county, string zip)
        {
            try
            {
                m_Status = new List<STATUS>();

                AGENTNET_TYPE_DATAS_MULTI response = null;
                string[] optionalParams = new string[7];//optional parameters are optional for future release.
                optionalParams[0] = officeId;
                optionalParams[1] = stateCode;
                optionalParams[2] = underWriterCode;
                optionalParams[3] = transactionType;
                optionalParams[4] = businessSegment;
                optionalParams[5] = county;
                optionalParams[6] = zip;

                response = GetMultiTypeDatas(AgentNetMultiDatasTypeEnum.BOPS_PRODUCTS_AND_PROPERTYTYPES, optionalParams);

                if (response != null)
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOProductsAndPropertyTypes failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif
        /// <summary>
        /// Returns prodocuts and property types along with email addresses for https post calls types. 
        /// </summary>
        /// <param name="officeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="transactionType"></param>
        /// <param name="businessSegment"></param>
        /// <param name="county"></param>
        /// <param name="zip"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetBOProductsAndPropertyTypesPost(string officeId, string stateCode, string underWriterCode, string transactionType, string businessSegment, string county, string zip)
        {
            try
            {
                m_Status = new List<STATUS>();

                AGENTNET_TYPE_DATAS_MULTI response = null;
                string[] optionalParams = new string[7];//optional parameters are optional for future release.

                optionalParams[0] = officeId;
                optionalParams[1] = stateCode;
                optionalParams[2] = underWriterCode;
                optionalParams[3] = transactionType;
                optionalParams[4] = businessSegment;
                optionalParams[5] = county;
                optionalParams[6] = zip;

                response = GetMultiTypeDatasPost(AgentNetMultiDatasTypeEnum.BOPS_PRODUCTS_AND_PROPERTYTYPES, optionalParams);

                if (response != null)
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOProductsAndPropertyTypes failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns Purpose of Transaction and County based on state
        /// </summary>
        /// <param name="StateCode"></param>
        
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetRecordingFees_County(string stateCode)
        {
            try
            {
                m_Status = new List<STATUS>();

                AGENTNET_TYPE_DATAS_MULTI response = null;
                string[] optionalParams = new string[1];//optional parameters are optional for future release.
                optionalParams[0] = stateCode;


                response = GetMultiTypeDatas(AgentNetMultiDatasTypeEnum.GET_RECORDING_FEES_COUNTY, optionalParams);

                if (response != null)
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetRecordingFees_POT_County failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns Purpose of Transaction and County based on state
        /// </summary>
        /// <param name="StateCode"></param>

        /// <returns></returns>
#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetRecordingFees_CountyPost( string stateCode)
        {
            try
            {
                m_Status = new List<STATUS>();

                AGENTNET_TYPE_DATAS_MULTI response = null;
                string[] optionalParams = new string[1];//optional parameters are optional for future release.

              
                optionalParams[0] = stateCode;


                response = GetMultiTypeDatasPost(AgentNetMultiDatasTypeEnum.GET_RECORDING_FEES_COUNTY, optionalParams);

                if (response != null)
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetRecordingFees_POT_CountyPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns transactions and businesssegments for the selected office.
        /// </summary>
        /// <param name="officeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="county"></param>
        /// <param name="zip"></param>
        /// <returns></returns>
#if MISMO32
        public AgentNetMultiTypeDatasResponse GetTransactionAndBusinessSegTypes(string officeId, string stateCode, string underWriterCode, string county, string zip, string fileId = "")
        {
            try
            {
                m_Status = new List<STATUS>();

                AgentNetMultiTypeDatasResponse response = null;
                string[] optionalParams = new string[6];//optional parameters are optional for future release.
                optionalParams[0] = officeId;
                optionalParams[1] = stateCode;
                optionalParams[2] = underWriterCode;
                optionalParams[3] = county;
                optionalParams[4] = zip;
                optionalParams[5] = fileId;

                response = new AgentNetMultiTypeDatasResponse();
                response.AGENTNET_TYPE_DATAS_MULTI = GetMultiTypeDatas(AgentNetMultiDatasTypeEnum.BOPS_TRANS_AND_BUS_SEGMENTS, optionalParams);
                if (m_Status.Count > 0)
                    response.STATUS = m_Status[0];
                if (response != null)
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetTransactionAndBusinessSegTypes failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif
       
        /// <summary>
        /// Returns transactions and businesssegments for the selected office.
        /// </summary>
        /// <param name="officeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="county"></param>
        /// <param name="zip"></param>
        /// <returns></returns>
#if MISMO32
        public AgentNetMultiTypeDatasResponse GetTransactionAndBusinessSegTypesPost(string officeId, string stateCode, string underWriterCode, string county, string zip, string fileId = "")
        {
            try
            {
                m_Status = new List<STATUS>();

                AgentNetMultiTypeDatasResponse response = null;
                string[] optionalParams = new string[6];//optional parameters are optional for future release.

                optionalParams[0] = officeId;
                optionalParams[1] = stateCode;
                optionalParams[2] = underWriterCode;
                optionalParams[3] = county;
                optionalParams[4] = zip;
                optionalParams[5] = fileId;

                response = new AgentNetMultiTypeDatasResponse();
                response.AGENTNET_TYPE_DATAS_MULTI = GetMultiTypeDatasPost(AgentNetMultiDatasTypeEnum.BOPS_TRANS_AND_BUS_SEGMENTS.ToString(), optionalParams);
                if (m_Status.Count > 0)
                    response.STATUS = m_Status[0];
                if (response != null)
                {
                    return response;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetTransactionAndBusinessSegTypesPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

#if MISMO32
        public AGENTNET_GET_DATA_RESPONSE GetServiceOrderFields(string officeId, string stateCode, string underWriterCode, string county, string zip, string fileId = "")
        {
            try
            {
                string[] optionalParams = new string[6];//optional parameters are optional for future release.
                optionalParams[0] = officeId;
                optionalParams[1] = stateCode;
                optionalParams[2] = underWriterCode;
                optionalParams[3] = county;
                optionalParams[4] = zip;
                optionalParams[5] = fileId;

                AgentNetWSUtilityV20Client client = new AgentNetWSUtilityV20Client();
                AgentNetGetDataResponse resp = client.GetServiceOrderFields(m_UserId, m_Password, DEALRequest.GetCurrentAgentNetVersion(), optionalParams);

                return resp.AGENTNET_GET_DATA_RESPONSE;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetServiceOrderFields failed: " + ex.ToString());
            }
            return null;
        }
#endif

#if MISMO32
        public AGENTNET_GET_DATA_RESPONSE GetServiceOrderFieldsPost(string officeId, string stateCode, string underWriterCode, string county, string zip, string fileId = "")
        {
            try
            {
                m_Status = new List<STATUS>();

                AGENTNET_GET_DATA_RESPONSE response = null;
                string[] optionalParams = new string[6];//optional parameters are optional for future release.

                optionalParams[0] = officeId;
                optionalParams[1] = stateCode;
                optionalParams[2] = underWriterCode;
                optionalParams[3] = county;
                optionalParams[4] = zip;
                optionalParams[5] = fileId;

                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetServiceOrderFieldsPost(optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetServiceOrderFieldsPost");

                if (CheckStatus(resp, "GetServiceOrderFieldsPost"))
                {
                    response = DEALResponse.GetAgentNetGetDataResponse(resp);
                    return response;
                }
                return null;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetTransactionAndBusinessSegTypesPost failed: " + ex.ToString());
            }
            return null;
        }
#endif

       /// <summary>
       /// Returns third-party uploaded documents to the user.
       /// </summary>
       /// <param name="fileId"></param>
       /// <param name="orderId"></param>
       /// <returns></returns>
#if MISMO32
        public AGENTNET_TITLE_SERVICE_DETAIL GetBOUploadedDocuments(string fileId, string orderId)
        {
            try
            {
                m_Status = new List<STATUS>();

                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetBOUploadedDocumentDetailsResponse response = null;

                response = service.GetBOUploadedDocuments(m_UserId, m_Password, fileId, orderId);
                if (response != null)
                {
                    m_Status.Add(response.STATUS);
                    return response.AGENTNET_TITLE_SERVICE_DETAIL;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOUploadedDocuments failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif
        /// <summary>
        /// Returns third-party uploaded documents to the user for https post call.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="orderId"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TITLE_SERVICE_DETAIL GetBOUploadedDocumentsPost(string fileId, string orderId)
        {
            try
            {
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateBOUploadedDocuments(fileId, orderId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetBOUploadedDocumentsPost");

                if (CheckStatus(resp, "GetBOUploadedDocumentsPost"))
                {
                    AGENTNET_TITLE_SERVICE_DETAIL getDatResponse = DEALResponse.GetAgentNetTitleServiceDetail(resp);
                    return getDatResponse;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOUploadedDocumentsPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns Request/Order updated details
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TITLE_SERVICE_UPDATE_DETAIL[] GetBOPSOrderUpdateDetails(string orderId)
        {
            try
            {
                m_Status = new List<STATUS>();

                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                BOPSOrderUpdateDetailResponse response = null;
                int internalOrderId=0;
                bool res= Int32.TryParse(orderId, out internalOrderId);
                if (!res)
                    return null;
                response = service.GetBOPSOrderUpdateDetails(m_UserId, m_Password, internalOrderId);
                if (response != null)
                {
                    m_Status.Add(response.STATUS);
                    return response.AGENTNET_TITLE_SERVICE_UPDATE_DETAILS;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOPSOrderUpdateDetails failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif
        /// <summary>
        /// Returns Request/Order updated details
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TITLE_SERVICE_UPDATE_DETAIL[] GetBOPSOrderUpdateDetailsPost(string orderId)
        {
            try
            {
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateBOPSUpdateOrderDetails(orderId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetBOPSOrderUpdateDetailsPost");

                if (CheckStatus(resp, "GetBOPSOrderUpdateDetailsPost"))
                {
                    AGENTNET_TITLE_SERVICE_UPDATE_DETAILS getDatResponse = DEALResponse.GetAgentNetTitleServiceUpdateDetail(resp);
                    if (getDatResponse != null)
                        return getDatResponse.AGENTNET_TITLE_SERVICE_UPDATE_DETAIL;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOPSOrderUpdateDetailsPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns transaction types and business segments.
        /// </summary>
        /// <param name="officeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="county"></param>
        /// <param name="zip"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetMultiTypeDatas(string multiType, params string[] Parms)
        {
            try
            {
                m_Status = new List<STATUS>();
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                AgentNetMultiTypeDatasResponse response = null;
                string[] optionalParams= null;
                if (Parms != null)
                {
                    if (Parms.Length > 0)
                    {
                        optionalParams = Parms;
                    }
                }

                response = service.GetMultiTypeDatas(m_UserId, m_Password, multiType, optionalParams);
                if (response != null)
                {
                    m_Status.Add(response.STATUS);
                    return response.AGENTNET_TYPE_DATAS_MULTI;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetMultiTypeDatas failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns transaction types and business segments for https post calls.
        /// </summary>
        /// <param name="officeId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="county"></param>
        /// <param name="zip"></param>
        /// <returns></returns>
#if MISMO32
        public AGENTNET_TYPE_DATAS_MULTI GetMultiTypeDatasPost(string multiType, params string[] parms)
        {
            try
            {
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateMultiTypeDatas(multiType, parms));
                
                MESSAGE resp = Invoke(message.MESSAGE, "GetMultiTypeDatasPost");

                if (CheckStatus(resp, "GetMultiTypeDatasPost"))
                {
                    AGENTNET_TYPE_DATAS_MULTI getDatResponse = DEALResponse.GetAgentNetTypeDatasMulti(resp);
                    return getDatResponse;
                }            
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetMultiTypeDatasPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

        /// <summary>
        /// Returns the list of rate types for the product supplied. OfficeId and  agentNetProductServiceId are optional parameters.
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="stateCode"></param>
        /// <param name="underWriterCode"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="isExtendedCoverage"></param>
        /// <param name="vendorName"></param>
        /// <param name="officeId"></param>
        /// <param name="agentNetProductServiceId"></param>
        /// <returns></returns>
        public AGENTNET_GET_DATA_RESPONSE GetRateTypesPost(string productId, string stateCode, string underWriterCode, string effectiveDate, bool isExtendedCoverage, string vendorName, string officeId, string agentNetProductServiceId, string county, string accountNumuber, string businessSegment)
        {
            try
            {
                string casheKey = productId + "/" + stateCode + "/" + underWriterCode + "/" + effectiveDate + "/" + isExtendedCoverage.ToString() + "/" + vendorName + "/" + officeId + "/" + agentNetProductServiceId + "/" + county + "/" + accountNumuber + "/" + businessSegment;
                if (sCashedRateTypes.ContainsKey(casheKey))
                    return sCashedRateTypes[casheKey];
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateRateTypes(productId, stateCode, underWriterCode, effectiveDate, isExtendedCoverage, vendorName, officeId, agentNetProductServiceId, county, accountNumuber, businessSegment));
                message.AGENTNET_REQUEST.OfficeId = officeId;
                MESSAGE resp = Invoke(message.MESSAGE, "GetRateTypesPost");
                if (CheckStatus(resp,"GetRateTypesPost"))
                {
                    AGENTNET_GET_DATA_RESPONSE getDatResponse= DEALResponse.GetAgentNetGetDataResponse(resp);
                    sCashedRateTypes.Add(casheKey, getDatResponse);
                    return getDatResponse;
                }                
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetRateTypesPost failed: " + ex.ToString());
            }
            return null;
        }
        /// <summary>
        ///  GetCPLFeeStates returns  list of states that has CPL fees.  
        /// </summary>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetCPLFeeStates()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                resp = service.GetCPLFeeStates(m_UserId, m_Password);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_TYPE_DATA != null && resp.AGENTNET_TYPE_DATA.Length > 0)
                        types.AddRange(resp.AGENTNET_TYPE_DATA);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCPLFeeStates failed: " + ex.ToString());
            }
            return null;
        }

        /// <summary>
        /// GetCPLFeeStatesPost returns  list of states that has CPL fees.
        /// </summary>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetCPLFeeStatesPost()
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetCPLFeeStates();
                MESSAGE resp = Invoke(message, "GetCPLFeeStatesPost");
                if (CheckStatus(resp, "GetCPLFeeStatesPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetCPLFeeStatesPost failed: " + ex.ToString());
            }
            return null;
        }
#if MISMO32
        /// <summary>
        ///  GetBOPSOrdersCompleted returns a list of BOPS orders that are completed and documents are ready
        /// </summary>
        /// <returns></returns>
        public List<AGENTNET_TITLE_SERVICE_COMPL> GetBOPSOrdersCompleted(bool isGetAll = false)
        {
            try
            {
                List<AGENTNET_TITLE_SERVICE_COMPL> types = new List<AGENTNET_TITLE_SERVICE_COMPL>();
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                BOPSOrdersCompletedResponse resp = null;
                resp = service.GetBOPSOrdersCompleted(m_UserId, m_Password, isGetAll);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_TITLE_SERVICE_COMPLS != null && resp.AGENTNET_TITLE_SERVICE_COMPLS.Length > 0)
                        types.AddRange(resp.AGENTNET_TITLE_SERVICE_COMPLS);
                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOPSOrdersCompleted failed: " + ex.ToString());
            }
            return null;
        }
        /// <summary>
        /// GetBOPSOrdersCompletedPost returns a list of BOPS orders that are completed and documents are ready
        /// </summary>
        /// <returns></returns>
        public List<AGENTNET_TITLE_SERVICE_COMPL> GetBOPSOrdersCompletedPost(bool isGetAll = false)
        {
            try
            {
                List<AGENTNET_TITLE_SERVICE_COMPL> types = new List<AGENTNET_TITLE_SERVICE_COMPL>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetBOPSOrdersCompleted(isGetAll);
                MESSAGE resp = Invoke(message, "GetBOPSOrdersCompletedPost");
                if (CheckStatus(resp, "GetBOPSOrdersCompletedPost"))
                {
                    AGENTNET_TITLE_SERVICE_COMPL[] list = DEALResponse.GetAgentNetTitleServiceCompls(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOPSOrdersCompletedPost failed: " + ex.ToString());
            }
            return null;
        }
        /// <summary>
        /// GetBOPSDocumentsList returns a list of documents for a BOPS order Id
        /// </summary>
        /// <returns></returns>
        public AGENTNET_TITLE_SERVICE_DOCS GetBOPSDocumentsList(int OrderId, bool bAllDocs = false)
        {
            try
            {
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
                BOPSDocumentsListResponse resp = null;
                resp = service.GetBOPSDocumentsList(m_UserId, m_Password, OrderId, bAllDocs);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    return resp.AGENTNET_TITLE_SERVICE_DOCS;
                }
                return null;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOPSOrdersCompleted failed: " + ex.ToString());
            }
            return null;
        }
        /// <summary>
        /// GetBOPSDocumentsListPost returns a list of documents for a BOPS order Id
        /// </summary>
        /// <returns></returns>
        public AGENTNET_TITLE_SERVICE_DOCS GetBOPSDocumentsListPost(int OrderId, bool bAllDocs = false)
        {
            try
            {
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MESSAGE message = null;
                message = dealReq.CreateGetBOPSDocumentsList(OrderId, bAllDocs);
                MESSAGE resp = Invoke(message, "GetBOPSDocumentsListPost");
                if (CheckStatus(resp, "GetBOPSDocumentsListPost"))
                {
                    return DEALResponse.GetAgentNetTitleServiceDocs(resp);
                }

            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBOPSDocumentsListPost failed: " + ex.ToString());
            }
            return null;
        }
#else
        //
#endif

#if MISMO32
        public String BuildCopyTypeTable(AGENTNET_TYPE_DATAS CopyTypes)
        {
            StringBuilder sbCopy = new StringBuilder();
            //AgentNetNameValueEnum.AgentNetCopyTypeDescription
            sbCopy.Append("<table style='font-family: Sans-Serif; font-size:8.25 pt'><tbody>");
            foreach(AGENTNET_TYPE_DATA type in CopyTypes.AGENTNET_TYPE_DATA)
            {
                String selected = String.Empty;
                if (type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 1 &&
                    !String.IsNullOrEmpty(type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[1].Value) &&
                    String.Compare(type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[1].Value, "true", true) == 0)
                    selected = " checked='checked'";
                sbCopy.Append("<tr>");
                sbCopy.Append("<td>" + "<input type='radio'" + selected + " name='rbCopyType' value='"+type.TypeId+"' />"+ type.Description + "</td>");
                sbCopy.Append("<td style='vertical-align:middle'>" + type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[0].Value + "</td>");
                sbCopy.Append("</tr>");
            }
            sbCopy.Append("</tbody></table>");

            return sbCopy.ToString();
        }
#endif

        private MESSAGE Invoke(MESSAGE msg, string requestName)
        {
            // For debugging dump the request XML
            //string requestXml = ANUtils.FormatXML(ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(msg));
            //ANUtils.StringToFile(ANUtils.FileDataPath + "\\" + requestName + "Request.xml", requestXml);

            try
            {
                m_xml1 = ANUtils.FormatXML(ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(msg));
            }
            catch(Exception ex)
            {
                m_xml1 = "Error: " + ex.Message;
            }

            InterfaceAgentNet agentNet = new InterfaceAgentNet(msg);

            MESSAGE resp = agentNet.HTTPPost();

            try
            {
                m_xml2 = ANUtils.FormatXML(ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(resp));
            }
            catch(Exception ex)
            {
                m_xml2 = "Error: " + ex.Message;
            }

            // For debugging dump the response XML
            //string responseXml = ANUtils.FormatXML(ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(resp));
            //ANUtils.StringToFile(ANUtils.FileDataPath + "\\" + requestName + "Response.xml", responseXml);

            return resp;
        }
        private bool CheckStatus(MESSAGE respMsg, string requestName)
        {
            if (respMsg != null)
            {
                MessageHelper ms = new MessageHelper(respMsg);
                m_Status.AddRange(ms.STATUSes);
                if (m_Status[0].StatusCode != DEALResponse.RETURN_CODE_SUCCESS)
                {
                    ANUtils.StringToFile("Error.log", requestName + " GET_DATA call failed - " + m_Status[0].StatusDescription);
                    return false;
                }
                return true;
            }
            return false;
        }

        public List<AGENTNET_PARTY> GetSignatoriesPost(string firmId, string underWriterCode, string stateCode, string accountNumber, string isEsignature, string isFirmLevelSignatory )
        {
            try
             {
                List<AGENTNET_PARTY> partyCollection = new List<AGENTNET_PARTY>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;

                string[] optionalParams = new string[6];
                optionalParams[0] = firmId;
                optionalParams[1] = underWriterCode;
                optionalParams[2] = stateCode;
                optionalParams[3] = accountNumber;
                optionalParams[4] = isEsignature;
				optionalParams[5] = isFirmLevelSignatory;
                MessageHelper message = new MessageHelper(dealReq.CreateGetParties(AgentNetPartyTypeEnum.SIGNATORIES, optionalParams));
                MESSAGE resp = Invoke(message.MESSAGE, "GetSignatoriesPost");
                if (CheckStatus(resp, "GetSignatoriesPost"))
                {
                    AGENTNET_PARTY[] list = DEALResponse.GetParties(resp);
                    if (list != null && list.Length > 0)
                        partyCollection.AddRange(list);
                }
                return partyCollection;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetSignatoriesPost failed: " + ex.ToString());
            }
            return null;
        }

        public List<AGENTNET_PARTY> GetSignatories(string firmId, string underWriterCode, string stateCode, string accountNumber, string isESignatureImage, string isFirmLevelSignatory)
        {
            List<AGENTNET_PARTY> types = new List<AGENTNET_PARTY>();
#if MISMO32
            AgentNetWSEntityV20Client service = new AgentNetWSEntityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
            PartiesResponse resp = null;
            string[] optionalParams = new string[6];
            optionalParams[0] = firmId;
            optionalParams[1] = underWriterCode;
            optionalParams[2]=stateCode;
            optionalParams[3] = accountNumber;
            optionalParams[4] = isESignatureImage;
			optionalParams[5] = isFirmLevelSignatory;
            resp = service.GetParties(m_UserId, m_Password, AgentNetPartyTypeEnum.SIGNATORIES, optionalParams);
            if (resp != null)
            {
                m_Status.Add(resp.STATUS);
                if (resp.AGENTNET_PARTIES != null && resp.AGENTNET_PARTIES.Length > 0)
                    types.AddRange(resp.AGENTNET_PARTIES);
            }
            return types;
        }
        /// <summary>
        /// Get the latest BusinessSegments list required for rates and fees
        /// </summary>
        /// <param name="stateCode">Statecode of the property</param>
        /// <param name="NAICPropertyType">NAICPropertyType of the property</param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetBusinessSegments(string stateCode, string NAICPropertyType, string FileNumber, int OfficeId, int FileId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
#if MISMO32
                AgentNetWSUtilityV20Client service = new AgentNetWSUtilityV20Client();
#else
                AgentNetWSClient service = new AgentNetWSClient();
#endif
                AgentNetTypeDataItemsResponse resp = null;
                string[] optionalParams = new string[2];
                optionalParams[0] = stateCode;
                optionalParams[1] = NAICPropertyType;
                //resp = service.GetBusinessSegments(m_UserId, m_Password, stateCode, NAICPropertyType);
                resp = service.GetBusinessSegments(m_UserId, m_Password, stateCode, NAICPropertyType, FileNumber, OfficeId, FileId);
                if (resp != null)
                {
                    m_Status.Add(resp.STATUS);
                    if (resp.AGENTNET_TYPE_DATA != null && resp.AGENTNET_TYPE_DATA.Length > 0)
                        types.AddRange(resp.AGENTNET_TYPE_DATA);

                }
                return types;
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBusinessSegments failed: " + ex.ToString());
            }
            return null;
        }
        /// <summary>
        /// Get the latest BusinessSegments list required for rates and fees
        /// </summary>
        /// <param name="stateCode">Statecode of the property</param>
        /// <param name="NAICPropertyType">NAICPropertyType of the property</param>
        /// <returns></returns>
        public List<AGENTNET_TYPE_DATA> GetBusinessSegmentsPost(string stateCode, string NAICPropertyType, string FileNumber, int OfficeId, int FileId)
        {
            try
            {
                List<AGENTNET_TYPE_DATA> types = new List<AGENTNET_TYPE_DATA>();
                DEALRequest dealReq = new DEALRequest();
                dealReq.LoginId = m_UserId;
                dealReq.LoginPassword = m_Password;
                MessageHelper message = new MessageHelper(dealReq.CreateGetBusinessSegments(stateCode, NAICPropertyType, FileNumber,  OfficeId,  FileId));
                MESSAGE resp = Invoke(message.MESSAGE, "GetBusinessSegmentsPost");
                if (CheckStatus(resp, "GetBusinessSegmentsPost"))
                {
                    AGENTNET_TYPE_DATA[] list = DEALResponse.GetAgentNetTypeDatas(resp);
                    if (list != null && list.Length > 0)
                        types.AddRange(list);
                    return types;
                }
            }
            catch (Exception ex)
            {
                ANUtils.StringToFile("Error.log", "GetBusinessSegmentsPost failed: " + ex.ToString());
            }
            return null;
        }
    }
}

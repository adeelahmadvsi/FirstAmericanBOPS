﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#if MISMO32
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
using AgentNetInterfaceHelper.v2;
namespace ThirdPartySoftwareSimulator.v2
#else
namespace ThirdPartySoftwareSimulator.v1
#endif
{
    public class BOPSHelper
    {
        #region Instantiation
        private DEALRequest m_Req = null;
        private DEALResponse m_Resp = null;
        private SERVICE m_Service = null;
        private AgentNetHelper m_ServiceHelper = null;
        #endregion
        #region constants
        private const string SERVICE_ORDER_FIELD_ID_TEXT = "ServiceOrderField_";
        private const string SERVICE_ORDER_GROUP_ID_TEXT = "tblServiceOrderGroup_";
        #endregion
        #region cTor
        public BOPSHelper(DEALRequest req, SERVICE s, DEALResponse resp)
        {
            m_ServiceHelper = new AgentNetHelper(DEALRequest.DefaultLoginId, DEALRequest.DefaultLoginPassword);
            m_Req = req;
            m_Resp = resp;
            m_Service = s;
        }
        #endregion
        #region Html Builder

        public string BuildBOPSGui(AGENTNET_SERVICE_ORDER_GROUPS groups)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<HTML><HEAD><style>body{background-color:#F0F0F0; border: #8F8F8F 1px solid;}</style></HEAD><BODY>");
            try
            {
                if(groups != null)
                {
                    sb.Append(BuildBOPSGui(groups.AGENTNET_SERVICE_ORDER_GROUP));
                }
                sb.Append("</BODY></HTML>");
                return sb.ToString();
            }
            catch(Exception)
            {
                return sb.ToString();
            }
            finally
            {
                sb.Clear();
            }
        }
        public string BuildBOPSGui(AGENTNET_SERVICE_ORDER_GROUP[] groups)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                foreach (AGENTNET_SERVICE_ORDER_GROUP group in groups)
                {
                    sb.Append(BuildBOPSGui(group)); 
                }
                return sb.ToString();
            }
            catch (Exception)
            {
                return sb.ToString();
            }
            finally
            {
                sb.Clear();
            }
        }
        public string BuildBOPSGui(AGENTNET_SERVICE_ORDER_GROUP group)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                    sb.Append("<DIV style=\"padding: 10px 10px 10px 10px\">");
                    if (!String.IsNullOrEmpty(group.Text))
                    {
                        sb.Append("<DIV style=\"font-size:19px; font-weight:bold\">" + group.Text + "</DIV>");
                    }
                    sb.Append("<HR />");

                    if (group.AGENTNET_SERVICE_ORDER_FIELDS != null)
                    {
                        if (group.AGENTNET_SERVICE_ORDER_FIELDS.AGENTNET_SERVICE_ORDER_FIELD == null)
                        {
                            group.AGENTNET_SERVICE_ORDER_FIELDS.AGENTNET_SERVICE_ORDER_FIELD = new AGENTNET_SERVICE_ORDER_FIELD[0];
                        }
                        sb.Append("<TABLE id=\"" + SERVICE_ORDER_GROUP_ID_TEXT + group.Name + "\">");
                        sb.Append(BuildBOPSGui(group.AGENTNET_SERVICE_ORDER_FIELDS.AGENTNET_SERVICE_ORDER_FIELD));
                        sb.Append("</TABLE>");
                    }
                    sb.Append("</DIV>");

                    return sb.ToString();
            }
            catch (Exception)
            {
                return sb.ToString();
            }
            finally
            {
                sb.Clear();
            }
        }
        public string BuildBOPSGui(AGENTNET_SERVICE_ORDER_GROUP group, bool IsIgnoreHeader)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                if (group.AGENTNET_SERVICE_ORDER_FIELDS != null &&
                   group.AGENTNET_SERVICE_ORDER_FIELDS.AGENTNET_SERVICE_ORDER_FIELD != null)
                {
                    sb.Append("<TABLE id=\"" + SERVICE_ORDER_GROUP_ID_TEXT + group.Name + "\">");
                    sb.Append(BuildBOPSGui(group.AGENTNET_SERVICE_ORDER_FIELDS.AGENTNET_SERVICE_ORDER_FIELD));
                    sb.Append("</TABLE>");
                }
                sb.Append("</DIV>");

                return sb.ToString();
            }
            catch (Exception)
            {
                return sb.ToString();
            }
            finally
            {
                sb.Clear();
            }
        }
        public string BuildBOPSGui(AGENTNET_SERVICE_ORDER_FIELD[] fields)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                
                foreach (AGENTNET_SERVICE_ORDER_FIELD field in fields)
                {
                    sb.Append("<TR>");
                    sb.Append(BuildHtmlElement(field));
                    sb.Append("</TR>");
                }
                return sb.ToString();
            }
            catch (Exception)
            {
                return sb.ToString();
            }
            finally
            {
                sb.Clear();
            }
        }

        public string BuildHtmlElement(AGENTNET_SERVICE_ORDER_FIELD field, bool isAddDefaultSelectObject = true)
        {
            String Element = String.Empty;
            try
            {
                switch (field.Type)
                {
                    case "DropDown":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<TD style=\"TEXT-ALIGN:right; WIDTH:150px\">" + field.Label + "</TD>" +
                                      "<TD><SELECT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" style=\"WIDTH:300px\"" + disabled + ">" +
                                      (isAddDefaultSelectObject ? ("<OPTION selected value=-1>----Select----</OPTION>") : "");
                            if (field.DataFields != null)
                            {
                                foreach (AGENTNET_TYPE_DATA type in field.DataFields)
                                {
                                    Element += "<OPTION value=" + type.TypeId + ">" + type.Description + "</OPTION>";
                                }
                            }
                            Element += "</SELECT></TD>";
                        }
                        break;
                    case "Header":
                        {
                            Element = "<H4>" + field.Label + "</H4>";
                        }
                        break;
                    case "ListBox":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<TD>" + field.Label + "<BR /><SELECT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" style=\"WIDTH:300px\" MULTIPLE SIZE=5" + disabled + ">";
                            if (field.DataFields != null)
                            {
                                foreach (AGENTNET_TYPE_DATA type in field.DataFields)
                                {
                                    Element += "<OPTION value=" + type.TypeId + ">" + type.Description + "</OPTION>";
                                }
                            }
                            Element += "</SELECT></TD>";
                        }
                        break;
                    case "Button":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<TD><BUTTON id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" style=\"WIDTH:100px\"" + disabled + ">" + field.Text + "</BUTTON></TD>";
                        }
                        break;
		            case "RadioButtonList":
                        {
                            StringBuilder sbCopy = new StringBuilder();
                            String disabled = field.IsDisabled ? " disabled" : "";
                            sbCopy.Append("<TD style=\"VERTICAL-ALIGN: top; TEXT-ALIGN:right\">" + field.Label + "</TD><TD><TABLE style=\"FONT-FAMILY: Sans-Serif; FONT-SIZE:8.25 pt\"><TBODY>");
                            foreach (AGENTNET_TYPE_DATA type in field.DataFields)
                            {
                                String selected = String.Empty;
                                if (type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 1 &&
                                    !String.IsNullOrEmpty(type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[1].Value) &&
                                    String.Compare(type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[1].Value, "true", true) == 0)
                                    selected = " checked='checked'";
                                sbCopy.Append("<TR>");
                                sbCopy.Append("<TD>" + "<INPUT type='radio'" + selected + " name='rb" + field.Name + "' value='" + type.TypeId + "'" + disabled + " />" + type.Description + "</TD>");
                                sbCopy.Append("<TD style='VERTICAL-ALIGN:middle'>" + type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[0].Value + "</TD>");
                                sbCopy.Append("</TR>");
                            }
                            sbCopy.Append("</TBODY></TABLE></TD>");

                            Element = sbCopy.ToString();
                            sbCopy.Clear();
                        }
                        break;
                    case "CheckBox":
                        {
                            String checkedString = field.IsChecked ? " Checked = \"Checked\"" : "";
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<TD colspan=\"2\"><INPUT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" type=\"checkbox\"" + checkedString + disabled + " /> " + field.Text + "</TD>";
                        }
                        break;
                    case "TextBox":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            String verticalAlign = field.IsMultiText ? "; vertical-align: top" : "";
                            Element = "<TD style=\"TEXT-ALIGN:right; WIDTH:150px" + verticalAlign + "\">" + field.Label + "</TD>" +
                                (field.IsMultiText ?
                                    "<TD><TEXTAREA id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" rows=\"5\" cols=\"80\"" + disabled + ">" + field.Text + "</TEXTAREA></TD>" :
                                    "<TD><INPUT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\"  style=\"WIDTH:300px\" type=\"text\" value=\"" + field.Text + "\"" + disabled + " /></TD>");
                        }
                        break;
                    case "Label":
                        {
                            Element = String.IsNullOrEmpty(field.Text) ? "<TD colspan=\"2\">" : "<TD>";
                            Element += "<LABEL id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\">" + field.Label + "</LABEL><TD>";
                            if(!String.IsNullOrEmpty(field.Text))
                            {
                                Element += "<TD><LABEL id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\">" + field.Label + "</LABEL><TD>";
                            }
                        }
                        break;
                    case "ElementGroup":
                        {
                            Element = "<TD>" + field.Label + "</TD><TD></TD></TR><TR>";
                            Element += "<TD></TD><TD><TABLE><TR>";
                            
                            foreach(AGENTNET_SERVICE_ORDER_FIELD item in field.ChildElements)
                            {
                                Element += BuildHtmlElement(item);
                            }

                            Element += "</TR></TABLE></TD>";
                        }
                        break;
                    default:
                        break;
                }
                return Element;
            }
            catch(Exception ex)
            {
                return String.Empty;
            }
        }

        public string BuildHtmlChildElement(AGENTNET_SERVICE_ORDER_FIELD field, bool isAddDefaultSelectObject = true)
        {
            String Element = String.Empty;
            try
            {
                switch (field.Type)
                {
                    case "DropDown":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<SELECT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" style=\"WIDTH:300px\"" + disabled + ">" +
                                      (isAddDefaultSelectObject ? ("<OPTION selected value=-1>----Select----</OPTION>") : "");
                            if (field.DataFields != null)
                            {
                                foreach (AGENTNET_TYPE_DATA type in field.DataFields)
                                {
                                    Element += "<OPTION value=" + type.TypeId + ">" + type.Description + "</OPTION>";
                                }
                            }
                            Element += "</SELECT>";
                        }
                        break;
                    case "Header":
                        {
                            Element = "<H4>" + field.Label + "</H4>";
                        }
                        break;
                    case "ListBox":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<SELECT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" style=\"WIDTH:300px\" MULTIPLE SIZE=5" + disabled + ">";
                            if (field.DataFields != null)
                            {
                                foreach (AGENTNET_TYPE_DATA type in field.DataFields)
                                {
                                    Element += "<OPTION value=" + type.TypeId + ">" + type.Description + "</OPTION>";
                                }
                            }
                            Element += "</SELECT>";
                        }
                        break;
                    case "Button":
                        {
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<BUTTON id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" style=\"WIDTH:100px\"" + disabled + ">" + field.Text + "</BUTTON>";
                        }
                        break;
                    case "RadioButtonList":
                        {
                            StringBuilder sbCopy = new StringBuilder();
                            sbCopy.Append("<TABLE style=\"FONT-FAMILY: Sans-Serif; FONT-SIZE:8.25 pt\"><TBODY>");
                            foreach (AGENTNET_TYPE_DATA type in field.DataFields)
                            {
                                String selected = String.Empty;
                                String disabled = field.IsDisabled ? " disabled" : "";
                                if (type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 1 &&
                                    !String.IsNullOrEmpty(type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[1].Value) &&
                                    String.Compare(type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[1].Value, "true", true) == 0)
                                    selected = " checked='checked'";
                                sbCopy.Append("<TR>");
                                sbCopy.Append("<TD>" + "<INPUT type='radio'" + selected + " name='rb" + field.Name + "' value='" + type.TypeId + "'" + disabled + " />" + type.Description + "</TD>");
                                sbCopy.Append("<TD style='VERTICAL-ALIGN:middle'>" + type.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE[0].Value + "</TD>");
                                sbCopy.Append("</TR>");
                            }
                            sbCopy.Append("</TBODY></TABLE>");

                            Element = sbCopy.ToString();
                            sbCopy.Clear();
                        }
                        break;
                    case "CheckBox":
                        {
                            String checkedString = field.IsChecked ? " Checked = \"Checked\"" : "";
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = "<INPUT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" type=\"checkbox\"" + checkedString + disabled + " /> " + field.Text;
                        }
                        break;
                    case "TextBox":
                        {
                            String verticalAlign = field.IsMultiText ? "; vertical-align: top" : "";
                            String disabled = field.IsDisabled ? " disabled" : "";
                            Element = (field.IsMultiText ?
                                    "<TEXTAREA id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\" rows=\"5\" cols=\"80\"" + disabled + ">" + field.Text + "</TEXTAREA>" :
                                    "<INPUT id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\"  style=\"WIDTH:300px\" type=\"text\"" + disabled + " value=\"" + field.Text + "\" />");
                        }
                        break;
                    case "Label":
                        {
                            Element = "<LABEL id=\"" + SERVICE_ORDER_FIELD_ID_TEXT + field.Name + "\">" + field.Label + "</LABEL>";
                            if (!String.IsNullOrEmpty(field.Text))
                            {
                                Element += ": " + field.Label;
                            }
                        }
                        break;
                    case "ElementGroup":
                        {
                            Element = "<TD>" + field.Label + "</TD><TD></TD></TR><TR>";
                            Element += "<TD></TD><TD><TABLE><TR>";

                            foreach (AGENTNET_SERVICE_ORDER_FIELD item in field.ChildElements)
                            {
                                Element += BuildHtmlElement(item);
                            }

                            Element += "</TR></TABLE></TD>";
                        }
                        break;
                    default:
                        break;
                }
                return Element;
            }
            catch (Exception ex)
            {
                return String.Empty;
            }
        }

        #endregion

        #region CustomEventArgs
        public class ServiceOrderHtmlEventArgs : EventArgs
        {
            public string value { get; set; }
            public string Text { get; set; }
            public bool isChecked { get; set; }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
#if MISMO32
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
using www.firstam.com._2011._03.datacontract.agentnet;
namespace AgentNetInterfaceHelper.v1
#endif
{
    public class RateAndFeeHelper
    {
        public RateAndFeeHelper()
        { }


        #region Constants - RF

        const string LNK_LBL_ADD_RMV_ENDRSMNT = "EndoLink_";
        const string TBL_ADD_QSTN = "tblAdditionalQuestion_";
        const string ADD_QSTN = "AdditionalQuestions_";
        const string TBL_ADD_QSTN_CPL = "tblAdditionalQuestionCPL_";
        const string ADD_QSTN_CPL = "AdditionalQuestionsCPL_";
        const string TXT_EFFCTV_DT = "txtEffectiveDate_";
        const string DDL_RT_TYP = "ddlRateType_";
        const string TBL_ENDRSMNT = "tblEndorsement_";
        const string TR_ADD_QSTN = "trAdditionalQuestion_";
        const string ENDRSMNT = "Endorsements_";
        const string TXT_LBLTY_AMNT = "txtLiabilityAmount_";
        const string CHK_EXTNDD_CVRG = "chkIsExtendedCoverage_";
        const string TD_RT_TYP_NM = "tdRateTypeName_";
        const string TD_RT_TYP = "tdRateType_";
        const string P_ADD_QSTN = "pAdditionalQuestion_";
        const string TR_PRR_PLCY_NMBR = "trPriorPolicyNumber_";
        const string PRR_PLCY_NMBR = "PriorPolicyNum_";
        const string REISSUE_RATE_TYPE = "2";
        const string LBL_PLCY_TYP = "lblPolicyType_";
        const string CHK_SMULTNS = "chkSimultaneous_";
        const string TXT_PRR_PLCY_NMBR = "txtPriorPolicyNumber_";
        const string TBL_SLCTD_ENDRSMNT = "tblSelectedEndorsement_";
        const string LBL_SLCTD_ENDRSMNT = "lblSelectedEndorsementText_";
        const string LBL_ENDRSMNT = "lblEndorsement_";
        const string MISC_ENDRSMNT = "Miscellaneous Endorsement";
        const string SLCTD_ENDRSMNT = "Endorsement";
        const string TR_PR_SLCTD_ENDRSMNT_ADD_QSTN = "trPreSelEndoAdditionalQuestion_";
        const string TR_SLCTD_ENDRSMNT_ADD_QSTN = "trSeleCtedEndoAdditionalQuestion_";
        const string LBL_JCKT_ADD_QSTN = "lblJacketAdditionalQuestion_";
        const string LBL_SLCTD_ENDRSMNT_ADD_QSTN = "lblSeletedEndoAdditionalQuestion_";
        const string DDL_JCKT_ADD_QSTN = "ddlJacketAdditionalQuestionAnswer_";
        const string DDL_ENDRSMNT_ADD_QSTN = "ddlEndoAdditionalQuestionAnswer_";
        const string TXT_JCKT_ADD_QSTN = "txtJacketAdditionalQuestionAnswer_";
        const string TXT_ENDRSMNT_ADD_QSTN = "txtEndoAdditionalQuestionAnswer_";
        const string LBL_CVRD_PRTY = "lblCoveredParty_";
        const string LBL_CPL_EFFCTV_DT = "lblCPLEffectiveDate_";
        const string LBL_CPL_ADD_QSTN = "lblCPLAdditionalQuestion_";
        const string DDL_CPL_ADD_QSTN = "ddlCPLtAdditionalQuestionAnswer_";
        const string TXT_CPL_ADD_QSTN_ANS = "txtCPLAdditionalQuestionAnswer_";
        const string LBL_CPL_NM = "lblCPLName_";
        const string TR_CPL_ADD_QSTN = "trCPLAdditionalQuestion_";
        const string TD_ENDRSMNT = "tdEndorsement_";
        const string TR_PR_SLCTD_ENDRSMNT = "trPreSelEndoName_";
        const string TR_SLCTD_ENDRSMNT = "trSelectedEndoName_";
        const string TBL_JCKT = "Product_Jacket_";
        const string LBL_JCK_ADD_QSTNT_NM = "lblJacketName_";
        const string CHK_ISOVERRIDE = "chkIsOverride";
        const string CBO_OVERRIDE_REASON = "cboOverrideReason";
        const string TXT_OVERRIDE_AMOUNT = "txtOverrideAmount";
        //const string TXT_RATE_EFFCTV_DT = "txtRateEffectiveDate";
        const string TBL_SIMUL_CHECK = "tblSimulCheck";
        const string TR_POLICY_RELATED_TO = "trPolicyRelatedTo_";
        const string TD_POLICY_RELATED_TO = "tdPolicyRelatedTo_";
        const string DDL_POLICY_RELATED_TO = "ddlPolicyRelatedTo_";
        const string LBL_POLICY_CATEGORY = "lblPolicyCategory_";
        const string TXT_POLICY_COMPLIANCE = "txtPolicyComplianceDate";

        private const string TAG_PREFIX = "GetQuotes_";
        private const string CPL_SECTION = "CplSection";
        private const string JACKET_SECTION = "JacketSection";
        private const string CALCULATION_SECTION = "CalculationSection";
        #endregion

        #region Variables/Properties

        Hashtable m_ChekedOrSelectedEndorsements = new Hashtable();
        Hashtable m_PreSelectedlineItemDetail = new Hashtable();

        StringBuilder m_HtmlText = null;
        private SERVICE m_PrePriceRequest = null; // previous successfull calculation
        bool m_IsOverrideState = false;
        string m_TaxCodeReceived;
        bool m_IsStatasticalCodeState = false;
        List<STATUS> m_GetRateTypesStatus = null;
        Hashtable m_JacketPricingEndorsementColl = new Hashtable();
        AGENTNET_GET_DATA_RESPONSE m_getDataResponse = null;
        bool m_FirstCPL = true;
        int m_StateSpecificMaxSimul = 2;
        Dictionary<int, String> m_MapOwnersToLoans = new Dictionary<int, String>();
        AgentNetHelper m_AgentNetHelper = new AgentNetHelper(DEALRequest.DefaultLoginId, DEALRequest.DefaultLoginPassword);
        Boolean m_IsPrePricing = false;
        Boolean m_IsPolicyComplianceDateRequired = false;


        public Hashtable ChekedOrSelectedEndorsements
        {
            get { return m_ChekedOrSelectedEndorsements; }
            set { m_ChekedOrSelectedEndorsements = value; }
        }

        public Hashtable PreSelectedlineItemDetail
        {
            get { return m_PreSelectedlineItemDetail; }
        }

        public Hashtable JacketPricingEndorsementColl
        {
            get { return m_JacketPricingEndorsementColl; }
            set { m_JacketPricingEndorsementColl = value; }
        }

        public List<AGENTNET_TYPE_DATA> OverrideReasons
        {
            get { return s_TypeDatas; }
            set { s_TypeDatas = value; }
        }

        #region static variables


        public static List<AGENTNET_TYPE_DATA> s_TypeDatas = null;

        #endregion
        #endregion

        #region Build Request

        public List<AGENTNET_PRODUCT_PRICING_REQUEST> BuildPricingReq(StringBuilder strBuilderJacket, StringBuilder strBuilderCPL, StringBuilder strBuilderRateFeePriceDetails, bool isDefault, int stateSpecificMaxCount, bool isDateUpdated, ref bool isValidaAmount, ref bool isValidaDate, bool isSecondLevel, ref bool isValidOverrideAmount, ref Boolean isSimul, ref Boolean isValidPolicyRelatedTo)
        {
            if (strBuilderJacket.Length > 0)
                ANUtils.StringToFile("BuildPricingReqJacket.html", strBuilderJacket.ToString());
            if (strBuilderCPL.Length > 0)
                ANUtils.StringToFile("BuildPricingReqCPL.html", strBuilderCPL.ToString());
            if (strBuilderRateFeePriceDetails.Length > 0)
                ANUtils.StringToFile("BuildPricingReqCalculate.html", strBuilderRateFeePriceDetails.ToString());
            HtmlParser htmldoc = new HtmlParser(strBuilderJacket.ToString());
            HtmlParser htmlCPLdoc = new HtmlParser(strBuilderCPL.ToString());
            HtmlParser htmldocRateFeePriceDetails = new HtmlParser(strBuilderRateFeePriceDetails.ToString());
            List<AGENTNET_PRODUCT_PRICING_REQUEST> listPricingReq = new List<AGENTNET_PRODUCT_PRICING_REQUEST>();
            List<AGENTNET_PRODUCT_PRICING_REQUEST> listPricingCPLReq = new List<AGENTNET_PRODUCT_PRICING_REQUEST>();
            List<AGENTNET_PRODUCT_LINEITEM_DETAIL> productLineItemDetail = null;
            if (isDateUpdated)
                m_StateSpecificMaxSimul = stateSpecificMaxCount;
            ParsedHtml htmlElem;
            isValidPolicyRelatedTo = true;
            if (htmldoc != null)
            {
                List<ParsedHtml> tables = htmldoc.GetTABLEs();
                foreach (ParsedHtml elem in tables)
                {
                    string strId = elem.GetAttribute("id");
                    bool isExtendedCoverage = false;
                    bool isOverride = false;
                    decimal overrideAmount = 0;
                    string overrideReason = string.Empty;

                    if (strId != null && strId.Length != 0)
                    {
                        if (String.Compare(strId, TBL_SIMUL_CHECK, true) == 0)
                        {
                            htmlElem = htmldoc.GetElementById(CHK_SMULTNS);
                            if (htmlElem != null)
                                isSimul = htmlElem.GetAttributeBool("CHECKED");
                        }
                        else
                        {
                            string[] productDetail = StringArrayId(strId); // TableName(0), Product(1), count(2), productId(3), ServiceProductId(4), nonEJacketPolicyNumber(5)
                            if (productDetail[0].Contains("Product"))
                            {
                                string count = productDetail[2];
                                string agentNetProductServiceId = productDetail[4];
                                AGENTNET_PRODUCT_PRICING_REQUEST pricingReq = new AGENTNET_PRODUCT_PRICING_REQUEST();
                                htmlElem = htmldoc.GetElementById(LBL_PLCY_TYP + count + "_" + agentNetProductServiceId);

                                pricingReq.ProductName = productDetail[1];
                                pricingReq.ProductID = productDetail[3];
                                pricingReq.NonEJacketPolicyNumber = productDetail[5];
                                if (htmlElem != null)
                                    pricingReq.ProductType = htmlElem.GetAttribute("title");
                                pricingReq.AgentNetProductServiceId = agentNetProductServiceId;

                                htmlElem = htmldoc.GetElementById(LBL_POLICY_CATEGORY + agentNetProductServiceId);
                                if (htmlElem != null)
                                    pricingReq.PolicyCategory = htmlElem.GetAttribute("title");

                                htmlElem = htmldoc.GetElementById(CHK_EXTNDD_CVRG + count + "_" + agentNetProductServiceId);
                                if (htmlElem != null)
                                    isExtendedCoverage = htmlElem.GetAttributeBool("CHECKED");
                                pricingReq.IsExtendedCoverage = isExtendedCoverage;

                                htmlElem = htmldoc.GetElementById(DDL_POLICY_RELATED_TO + agentNetProductServiceId);
                                if (htmlElem != null && isValidPolicyRelatedTo)
                                {
                                    List<ParsedHtml> options = htmldoc.GetOptionElements(htmlElem);
                                    foreach (ParsedHtml p in options)
                                    {
                                        if (p.GetAttributeBool("selected"))
                                        {
                                            pricingReq.LinkedProductServiceId = p.GetAttribute("value");
                                            if (pricingReq.LinkedProductServiceId == "0")
                                            {
                                                pricingReq.LinkedProductServiceId = "";
                                                isValidPolicyRelatedTo = false;
                                            }
                                            break;
                                        }
                                    }
                                }

                                htmlElem = htmldoc.GetElementById(DDL_RT_TYP + count + "_" + agentNetProductServiceId);
                                if (htmlElem != null)
                                {
                                    List<ParsedHtml> options = htmldoc.GetOptionElements(htmlElem);
                                    foreach (ParsedHtml p in options)
                                    {
                                        if (p.GetAttributeBool("selected"))
                                        {
                                            pricingReq.RateType = p.GetAttribute("value");
                                            if (pricingReq.RateType == "0")
                                                pricingReq.RateType = "";
                                            break;
                                        }
                                    }
                                }
                                htmlElem = htmldoc.GetElementById(TXT_LBLTY_AMNT + count + "_" + agentNetProductServiceId);
                                if (htmlElem != null)
                                {
                                    try
                                    {
                                        pricingReq.LiabilityAmount = htmlElem.GetAttributeDec("value");
                                    }
                                    catch (Exception)
                                    {
                                        isValidaAmount = false;
                                    }
                                    if (pricingReq.LiabilityAmount == 0)
                                        isValidaAmount = false; ;
                                }
                                htmlElem = htmldoc.GetElementById(TXT_EFFCTV_DT + count + "_" + agentNetProductServiceId);
                                if (htmlElem != null)
                                    try
                                    {
                                        pricingReq.EffectiveDate = htmlElem.GetAttributeDate("value");
                                    }
                                    catch (Exception)
                                    {
                                        isValidaDate = false;
                                    }
                                //htmlElem = htmldoc.GetElementById(TXT_POLICY_COMPLIANCE);
                                //if(htmlElem!=null)
                                //{
                                //    string abc = htmlElem.GetAttribute("value");
                                //}

                                htmlElem = htmldoc.GetElementById(TXT_PRR_PLCY_NMBR + count + "_" + agentNetProductServiceId);
                                if (htmlElem != null)
                                    pricingReq.PriorPolicyNumber = htmlElem.GetAttribute("value");


                                #region Product/Jacket Statistical codes
                                string statisticalCodePolicy = string.Empty;
                                if (htmldocRateFeePriceDetails != null)
                                {
                                    htmlElem = htmldocRateFeePriceDetails.GetElementById("cboStatisticalCodes" + agentNetProductServiceId);
                                    if (htmlElem != null)
                                    {
                                        List<ParsedHtml> options = htmldocRateFeePriceDetails.GetOptionElements(htmlElem);
                                        foreach (ParsedHtml p in options)
                                        {
                                            if (p.GetAttributeBool("selected"))
                                            {
                                                statisticalCodePolicy = p.GetAttribute("value");
                                                if (statisticalCodePolicy == "0")
                                                    statisticalCodePolicy = "";
                                                break;
                                            }
                                        }
                                    }
                                }
                                pricingReq.StatisticalCode = statisticalCodePolicy;

                                #endregion


                                htmlElem = htmldoc.GetElementById(TBL_ENDRSMNT + count + "_" + agentNetProductServiceId);
                                List<AGENTNET_ADDITIONAL_QUESTION> agentNetAdditionalQuestions;
                                if (htmlElem != null)
                                {
                                    List<ParsedHtml> htmlTdElemCol = htmldoc.GetTDElements(htmlElem);
                                    if (htmlTdElemCol.Count > 0)
                                    {
                                        int endoCount = 0;
                                        productLineItemDetail = new List<AGENTNET_PRODUCT_LINEITEM_DETAIL>();
                                        foreach (ParsedHtml element in htmlTdElemCol)
                                        {
                                            ParsedHtml elmt = htmldoc.GetElementById(LBL_ENDRSMNT + count + "_" + endoCount + "_" + agentNetProductServiceId);
                                            AGENTNET_PRODUCT_LINEITEM_DETAIL lineItem = new AGENTNET_PRODUCT_LINEITEM_DETAIL();
                                            if (elmt != null)
                                            {
                                                string strEndoId = elmt.GetAttribute("for");

                                                if (strEndoId != null)
                                                {
                                                    string strEndoType = element.GetAttribute("id");
                                                    if (strEndoType != null)
                                                    {
                                                        string[] strEndoIdArray = strEndoType.Split('_');
                                                        lineItem.LineItemID = strEndoId.Substring(0, strEndoId.LastIndexOf('_'));
                                                        if (strEndoIdArray[3] == MISC_ENDRSMNT)
                                                        {
                                                            string miscAmount = strEndoId.Substring(strEndoId.LastIndexOf('_') + 1);
                                                            lineItem.LineItemType = strEndoIdArray[3];
                                                            lineItem.LineItemDescr = elmt.GetAttribute("title");
                                                            lineItem.MiscEndorsmentAmount = Convert.ToDecimal(miscAmount);
                                                        }
                                                        else
                                                        {

                                                            lineItem.LineItemType = strEndoIdArray[3];
                                                            lineItem.LineItemDescr = "";
                                                        }
                                                        isOverride = false;
                                                        overrideAmount = 0;
                                                        overrideReason = string.Empty;
                                                        StructOverride productOverrideAmount = GetOverrideFields(agentNetProductServiceId, lineItem.LineItemID, ProductTypeEnum.Endorsement, htmldocRateFeePriceDetails, isDefault, ref isValidOverrideAmount, endoCount);

                                                        isOverride = productOverrideAmount.isOverride;
                                                        if (productOverrideAmount.OverrideReason != null)
                                                            overrideReason = productOverrideAmount.OverrideReason;
                                                        overrideAmount = productOverrideAmount.OverrideAmount;
                                                        lineItem.IsOverride = isOverride;
                                                        lineItem.OverrideAmount = overrideAmount;
                                                        if (overrideReason == "0")
                                                            overrideReason = string.Empty;
                                                        lineItem.OverrideReason = overrideReason;
                                                        #region Endorsement Statistical codes

                                                        string lineItemStatisticalCode = string.Empty;
                                                        if (htmldocRateFeePriceDetails != null)
                                                        {
                                                            htmlElem = htmldocRateFeePriceDetails.GetElementById("cboStatisticalCodes" + lineItem.LineItemID + agentNetProductServiceId + endoCount);
                                                            if (htmlElem != null)
                                                            {
                                                                List<ParsedHtml> options = htmldocRateFeePriceDetails.GetOptionElements(htmlElem);
                                                                foreach (ParsedHtml p in options)
                                                                    if (p.GetAttributeBool("selected"))
                                                                    {
                                                                        lineItemStatisticalCode = p.GetAttribute("value");
                                                                        if (lineItemStatisticalCode == "0")
                                                                            lineItemStatisticalCode = "";
                                                                        break;
                                                                    }
                                                            }
                                                        }

                                                        lineItem.StatisticalCode = lineItemStatisticalCode;
                                                        #endregion
                                                        endoCount++;
                                                    }
                                                }
                                            }
                                            // Add Additional Questions for Endorsement
                                            if (isSecondLevel)
                                            {
                                                agentNetAdditionalQuestions = new List<AGENTNET_ADDITIONAL_QUESTION>();
                                                agentNetAdditionalQuestions = BuildAddtionalQuestionReq(htmldoc, agentNetProductServiceId, count, "", lineItem.LineItemID);
                                                lineItem.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                                                if (agentNetAdditionalQuestions != null && agentNetAdditionalQuestions.Count > 0)
                                                    lineItem.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = agentNetAdditionalQuestions.ToArray();
                                            }
                                            productLineItemDetail.Add(lineItem);
                                        }
                                        pricingReq.AGENTNET_PRODUCT_LINEITEM_DETAILS = new AGENTNET_PRODUCT_LINEITEM_DETAILS();
                                        pricingReq.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL = productLineItemDetail.ToArray();
                                    }
                                }
                                // Add Additional Questions for Jacket
                                if (isSecondLevel)
                                {
                                    agentNetAdditionalQuestions = new List<AGENTNET_ADDITIONAL_QUESTION>();
                                    agentNetAdditionalQuestions = BuildAddtionalQuestionReq(htmldoc, agentNetProductServiceId, count, "JACKET", "");
                                    pricingReq.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                                    if (agentNetAdditionalQuestions != null && agentNetAdditionalQuestions.Count > 0)
                                        pricingReq.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = agentNetAdditionalQuestions.ToArray();
                                }

                                #region Product/Jacket Override details

                                isOverride = false;
                                overrideAmount = 0;
                                overrideReason = string.Empty;

                                StructOverride productOverrideAmountJacket = GetOverrideFields(agentNetProductServiceId, "", ProductTypeEnum.Jacket, htmldocRateFeePriceDetails, isDefault, ref isValidOverrideAmount);

                                isOverride = productOverrideAmountJacket.isOverride;
                                if (productOverrideAmountJacket.OverrideReason != null)
                                    overrideReason = productOverrideAmountJacket.OverrideReason;

                                overrideAmount = productOverrideAmountJacket.OverrideAmount;

                                pricingReq.IsOverride = isOverride;
                                pricingReq.OverrideAmount = overrideAmount;
                                if (overrideReason == "0")
                                    overrideReason = string.Empty;
                                pricingReq.OverrideReason = overrideReason;

                                #endregion
                                listPricingReq.Add(pricingReq);
                            }
                        }
                    }
                }
            }

            if (!isValidPolicyRelatedTo)
            {
                int LoanPolicyCount = listPricingReq.Count(i => String.Compare(i.PolicyCategory, "Loan") == 0);
                int OwnerPolicyCount = listPricingReq.Count(i => String.Compare(i.PolicyCategory, "Owner") == 0);

                if (listPricingReq.Count > m_StateSpecificMaxSimul ||
                   OwnerPolicyCount < 2 ||
                   LoanPolicyCount == 0 ||
                   isSimul == false)
                {
                    isValidPolicyRelatedTo = true;
                }
            }

            if (htmlCPLdoc != null)
            {
                listPricingCPLReq = BuildPricingReqForCPL(htmlCPLdoc, isDefault, htmldocRateFeePriceDetails, isSecondLevel, ref isValidOverrideAmount);

                if (listPricingCPLReq != null && listPricingCPLReq.Count() > 0)
                {
                    listPricingReq.AddRange(listPricingCPLReq);
                }

            }
            return listPricingReq;
        }

        public List<AGENTNET_PRODUCT_PRICING_REQUEST> BuildPricingReqForCPL(HtmlParser htmlCPLdoc, bool isDefault, HtmlParser htmlPricingDetails, bool isSecondLevel, ref bool isValidOverrideAmount)
        {

            List<AGENTNET_PRODUCT_PRICING_REQUEST> listPricingCPLReq = new List<AGENTNET_PRODUCT_PRICING_REQUEST>();


            string questonId = string.Empty;
            string answerType = string.Empty;
            string answerId = string.Empty;
            string answerText = string.Empty;

            List<ParsedHtml> elems = htmlCPLdoc.GetTABLEs();
            ParsedHtml htmlElement;
            foreach (ParsedHtml tableElem in elems)
            {
                AGENTNET_PRODUCT_PRICING_REQUEST pricingReq = new AGENTNET_PRODUCT_PRICING_REQUEST();
                List<AGENTNET_PRODUCT_LINEITEM_DETAIL> listLineItemDetails = new List<AGENTNET_PRODUCT_LINEITEM_DETAIL>();
                string strId = tableElem.GetAttribute("id");
                if (strId != null && strId.Length != 0)
                {
                    string[] productDetail = StringArrayId(strId); // TableName(0), Product(1), count(2), productId(3),productType (4), ServiceProductId(5)
                    if (productDetail[0].Contains("Product") && productDetail[0].Length > 4)
                    {
                        string count = productDetail[2];
                        string agentNetProductServiceId = productDetail[5];
                        pricingReq.ProductName = productDetail[1];
                        pricingReq.ProductType = productDetail[4];
                        pricingReq.ProductID = productDetail[3];
                        pricingReq.AgentNetProductServiceId = agentNetProductServiceId;

                        pricingReq.AGENTNET_PRODUCT_LINEITEM_DETAILS = new AGENTNET_PRODUCT_LINEITEM_DETAILS();

                        List<ParsedHtml> trElements = htmlCPLdoc.GetTRElements(tableElem);
                        int coveredPartyCount = 0;
                        foreach (ParsedHtml trElem in trElements)
                        {
                            AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail = new AGENTNET_PRODUCT_LINEITEM_DETAIL();

                            htmlElement = htmlCPLdoc.GetElementById(LBL_CVRD_PRTY + count + "_" + coveredPartyCount + "_" + agentNetProductServiceId);
                            if (htmlElement != null)
                            {
                                lineItemDetail.LineItemID = htmlElement.GetAttribute("for");
                                lineItemDetail.LineItemType = htmlElement.GetAttribute("title");
                                htmlElement = htmlCPLdoc.GetElementById(LBL_CPL_EFFCTV_DT + count + "_" + coveredPartyCount + "_" + agentNetProductServiceId);
                                if (htmlElement != null)
                                {
                                    string effectiveDate = htmlElement.GetAttribute("title");
                                    if (!string.IsNullOrEmpty(effectiveDate))
                                        pricingReq.EffectiveDate = Convert.ToDateTime(effectiveDate);
                                }
                                #region override options

                                bool isOverride = false;
                                decimal overrideAmount = 0;
                                string overrideReason = string.Empty;

                                if ((!isDefault) && htmlPricingDetails != null)
                                {
                                    List<ParsedHtml> element = htmlPricingDetails.GetTABLEs();
                                    foreach (ParsedHtml elem in element)
                                    {
                                        ParsedHtml htmlElem;
                                        string controlId = null;
                                        controlId = TXT_OVERRIDE_AMOUNT + lineItemDetail.LineItemID;
                                        htmlElem = htmlPricingDetails.GetElementById(controlId);
                                        if (htmlElem != null)
                                        {
                                            if (!string.IsNullOrEmpty(htmlElem.GetAttribute("value")))
                                            {
                                                try
                                                {
                                                    overrideAmount = Convert.ToDecimal(htmlElem.GetAttribute("value"));
                                                }
                                                catch (Exception)
                                                {
                                                    isValidOverrideAmount = false;
                                                }
                                            }
                                        }

                                        controlId = CBO_OVERRIDE_REASON + lineItemDetail.LineItemID;
                                        htmlElem = htmlPricingDetails.GetElementById(controlId);
                                        if (htmlElem != null)
                                        {
                                            List<ParsedHtml> options = htmlPricingDetails.GetOptionElements(htmlElem);
                                            foreach (ParsedHtml elementSel in options)
                                            {
                                                if (elementSel.GetAttributeBool("selected"))
                                                {
                                                    overrideReason = elementSel.GetAttribute("value");
                                                    if (overrideReason == "0")
                                                        overrideReason = String.Empty;
                                                    break;
                                                }
                                            }
                                        }

                                        if (isValidOverrideAmount && (overrideAmount >= 0 || !String.IsNullOrEmpty(overrideReason)))
                                        {
                                            controlId = "lblCalulatedPremium" + lineItemDetail.LineItemID;
                                            htmlElem = htmlPricingDetails.GetElementById(controlId);
                                            decimal CalculatedAmount = -1;
                                            if (htmlElem != null)
                                            {
                                                if (!string.IsNullOrEmpty(htmlElem.GetAttribute("data-value")))
                                                {
                                                    Decimal.TryParse(htmlElem.GetAttribute("data-value").ToString(), out CalculatedAmount);
                                                }
                                            }
                                            if ((CalculatedAmount >= 0 && CalculatedAmount != overrideAmount) ||
                                                (CalculatedAmount == overrideAmount && !String.IsNullOrEmpty(overrideReason)))
                                            {
                                                isOverride = true;
                                            }
                                        }
                                    }

                                    lineItemDetail.IsOverride = isOverride;
                                    lineItemDetail.OverrideAmount = overrideAmount;
                                    lineItemDetail.OverrideReason = overrideReason;
                                }

                                #endregion

                                htmlElement = htmlCPLdoc.GetElementById(TBL_ADD_QSTN_CPL + count + "_" + coveredPartyCount + "_" + agentNetProductServiceId);
                                if (htmlElement != null && isSecondLevel)
                                {
                                    List<ParsedHtml> trElementCol = htmlCPLdoc.GetTRElements(htmlElement);
                                    List<AGENTNET_ADDITIONAL_QUESTION> agentNetAdditionalQuestions = new List<AGENTNET_ADDITIONAL_QUESTION>();
                                    lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                                    int questionCount = 0;
                                    foreach (ParsedHtml trElemAQ in trElementCol)
                                    {
                                        AGENTNET_ADDITIONAL_QUESTION addQuest = new AGENTNET_ADDITIONAL_QUESTION();
                                        List<AGENTNET_ADDITIONAL_QUESTION_ANSWER> questAnswerList = new List<AGENTNET_ADDITIONAL_QUESTION_ANSWER>();

                                        addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS = new AGENTNET_ADDITIONAL_QUESTION_ANSWERS();

                                        if (trElemAQ.Attributes.Count > 0)
                                        {
                                            ParsedHtml htmlElemQA = htmlCPLdoc.GetElementById(LBL_CPL_ADD_QSTN + count + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetProductServiceId);

                                            string controlId = trElemAQ.GetAttribute("id");
                                            string[] arrayControlId = controlId.Split('_');
                                            string questType = arrayControlId[2];
                                            if (arrayControlId.Length > 3)
                                            {
                                                if (htmlElemQA != null)
                                                {
                                                    addQuest.QuestionID = htmlElemQA.GetAttribute("for");
                                                    addQuest.QuestionDescr = htmlElemQA.GetAttribute("title");
                                                    addQuest.QuestionType = questType;

                                                }

                                                htmlElemQA = htmlCPLdoc.GetElementById(DDL_CPL_ADD_QSTN + count + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetProductServiceId);
                                                if (htmlElemQA != null)
                                                {
                                                    List<ParsedHtml> htmlElemCol = htmlCPLdoc.GetOptionElements(htmlElemQA);
                                                    if (htmlElemCol.Count > 0)
                                                    {

                                                        foreach (ParsedHtml ansEle in htmlElemCol)
                                                        {
                                                            if (ansEle.GetAttributeBool("selected"))
                                                            {
                                                                AGENTNET_ADDITIONAL_QUESTION_ANSWER questAnswer = new AGENTNET_ADDITIONAL_QUESTION_ANSWER();
                                                                questAnswer.AnswerID = ansEle.GetAttribute("value");
                                                                questAnswer.AnswerDescr = ansEle.GetAttribute("title");
                                                                questAnswer.AnswerType = answerType;
                                                                string answerTypes = htmlElemQA.GetAttribute("name");
                                                                if (!string.IsNullOrEmpty(answerTypes))
                                                                {
                                                                    string[] answerTypeArry = answerTypes.Split('_');
                                                                    questAnswer.AnswerType = answerTypeArry[4];
                                                                    questAnswer.AnswerDataType = answerTypeArry[3];
                                                                }
                                                                questAnswerList.Add(questAnswer);
                                                                addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER = questAnswerList.ToArray();
                                                                agentNetAdditionalQuestions.Add(addQuest);
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    htmlElemQA = htmlCPLdoc.GetElementById(TXT_CPL_ADD_QSTN_ANS + count + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetProductServiceId);
                                                    if (htmlElemQA != null)
                                                    {
                                                        AGENTNET_ADDITIONAL_QUESTION_ANSWER questAnswer = new AGENTNET_ADDITIONAL_QUESTION_ANSWER();
                                                        questAnswer.AnswerDescr = htmlElemQA.GetAttribute("value");

                                                        string answerTypes = htmlElemQA.GetAttribute("name");
                                                        if (!string.IsNullOrEmpty(answerTypes))
                                                        {
                                                            string[] answerTypeArry = answerTypes.Split('_');
                                                            questAnswer.AnswerType = answerTypeArry[4];
                                                            questAnswer.AnswerDataType = answerTypeArry[3];
                                                        }
                                                        questAnswerList.Add(questAnswer);
                                                        addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER = questAnswerList.ToArray();
                                                        agentNetAdditionalQuestions.Add(addQuest);
                                                    }
                                                }

                                                questionCount++;
                                            }

                                        }

                                    }
                                    //Change 
                                    lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = agentNetAdditionalQuestions.ToArray();

                                }
                                listLineItemDetails.Add(lineItemDetail);
                                coveredPartyCount++;
                            }
                        }
                        pricingReq.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL = listLineItemDetails.ToArray();
                        listPricingCPLReq.Add(pricingReq);
                    }

                }

            }


            return listPricingCPLReq;
        }

        public DateTime GetJacketMinEffectiveDate(string strBuilderJacket, ref int policyCount)
        {
            HtmlParser htmldoc = new HtmlParser(strBuilderJacket.ToString());
            List<DateTime> EffectiveDates = new List<DateTime>();
            ParsedHtml htmlElem;
            if (htmldoc != null)
            {
                List<ParsedHtml> tables = htmldoc.GetTABLEs();
                foreach (ParsedHtml elem in tables)
                {
                    string strId = elem.GetAttribute("id");
                    if (strId != null && strId.Length != 0)
                    {
                        if (!(String.Compare(strId, TBL_SIMUL_CHECK, true) == 0))
                        {
                            string[] productDetail = StringArrayId(strId); // TableName(0), Product(1), count(2), productId(3), ServiceProductId(4), nonEJacketPolicyNumber(5)
                            if (productDetail[0].Contains("Product"))
                            {
                                string count = productDetail[2];
                                string agentNetProductServiceId = productDetail[4];

                                htmlElem = htmldoc.GetElementById(TXT_EFFCTV_DT + count + "_" + agentNetProductServiceId);
                                if (htmlElem != null)
                                    try
                                    {
                                        EffectiveDates.Add(htmlElem.GetAttributeDate("value"));
                                    }
                                    catch (Exception) { }
                                //Empty catch block to handle scenario where user manually removes of the effective date of any policy.
                                //Not an invalid scenario. This block acts similar as TryParse.
                            }
                        }
                    }
                }
            }
            policyCount = EffectiveDates.Count;
            if (EffectiveDates.Count == 0)
                return DateTime.Now;
            return EffectiveDates.Min();
        }

        public string[] StringArrayId(string controlId)
        {
            string[] productDetail = controlId.Split('_');
            return productDetail;
        }

        private List<AGENTNET_ADDITIONAL_QUESTION> BuildAddtionalQuestionReq(HtmlParser htmldoc, string agentNetProductServiceId, string count, string endoType, string endoId)
        {
            List<AGENTNET_ADDITIONAL_QUESTION> agentNetAdditionalQuestions = new List<AGENTNET_ADDITIONAL_QUESTION>();
            ParsedHtml htmlElem = htmldoc.GetElementById(TBL_ADD_QSTN + count + "_" + agentNetProductServiceId);
            if (htmlElem != null)
            {
                List<ParsedHtml> htmlTdElemCol = htmldoc.GetTRElements(htmlElem);
                if (htmlTdElemCol.Count > 0)
                {
                    int questionCount = 0;
                    foreach (ParsedHtml element in htmlTdElemCol)
                    {
                        AGENTNET_ADDITIONAL_QUESTION addQuest = new AGENTNET_ADDITIONAL_QUESTION();
                        string trId = element.GetAttribute("id");
                        string questionId = null;
                        string questionType = null;
                        string questionDescr = null;
                        string answerType = null;
                        string answerDataType = null;
                        if (!string.IsNullOrEmpty(trId) && (trId.Contains(TR_PR_SLCTD_ENDRSMNT_ADD_QSTN) || trId.Contains(TR_SLCTD_ENDRSMNT_ADD_QSTN)))
                        {
                            int ansCount = 0;
                            ParsedHtml elmt;
                            ParsedHtml htmlElement;
                            if (endoType == "JACKET")
                            {
                                elmt = htmldoc.GetElementById(LBL_JCKT_ADD_QSTN + count + "_" + questionCount + "_" + agentNetProductServiceId);
                                htmlElement = htmldoc.GetElementById(DDL_JCKT_ADD_QSTN + count + "_" + questionCount + "_" + agentNetProductServiceId);

                            }
                            else
                            {
                                elmt = htmldoc.GetElementById(LBL_SLCTD_ENDRSMNT_ADD_QSTN + count + "_" + questionCount + "_" + endoId + "_" + agentNetProductServiceId);
                                htmlElement = htmldoc.GetElementById(DDL_ENDRSMNT_ADD_QSTN + count + "_" + questionCount + "_" + endoId + "_" + agentNetProductServiceId);
                            }


                            if (elmt != null)
                            {
                                questionDescr = elmt.GetAttribute("title");
                                string strQuestionIdType = elmt.GetAttribute("for");
                                if (!string.IsNullOrEmpty(strQuestionIdType))
                                    questionId = strQuestionIdType.Substring(0, strQuestionIdType.LastIndexOf('_'));
                                if (!string.IsNullOrEmpty(strQuestionIdType))
                                    questionType = strQuestionIdType.Substring(strQuestionIdType.LastIndexOf('_') + 1);

                                addQuest.QuestionID = questionId;
                                addQuest.QuestionDescr = questionDescr;
                                addQuest.QuestionType = questionType;

                                List<AGENTNET_ADDITIONAL_QUESTION_ANSWER> questAnswerList = new List<AGENTNET_ADDITIONAL_QUESTION_ANSWER>();

                                addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS = new AGENTNET_ADDITIONAL_QUESTION_ANSWERS();

                                if (htmlElement != null)
                                {
                                    string answerTypes = htmlElement.GetAttribute("name");
                                    if (!string.IsNullOrEmpty(answerTypes))
                                    {
                                        string[] answerTypeArry = answerTypes.Split('_');
                                        answerType = answerTypeArry[3];
                                        if (!string.IsNullOrEmpty(answerTypeArry[2]))
                                            answerDataType = answerTypeArry[2];
                                    }
                                    List<ParsedHtml> htmlElemCol = htmldoc.GetOptionElements(htmlElement);
                                    if (htmlElemCol.Count > 0)
                                    {

                                        foreach (ParsedHtml ehtmlEle in htmlElemCol)
                                        {
                                            if (ehtmlEle.GetAttributeBool("selected"))
                                            {
                                                AGENTNET_ADDITIONAL_QUESTION_ANSWER questAnswer = new AGENTNET_ADDITIONAL_QUESTION_ANSWER();
                                                questAnswer.AnswerID = ehtmlEle.GetAttribute("value");
                                                questAnswer.AnswerDescr = ehtmlEle.GetAttribute("title");
                                                questAnswer.AnswerType = answerType;
                                                questAnswer.AnswerDataType = answerDataType;
                                                questAnswerList.Add(questAnswer);
                                                addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER = questAnswerList.ToArray();
                                                agentNetAdditionalQuestions.Add(addQuest);
                                                break;
                                            }
                                            ansCount++;
                                        }
                                    }
                                }
                                else
                                {
                                    htmlElement = htmldoc.GetElementById(TXT_JCKT_ADD_QSTN + count + "_" + questionCount + "_" + agentNetProductServiceId);
                                    if (endoType != "JACKET")
                                        htmlElement = htmldoc.GetElementById(TXT_ENDRSMNT_ADD_QSTN + count + "_" + questionCount + "_" + endoId + "_" + agentNetProductServiceId);
                                    if (htmlElement != null)
                                    {
                                        AGENTNET_ADDITIONAL_QUESTION_ANSWER questAnswer = new AGENTNET_ADDITIONAL_QUESTION_ANSWER();
                                        questAnswer.AnswerDescr = htmlElement.GetAttribute("value");
                                        string answerTypes = htmlElement.GetAttribute("name");
                                        if (!string.IsNullOrEmpty(answerTypes))
                                        {
                                            string[] answerTypeArry = answerTypes.Split('_');
                                            questAnswer.AnswerType = answerTypeArry[3];
                                            questAnswer.AnswerDataType = answerTypeArry[2];
                                        }

                                        questAnswerList.Add(questAnswer);
                                        addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER = questAnswerList.ToArray();

                                        ansCount++;
                                        agentNetAdditionalQuestions.Add(addQuest);
                                    }
                                }
                            }
                            questionCount++;
                        }
                    }
                }
            }
            return agentNetAdditionalQuestions;
        }

        #endregion

        #region Build Rates & Fees Controls.
        public string BuildRateFeeJacketControls(string stateCode, string underWriterCode, string officeId, List<JacketDetail> jacketDetails, SERVICE prePriceRequest, string County, string accountNumuber, string businessSegment, DateTime rateEffectiveDate)
        {
            m_PrePriceRequest = prePriceRequest; // this is the pre-pricing request if there was any 
            List<JacketDetail> productsDetails = jacketDetails;
            StringBuilder strBuldrRF = new StringBuilder();
            StringBuilder strBuldrRateEffectiveDateId = new StringBuilder();
            string rateEffectiveDateStr = rateEffectiveDate.ToShortDateString();
            try
            {
                bool isExtendedCoverage = false;
                //bool isRateEffecticeDateAdded = false;
                strBuldrRF.Append("<HTML><BODY><P>");
                int totalJacketCount = productsDetails.Count();
                int count = 0;
                string sreSimultaneous = "";
                int PrepricingCount = 0;

                String MinEffDate = productsDetails.Min(i => i.EffectiveDate);
                foreach (JacketDetail productsDetail in productsDetails)
                {
                    if (String.IsNullOrEmpty(productsDetail.AgentNetPolicyNumber) &&
                        String.IsNullOrEmpty(productsDetail.NonEJacletPolicyNumber))
                        PrepricingCount++;
                }
                if (PrepricingCount == productsDetails.Count)
                    m_IsPrePricing = true;
                m_getDataResponse = GetPolicySimulCountByState(stateCode, MinEffDate, officeId);
                if (m_getDataResponse != null &&
                    m_getDataResponse.AGENTNET_NAME_VALUES != null &&
                    m_getDataResponse.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null &&
                    m_getDataResponse.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
                {
                    foreach (AGENTNET_NAME_VALUE nv in m_getDataResponse.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE)
                    {
                        if (String.Compare(nv.Name, AgentNetNameValueEnum.MaxSimultaneousPolicyCount.ToString(), true) == 0)
                        {
                            Int32.TryParse(nv.Value, out m_StateSpecificMaxSimul);
                            if (m_StateSpecificMaxSimul == 0)
                                m_StateSpecificMaxSimul = 2;
                            break;
                        }
                    }
                }
                if (productsDetails.Count > 1 && productsDetails.Count <= m_StateSpecificMaxSimul)
                    sreSimultaneous = "CHECKED";

                SetOwnerPoliciesForMap(productsDetails);

                sreSimultaneous = m_IsPrePricing ? GetPrepricingSimultaneous(sreSimultaneous) : sreSimultaneous;

                //strBuldrRF.Append(BuildSimultaneousCheckbox(productsDetails.Count, sreSimultaneous));

                if (productsDetails.Count > 1 && productsDetails.Count <= m_StateSpecificMaxSimul)
                    strBuldrRF.Append("<table id=\"" + TBL_SIMUL_CHECK + "\" style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr> <td> <input id=\"" + CHK_SMULTNS + "\" type=\"checkbox\" name = \"Price as Simultanious?\" checked=\"" + sreSimultaneous + "\"  /> Price as Simultaneous? </td></tr></table>");
                else
                    strBuldrRF.Append("<table id=\"" + TBL_SIMUL_CHECK + "\" style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr> <td> <input id=\"" + CHK_SMULTNS + "\" type=\"checkbox\" name = \"Price as Simultanious?\" disabled=\"disabled\"  /> Price as Simultaneous? </td></tr></table>");

                foreach (JacketDetail prod in productsDetails)
                {
                    string productName = prod.ProductName;
                    string productId = Convert.ToString(prod.AgentNetProductId);
                    string productType = prod.ProductName;
                    string LiabilityAmount = FormatDollar(prod.LiabilityAmount);
                    string agentNetServiceId = Convert.ToString(prod.AgentNetFileServiceJacketId);
                    string effectiveDate = Convert.ToString(prod.EffectiveDate);
                    string effDate = Convert.ToDateTime(effectiveDate).ToShortDateString();
                    if (!rateEffectiveDateStr.Equals(effDate))
                    {
                        effectiveDate = rateEffectiveDateStr;
                        effDate = rateEffectiveDateStr;
                    }
                    m_getDataResponse = GetJacketRateType(productId, stateCode, underWriterCode, effectiveDate, LiabilityAmount, agentNetServiceId, false, ProductTypeEnum.Jacket, officeId, County, accountNumuber, businessSegment);
                    //if (!isRateEffecticeDateAdded)
                    //{
                    //    strBuldrRateEffectiveDateId.Append(agentNetServiceId);
                    //    isRateEffecticeDateAdded = true;
                    //}
                    //else
                    //    strBuldrRateEffectiveDateId.Append("_" + agentNetServiceId);

                    #region HTML Builder

                    strBuldrRF.Append("<table  id=\"" + TBL_JCKT + count + "_" + productId + "_" + agentNetServiceId + "_" + prod.NonEJacletPolicyNumber + "\"  style=\"font-family:Microsoft Sans Serif; font-size:12px;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");

                    strBuldrRF.Append("<tr><td>" + prod.PolicySequence + "</td></tr>");
                    if (productsDetails.Count > 1 && productsDetails.Count <= m_StateSpecificMaxSimul)
                        strBuldrRF.Append(" <tr> <td colspan = \"9\"> <table style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr>");
                    else
                        strBuldrRF.Append(" <tr> <td colspan = \"9\"> <table style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr>");
                    strBuldrRF.Append(BuildExtendedCoverage(agentNetServiceId, ref isExtendedCoverage, count));
                    strBuldrRF.Append("<tr> <td> Policy Type:  </td> ");

                    strBuldrRF.Append("<td>  <label title=" + "'" + productType + "'" + "style=\"width:210px\" id=\"" + LBL_PLCY_TYP + count + "_" + agentNetServiceId + "\" >" + productType + "</label>  </td> ");
                    string prepriceRateType = GetPrepricingRateType(productId);
                    strBuldrRF.Append(BuildRateType(productId, effDate, LiabilityAmount, agentNetServiceId, isExtendedCoverage, count, stateCode, underWriterCode, officeId, prepriceRateType, County, accountNumuber, businessSegment));

                    strBuldrRF.Append("<td>&nbsp;  Liability Amount:  </td> ");
                    strBuldrRF.Append("<td>  <input type=\"text\" style=\"width:100px\" id=\"" + TXT_LBLTY_AMNT + count + "_" + agentNetServiceId + "\"  value=" + "'" + LiabilityAmount + "'" + "/>  </td> ");
                    strBuldrRF.Append("<td>&nbsp;  Date of Policy: </td> ");
                    if (Convert.ToDateTime(effDate) == DateTime.MinValue)
                        effDate = null;
                    strBuldrRF.Append("<td>  <input type=\"text\"  name =\"" + TXT_EFFCTV_DT + count + "_" + productId + "_" + agentNetServiceId + "\" title=\"mm/dd/yyyy\" style=\"width:100px\" id=\"" + TXT_EFFCTV_DT + count + "_" + agentNetServiceId + "\" value=" + "'" + effDate + "'" + "/>  </td> ");
                    strBuldrRF.Append("<%--" + PRR_PLCY_NMBR + count + "_" + agentNetServiceId + "--%>");
                    strBuldrRF.Append("<td style='display:none'><label style='display:none' id = '" + LBL_POLICY_CATEGORY + agentNetServiceId + "' title = '" + prod.PolicyCategory + "'>" + prod.PolicyCategory + "</label></td>");

                    if ((String.Compare(prod.PolicyCategory, "Loan", true) == 0) &&
                        m_MapOwnersToLoans != null &&
                        m_MapOwnersToLoans.Count >= 2)
                    {
                        bool isSimul = (String.Compare(sreSimultaneous, "CHECKED", true) == 0);
                        strBuldrRF.Append(BuildPolicyRelatedTo(prod.AgentNetFileServiceJacketId, !isSimul));
                    }

                    strBuldrRF.Append("<tr> <td> Endorsements:  </td> ");
                    strBuldrRF.Append(" <td colspan = \"8\">&nbsp; <a href=\"" + LNK_LBL_ADD_RMV_ENDRSMNT + count + "_" + agentNetServiceId + "\"  id=\"endorsementLink_" + count + "_" + agentNetServiceId + "\"> Add/Remove Endorsements </a> </td> </tr>");
                    List<JacketEndorsement> preSelJacketEndorsement = new List<JacketEndorsement>();
                    JacketDetail prodDetail = jacketDetails.Where(p => p.AgentNetFileServiceJacketId.Equals(Convert.ToInt32(agentNetServiceId))).FirstOrDefault();
                    if (prodDetail.JacketEndorsement != null)
                    {
                        preSelJacketEndorsement = prodDetail.JacketEndorsement.ToList();
                    }

                    string preSelLineItem = BuildPreSelLineItem(agentNetServiceId, count, preSelJacketEndorsement);
                    if (!string.IsNullOrEmpty(preSelLineItem))
                    {
                        strBuldrRF.Append(preSelLineItem);
                    }
                    strBuldrRF.Append("<%--" + ENDRSMNT + LNK_LBL_ADD_RMV_ENDRSMNT + count + "_" + agentNetServiceId + "--%>");
                    strBuldrRF.Append("<%--" + ADD_QSTN + count + "_" + agentNetServiceId + "--%>");

                    #endregion

                    count++;

                    strBuldrRF.Append("</tr></table>");
                    if (totalJacketCount > 1)
                        strBuldrRF.Append("<p><hr  color=\"black\"></p>");
                    else
                        strBuldrRF.Append("<p></p>");
                }
                //strBuldrRF.Append("<table style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr> <td>  Rate Effective Date: </td>");
                //strBuldrRF.Append("<td>  <input type=\"text\"  name =\"" + TXT_RATE_EFFCTV_DT + "\" title=\"mm/dd/yyyy\" style=\"width:100px\" id=\"" + strBuldrRateEffectiveDateId + "\" />  </td> ");
                //strBuldrRF.Append("</tr></table>");
                strBuldrRF.Append("</P></BODY></HTML>");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strBuldrRF.ToString();
        }

        private string BuildPreSelLineItem(string agentNetServiceId, int policyCount, List<JacketEndorsement> preSelectedLineItemDetails)
        {
            string preSelLineItemControlsHTML = null;
            int amount = 0;
            AGENTNET_PRICING_ENDORSEMENT[] pricingEndorsments = (AGENTNET_PRICING_ENDORSEMENT[])m_JacketPricingEndorsementColl[agentNetServiceId];
            List<AGENTNET_PRODUCT_LINEITEM_DETAIL> PreSelLineItem = null;
            PreSelLineItem = new List<AGENTNET_PRODUCT_LINEITEM_DETAIL>();

            if (pricingEndorsments != null && pricingEndorsments.Count() > 0)
            {
                int endoCount = 0;
                foreach (AGENTNET_PRICING_ENDORSEMENT pricingEndorsement in pricingEndorsments)
                {
                    int endorsementCount = 0;
                    if (!string.IsNullOrEmpty(pricingEndorsement.ClientEndorCode) && pricingEndorsement.ClientEndorCode.Contains(","))
                    {
                        string[] vendorEndorsementIds = pricingEndorsement.ClientEndorCode.ToLower().Split(',');
                        foreach (string vendorEndorsementId in vendorEndorsementIds)
                        {
                            endorsementCount = preSelectedLineItemDetails.Where(p => p.EndorsementCode.ToLower() == vendorEndorsementId.Trim()).Count();
                            if (endorsementCount > 0)
                                break;
                        }

                    }
                    else
                    {
                        endorsementCount = preSelectedLineItemDetails.Where(p => p.EndorsementCode.ToLower() == pricingEndorsement.ClientEndorCode.ToLower().Trim()).Count();
                    }
                    if (endorsementCount == 0)
                    {
                        // Below logic isstrictly for the way Simulator was coded where if the p.EndorsementCode begins withe  "~", it is a AgentNet endorsement retrieved during pre-pricing
                        foreach (JacketEndorsement je in preSelectedLineItemDetails)
                        {
                            if (je.EndorsementCode != null && je.EndorsementCode.Length > 0 && je.EndorsementCode[0] == '~')
                            {
                                string agentnetCode = je.EndorsementCode.Substring(1);
                                if (agentnetCode == pricingEndorsement.AgentNetEndorCode)
                                {
                                    endorsementCount = 1;
                                    break;
                                }
                            }
                        }
                    }
                    if (endorsementCount > 0 || pricingEndorsement.IsPreSelected)
                    {
                        preSelLineItemControlsHTML += "<tr> <td id=\"" + TD_ENDRSMNT + policyCount + "_" + endoCount + "_" + "Endorsement\"> <label id=\"" + LBL_ENDRSMNT + policyCount + "_" + endoCount + "_" + agentNetServiceId + "\" style=\"width:300px\" for=\"" + pricingEndorsement.AgentNetEndorCode + "_" + amount + "\">" + pricingEndorsement.EndorsementName + "</label>  </td> </tr>";
                        endoCount++;
                        AGENTNET_PRODUCT_LINEITEM_DETAIL lineItem = new AGENTNET_PRODUCT_LINEITEM_DETAIL();
                        lineItem.LineItemID = pricingEndorsement.AgentNetEndorCode;
                        lineItem.LineItemType = "Endorsement";
                        lineItem.LineItemDescr = pricingEndorsement.EndorsementName;
                        PreSelLineItem.Add(lineItem);
                    }
                }

                if (!string.IsNullOrEmpty(preSelLineItemControlsHTML))
                    preSelLineItemControlsHTML = "<tr> <td colspan = \"11\"> <table style=\"font-family:Microsoft Sans Serif; font-size:12px;\" id=\"" + TBL_ENDRSMNT + policyCount + "_" + agentNetServiceId + "\">" + preSelLineItemControlsHTML + "</table></td> </tr>";
                if (PreSelLineItem.Count > 0)
                {
                    if (ChekedOrSelectedEndorsements == null)
                        ChekedOrSelectedEndorsements = new Hashtable();
                    if (ChekedOrSelectedEndorsements.ContainsKey(agentNetServiceId))
                        ChekedOrSelectedEndorsements.Remove(agentNetServiceId);
                    ChekedOrSelectedEndorsements.Add(agentNetServiceId, PreSelLineItem);
                }
            }

            return preSelLineItemControlsHTML;
        }

        private string BuildExtendedCoverage(string agentNetServiceId, ref bool isExtendedCoverage, int count)
        {
            bool extendedCoverageVisibility = false;
            bool disableextended = false;
            string extendedCoverageHTML = " <td colspan = \"0\"> <input id=\"" + CHK_EXTNDD_CVRG + count + "_" + agentNetServiceId + "\" type=\"checkbox\" name = \"ExtendedCoverage_" + count + "_" + agentNetServiceId + "\" style=\"display:none;\" /> <label  for=\"lblPolicyType_" + count + "\" style=\"display:none;\"> ExtendedCoverage </label> </td> </tr></td></tr></table>";
            if (m_getDataResponse != null && m_getDataResponse.AGENTNET_NAME_VALUES != null && m_getDataResponse.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null && m_getDataResponse.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Count() > 0)
            {
                foreach (AGENTNET_NAME_VALUE extednde in m_getDataResponse.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE)
                {
                    if (extednde.Name.Equals("CheckBoxExtendedCoverage") && extednde.Value.Equals("true"))
                    {
                        extendedCoverageVisibility = true;
                    }
                    if (extednde.Name.Equals("IsExtendedCoverage") && extednde.Value.Equals("true"))
                    {
                        disableextended = true;
                    }
                }
                if (extendedCoverageVisibility)
                {
                    extendedCoverageHTML = "<td colspan = \"0\"> <input id=\"" + CHK_EXTNDD_CVRG + count + "_" + agentNetServiceId + "\"  type=\"checkbox\" name = \"ExtendedCoverage_" + count + "_" + agentNetServiceId + "\" /> <label  for=\"lblPolicyType_" + count + "_" + agentNetServiceId + "\"> ExtendedCoverage </label> </td> </tr></td></tr></table>";
                    isExtendedCoverage = true;
                }

                else
                    extendedCoverageHTML = " <td colspan = \"0\"> <input id=\"" + CHK_EXTNDD_CVRG + count + "_" + agentNetServiceId + "\" type=\"checkbox\" name = \"ExtendedCoverage_" + count + "_" + agentNetServiceId + "\" style=\"display:none;\"  /> <label  for=\"lblPolicyType_" + count + "_" + agentNetServiceId + "\" style=\"display:none;\"> ExtendedCoverage </label> </td> </tr></td></tr></table>";

                if (disableextended)
                {
                    extendedCoverageHTML = " <td colspan = \"0\"> <input id=\"" + CHK_EXTNDD_CVRG + count + "_" + agentNetServiceId + "\" type=\"checkbox\" name = \"ExtendedCoverage_" + count + "_" + agentNetServiceId + "\" disabled=\"disabled\" checked=\"checked\" /> <label  for=\"lblPolicyType_" + count + "_" + agentNetServiceId + "\"> ExtendedCoverage </label> </td> </tr></td></tr></table>";
                    isExtendedCoverage = true;
                }


            }
            return extendedCoverageHTML;
        }

        public string BuildPolicyRelatedTo(int productServiceId, bool isNonSimultaneous = false)
        {
            String policyRelatedToHTML = String.Empty;
            String showHideRow = isNonSimultaneous ? " style = \"display:none\" " : " style=\"display:\"";
            policyRelatedToHTML = "<tr id=\"" + TR_POLICY_RELATED_TO + productServiceId + "\"" + showHideRow + "> <td>Policy Related To: </td>";

            if (m_MapOwnersToLoans != null && m_MapOwnersToLoans.Count > 0)
            {
                policyRelatedToHTML += "<td  id=\"" + TD_POLICY_RELATED_TO + productServiceId + "\" colspan=\"6\">";
                policyRelatedToHTML += "<select style=\"width:130px\" id=\"" + DDL_POLICY_RELATED_TO + productServiceId + "\">";

                policyRelatedToHTML += "<option value='0' title='---Select---'> ---Select---  </option>";

                foreach (KeyValuePair<int, String> ownerPolicy in m_MapOwnersToLoans)
                {
                    policyRelatedToHTML += "<option value='" + ownerPolicy.Key + "' title='" + ownerPolicy.Value + "'>" + ownerPolicy.Value + "</option>";
                }
                policyRelatedToHTML += "</select> (Required- must indicate which Owner policy Loan policy is related to.) </td>";
            }
            else
                policyRelatedToHTML += "<td></select> </td>";
            return policyRelatedToHTML;
        }

        public string BuildSimultaneousCheckbox(Boolean isSimul)
        {
            if (isSimul)
                return "<table id=\"" + TBL_SIMUL_CHECK + "\" style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr> <td> <input id=\"" + CHK_SMULTNS + "\" type=\"checkbox\" name = \"Price as Simultanious?\" checked=\"CHECKED\"  /> Price as Simultaneous? </td></tr></table>";
            else
                return "<table id=\"" + TBL_SIMUL_CHECK + "\" style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr> <td> <input id=\"" + CHK_SMULTNS + "\" type=\"checkbox\" name = \"Price as Simultanious?\" disabled=\"disabled\"  /> Price as Simultaneous? </td></tr></table>";
        }

        public string BuildRateType(string productId, string effectiveDate, string LiabilityAmount, string agentNetServiceId, bool isExtendedCoverage, int count, string stateCode, string underWriterCode, string officeId, string prepriceRateType, string County, string accountNumuber, string businessSegment)
        {
            string rateTypeHTML = null;
            AGENTNET_TYPE_DATA[] typeDatas = null;
            m_getDataResponse = GetJacketRateType(productId, stateCode, underWriterCode, effectiveDate, LiabilityAmount, agentNetServiceId, isExtendedCoverage, ProductTypeEnum.Jacket, officeId, County, accountNumuber, businessSegment);
            if (m_getDataResponse != null && m_getDataResponse.AGENTNET_TYPE_DATAS != null)
                typeDatas = m_getDataResponse.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA;

            rateTypeHTML = "<td id=\"" + TD_RT_TYP_NM + count + "_" + agentNetServiceId + "\"> &nbsp; Rate Type: </td>";
            rateTypeHTML += "<td></td> <td id=\"" + TD_RT_TYP + count + "_" + agentNetServiceId + "\"> <select style=\"width:130px\" id=\"" + DDL_RT_TYP + count + "_" + agentNetServiceId + "\">";
            rateTypeHTML += "<option value='0' title='---Select---'> ---Select---  </option>";
            if (typeDatas != null)
            {
                foreach (AGENTNET_TYPE_DATA typeDataItem in typeDatas)
                {
                    if (typeDataItem.TypeId == prepriceRateType)
                        rateTypeHTML += "<option value='" + typeDataItem.TypeId + "' title='" + typeDataItem.Description + "' SELECTED>" + typeDataItem.Description + "</option>";
                    else
                        rateTypeHTML += "<option value='" + typeDataItem.TypeId + "' title='" + typeDataItem.Description + "'>" + typeDataItem.Description + "</option>";
                }
                rateTypeHTML += "</select> </td>";
            }
            else
                rateTypeHTML += "</select> </td>";
            return rateTypeHTML;
        }

        public string BuildPriorPolicy(string agentNetServiceId, int count)
        {
            string priorPolicyControlHTML = "<tr id=\"" + TR_PRR_PLCY_NMBR + count + "_" + agentNetServiceId + "\"><td colspan = \"0\">Prior Policy Number:</td><td colspan = \"8\"> &nbsp; <input type=\"text\"  style=\"width:100px\" id=\"" + TXT_PRR_PLCY_NMBR + count + "_" + agentNetServiceId + "\" value=\"\"/></td></tr>";
            return priorPolicyControlHTML;
        }

        public string BuildEndorsment(string agentNetServiceId, int policyCount, StringBuilder strBuilderRF)
        {
            string endorsmentControlHTML = null;
            AGENTNET_PRICING_ENDORSEMENT[] pricingEndorsments = (AGENTNET_PRICING_ENDORSEMENT[])m_JacketPricingEndorsementColl[agentNetServiceId];
            if (ChekedOrSelectedEndorsements.ContainsKey(agentNetServiceId))
            {
                List<AGENTNET_PRODUCT_LINEITEM_DETAIL> lineItemDetail = (List<AGENTNET_PRODUCT_LINEITEM_DETAIL>)ChekedOrSelectedEndorsements[agentNetServiceId];
                if (lineItemDetail != null)
                {

                    if (lineItemDetail.Count > 0)
                    {
                        int endoCount = 0;
                        foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemEndo in lineItemDetail)
                        {
                            if (!strBuilderRF.ToString().Contains(LBL_ENDRSMNT + policyCount + "_" + agentNetServiceId + "_" + lineItemEndo.LineItemID))
                                endorsmentControlHTML += "<tr> <td colspan = \"11\" id=\"" + TD_ENDRSMNT + policyCount + "_" + endoCount + "_" + lineItemEndo.LineItemType + "\"> <label id=\"" + LBL_ENDRSMNT + policyCount + "_" + endoCount + "_" + agentNetServiceId + "\" style=\"width:300px\" for=\"" + lineItemEndo.LineItemID + "_" + lineItemEndo.MiscEndorsmentAmount + "\" title=\"" + lineItemEndo.LineItemDescr + "\">" + lineItemEndo.LineItemDescr + "</label></td></tr>";
                            endoCount++;
                        }
                        if (!string.IsNullOrEmpty(endorsmentControlHTML))
                            endorsmentControlHTML = "<tr> <td colspan = \"11\"> <table style=\"font-family:Microsoft Sans Serif; font-size:12px;\" id=\"" + TBL_ENDRSMNT + policyCount + "_" + agentNetServiceId + "\">" + endorsmentControlHTML + "</table></td> </tr>";
                    }
                }
            }

            return endorsmentControlHTML;
        }

        public string BuildAdditionalQuestion(List<AGENTNET_PRODUCT_LINEITEM_DETAIL> productLineItemDetail, AGENTNET_ADDITIONAL_QUESTION[] additionalQuestions, string agentNetServiceId, int policyCount, string policyType, AGENTNET_PRODUCT_PRICING_REPONSE productResponse)
        {
            string additionalQuestionHTML = null;
            try
            {

                if ((additionalQuestions != null && additionalQuestions.Length > 0) || (productLineItemDetail != null && productLineItemDetail.Count > 0))
                {
                    additionalQuestionHTML = "<table id=\"" + TBL_ADD_QSTN + policyCount + "_" + agentNetServiceId + "\" style=\"font-family:Microsoft Sans Serif; font-size:12px;border-width:thin; border-color:Black;\" border = \"1\" >";
                    if (additionalQuestions != null && additionalQuestions.Length > 0)
                    {
                        additionalQuestionHTML += "<tr  id=\"" + TR_PR_SLCTD_ENDRSMNT + policyCount + "_" + agentNetServiceId + "\"><td colspan = \"2\" style=\"font-weight:bold;\"> <label id=\"" + LBL_JCK_ADD_QSTNT_NM + policyCount + "_" + agentNetServiceId + "\" style=\"width:300px\"  title=\"" + policyType + "\">" + policyType + "</label></td></tr>";
                        int questionCount = 0;
                        foreach (AGENTNET_ADDITIONAL_QUESTION additionalQuest in additionalQuestions)
                        {
                            string prePriceAnswer = GetPrepricingQuestionAnswer(additionalQuest, null, productResponse);
                            if (additionalQuest.QuestionType.ToLower().Equals("others"))
                            {
                                additionalQuestionHTML += "<tr id=\"" + TR_PR_SLCTD_ENDRSMNT_ADD_QSTN + policyCount + "_" + agentNetServiceId + "\"><td> <label id=\"" + LBL_JCKT_ADD_QSTN + policyCount + "_" + questionCount + "_" + agentNetServiceId + "\"   for=\"" + additionalQuest.QuestionID + "_" + additionalQuest.QuestionType + "\"  title=\"" + additionalQuest.QuestionDescr + "\">" + additionalQuest.QuestionDescr + "</label></td>";
                            }
                            int ansCount = 0;
                            foreach (AGENTNET_ADDITIONAL_QUESTION_ANSWER additionalAns in additionalQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER)
                            {
                                if (additionalAns != null)
                                {
                                    if (additionalAns.AnswerType.ToLower() == "options")
                                    {
                                        if (ansCount == 0)
                                        {
                                            additionalQuestionHTML += "<td> <select style=\"width:130px\" id=\"" + DDL_JCKT_ADD_QSTN + policyCount + "_" + questionCount + "_" + agentNetServiceId + "\"  name=\"" + policyCount + "_" + questionCount + "_" + additionalAns.AnswerDataType + "_" + additionalAns.AnswerType + "\">";
                                        }
                                        if (prePriceAnswer == additionalAns.AnswerID)
                                            additionalQuestionHTML += "<option value='" + additionalAns.AnswerID + "' title='" + additionalAns.AnswerDescr + "' SELECTED >" + additionalAns.AnswerDescr + "</option>";
                                        else
                                            additionalQuestionHTML += "<option value='" + additionalAns.AnswerID + "' title='" + additionalAns.AnswerDescr + "'>" + additionalAns.AnswerDescr + "</option>";
                                    }
                                    if (additionalAns.AnswerType.ToLower() == "text")
                                    {
                                        additionalQuestionHTML += "<td><input type=\"text\" style=\"width:100px\" id=\"" + TXT_JCKT_ADD_QSTN + policyCount + "_" + questionCount + "_" + agentNetServiceId + "\"  value=\"" + additionalAns.AnswerDescr + "\"  name=\"" + policyCount + "_" + questionCount + "_" + additionalAns.AnswerDataType + "_" + additionalAns.AnswerType + "\"/>";
                                    }
                                }
                                ansCount++;
                            }
                            additionalQuestionHTML += "</td></tr>";
                            questionCount++;
                        }
                    }
                    if (productLineItemDetail != null && productLineItemDetail.Count > 0)
                    {
                        foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemAdditionalQuestion in productLineItemDetail)
                        {
                            //Bind the Additional Questions. 
                            if (lineItemAdditionalQuestion.AGENTNET_ADDITIONAL_QUESTIONS != null && lineItemAdditionalQuestion.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION != null)
                            {
                                additionalQuestionHTML += "<tr id=\"" + TR_SLCTD_ENDRSMNT + policyCount + "_" + agentNetServiceId + "\" ><td colspan = \"2\" style=\"font-weight:bold;\"> <label id=\"lblSeletedEndo_" + policyCount + "_" + agentNetServiceId + "\" style=\"width:300px\"  title='" + lineItemAdditionalQuestion.LineItemID + "'>" + lineItemAdditionalQuestion.LineItemDescr + "</label></td></tr>";
                                int questionCount = 0;
                                foreach (AGENTNET_ADDITIONAL_QUESTION additionalQuestion in lineItemAdditionalQuestion.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION)
                                {// Change 
                                    string prePriceAnswer = GetPrepricingQuestionAnswer(additionalQuestion, lineItemAdditionalQuestion, productResponse);
                                    if (additionalQuestion.QuestionType.ToLower().Equals("others"))
                                    {
                                        additionalQuestionHTML += "<tr id=\"" + TR_SLCTD_ENDRSMNT_ADD_QSTN + policyCount + "_" + lineItemAdditionalQuestion.LineItemID + "_" + agentNetServiceId + "\"><td> <label id=\"" + LBL_SLCTD_ENDRSMNT_ADD_QSTN + policyCount + "_" + questionCount + "_" + lineItemAdditionalQuestion.LineItemID + "_" + agentNetServiceId + "\"   for =\"" + additionalQuestion.QuestionID + "_" + additionalQuestion.QuestionType + "\"  title=\"" + additionalQuestion.QuestionDescr + "\">" + additionalQuestion.QuestionDescr + "</label></td>";
                                    }
                                    if (additionalQuestion.AGENTNET_ADDITIONAL_QUESTION_ANSWERS != null && additionalQuestion.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER != null)
                                    {
                                        int ansCount = 0;
                                        foreach (AGENTNET_ADDITIONAL_QUESTION_ANSWER additionalQuestionAnswer in additionalQuestion.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER)
                                        {
                                            if (additionalQuestionAnswer != null)
                                            {
                                                if (additionalQuestionAnswer.AnswerType.ToLower() == "options")
                                                {
                                                    if (ansCount == 0)
                                                    {
                                                        additionalQuestionHTML += "<td> <select style=\"width:130px\" id=\"" + DDL_ENDRSMNT_ADD_QSTN + policyCount + "_" + questionCount + "_" + lineItemAdditionalQuestion.LineItemID + "_" + agentNetServiceId + "\" name=\"" + policyCount + "_" + questionCount + "_" + additionalQuestionAnswer.AnswerDataType + "_" + additionalQuestionAnswer.AnswerType + "\">";
                                                    }
                                                    if (prePriceAnswer == additionalQuestionAnswer.AnswerID)
                                                        additionalQuestionHTML += "<option value='" + additionalQuestionAnswer.AnswerID + "' title='" + additionalQuestionAnswer.AnswerDescr + "' SELECTED >" + additionalQuestionAnswer.AnswerDescr + "</option>";
                                                    else
                                                        additionalQuestionHTML += "<option value='" + additionalQuestionAnswer.AnswerID + "' title='" + additionalQuestionAnswer.AnswerDescr + "'>" + additionalQuestionAnswer.AnswerDescr + "</option>";
                                                }
                                                if (additionalQuestionAnswer.AnswerType.ToLower() == "text")
                                                {
                                                    additionalQuestionHTML += "<td><input type=\"text\" style=\"width:100px\" id=\"" + TXT_ENDRSMNT_ADD_QSTN + policyCount + "_" + questionCount + "_" + lineItemAdditionalQuestion.LineItemID + "_" + agentNetServiceId + "\"  value=\"" + additionalQuestionAnswer.AnswerDescr + "\" name=\"" + policyCount + "_" + questionCount + "_" + additionalQuestionAnswer.AnswerDataType + "_" + additionalQuestionAnswer.AnswerType + "\"/>";
                                                }
                                            }

                                            ansCount++;
                                        }
                                        additionalQuestionHTML += "</td></tr>";
                                        questionCount++;
                                    }
                                }

                            }
                        }
                    }
                    additionalQuestionHTML += "</table>";
                    additionalQuestionHTML = "<p id=\"" + P_ADD_QSTN + policyCount + "_" + agentNetServiceId + "\"></p><tr id=\"" + TR_ADD_QSTN + policyCount + "_" + agentNetServiceId + "\"><td valign=\"top\">Additional Question:  </td><td colspan = \"9\" >" + additionalQuestionHTML + "</td></tr>";
                }
                if (!string.IsNullOrEmpty(additionalQuestionHTML))
                {
                    if (!(additionalQuestionHTML.Contains(TR_PR_SLCTD_ENDRSMNT) || additionalQuestionHTML.Contains(TR_SLCTD_ENDRSMNT)))
                        additionalQuestionHTML = null;
                }
            }
            catch (Exception ex)
            {
                additionalQuestionHTML = null;
            }
            return additionalQuestionHTML;
        }

        public void ClearControl(string agentNetServiceId, int count, ref StringBuilder origHtmlContent, string controlName)
        {
            string actualContent = "";

            try
            {
                string newContent = null;
                string controlID = controlName + count + "_" + agentNetServiceId;
                if (newContent == null)
                    newContent = "";

                string origHtml = origHtmlContent.ToString();
                int startIndex = -1, endIndex = -1, curPos = -1, closeStartIndex;
                string controlHtml = "", controlTag = "";

                curPos = origHtml.IndexOf("\"" + controlID + "\"");
                if (curPos == -1)
                    curPos = origHtml.IndexOf(controlID);
                if (curPos != -1)
                {
                    endIndex = origHtml.IndexOf(">", curPos);

                    controlHtml = origHtml.Substring(0, endIndex + 1);
                    controlHtml = controlHtml.Substring(controlHtml.LastIndexOf("<"));
                    controlTag = controlHtml.Substring(1, controlHtml.IndexOf(" ") - 1);
                    startIndex = origHtml.IndexOf(controlHtml);

                    closeStartIndex = origHtml.IndexOf("</" + controlTag + ">", endIndex + 1);
                    actualContent = origHtml.Substring(startIndex, (origHtml.IndexOf(">", closeStartIndex) - startIndex + 1)); //origHtml.Substring(endIndex + 1, (closeStartIndex - endIndex - 1));

                    origHtml = origHtml.Remove(startIndex, (origHtml.IndexOf(">", closeStartIndex) - startIndex + 1));
                    origHtml = origHtml.Insert(startIndex, newContent);

                    origHtmlContent = new StringBuilder(origHtml);
                }
                //return true;
            }
            catch
            {
                actualContent = null;
                //return false;
            }
        }

        private void SetOwnerPoliciesForMap(List<JacketDetail> productsDetails)
        {

            try
            {
                if (m_MapOwnersToLoans == null || m_MapOwnersToLoans.Count == 0)
                {
                    foreach (JacketDetail jacket in productsDetails)
                    {
                        if (String.Compare(jacket.PolicyCategory, "Owner", true) == 0)
                            m_MapOwnersToLoans.Add(jacket.AgentNetFileServiceJacketId, jacket.PolicySequence);
                    }
                }
            }
            catch (Exception ex)
            {
                m_MapOwnersToLoans = new Dictionary<int, string>();
            }
        }
        #endregion

        #region Build Rates & Fees CPL Controls.

        public string BuildRateFeeCPLControls(List<CPLDetail> cplDetails, int jacketsCount)
        {
            int itemCount = 0;
            //bool isRateEffecticeDateAdded = false;
            StringBuilder strBuldrRF = new StringBuilder();
            //Rate Effective Date for CPL
            //StringBuilder strBuldrRateEffectiveDateId = new StringBuilder();
            try
            {
                if (cplDetails != null && cplDetails.Count() > 0)
                {
                    strBuldrRF.Append("<HTML><BODY><P>");
                    foreach (CPLDetail p in cplDetails)
                    {
                        string productName = p.ProductName;
                        string productType = p.ProductType;
                        string agentNetServiceId = Convert.ToString(p.AgentNetServiceProductId);
                        string productId = Convert.ToString(p.AgentNetProductId);
                        string createDate = p.ClosingDate;
                        //if (!isRateEffecticeDateAdded)
                        //{
                        //    strBuldrRateEffectiveDateId.Append(agentNetServiceId);
                        //    isRateEffecticeDateAdded = true;
                        //}
                        //else
                        //    strBuldrRateEffectiveDateId.Append("_" + agentNetServiceId);
                        strBuldrRF.Append("<table id=\"Product_" + productName + "_" + itemCount + "_" + productId + "_" + productType + "_" + agentNetServiceId + "\"  style=\"font-family:Microsoft Sans Serif; font-size:12px;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
                        int coveredPartyCount = 0;
                        foreach (CPLCoveredParty coveredParty in p.cplCoveredParty)
                        {
                            string lineItemId = coveredParty.CoveredPartyId;
                            string lineItemType = coveredParty.CoveredPartyName;
                            string letterType = productType;

                            strBuldrRF.Append("<tr> <td style=\"width:100px\"> LetterType:  &nbsp;</td> ");
                            strBuldrRF.Append("<td >  <label title=\"" + productType + "\" style=\"width:200px\" id=\"lblLetterType_" + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "\" >" + productType + "</label>  </td> ");
                            strBuldrRF.Append(" <td > Covered Party:  &nbsp;</td> ");
                            strBuldrRF.Append("<td>  <label title=\"" + lineItemType + "\" style=\"width:200px\" id=\"" + LBL_CVRD_PRTY + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "\" for=\"" + lineItemId + "\">" + lineItemType + "</label>  </td> ");
                            strBuldrRF.Append("<td > Effective Date:  &nbsp;</td> ");
                            strBuldrRF.Append("<td>  <label title=\"" + createDate + "\" style=\"width:200px\" id=\"" + LBL_CPL_EFFCTV_DT + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "\" for=\"" + createDate + "\">" + createDate + "</label>  </td> ");
                            strBuldrRF.Append("<%--" + ADD_QSTN_CPL + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "--%>");
                            strBuldrRF.Append("</tr>");
                            coveredPartyCount++;
                        }
                        itemCount++;
                        strBuldrRF.Append("</table>");
                    }
                    //Rate Effective Date for CPL
                    //if (jacketsCount == 0)
                    //{
                    //    strBuldrRF.Append("<table style=\"font-family:Microsoft Sans Serif; font-size:12px;\"> <tr> <td>  Rate Effective Date: </td>");
                    //    strBuldrRF.Append("<td>  <input type=\"text\"  name =\"" + TXT_RATE_EFFCTV_DT + "\" title=\"mm/dd/yyyy\" style=\"width:100px\" id=\"" + strBuldrRateEffectiveDateId + "\" />  </td> ");
                    //    strBuldrRF.Append("</tr></table>");
                    //}
                    strBuldrRF.Append("</P></BODY></HTML>");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strBuldrRF.ToString();
        }

        public string BuildAdditionalQuestionForCPL(AGENTNET_ADDITIONAL_QUESTION[] additionalQuestions, string agentNetServiceId, int itemCount, int coveredPartyCount, string policyType, string lineItemType, string stateCode = "")
        {
            string additionalQuestionHTML = null;
            additionalQuestionHTML = "<table id=\"" + TBL_ADD_QSTN_CPL + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "\" style=\"font-family:Microsoft Sans Serif; font-size:12px;border-width:thin; border-color:Black;\" border = \"1\" >";
            if (additionalQuestions != null && additionalQuestions.Length > 0)
            {
                additionalQuestionHTML += "<tr><td colspan = \"2\" style=\"font-weight:bold;\"> <label id=\"" + LBL_CPL_NM + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "\" style=\"width:250px\"  title=\"" + policyType + "\" >" + policyType + " " + lineItemType + "</label></td></tr>";
                int questionCount = 0;
                foreach (AGENTNET_ADDITIONAL_QUESTION additionalQuest in additionalQuestions)
                {
                    if (additionalQuest.QuestionType.ToLower().Equals("others"))
                    {
                        additionalQuestionHTML += "<tr id=\"" + TR_CPL_ADD_QSTN + itemCount + "_" + coveredPartyCount + "_" + additionalQuest.QuestionType + "_" + agentNetServiceId + "\" ><td> <label id=\"" + LBL_CPL_ADD_QSTN + itemCount + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetServiceId + "\" for =\"" + additionalQuest.QuestionID + "\"  title=\"" + additionalQuest.QuestionDescr + "\" style=\"width:200px\">" + additionalQuest.QuestionDescr + "</label>  </td>";

                        int ansCount = 0;
                        foreach (AGENTNET_ADDITIONAL_QUESTION_ANSWER additionalAns in additionalQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER)
                        {
                            if (additionalAns != null)
                            {
                                if (additionalAns.AnswerType.ToLower() == "options")
                                {
                                    if (ansCount == 0)
                                    {
                                        additionalQuestionHTML += "<td> <select style=\"width:130px\" id=\"" + DDL_CPL_ADD_QSTN + itemCount + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetServiceId + "\"  name=\"ans_" + coveredPartyCount + "_" + questionCount + "_" + additionalAns.AnswerDataType + "_" + additionalAns.AnswerType + "\">";
                                    }
                                    additionalQuestionHTML += "<option value=\"" + additionalAns.AnswerID + "\"  title=\"" + additionalAns.AnswerDescr + "\" >" + additionalAns.AnswerDescr + "</option>";
                                }
                                if (additionalAns.AnswerType.ToLower() == "text")
                                {
                                    if (!string.IsNullOrEmpty(stateCode) && stateCode.ToUpper().Equals("NC"))
                                    {
                                        if (m_FirstCPL)
                                            additionalQuestionHTML += "<td><input type=\"text\" style=\"width:100px\" id=\"" + TXT_CPL_ADD_QSTN_ANS + itemCount + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetServiceId + "\"  value=\"" + additionalAns.AnswerID + "\"  name=\"ans_" + coveredPartyCount + "_" + questionCount + "_" + additionalAns.AnswerDataType + "_" + additionalAns.AnswerType + "\"/>";
                                        else
                                            additionalQuestionHTML += "<td><input type=\"text\" style=\"width:100px\" id=\"" + TXT_CPL_ADD_QSTN_ANS + itemCount + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetServiceId + "\"  value=\"\"  name=\"ans_" + coveredPartyCount + "_" + questionCount + "_" + additionalAns.AnswerDataType + "_" + additionalAns.AnswerType + "\"/>";
                                        m_FirstCPL = false;
                                    }
                                    else
                                        additionalQuestionHTML += "<td><input type=\"text\" style=\"width:100px\" id=\"" + TXT_CPL_ADD_QSTN_ANS + itemCount + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetServiceId + "\"  value=\"\"  name=\"ans_" + coveredPartyCount + "_" + questionCount + "_" + additionalAns.AnswerDataType + "_" + additionalAns.AnswerType + "\"/>";

                                }
                            }
                            ansCount++;
                        }
                        questionCount++;
                    }
                    additionalQuestionHTML += "</td></tr>";

                }
            }

            additionalQuestionHTML += "</table>";
            additionalQuestionHTML = "<tr id=\"" + TR_ADD_QSTN + itemCount + "_" + coveredPartyCount + "_" + agentNetServiceId + "\"><td valign=\"top\" style=\"width:100px\" >Additional Question:  </td><td colspan = \"5\" >" + additionalQuestionHTML + "</td></tr>";
            return additionalQuestionHTML;
        }


        #endregion

        #region AgentNetWSClient Service Calls.

        public AgentNetGetDataResponse GetRateTypes(string productId, string stateCode, string underWriterCode, string effectiveDate, bool isExtendedCoverage, string agentNetProductServiceId, string officeId, string County, string accountNumuber, string businessSegment)
        {

            AGENTNET_GET_DATA_RESPONSE getDataResp = null;
            if (InterfaceAgentNet.IsPOSTSet)
            {
                getDataResp = m_AgentNetHelper.GetRateTypesPost(productId, stateCode, underWriterCode, effectiveDate, isExtendedCoverage, DEALRequest.ClientSystemName, officeId, agentNetProductServiceId, County, accountNumuber, businessSegment);
            }
            else
            {
                getDataResp = m_AgentNetHelper.GetRateTypes(productId, stateCode, underWriterCode, effectiveDate, isExtendedCoverage, DEALRequest.ClientSystemName, officeId, agentNetProductServiceId, County, accountNumuber, businessSegment);
            }
            AgentNetGetDataResponse response = new AgentNetGetDataResponse();
            response.AGENTNET_GET_DATA_RESPONSE = getDataResp;
            if (m_AgentNetHelper.GetStatuses() != null && m_AgentNetHelper.GetStatuses().Count > 0)
                response.STATUS = m_AgentNetHelper.GetStatuses()[0];
            return response;

        }

        /// <summary>
        /// Get jackets from DB rather than from resp object.
        /// </summary>
        /// <param name="agentnetProductId"></param>
        /// <param name="effectiveDate"></param>
        private MESSAGE GetJackets(string fileId)
        {
            if (InterfaceAgentNet.IsPOSTSet)
                return m_AgentNetHelper.GetCreatedJacketsByFileIdPost(fileId, string.Empty);
            return m_AgentNetHelper.GetCreatedJacketsByFileId(fileId, string.Empty);
        }

        public AGENTNET_GET_DATA_RESPONSE GetPolicySimulCountByState(string stateCode, String MinEffDate, string officeId)
        {
            if (InterfaceAgentNet.IsPOSTSet)
                return m_AgentNetHelper.GetPolicySimulCountByStatePost(stateCode, MinEffDate, officeId);
            return m_AgentNetHelper.GetPolicySimulCountByState(stateCode, MinEffDate, officeId);
        }

        public MESSAGE GetCPL(string fileId)
        {
            if (InterfaceAgentNet.IsPOSTSet)
                return m_AgentNetHelper.GetCreatedCPLsByFileId(fileId, string.Empty);
            return m_AgentNetHelper.GetCreatedCPLsByFileId(fileId, string.Empty);
        }

        private AGENTNET_GET_DATA_RESPONSE GetJacketRateType(string productId, string stateCode, string underWriterCode, string effectiveDate, string LiabilityAmount, string agentNetServiceId, bool isExtendedCoverage, ProductTypeEnum prodTypeEnum, string officeId, string County, string accountNumuber, string businessSegment)
        {
            AGENTNET_GET_DATA_RESPONSE getDataResponse = null;
            if (prodTypeEnum.Equals(ProductTypeEnum.Jacket))
            {
                AgentNetGetDataResponse get_resp = GetRateTypes(productId, stateCode, underWriterCode, effectiveDate, isExtendedCoverage, agentNetServiceId, officeId, County, accountNumuber, businessSegment);
                if (get_resp != null)
                {
                    getDataResponse = get_resp.AGENTNET_GET_DATA_RESPONSE;
                    if (get_resp.Result == false)
                    {
                        if (get_resp.STATUS != null && get_resp.STATUS.StatusCode != null)
                        {
                            if (m_GetRateTypesStatus == null)
                                m_GetRateTypesStatus = new List<STATUS>();

                            if (!m_GetRateTypesStatus.Contains(get_resp.STATUS))
                                m_GetRateTypesStatus.Add(get_resp.STATUS);
                        }
                    }
                }

                //Added following logic for endorsement
                AGENTNET_PRICING_ENDORSEMENT[] jacketEndorsementColl = null;
                if (getDataResponse != null && getDataResponse.AGENTNET_PRICING_ENDORSEMENTS != null && getDataResponse.AGENTNET_PRICING_ENDORSEMENTS.AGENTNET_PRICING_ENDORSEMENT != null)
                    jacketEndorsementColl = getDataResponse.AGENTNET_PRICING_ENDORSEMENTS.AGENTNET_PRICING_ENDORSEMENT;

                if (m_JacketPricingEndorsementColl.ContainsKey(agentNetServiceId))
                {
                    m_JacketPricingEndorsementColl.Remove(agentNetServiceId);
                }
                if (jacketEndorsementColl != null)
                {
                    m_JacketPricingEndorsementColl.Add(agentNetServiceId, jacketEndorsementColl);
                }
            }
            return getDataResponse;
        }

        #endregion AgentNetWSClient Service Calls.

        #region Override

        private StructOverride GetOverrideFields(string serviceProductId, string lineItemId, ProductTypeEnum productType, HtmlParser htmlDocRatefeePriceDetails, bool isDefault, ref bool isValidOverrideAmnt, int endoCount = 0)
        {
            StructOverride structOverr = new StructOverride();

            bool isOverride = false;
            decimal overrideAmount = -1;
            string overrideReason = string.Empty;

            if ((!isDefault) && htmlDocRatefeePriceDetails != null)
            {
                List<ParsedHtml> tables = htmlDocRatefeePriceDetails.GetTABLEs();
                foreach (ParsedHtml elem in tables)
                {
                    ParsedHtml htmlElem;
                    string controlId = null;

                    if (productType.Equals(ProductTypeEnum.Endorsement))
                        controlId = CBO_OVERRIDE_REASON + lineItemId + serviceProductId + endoCount;
                    else
                        controlId = CBO_OVERRIDE_REASON + serviceProductId;

                    htmlElem = htmlDocRatefeePriceDetails.GetElementById(controlId);
                    if (htmlElem != null)
                    {
                        List<ParsedHtml> options = htmlDocRatefeePriceDetails.GetOptionElements(htmlElem);
                        foreach (ParsedHtml p in options)
                        {
                            if (p.GetAttributeBool("selected"))
                            {
                                overrideReason = p.GetAttribute("value");
                                if (overrideReason == "0")
                                    overrideReason = String.Empty;
                                break;
                            }
                        }

                    }

                    if (productType.Equals(ProductTypeEnum.Endorsement))
                        controlId = TXT_OVERRIDE_AMOUNT + lineItemId + serviceProductId + endoCount;
                    else
                        controlId = TXT_OVERRIDE_AMOUNT + serviceProductId;
                    htmlElem = htmlDocRatefeePriceDetails.GetElementById(controlId);
                    if (htmlElem != null)
                    {
                        if (!string.IsNullOrEmpty(htmlElem.GetAttribute("value")))
                        {
                            try
                            {
                                overrideAmount = Convert.ToDecimal(htmlElem.GetAttribute("value"));
                            }
                            catch (Exception)
                            {
                                isValidOverrideAmnt = false;
                            }
                        }
                    }

                    if (isValidOverrideAmnt && overrideAmount >= 0)
                    {
                        if (productType.Equals(ProductTypeEnum.Endorsement))
                            controlId = "lblCalulatedPremium" + lineItemId + serviceProductId + endoCount;
                        else
                            controlId = "lblCalulatedPremium" + serviceProductId;

                        htmlElem = htmlDocRatefeePriceDetails.GetElementById(controlId);
                        decimal CalculatedAmount = -1;
                        if (htmlElem != null)
                        {
                            if (!string.IsNullOrEmpty(htmlElem.GetAttribute("data-value")))
                            {
                                Decimal.TryParse(htmlElem.GetAttribute("data-value").ToString(), out CalculatedAmount);
                            }
                        }
                        if ((CalculatedAmount >= 0 && CalculatedAmount != overrideAmount) ||
                            (CalculatedAmount == overrideAmount && !String.IsNullOrEmpty(overrideReason)))
                        {
                            isOverride = true;
                        }
                    }
                }
            }

            structOverr.isOverride = isOverride;
            structOverr.OverrideAmount = overrideAmount;
            structOverr.OverrideReason = overrideReason;

            return structOverr;
        }

        struct StructOverride
        {
            public bool isOverride;
            public string OverrideReason;
            public decimal OverrideAmount;
        }
        /// <summary>
        ///Used To check whether any additional questions exist for endorsements since endorsements are displayed in another form.
        /// </summary>
        /// <returns></returns>
        public bool IsEndorsementAdditionalQuestionsExist(MESSAGE resp)
        {
            if (DEALResponse.GetDEAL(resp) != null)
            {
                if (DEALResponse.GetDEAL(resp).SERVICES != null)
                {
                    List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = new List<AGENTNET_PRODUCT_PRICING_REPONSE>();
                    if (resp != null)
                    {
                        if (resp.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                            return false;
                        else
                        {
                            ServiceHelper respService = new ServiceHelper(resp.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                            if (respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES != null)
                            {
                                lstPricingResponse = respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();
                                if (lstPricingResponse != null)
                                {
                                    lstPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals("jacket")).ToList();
                                    foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstPricingResponse)
                                    {
                                        if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null)
                                        {
                                            foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                                            {
                                                if (lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS != null)
                                                {
                                                    if (lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION != null)
                                                    {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }
        /// <summary>
        ///Used To check whether any additional questions exist for endorsements since endorsements are displayed in another form.
        /// </summary>
        /// <returns></returns>
        public bool IsRateFeeExistForProduct(MESSAGE resp)
        {
            if (DEALResponse.GetDEAL(resp) != null)
            {
                if (DEALResponse.GetDEAL(resp).SERVICES != null)
                {
                    List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = new List<AGENTNET_PRODUCT_PRICING_REPONSE>();
                    if (resp != null)
                    {
                        if (resp.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                            return false;
                        else
                        {
                            ServiceHelper respService = new ServiceHelper(resp.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                            if (respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES != null)
                            {
                                lstPricingResponse = respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();
                                if (lstPricingResponse != null)
                                {
                                    foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstPricingResponse)
                                    {
                                        if (productResponse.AGENTNET_RATE_FEES != null)
                                        {
                                            if (productResponse.AGENTNET_RATE_FEES.AGENTNET_RATE_FEE != null)
                                            {
                                                return true;
                                            }
                                        }
                                        else if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null)
                                        {
                                            foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                                            {
                                                if (lineItemDetail.AGENTNET_RATE_FEES != null)
                                                {
                                                    if (lineItemDetail.AGENTNET_RATE_FEES.AGENTNET_RATE_FEE != null)
                                                    {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }

        private string FormatMoney(string val)
        {
            if (val.Length > 0)
            {
                decimal amt = Convert.ToDecimal(val);
                return FormatDollar(amt);
            }
            else
                return "";
        }
        private string FormatDollar(decimal amt)
        {
            return String.Format("{0:C}", amt);
        }

        #endregion

        #region enums

        public enum ProductTypeEnum
        {
            CPL,
            Jacket,
            Endorsement,
            JacketAdditionalQuestion,
            CPLAdditionalQuestion,
        }


        #endregion

        #region BindRateFeeData
        private void BuildRateFeeTableRowForJacket(string productResponseId, string lineItemId, string productName, string productType,
                                 string grossPremiumAmount, ref int rowCount, bool isDefault,
                                 string calculatedPremium, bool isOverride, string overrideAmount, string overrideReasonTypeCdId, AGENTNET_TYPE_DATA[] statisticalCodes,
                                 string statCode, string rateFeeType, string rateFeeDescr, int lineItemCount, ProductTypeEnum product, string agentRetention, string netdueAmt,
                                 String tridAmount, bool isDisplayTridAmount, bool isPricingQuote)
        {
            if (isDefault)
            {
                StringBuilder row = new StringBuilder();
                string rowId;
                string text;
                bool isFirstColumn = false;
                bool isLastColumn = false;
                bool isAmount = false;
                if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Tax))
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblTaxType" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblTaxType" + productResponseId;
                    text = rateFeeDescr;
                    isFirstColumn = true;
                    row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                else if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Fee))
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblFeeType" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblFeeType" + productResponseId;
                    text = rateFeeDescr;
                    isFirstColumn = true;
                    row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                else if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Endorsement) || rateFeeType.Equals(RateFeeLineItemTypeEnum.Jacket) || rateFeeType.Equals(RateFeeLineItemTypeEnum.MiscEndorsement))
                {
                    if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Endorsement) || rateFeeType.Equals(RateFeeLineItemTypeEnum.MiscEndorsement))
                    {
                        if (product.Equals(ProductTypeEnum.Endorsement))
                            rowId = "lblEndorseType" + lineItemId + productResponseId + lineItemCount;
                        else
                            rowId = "lblEndorseType" + productResponseId;

                        text = "  " + productType;
                        isFirstColumn = true;
                        row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                    }
                    else
                    {
                        if (product.Equals(ProductTypeEnum.Endorsement))
                            rowId = "lblProductType" + lineItemId + productResponseId + lineItemCount;
                        else
                            rowId = "lblProductType" + productResponseId;
                        text = productType;
                        isFirstColumn = true;
                        row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                    }

                    if (statisticalCodes != null && statisticalCodes.Count() > 0)
                    {
                        if (product.Equals(ProductTypeEnum.Endorsement))
                            rowId = "cboStatisticalCodes" + lineItemId + productResponseId + lineItemCount;
                        else
                            rowId = "cboStatisticalCodes" + productResponseId;
                        isFirstColumn = false;
                        row.Append(AddDropDown("StatisticalCodes", statisticalCodes, rowId, statCode));
                    }
                }


                if (product.Equals(ProductTypeEnum.Endorsement))
                    rowId = "lblGrossPremium" + lineItemId + productResponseId + lineItemCount;
                else
                    rowId = "lblGrossPremium" + productResponseId;

                text = FormatMoney(calculatedPremium);
                isFirstColumn = false;
                isAmount = true;
                row.Append(AddRow("GrossPremiumFee", rowId, text, isFirstColumn, isLastColumn, isAmount));

                if (!isPricingQuote)
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblAgentretention" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblAgentretention" + productResponseId;
                    text = FormatMoney(agentRetention);
                    isFirstColumn = false;
                    row.Append(AddRow("AgentRetention", rowId, text, isFirstColumn, isLastColumn, isAmount));


                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblnetDueAmount" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblnetDueAmount" + productResponseId;
                    text = FormatMoney(netdueAmt);
                    isFirstColumn = false;
                    isLastColumn = isDisplayTridAmount ? false : true;
                    row.Append(AddRow("NetPremiumFees", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                if (isDisplayTridAmount)
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblGrossPremiumTrid" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblGrossPremiumTrid" + productResponseId;

                    text = FormatMoney(tridAmount);
                    isFirstColumn = false;
                    isAmount = true;
                    isLastColumn = true;
                    row.Append(AddRow("GrossPremiumFee", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                m_HtmlText.Append(row.ToString());
                rowCount++;
            }
            else
            {
                StringBuilder row = new StringBuilder();
                string rowId;
                string text;
                bool isFirstColumn = false;
                bool isLastColumn = false;
                bool isAmount = false;

                if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Tax))
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblTaxType" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblTaxType" + productResponseId;
                    text = rateFeeDescr;
                    isFirstColumn = true;
                    row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                else if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Fee))
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblFeeType" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblFeeType" + productResponseId;
                    text = rateFeeDescr;
                    isFirstColumn = true;
                    row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                else
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblProductType" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblProductType" + productResponseId;
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        text = "  " + productType;
                    else
                        text = productType;
                    isFirstColumn = true;
                    row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                if (statisticalCodes != null && statisticalCodes.Count() > 0)
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "cboStatisticalCodes" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "cboStatisticalCodes" + productResponseId;
                    isFirstColumn = false;
                    row.Append(AddDropDown("StatisticalCodes", statisticalCodes, rowId, statCode));

                }

                if (product.Equals(ProductTypeEnum.Endorsement))
                    rowId = "lblCalulatedPremium" + lineItemId + productResponseId + lineItemCount;
                else
                    rowId = "lblCalulatedPremium" + productResponseId;
                isFirstColumn = false;
                if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Fee) || rateFeeType.Equals(RateFeeLineItemTypeEnum.Tax))
                    text = "";
                else
                    text = FormatMoney(calculatedPremium);
                row.Append("<TD headers=\"CalculatedPremium\" align=\"middle\">  <label id=\"" + rowId + "\"  data-value=" + "'" + calculatedPremium + "'" + ">" + text + "</label>  </TD> ");

                if (product.Equals(ProductTypeEnum.Endorsement))
                    rowId = TXT_OVERRIDE_AMOUNT + lineItemId + productResponseId + lineItemCount;
                else
                    rowId = TXT_OVERRIDE_AMOUNT + productResponseId;
                if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Fee) || rateFeeType.Equals(RateFeeLineItemTypeEnum.Tax))
                {
                    text = "";
                    row.Append(AddRow("OverrideAmount", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                else
                {
                    String Amount = (isOverride && Convert.ToDecimal(overrideAmount) != Convert.ToDecimal(calculatedPremium)) ? overrideAmount : calculatedPremium;
                    row.Append("<TD headers=\"OverrideAmount\">  <input type=\"text\" id=\"" + rowId + "\"  value=" + "'" + Amount + "'" + "/>  </TD> ");
                }
                if (product.Equals(ProductTypeEnum.Endorsement))
                    rowId = CBO_OVERRIDE_REASON + lineItemId + productResponseId + lineItemCount;
                else
                    rowId = CBO_OVERRIDE_REASON + productResponseId;
                if (rateFeeType.Equals(RateFeeLineItemTypeEnum.Fee) || rateFeeType.Equals(RateFeeLineItemTypeEnum.Tax))
                {
                    text = "";
                    row.Append(AddRow("OverrideReasons", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                else
                {
                    row.Append(AddDropDown("OverrideReasons", OverrideReasons.ToArray(), rowId, overrideReasonTypeCdId));
                }

                if (product.Equals(ProductTypeEnum.Endorsement))
                    rowId = "lblGrossPremium" + lineItemId + productResponseId + lineItemCount;
                else
                    rowId = "lblGrossPremium" + productResponseId;

                text = FormatMoney(grossPremiumAmount);
                isFirstColumn = false;
                isAmount = true;
                row.Append(AddRow("GrossPremiumFee", rowId, text, isFirstColumn, isLastColumn, isAmount));

                if (!isPricingQuote)
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblAgentretention" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblAgentretention" + productResponseId;
                    text = FormatMoney(agentRetention);
                    isFirstColumn = false;
                    row.Append(AddRow("AgentRetention", rowId, text, isFirstColumn, isLastColumn, isAmount));

                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblnetDueAmount" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblnetDueAmount" + productResponseId;
                    text = FormatMoney(netdueAmt);
                    isFirstColumn = false;
                    isLastColumn = isDisplayTridAmount ? false : true;
                    row.Append(AddRow("NetPremiumFees", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                if (isDisplayTridAmount)
                {
                    if (product.Equals(ProductTypeEnum.Endorsement))
                        rowId = "lblGrossPremiumTrid" + lineItemId + productResponseId + lineItemCount;
                    else
                        rowId = "lblGrossPremiumTrid" + productResponseId;

                    text = FormatMoney(tridAmount);
                    isFirstColumn = false;
                    isAmount = true;
                    isLastColumn = true;
                    row.Append(AddRow("GrossPremiumFee", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                rowCount++;
                m_HtmlText.Append(row.ToString());
            }

        }
        private StringBuilder AddRow(string headername, string id, string text, bool isFirstColumn, bool isLastColumn, bool isAmount, bool isTotalColumn = false)
        {
            StringBuilder textRow = new StringBuilder();

            if (isFirstColumn)
                textRow.Append("<TR>");

            textRow.Append("<TD  id=\"" + id + "\" ");

            if (isTotalColumn)
                textRow.Append("style=\"border-top: 1px solid #000000; padding-top: 5px\"" + " ");

            if (isAmount)
                textRow.Append("align=\"right\" ");

            textRow.Append("headers=\"" + headername + "\">" + text + "</TD>");

            if (isLastColumn)
                textRow.Append("</TR>");

            return textRow;
        }
        private StringBuilder AddDropDown(string headername, AGENTNET_TYPE_DATA[] typeDatas, string id, string selectedValue)
        {
            StringBuilder dropDown = new StringBuilder();
            dropDown.Append("<TD headers=\"" + headername + "\">");
            dropDown.Append(" <select style=\"width:130px\" id=\"" + id + "\">");
            dropDown.Append("<option value='0' title='---Select---'> ---Select---  </option>");
            foreach (AGENTNET_TYPE_DATA typeDataItem in typeDatas)
            {
                if (typeDataItem.TypeId == selectedValue)
                {
                    if (headername == "OverrideReasons")
                        dropDown.Append("<option  selected=\"selected\" value='" + typeDataItem.TypeId + "' title='" + typeDataItem.Description + "'>" + typeDataItem.Description + "</option>");
                    else
                        dropDown.Append("<option  selected=\"selected\" value='" + typeDataItem.TypeId + "' title='" + typeDataItem.Description + "'>" + typeDataItem.TypeId + "</option>");
                }
                else
                {
                    if (headername == "OverrideReasons")
                        dropDown.Append("<option value='" + typeDataItem.TypeId + "' title='" + typeDataItem.Description + "'>" + typeDataItem.Description + "</option>");
                    else
                        dropDown.Append("<option value='" + typeDataItem.TypeId + "' title='" + typeDataItem.Description + "'>" + typeDataItem.TypeId + "</option>");
                }
            }
            dropDown.Append("</select> </TD>");
            return dropDown;
        }
        public StringBuilder BindRateFeeData(MESSAGE m_MessageObjForProductResponse, bool isDefault, bool isPricingQuote = false)
        {

            List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = new List<AGENTNET_PRODUCT_PRICING_REPONSE>();
            GrandTotal grandTotal = new GrandTotal();
            Boolean isDisplayTRIDCol = false;
            string PCDValue = string.Empty;
            //         #if MISMO32
            //            string StateCode=  m_MessageObjForProductResponse.DEAL_SETS.DEAL_SET[0].PARTIES.PARTY[0].ADDRESSES.ADDRESS[0].StateCode;
            //# endif
            if (m_MessageObjForProductResponse != null)
            {
                if (m_MessageObjForProductResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                    return null;
                else
                {
                    if (m_MessageObjForProductResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0] != null)
                    {
                        ServiceHelper respService = new ServiceHelper(m_MessageObjForProductResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                        if (respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE != null)
                            lstPricingResponse = respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();

                        m_HtmlText = new StringBuilder();
                        ParseNameValuePairs(m_MessageObjForProductResponse, ref m_IsOverrideState, ref m_IsStatasticalCodeState, ref m_TaxCodeReceived);

                        String TRIDColumnString = String.Empty;

                        foreach (AGENTNET_PRODUCT_PRICING_REPONSE pResp in lstPricingResponse)
                        {

#if MISMO32
                            
                            if (pResp.IsPolicyComplianceDateAvailable)
                            {
                                PCDValue = pResp.PolicyComplianceDate.ToShortDateString();
                                m_IsPolicyComplianceDateRequired = true;
                            }
#endif
                            if (pResp.IsDisplayTRIDAmount ||
                               (pResp.AGENTNET_PRODUCT_LINEITEM_DETAILS != null &&
                               pResp.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null &&
                               pResp.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Count(i => i.IsDisplayTRIDAmount) > 0))
                            {
                                TRIDColumnString = "<th id=\"GrossPremiumFeeTRID\" style=\"text-align:center;\">TRID Premium/Fee</th> ";
                                isDisplayTRIDCol = true;
                                break;
                            }
                        }

                        String splitDetailHeader = String.Empty;
                        if (!isPricingQuote)
                        {
                            splitDetailHeader = "<th id=\"AgentRetention\">Agent Retention</th><th id=\"NetPremiumFees\">Net Premium/Fee</th>";
                        }

                        if (isDefault)
                        {
                            m_HtmlText.Append("<HTML><BODY><P><TABLE cellspacing=\"0\" cellpadding=\"5\" style=\"font-family:Microsoft Sans Serif; font-size:12px; width=\"800px\" ID=\"RateFeePriceDetails\"  >");
                            if (m_IsStatasticalCodeState)
                                m_HtmlText.Append("<TR><th id=\"Description\">Description</th><th id=\"StatisticalCodes\">Statistical Codes</th> <th id=\"GrossPremiumFee\" style=\"text-align:center;\">Gross Premium/Fee</th>" + splitDetailHeader + TRIDColumnString + " </TR>");
                            else
                                m_HtmlText.Append("<TR><th id=\"Description\">Description</th><th id=\"GrossPremiumFee\" style=\"text-align:center\">Gross Premium/Fee</th>" + splitDetailHeader + TRIDColumnString + " </TR>");
                        }
                        else
                        {
                            //get the override reasons
                            if (s_TypeDatas == null)
                            {
                                s_TypeDatas = new List<AGENTNET_TYPE_DATA>();
                                string responseXml = string.Empty;
                                s_TypeDatas = m_AgentNetHelper.GetOverrideReasons();
                            }
                            m_HtmlText.Append("<HTML><BODY><P><TABLE style=\"font-family:Microsoft Sans Serif; font-size:12px; width=\"1200px\" ID=\"RateFeePriceDetails\"  >");
                            if (m_IsStatasticalCodeState)
                                m_HtmlText.Append("<TR><th id=\"Description\">Description</th><th id=\"StatisticalCodes\">Statistical Codes</th> <th id=\"CalculatedPremium\">Calculated Premium</th><th id=\"OverrideAmount\">Override Amount</th><th id=\"OverrideReasons\">Override Reasons</th><th id=\"GrossPremiumFee\" style=\"text-align:center\">Gross Premium/Fee</th>" + splitDetailHeader + TRIDColumnString + " </TR>");
                            else
                                m_HtmlText.Append("<TR><th id=\"Description\">Description</th> <th id=\"CalculatedPremium\">Calculated Premium</th><th id=\"OverrideAmount\">Override Amount</th><th id=\"OverrideReasons\">Override Reasons</th><th id=\"GrossPremiumFee\" style=\"text-align:center\">Gross Premium/Fee</th>" + splitDetailHeader + TRIDColumnString + " </TR>");
                        }
                        int rowCount = 1;

                        //bind CPL's
                        List<AGENTNET_PRODUCT_PRICING_REPONSE> lstCPLPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.CPL.ToLower())).ToList();
                        if (lstCPLPricingResponse != null && lstCPLPricingResponse.Count() > 0)
                        {
                            m_HtmlText = BindCPLRateFeeData(lstCPLPricingResponse, ref rowCount, m_HtmlText, isDefault, m_IsStatasticalCodeState, ref grandTotal, isPricingQuote);
                        }
                        //Bind jackets
                        List<AGENTNET_PRODUCT_PRICING_REPONSE> lstJacketPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.Jacket.ToLower())).ToList();
                        if (lstJacketPricingResponse != null && lstJacketPricingResponse.Count() > 0)
                        {
                            m_HtmlText = BindJacketRateFeeData(lstJacketPricingResponse, ref rowCount, m_HtmlText, isDefault, m_IsStatasticalCodeState, ref grandTotal, isPricingQuote);
                        }

                        BuildRateFeeTableRowForGrandTotal(grandTotal, isDefault, isDisplayTRIDCol, isPricingQuote);

                    }

                    if (m_IsPolicyComplianceDateRequired == true)
                    {
                        if (Convert.ToDateTime(PCDValue) == DateTime.MinValue)
                            PCDValue = null;

                        m_HtmlText.Append("<tr><td>Policy Compliance Date:</td><td><input type=\"text\" style=\"width:100px\" id=\"" + TXT_POLICY_COMPLIANCE + "\"  title=\"mm/dd/yyyy\" style=\"width:100px\"  value=\"" + PCDValue + "\"/></td></tr>");
                    }

                    m_HtmlText.Append("</TABLE></P></BODY></HTML>");



                }
            }
            return m_HtmlText;

        }
        public StringBuilder BindJacketRateFeeData(List<AGENTNET_PRODUCT_PRICING_REPONSE> lstproductResponses, ref int rowCount, StringBuilder htmlText, bool isDefault, bool isStatasticalCodeState, ref GrandTotal grandTotal, bool isPricingQuote)
        {
            bool isTridOverride = lstproductResponses.Count(i => i.IsOverride) > 0;
            if (!isTridOverride)
            {
                foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstproductResponses)
                {
                    if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null &&
                        productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null)
                        isTridOverride = productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Count(i => i.IsOverride) > 0;
                    if (isTridOverride)
                        break;
                }
            }
            foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstproductResponses)
            {
                string productType = productResponse.ProductType;
                string productName = productResponse.ProductName;

                string grossPremiumAmount = string.Empty;
                String tridAmount = String.Empty;
                String grossPremiumTridAmount = String.Empty;
                String overriddenTridAmount = String.Empty;
                string calculatedPremium = string.Empty;

                string agentRetension = string.Empty;
                string netDueAmount = string.Empty;
                bool isOverride = productResponse.IsOverride;
                string overrideAmount = string.Empty;
                string overrideReasonTypeCdId = string.Empty;
                bool isDisplayTRIDAmount = productResponse.IsDisplayTRIDAmount;

                if (isOverride)
                {
                    overrideAmount = Convert.ToString(productResponse.OverrideAmount);
                    overrideReasonTypeCdId = productResponse.OverrideReason;
                }

                AGENTNET_TYPE_DATA[] typeStatisticalCodes = null;

                string statCode = string.Empty;
                if (productResponse.AGENTNET_TYPE_DATAS != null)
                {
                    typeStatisticalCodes = productResponse.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA;
                    statCode = productResponse.StatisticalCode;
                    if (statCode == null || statCode == string.Empty)
                        statCode = GetPrepricingStatisticalCode(productResponse.ProductID);
                }

                string productResponseId = productResponse.ProductResponseId;
                string rateFeeType = string.Empty;
                string rateFeeDescr = string.Empty;
                int lineItemCount = 0;
                if (productResponse.AGENTNET_RATE_FEES != null)
                {
                    foreach (AGENTNET_RATE_FEE rateFee in productResponse.AGENTNET_RATE_FEES.AGENTNET_RATE_FEE)
                    {
                        grossPremiumAmount = Convert.ToString(rateFee.GrossAmount);
                        calculatedPremium = Convert.ToString(rateFee.CalculatedAmount);
                        agentRetension = Convert.ToString(rateFee.AgentRetentionAmount);
                        netDueAmount = Convert.ToString(rateFee.NetAmount);
                        rateFeeDescr = Convert.ToString(rateFee.RateFeeDscr);
                        rateFeeType = rateFee.RateFeeType;
                        grossPremiumTridAmount = isTridOverride ? Convert.ToString(rateFee.OverriddenTRIDAmount) : Convert.ToString(rateFee.TRIDAmount);

                        grandTotal.CalculatedPremiumTotal += rateFee.CalculatedAmount;
                        grandTotal.GrossPremiumTotal += rateFee.GrossAmount;
                        grandTotal.OverrideAmountTotal += isOverride ? productResponse.OverrideAmount : rateFee.GrossAmount;
                        grandTotal.NetPremiumTotal += rateFee.NetAmount;
                        grandTotal.AgentRetentionTotal += rateFee.AgentRetentionAmount;
                        grandTotal.TRIDPremiumTotal += isOverride ? rateFee.OverriddenTRIDAmount : rateFee.TRIDAmount;

                        //build actual data row
                        BuildRateFeeTableRowForJacket(productResponseId, "", productName, productType,
                            grossPremiumAmount, ref rowCount, isDefault,
                            calculatedPremium, isOverride, overrideAmount, overrideReasonTypeCdId, typeStatisticalCodes, statCode, rateFeeType,
                            rateFeeDescr, lineItemCount, ProductTypeEnum.Jacket, agentRetension, netDueAmount, grossPremiumTridAmount, isDisplayTRIDAmount, isPricingQuote);
                        lineItemCount++;
                    }
                }

                AGENTNET_PRODUCT_LINEITEM_DETAIL[] productLineItemDetails = null;
                if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null)
                    productLineItemDetails = productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL;

                if (productLineItemDetails != null)
                {
                    lineItemCount = 0;
                    foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL productLineItem in productLineItemDetails)
                    {
                        string lineItemType = productLineItem.LineItemType;
                        string lineItem = productLineItem.LineItemDescr;
                        string lineItemId = productLineItem.LineItemID;
                        grossPremiumAmount = string.Empty;
                        calculatedPremium = string.Empty;
                        agentRetension = string.Empty;
                        netDueAmount = string.Empty;
                        isOverride = productLineItem.IsOverride;
                        overrideAmount = string.Empty;
                        overrideReasonTypeCdId = string.Empty;
                        tridAmount = String.Empty;

                        if (productLineItem.AGENTNET_TYPE_DATAS != null)
                        {
                            typeStatisticalCodes = productLineItem.AGENTNET_TYPE_DATAS.AGENTNET_TYPE_DATA;
                            statCode = productLineItem.StatisticalCode;
                            if (statCode == null || statCode == string.Empty)
                                statCode = GetPrepricingStatisticalCodeLineItem(productLineItem, productResponse);
                        }
                        if (isOverride)
                        {
                            overrideAmount = Convert.ToString(productLineItem.OverrideAmount);
                            overrideReasonTypeCdId = productLineItem.OverrideReason;
                        }

                        rateFeeType = string.Empty;
                        rateFeeDescr = string.Empty;

                        if (productLineItem.AGENTNET_RATE_FEES != null)
                        {
                            foreach (AGENTNET_RATE_FEE rateFee in productLineItem.AGENTNET_RATE_FEES.AGENTNET_RATE_FEE)
                            {

                                grossPremiumAmount = Convert.ToString(rateFee.GrossAmount);
                                calculatedPremium = Convert.ToString(rateFee.CalculatedAmount);
                                agentRetension = Convert.ToString(rateFee.AgentRetentionAmount);
                                netDueAmount = Convert.ToString(rateFee.NetAmount);
                                rateFeeDescr = Convert.ToString(rateFee.RateFeeDscr);
                                rateFeeType = rateFee.RateFeeType;
                                tridAmount = isTridOverride ? Convert.ToString(rateFee.OverriddenTRIDAmount) : Convert.ToString(rateFee.TRIDAmount);

                                grandTotal.CalculatedPremiumTotal += rateFee.CalculatedAmount;
                                grandTotal.GrossPremiumTotal += rateFee.GrossAmount;
                                grandTotal.OverrideAmountTotal += isOverride ? productLineItem.OverrideAmount : rateFee.GrossAmount;
                                grandTotal.NetPremiumTotal += rateFee.NetAmount;
                                grandTotal.AgentRetentionTotal += rateFee.AgentRetentionAmount;
                                grandTotal.TRIDPremiumTotal += isOverride ? rateFee.OverriddenTRIDAmount : rateFee.TRIDAmount;

                                //build actual data row
                                BuildRateFeeTableRowForJacket(productResponseId, lineItemId, productName, lineItem,
                                    grossPremiumAmount, ref rowCount, isDefault,
                                    calculatedPremium, isOverride, overrideAmount, overrideReasonTypeCdId, typeStatisticalCodes, statCode, rateFeeType, rateFeeDescr,
                                    lineItemCount, ProductTypeEnum.Endorsement, agentRetension, netDueAmount, tridAmount, isDisplayTRIDAmount, isPricingQuote);
                                lineItemCount++;
                            }
                        }
                    }
                }
            }
            return m_HtmlText;
        }
        public StringBuilder BindCPLRateFeeData(List<AGENTNET_PRODUCT_PRICING_REPONSE> lstCPLPricingResponse, ref int rowCount, StringBuilder htmlText, bool isDefault, bool isStatasticalCodeState, ref GrandTotal grandTotal, bool isPricingQuote)
        {
            if (lstCPLPricingResponse != null)
            {
                foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstCPLPricingResponse)
                {
                    string productType = productResponse.ProductType;
                    string productName = productResponse.ProductName;
                    bool isTRIDOverride = false;

                    if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null)
                    {
                        Nullable<int> OverrideCount = productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Count(i => i.IsOverride);
                        if (OverrideCount.HasValue && OverrideCount.Value > 0)
                            isTRIDOverride = true;
                        foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                        {
                            string lineItemId = lineItemDetail.LineItemID;
                            string lineItemType = lineItemDetail.LineItemType;
                            string lineItemDesc = lineItemDetail.LineItemDescr;

                            string grossPremiumAmount = string.Empty;
                            string calculatedPremium = string.Empty;
                            bool isOverride = false;
                            string overrideAmount = string.Empty;
                            string overrideReasonTepeCdId = string.Empty;
                            string agentRetension = string.Empty;
                            string netDueAmount = string.Empty;
                            Boolean isDisplayTridAmount = lineItemDetail.IsDisplayTRIDAmount;
                            string tRIDAmount = String.Empty;
                            string overriddenTRIDAmount = String.Empty;

                            isOverride = lineItemDetail.IsOverride;
                            if (isOverride)
                            {
                                overrideAmount = Convert.ToString(lineItemDetail.OverrideAmount);
                                overrideReasonTepeCdId = lineItemDetail.OverrideReason;
                            }

                            if (lineItemDetail.AGENTNET_RATE_FEES != null)
                            {
                                foreach (AGENTNET_RATE_FEE rateFee in lineItemDetail.AGENTNET_RATE_FEES.AGENTNET_RATE_FEE)
                                {
                                    grossPremiumAmount = Convert.ToString(rateFee.GrossAmount);
                                    calculatedPremium = Convert.ToString(rateFee.CalculatedAmount);
                                    agentRetension = Convert.ToString(rateFee.AgentRetentionAmount);
                                    netDueAmount = Convert.ToString(rateFee.NetAmount);
                                    tRIDAmount = Convert.ToString(rateFee.TRIDAmount);
                                    overriddenTRIDAmount = Convert.ToString(rateFee.OverriddenTRIDAmount);

                                    grandTotal.CalculatedPremiumTotal += rateFee.CalculatedAmount;
                                    grandTotal.GrossPremiumTotal += rateFee.GrossAmount;
                                    grandTotal.OverrideAmountTotal += isOverride ? lineItemDetail.OverrideAmount : rateFee.GrossAmount;
                                    grandTotal.NetPremiumTotal += rateFee.NetAmount;
                                    grandTotal.AgentRetentionTotal += rateFee.AgentRetentionAmount;
                                    grandTotal.TRIDPremiumTotal += isOverride ? rateFee.OverriddenTRIDAmount : rateFee.TRIDAmount;

                                    //TFS 460663- display CPL Municipal tax
                                    if (rateFee.RateFeeType.Equals(RateFeeLineItemTypeEnum.CPL) || rateFee.RateFeeType.Equals(RateFeeLineItemTypeEnum.Tax))
                                    {
                                        //build actual data row
                                        BuildRateFeeTableRow(lineItemId, lineItemType, productName, productType,
                                            grossPremiumAmount, ref rowCount, isDefault, calculatedPremium, isOverride,
                                            overrideAmount, overrideReasonTepeCdId, agentRetension, netDueAmount,
                                            isDisplayTridAmount, tRIDAmount, isTRIDOverride, overriddenTRIDAmount, isPricingQuote);
                                    }
                                }
                            }
                        }
                    }
                }

            }
            return m_HtmlText;
        }


        public StringBuilder BuildRateFeeTableRow(string lineItemId, string lineItemType, string productName,
            string productType, string grossAmount, ref int rowCount, bool isDefaultView, string calculatedPremium,
            bool isOverride, string overrideAmount, string overrideReasonTypeCdId, string agentRetensionAmt,
            string netDueAmt, bool isDisplayTRIDAmount, string tridAmount, bool isTRIDOverride, String overriddenTRIDAmount, bool isPricingQuote)
        {

            StringBuilder row = new StringBuilder();
            string rowId;
            string text;
            bool isFirstColumn = false;
            bool isLastColumn = false;
            bool isAmount = false;
            if (isDefaultView)
            {
                rowId = "lblProductType" + lineItemId;
                text = productType + " " + productName + " - " + lineItemType;
                //TFS 460663- display tax details in ratefee screen
                if (!string.IsNullOrEmpty(lineItemType) && lineItemType.Contains("Tax"))
                {
                    text = lineItemType;
                }
                isFirstColumn = true;
                row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));
                if (m_IsStatasticalCodeState)
                {
                    isFirstColumn = false;
                    rowId = "lblStatisticalCodes" + lineItemId;
                    text = "";
                    row.Append(AddRow("StatisticalCodes", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                rowId = "lblGrossPremium" + lineItemId;
                text = FormatMoney(grossAmount);
                isFirstColumn = false;
                isAmount = true;
                row.Append(AddRow("GrossPremiumFee", rowId, text, isFirstColumn, isLastColumn, isAmount));

                if (!isPricingQuote)
                {
                    rowId = "lblAgentretention" + lineItemId;
                    text = FormatMoney(agentRetensionAmt);
                    isFirstColumn = false;
                    row.Append(AddRow("AgentRetention", rowId, text, isFirstColumn, isLastColumn, isAmount));

                    rowId = "lblnetDueAmount" + lineItemId;
                    text = FormatMoney(netDueAmt);
                    isFirstColumn = false;
                    isLastColumn = isDisplayTRIDAmount ? false : true;
                    row.Append(AddRow("NetPremiumFees", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                if (isDisplayTRIDAmount)
                {
                    rowId = "lblGrossPremiumTRID" + lineItemId;
                    text = FormatMoney(tridAmount);
                    isFirstColumn = false;
                    isLastColumn = true;
                    isAmount = true;
                    row.Append(AddRow("GrossPremiumFeeTRID", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                m_HtmlText.Append(row.ToString());
                rowCount++;

            }
            else
            {
                rowId = "lblProductType" + lineItemId;
                text = productType + " " + productName + " - " + lineItemType;
                isFirstColumn = true;
                row.Append(AddRow("Description", rowId, text, isFirstColumn, isLastColumn, isAmount));

                if (m_IsStatasticalCodeState)
                {
                    isFirstColumn = false;
                    rowId = "lblStatisticalCodes" + lineItemId;
                    text = "";
                    row.Append(AddRow("StatisticalCodes", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                rowId = "lblCalulatedPremium" + lineItemId;
                isFirstColumn = false;
                text = FormatMoney(calculatedPremium);
                row.Append("<TD headers=\"CalculatedPremium\" align=\"middle\">  <label id=\"" + rowId + "\"  data-value=" + "'" + calculatedPremium + "'" + ">" + text + "</label>  </TD> ");

                rowId = TXT_OVERRIDE_AMOUNT + lineItemId;
                String Amount = (isOverride && Convert.ToDecimal(overrideAmount) != Convert.ToDecimal(calculatedPremium)) ? overrideAmount : calculatedPremium;
                row.Append("<TD headers=\"OverrideAmount\">  <input type=\"text\" id=\"" + rowId + "\"  value=" + "'" + Amount + "'" + "/>  </TD> ");

                rowId = CBO_OVERRIDE_REASON + lineItemId;
                row.Append(AddDropDown("OverrideReasons", OverrideReasons.ToArray(), rowId, overrideReasonTypeCdId));

                decimal overrAmount = 0;
                if (overrideAmount.Length > 0)//gross amount is override amount.
                    overrAmount = Convert.ToDecimal(overrideAmount);

                rowId = "lblGrossPremium" + lineItemId;
                if (overrAmount > 0)
                    text = FormatMoney(Convert.ToString(overrAmount));
                else
                    text = FormatMoney(grossAmount);
                isFirstColumn = false;
                isAmount = true;
                row.Append(AddRow("GrossPremiumFee", rowId, text, isFirstColumn, isLastColumn, isAmount));

                if (!isPricingQuote)
                {
                    rowId = "lblAgentretention" + lineItemId;
                    text = FormatMoney(agentRetensionAmt);
                    isFirstColumn = false;
                    row.Append(AddRow("AgentRetention", rowId, text, isFirstColumn, isLastColumn, isAmount));

                    rowId = "lblnetDueAmount" + lineItemId;
                    text = FormatMoney(netDueAmt);
                    isFirstColumn = false;
                    isLastColumn = isDisplayTRIDAmount ? false : true;
                    row.Append(AddRow("NetPremiumFees", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }

                if (isDisplayTRIDAmount)
                {
                    rowId = "lblGrossPremiumTRID" + lineItemId;
                    text = text = isTRIDOverride ? FormatMoney(overriddenTRIDAmount) : FormatMoney(tridAmount);
                    isFirstColumn = false;
                    isAmount = true;
                    isLastColumn = true;
                    row.Append(AddRow("GrossPremiumFeeTRID", rowId, text, isFirstColumn, isLastColumn, isAmount));
                }
                m_HtmlText.Append(row.ToString());
                rowCount++;
            }
            return m_HtmlText;

        }

        public void ParseNameValuePairs(MESSAGE productResponse, ref bool isoverride, ref bool isstacodeState, ref string taxCode)//Parse meta data received.
        {
            if (productResponse != null)
            {
                if (productResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                    return;
                else
                {
                    if (productResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0] != null)
                    {

                        //Add service response to the original response object to see the rate fee repsponse from original object.
                        ServiceHelper reponseService = new ServiceHelper(productResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                        if (reponseService.AGENTNET_PRODUCT_RESPONSE != null &&
                            reponseService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE != null &&
                            reponseService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES != null)
                        {
                            if (reponseService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_NAME_VALUES != null)
                            {
                                AGENTNET_NAME_VALUE[] nameValueCollection = reponseService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE;
                                if (nameValueCollection != null && nameValueCollection.Count() > 0)
                                {
                                    for (int i = 0; i < nameValueCollection.Count(); i++)
                                    {
                                        AGENTNET_NAME_VALUE nameValue = nameValueCollection[i];
                                        switch (nameValue.Name)
                                        {
                                            case "IsOverride":
                                                if (nameValue.Value.ToLower().Equals("true"))
                                                    isoverride = true;
                                                else
                                                    isoverride = false;
                                                break;

                                            case "KYTaxCode":
                                                taxCode = nameValue.Value;
                                                break;
                                            case "IsStatasticalCodeState":
                                                if (nameValue.Value.ToLower().Equals("true"))
                                                    isstacodeState = true;
                                                else
                                                    isstacodeState = false;
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void BuildRateFeeTableRowForGrandTotal(GrandTotal grandTotal, Boolean isDefault, Boolean isDisplayTridAmount, bool isPricingQuote)
        {
            if (isDefault)
            {
                StringBuilder row = new StringBuilder();
                string text;
                //Col index 1 - Description
                row.Append(AddRow("Description", "gtDescription", "Grand Total", true, false, false, true));

                //Col index 2 - GrossPremium
                text = FormatMoney(grandTotal.CalculatedPremiumTotal.ToString());
                row.Append(AddRow("GrossPremiumFee", "gtGrossPremium", text, false, false, true, true));

                if (!isPricingQuote)
                {
                    //Col index 3 - AgentRetention
                    text = FormatMoney(grandTotal.AgentRetentionTotal.ToString());
                    row.Append(AddRow("AgentRetention", "gtAgentRetention", text, false, false, true, true));

                    //Col index 4 - NetPremiumFees
                    text = FormatMoney(grandTotal.NetPremiumTotal.ToString());
                    row.Append(AddRow("NetPremiumFees", "gtNetPremiumFees", text, false, !isDisplayTridAmount, true, true));
                }

                //Col index 5 - TRIDPremiumFee
                if (isDisplayTridAmount)
                {
                    text = FormatMoney(grandTotal.TRIDPremiumTotal.ToString());
                    row.Append(AddRow("TRIDPremiumFee", "gtTRIDPremiumFee", text, false, true, true, true));
                }
                m_HtmlText.Append(row.ToString());
            }
            else
            {
                StringBuilder row = new StringBuilder();
                string text;
                //Col index 1 - Description
                row.Append(AddRow("Description", "gtDescription", "Grand Total: ", true, false, false, true));


                //Col index 2 - CalculatedPremium
                text = FormatMoney(grandTotal.CalculatedPremiumTotal.ToString());
                row.Append(AddRow("CalculatedPremium", "gtCalculatedPremium", text, false, false, true, true));

                //Col index 3 - OverrideAmount
                text = FormatMoney(grandTotal.OverrideAmountTotal.ToString());
                row.Append(AddRow("OverrideAmount", "gtOverrideAmount", text, false, false, true, true));

                //Col index 4 - OverrideReasons -- Keep Blank Col
                row.Append(AddRow("OverrideReasons", "gtOverrideReasons", "&nbsp;", false, false, false, true));

                //Col index 5 - GrossPremiumFee
                text = FormatMoney(grandTotal.GrossPremiumTotal.ToString());
                row.Append(AddRow("GrossPremiumFee", "gtGrossPremiumFee", text, false, false, true, true));

                if (!isPricingQuote)
                {
                    //Col index 6 - AgentRetention
                    text = FormatMoney(grandTotal.AgentRetentionTotal.ToString());
                    row.Append(AddRow("AgentRetention", "gtAgentRetention", text, false, false, true, true));

                    //Col index 7 - NetPremiumFees
                    text = FormatMoney(grandTotal.NetPremiumTotal.ToString());
                    row.Append(AddRow("NetPremiumFees", "gtNetPremiumFees", text, false, !isDisplayTridAmount, true, true));
                }

                //Col index 8 - TRIDPremiumFee
                if (isDisplayTridAmount)
                {
                    text = FormatMoney(grandTotal.TRIDPremiumTotal.ToString());
                    row.Append(AddRow("TRIDPremiumFee", "gtTRIDPremiumFee", text, false, true, true, true));
                }
                m_HtmlText.Append(row.ToString());
            }
        }

        #endregion


        #region Policy Compliance Date
        public DateTime GetPolicyComplianceDate(String policyComplianceDate)
        {
            HtmlParser htmldoc = new HtmlParser(policyComplianceDate);
            ParsedHtml htmlElem = htmldoc.GetElementById(TXT_POLICY_COMPLIANCE);
            if (htmlElem != null)
            {
                try
                {
                    //#if MISMO32
                    //                    if (htmlElem.GetAttributeDate("value") == DateTime.MinValue)
                    //                    {
                    //                        AGENTNET_PRODUCT_PRICING_REQUESTS anrq = new AGENTNET_PRODUCT_PRICING_REQUESTS();
                    //                        anrq.IsPolicyComplianceDateNull = true;
                    //                    }
                    //#endif
                    return htmlElem.GetAttributeDate("value");
                }
                catch (Exception)
                {
                    return DateTime.MinValue;
                }
            }
            return DateTime.MinValue;
        }
        #endregion

        #region Policy Compliance Date NULL
        public Boolean GetPolicyComplianceDateNull(String policyComplianceDateNull)
        {
            HtmlParser htmldoc = new HtmlParser(policyComplianceDateNull);
            ParsedHtml htmlElem = htmldoc.GetElementById(TXT_POLICY_COMPLIANCE);
            Boolean pcdnull = false;
            if (htmlElem != null)
            {
                try
                {
#if MISMO32
                    if (htmlElem.GetAttributeDate("value") == DateTime.MinValue)
                    {
                        AGENTNET_PRODUCT_PRICING_REQUESTS anrq = new AGENTNET_PRODUCT_PRICING_REQUESTS();
                        anrq.IsPolicyComplianceDateNull = true;
                        pcdnull =anrq.IsPolicyComplianceDateNull;
                    }
#endif

                }
                catch (Exception)
                {
                    return false;
                }
            }
            return pcdnull;
        }
        #endregion
        public List<AGENTNET_PRODUCT_LINEITEM_DETAIL> GetProductLineItemByProductId(string agentnetJacketServiceId, MESSAGE messageObjForProductResponse)
        {
            List<AGENTNET_PRODUCT_LINEITEM_DETAIL> lineItemAddQuesionsColl = null;
            List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = new List<AGENTNET_PRODUCT_PRICING_REPONSE>();
            // AddAdditionalQ
            if (messageObjForProductResponse != null)
            {
                if (messageObjForProductResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                    return null;
                else
                {
                    ServiceHelper respService = new ServiceHelper(messageObjForProductResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                    if (respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES != null)
                    {
                        lstPricingResponse = respService.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();
                        if (lstPricingResponse != null)
                        {
                            //Get jackets from the list 
                            AGENTNET_PRODUCT_PRICING_REPONSE productResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals("jacket") && p.ProductResponseId.Equals(agentnetJacketServiceId)).FirstOrDefault();
                            //check whether any additional questions exist for lineItems.
                            if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null)
                            {
                                foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                                {
                                    if (lineItemAddQuesionsColl == null)
                                        lineItemAddQuesionsColl = new List<AGENTNET_PRODUCT_LINEITEM_DETAIL>();

                                    lineItemAddQuesionsColl.Add(lineItemDetail);
                                }
                            }
                        }
                    }
                }
            }

            return lineItemAddQuesionsColl;
        }
        #region Level 2 question only helpers 
        /*
        This region has two public functions that client can use as follows:
        1. When a client invokes Rates and Fees, the client can call 
           FormatLevel2Page function passng the Request and response MESSAGE objects from the invocation.
        2. If there are any L2 questions, 
           this function returns HTML string that can use displayed on the screen.
           - If there is no L2 question, this function will return null;
        3. After the user answers the questions, the client than need to call GenerateLevel2Request passing 
           the updated level 2 questions HTML string and the original request and response MESSAGE objects.
        4. Client then needs to call Rates and Fees again using 
           the MESSAGE object returned from GenerateLevel2Request function.
           NOTE: "stateCode" is required only if it's NC used for CPL questions 
        */
        public string FormatLevel2Page(MESSAGE ratesFeeMessageResponse, MESSAGE rateFeeMessageRequest, string stateCode = "")
        {
            bool isAdditionalQuestionsExist = false;
            var l2Html = new StringBuilder();
            List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = null;
            var listPricingReq = new List<AGENTNET_PRODUCT_PRICING_REQUEST>();
            listPricingReq.AddRange(rateFeeMessageRequest.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST);
            if (ratesFeeMessageResponse != null)
            {
                if (ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                    return null;
                else
                {
                    if (ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE.Count() > 0)
                    {
                        SERVICE reponseService = ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0];
                        ServiceHelper s = new ServiceHelper(ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                        if (s.AGENTNET_PRODUCT_RESPONSE != null &&
                                s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE != null &&
                                s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES != null)
                        {
                            if (s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE != null)
                                lstPricingResponse = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();
                            if (lstPricingResponse != null)
                                lstPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.Jacket.ToLower())).ToList();

                            if (lstPricingResponse != null && lstPricingResponse.Count() > 0)
                            {
                                int itemCount = 0;
                                string additionalQuestion = null;
                                foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstPricingResponse)
                                {
                                    string agentNetServiceId = productResponse.ProductResponseId;
                                    AGENTNET_ADDITIONAL_QUESTION[] additionalQuestionCol = null;
                                    if (productResponse.AGENTNET_ADDITIONAL_QUESTIONS != null && productResponse.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION != null)
                                    {
                                        isAdditionalQuestionsExist = true;
                                        additionalQuestionCol = productResponse.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION.ToArray();
                                    }
                                    var productLineItemDetailWithAdditionalQustions = this.GetProductLineItemByProductId(agentNetServiceId, ratesFeeMessageResponse);
                                    if ((productLineItemDetailWithAdditionalQustions != null && productLineItemDetailWithAdditionalQustions.Count > 0) || (additionalQuestionCol != null && additionalQuestionCol.Length > 0))
                                    {
                                        if (productResponse.AGENTNET_ADDITIONAL_QUESTIONS != null && productResponse.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION != null
                                            && productResponse.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION.Length == 0)
                                            l2Html.Append("<P><B>" + productResponse.ProductType + "</B></P>");
                                        isAdditionalQuestionsExist = true;
                                        additionalQuestion = this.BuildAdditionalQuestion(productLineItemDetailWithAdditionalQustions, additionalQuestionCol, agentNetServiceId, itemCount, productResponse.ProductType, productResponse);
                                        l2Html.Append(additionalQuestion);
                                    }
                                    itemCount++;
                                }
                            }
                            #region CPL
                            if (s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE != null)
                            {
                                lstPricingResponse = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();
                                lstPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.CPL.ToLower())).ToList();
                            }
                            if (lstPricingResponse != null && lstPricingResponse.Count() > 0)
                            {
                                string additionalCPLQuestion = null;
                                int itemCPLCount = 0;
                                DateTime pcd = DateTime.Now;
                                foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstPricingResponse)
                                {
                                    string agentNetServiceId = productResponse.ProductResponseId;

                                    if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null)
                                    {
                                        if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Count() > 0)
                                        {
                                            int coveredPartyCount = 0;
                                            foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                                            {
                                                string lineItemId = string.Empty;
                                                string lineItemType = string.Empty;
                                                string lineItemDesc = string.Empty;
                                                string effectiveDate = string.Empty;
                                                lineItemId = lineItemDetail.LineItemID;
                                                lineItemType = lineItemDetail.LineItemType;
                                                lineItemDesc = lineItemDetail.LineItemDescr;
                                                effectiveDate = Convert.ToString(productResponse.EffectiveDate);

                                                AGENTNET_ADDITIONAL_QUESTION[] additionalQuestions = null;
                                                if (lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS != null)
                                                {
                                                    if (lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION != null && lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION.Count() > 0)
                                                    {
                                                        additionalQuestions = lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION.ToArray();
                                                        if (additionalQuestions != null && additionalQuestions.Length > 0)
                                                        {
                                                            isAdditionalQuestionsExist = true;
                                                            string tblName = TBL_ADD_QSTN_CPL + itemCPLCount + "_" + coveredPartyCount + "_" + agentNetServiceId;
                                                            additionalCPLQuestion = this.BuildAdditionalQuestionForCPL(additionalQuestions, agentNetServiceId, itemCPLCount, coveredPartyCount, productResponse.ProductType, lineItemType, stateCode);
                                                            l2Html.Append(additionalCPLQuestion);
                                                        }
                                                    }
                                                }
                                                coveredPartyCount++;
                                            }
                                        }
                                    }
                                    itemCPLCount++;
                                }
                            }
                            #endregion

                            if (isAdditionalQuestionsExist)
                                return l2Html.ToString();

                        }
                    }
                }
            }
            return null;
        }
        public MESSAGE GenerateLevel2Request(string level2Html, MESSAGE ratesFeeMessageResponse, MESSAGE rateFeeMessageRequest)
        {
            // First parse the HTML and get all the values in the dictionary 
            var answers = new Dictionary<string, string>();
            HtmlParser htmlDoc = new HtmlParser(level2Html);

            //List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = null;
            var listPricingReq = new List<AGENTNET_PRODUCT_PRICING_REQUEST>();
            listPricingReq.AddRange(rateFeeMessageRequest.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST);
            if (ratesFeeMessageResponse != null)
            {
                if (ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES == null)
                    return null;
                else
                {
                    if (ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE.Count() > 0)
                    {
                        //Add service response to the original response object to see the rate fee repsponse from original object.
                        SERVICE reponseService = ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0];
                        ServiceHelper s = new ServiceHelper(ratesFeeMessageResponse.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE[0]);
                        GenerateLevel2RequestAddQuestions(htmlDoc, s, listPricingReq);
                    }
                }
            }
            return rateFeeMessageRequest;
        }
        private void GenerateLevel2RequestAddQuestions(HtmlParser htmlDoc, ServiceHelper s, List<AGENTNET_PRODUCT_PRICING_REQUEST> listPricingReq)
        {
            List<AGENTNET_PRODUCT_PRICING_REPONSE> lstPricingResponse = null;
            if (s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE != null)
                lstPricingResponse = s.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES.AGENTNET_PRODUCT_PRICING_REPONSE.ToList();
            if (lstPricingResponse != null)
                //lstPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.Jacket.ToLower())).ToList();
                lstPricingResponse = lstPricingResponse.Where(p => p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.Jacket.ToLower()) || p.ProductName.ToLower().Equals(AgentNetProductTypeEnum.CPL.ToLower())).ToList();

            if (lstPricingResponse != null && lstPricingResponse.Count() > 0)
            {
                int itemCount = 0;
                foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstPricingResponse)
                {
                    string agentNetServiceId = productResponse.ProductResponseId;
                    //AGENTNET_ADDITIONAL_QUESTION[] additionalQuestionCol = null;
                    List<AGENTNET_ADDITIONAL_QUESTION> additionalQuestionCol = null;
                    if (productResponse.ProductName.ToLower().Equals(AgentNetProductTypeEnum.Jacket.ToLower()))
                        additionalQuestionCol = this.BuildAddtionalQuestionReq(htmlDoc, agentNetServiceId, itemCount.ToString(), "JACKET", "");
                    var priceReq = listPricingReq.Where(req => req.AgentNetProductServiceId == agentNetServiceId).FirstOrDefault();
                    if (priceReq == null)
                        throw new Exception("Request XML does not have the corresponding pricing request for AgentNetServiceId = " + agentNetServiceId.ToString());
                    if (additionalQuestionCol != null && additionalQuestionCol.Count > 0)
                    {
                        priceReq.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                        priceReq.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = additionalQuestionCol.ToArray();
                    }
                    // find the place in the request and add this
                    //int subItemCount = 0;
                    if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Length > 0)
                    {
                        foreach (var subItem in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                        {
                            var additionalQuestionSubItemCol = this.BuildAddtionalQuestionReq(htmlDoc, agentNetServiceId, itemCount.ToString(), "ENDORSEMENT", subItem.LineItemID);
                            // find the place in the request and add this
                            if (additionalQuestionSubItemCol != null && additionalQuestionSubItemCol.Count > 0)
                            {
                                var subItemReq = priceReq.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Where(reqSubItem => reqSubItem.LineItemID == subItem.LineItemID).FirstOrDefault();
                                if (subItemReq == null)
                                    throw new Exception("Request XML does not have the corresponding pricing request for AgentNetServiceId = " + agentNetServiceId.ToString() + " SubItemId=" + subItem.LineItemID);
                                subItemReq.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                                subItemReq.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = additionalQuestionSubItemCol.ToArray();
                            }
                        }
                    }
                    itemCount++;
                }
                #region CPL answers
                itemCount = 0;
                foreach (AGENTNET_PRODUCT_PRICING_REPONSE productResponse in lstPricingResponse)
                {
                    if (productResponse.ProductName.ToLower() != (AgentNetProductTypeEnum.CPL.ToLower()))
                        continue;
                    string agentNetServiceId = productResponse.ProductResponseId;
                    List<AGENTNET_ADDITIONAL_QUESTION> additionalQuestionCol = null;
                    additionalQuestionCol = this.BuildAddtionalQuestionReq(htmlDoc, agentNetServiceId, itemCount.ToString(), "CPL", "");
                    var priceReq = listPricingReq.Where(req => req.AgentNetProductServiceId == agentNetServiceId).FirstOrDefault();
                    if (priceReq == null)
                        throw new Exception("Request XML does not have the corresponding pricing request for AgentNetServiceId = " + agentNetServiceId.ToString());
                    if (additionalQuestionCol != null && additionalQuestionCol.Count > 0)
                    {// find the place in the request and add this
                        priceReq.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                        priceReq.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = additionalQuestionCol.ToArray();
                    }
                    // now check the subitems
                    int subItemCount = 0;
                    if (productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null && productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Length > 0)
                    {
                        foreach (var subItem in productResponse.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                        {
                            var additionalQuestionSubItemCol = this.GenerateLevel2RequestAddQuestionsCPL(htmlDoc, subItem, agentNetServiceId, itemCount, subItemCount);
                            // find the place in the request and add this
                            if (additionalQuestionSubItemCol != null && additionalQuestionSubItemCol.Count > 0)
                            {
                                var subItemReq = priceReq.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Where(reqSubItem => reqSubItem.LineItemID == subItem.LineItemID).FirstOrDefault();
                                if (subItemReq == null)
                                    throw new Exception("Request XML does not have the corresponding pricing request for AgentNetServiceId = " + agentNetServiceId.ToString() + " SubItemId=" + subItem.LineItemID);
                                subItemReq.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                                subItemReq.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION = additionalQuestionSubItemCol.ToArray();
                            }
                            subItemCount++;
                        }
                    }

                }
                #endregion
            }
        }
        private List<AGENTNET_ADDITIONAL_QUESTION> GenerateLevel2RequestAddQuestionsCPL(HtmlParser htmlCPLdoc, AGENTNET_PRODUCT_LINEITEM_DETAIL lineItemDetail, string agentNetProductServiceId, int count, int coveredPartyCount)
        {
            var htmlElement = htmlCPLdoc.GetElementById(TBL_ADD_QSTN_CPL + count + "_" + coveredPartyCount + "_" + agentNetProductServiceId);
            if (htmlElement != null)
            {
                List<ParsedHtml> trElementCol = htmlCPLdoc.GetTRElements(htmlElement);
                List<AGENTNET_ADDITIONAL_QUESTION> agentNetAdditionalQuestions = new List<AGENTNET_ADDITIONAL_QUESTION>();
                lineItemDetail.AGENTNET_ADDITIONAL_QUESTIONS = new AGENTNET_ADDITIONAL_QUESTIONS();
                int questionCount = 0;
                foreach (ParsedHtml trElemAQ in trElementCol)
                {
                    AGENTNET_ADDITIONAL_QUESTION addQuest = new AGENTNET_ADDITIONAL_QUESTION();
                    List<AGENTNET_ADDITIONAL_QUESTION_ANSWER> questAnswerList = new List<AGENTNET_ADDITIONAL_QUESTION_ANSWER>();

                    addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS = new AGENTNET_ADDITIONAL_QUESTION_ANSWERS();

                    if (trElemAQ.Attributes.Count > 0)
                    {
                        ParsedHtml htmlElemQA = htmlCPLdoc.GetElementById(LBL_CPL_ADD_QSTN + count + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetProductServiceId);

                        string controlId = trElemAQ.GetAttribute("id");
                        string[] arrayControlId = controlId.Split('_');
                        string questType = arrayControlId[2];
                        if (arrayControlId.Length > 3)
                        {
                            if (htmlElemQA != null)
                            {
                                addQuest.QuestionID = htmlElemQA.GetAttribute("for");
                                addQuest.QuestionDescr = htmlElemQA.GetAttribute("title");
                                addQuest.QuestionType = questType;

                            }

                            htmlElemQA = htmlCPLdoc.GetElementById(DDL_CPL_ADD_QSTN + count + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetProductServiceId);
                            if (htmlElemQA != null)
                            {
                                List<ParsedHtml> htmlElemCol = htmlCPLdoc.GetOptionElements(htmlElemQA);
                                if (htmlElemCol.Count > 0)
                                {

                                    foreach (ParsedHtml ansEle in htmlElemCol)
                                    {
                                        if (ansEle.GetAttributeBool("selected"))
                                        {
                                            AGENTNET_ADDITIONAL_QUESTION_ANSWER questAnswer = new AGENTNET_ADDITIONAL_QUESTION_ANSWER();
                                            questAnswer.AnswerID = ansEle.GetAttribute("value");
                                            questAnswer.AnswerDescr = ansEle.GetAttribute("title");
                                            questAnswer.AnswerType = string.Empty;// answerType;
                                            string answerTypes = htmlElemQA.GetAttribute("name");
                                            if (!string.IsNullOrEmpty(answerTypes))
                                            {
                                                string[] answerTypeArry = answerTypes.Split('_');
                                                questAnswer.AnswerType = answerTypeArry[4];
                                                questAnswer.AnswerDataType = answerTypeArry[3];
                                            }
                                            questAnswerList.Add(questAnswer);
                                            addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER = questAnswerList.ToArray();
                                            agentNetAdditionalQuestions.Add(addQuest);
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                htmlElemQA = htmlCPLdoc.GetElementById(TXT_CPL_ADD_QSTN_ANS + count + "_" + coveredPartyCount + "_" + questionCount + "_" + agentNetProductServiceId);
                                if (htmlElemQA != null)
                                {
                                    AGENTNET_ADDITIONAL_QUESTION_ANSWER questAnswer = new AGENTNET_ADDITIONAL_QUESTION_ANSWER();
                                    questAnswer.AnswerDescr = htmlElemQA.GetAttribute("value");

                                    string answerTypes = htmlElemQA.GetAttribute("name");
                                    if (!string.IsNullOrEmpty(answerTypes))
                                    {
                                        string[] answerTypeArry = answerTypes.Split('_');
                                        questAnswer.AnswerType = answerTypeArry[4];
                                        questAnswer.AnswerDataType = answerTypeArry[3];
                                    }
                                    questAnswerList.Add(questAnswer);
                                    addQuest.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER = questAnswerList.ToArray();
                                    agentNetAdditionalQuestions.Add(addQuest);
                                }
                            }

                            questionCount++;
                        }

                    }

                }
                return agentNetAdditionalQuestions;
            }
            return null;
        }
        #endregion

        #region GetPrepricingAnswers
        private Dictionary<string, AGENTNET_PRODUCT_PRICING_REQUEST> m_PrepricingResponsesMap = null;
        private AGENTNET_PRODUCT_PRICING_REQUEST GetPrepricingResponse(AGENTNET_PRODUCT_PRICING_REPONSE cr)
        {
            if (m_PrepricingResponsesMap == null)
            {
                m_PrepricingResponsesMap = new Dictionary<string, AGENTNET_PRODUCT_PRICING_REQUEST>();
                if (m_PrePriceRequest != null)
                {
                    ServiceHelper reqService = new ServiceHelper(m_PrePriceRequest);
                    if (reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS != null &&
                        reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST != null)
                    {
                        foreach (AGENTNET_PRODUCT_PRICING_REQUEST r in reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST)
                        {
                            string key = r.ProductID + "/" + r.RateType + "/" + FormatDollar(r.LiabilityAmount) + "/" + r.IsSimultaniousPrice.ToString();
                            m_PrepricingResponsesMap.Add(key, r);
                        }
                    }
                }
            }
            string curr_key = cr.ProductID + "/" + cr.RateType + "/" + FormatDollar(cr.LiabilityAmount) + "/" + cr.IsSimultaniousPrice.ToString();
            if (m_PrepricingResponsesMap.ContainsKey(curr_key))
                return m_PrepricingResponsesMap[curr_key];
            return null;
        }
        private string GetPrepricingSimultaneous(string strSimultaneous)
        {
            if (m_PrePriceRequest != null)
            {
                ServiceHelper reqService = new ServiceHelper(m_PrePriceRequest);
                if (reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS != null)
                {
                    if (reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.IsSimultaniousPrice)
                        return "CHECKED";
                    return "";
                }

            }
            return strSimultaneous;
        }
        private string GetPrepricingRateType(string productID)
        {
            if (m_PrePriceRequest != null)
            {
                ServiceHelper reqService = new ServiceHelper(m_PrePriceRequest);
                if (reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS != null &&
                     reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST != null)
                {
                    foreach (AGENTNET_PRODUCT_PRICING_REQUEST r in reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST)
                    {
                        if (r.ProductID == productID)
                            return r.RateType;
                    }
                }

            }
            return "";
        }
        private string GetPrepricingStatisticalCode(string productID)
        {
            if (m_PrePriceRequest != null)
            {
                ServiceHelper reqService = new ServiceHelper(m_PrePriceRequest);
                if (reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS != null &&
                    reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST != null)
                {
                    foreach (AGENTNET_PRODUCT_PRICING_REQUEST r in reqService.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST)
                    {
                        if (r.ProductID == productID)
                            return r.StatisticalCode;
                    }
                }

            }
            return "";
        }
        private string GetPrepricingStatisticalCodeLineItem(AGENTNET_PRODUCT_LINEITEM_DETAIL lineDetail, AGENTNET_PRODUCT_PRICING_REPONSE cr)
        {
            AGENTNET_PRODUCT_PRICING_REQUEST pr = GetPrepricingResponse(cr);
            if (pr != null)
            {
                if (lineDetail != null) // this means the question is at a line item
                {
                    if (pr.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && pr.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null && pr.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Length > 0)
                    {
                        foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL li in pr.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                        {
                            if (li.LineItemID == lineDetail.LineItemID)
                            {
                                if (li.StatisticalCode != null)
                                    return li.StatisticalCode;
                                return "";
                            }
                        }
                    }

                }
            }
            return "";
        }
        private string GetPrepricingQuestionAnswer(AGENTNET_ADDITIONAL_QUESTION question, AGENTNET_PRODUCT_LINEITEM_DETAIL lineDetail, AGENTNET_PRODUCT_PRICING_REPONSE cr)
        {
            AGENTNET_PRODUCT_PRICING_REQUEST pr = GetPrepricingResponse(cr);
            if (pr != null)
            {
                if (lineDetail != null) // this means the question is at a line item
                {
                    if (pr.AGENTNET_PRODUCT_LINEITEM_DETAILS != null && pr.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL != null && pr.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL.Length > 0)
                    {
                        foreach (AGENTNET_PRODUCT_LINEITEM_DETAIL li in pr.AGENTNET_PRODUCT_LINEITEM_DETAILS.AGENTNET_PRODUCT_LINEITEM_DETAIL)
                        {
                            if (li.LineItemID == lineDetail.LineItemID)
                            {
                                return GetPricingQuestionAnswer(question, li.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION);
                            }
                        }
                    }

                }
                else // this means question is for the product level
                {
                    if (pr.AGENTNET_ADDITIONAL_QUESTIONS != null && pr.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION != null &&
                        pr.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION.Length > 0)
                    {
                        return GetPricingQuestionAnswer(question, pr.AGENTNET_ADDITIONAL_QUESTIONS.AGENTNET_ADDITIONAL_QUESTION);
                    }
                }
            }


            return null;
        }
        private string GetPricingQuestionAnswer(AGENTNET_ADDITIONAL_QUESTION question, AGENTNET_ADDITIONAL_QUESTION[] prepriceQuestions)
        {

            foreach (AGENTNET_ADDITIONAL_QUESTION q in prepriceQuestions)
            {
                if (q.QuestionID == question.QuestionID &&
                    q.AGENTNET_ADDITIONAL_QUESTION_ANSWERS != null && q.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER != null && q.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER.Length > 0)
                {
                    AGENTNET_ADDITIONAL_QUESTION_ANSWER a = q.AGENTNET_ADDITIONAL_QUESTION_ANSWERS.AGENTNET_ADDITIONAL_QUESTION_ANSWER[0];
                    if (a.AnswerType.ToLower() == "text")
                        return a.AnswerDescr;
                    return a.AnswerID;
                }
            }
            return null;
        }
        #endregion

        #region Pricing Quote Helper

        public string BuildQuoteGui()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<HTML><HEAD><style>body{background-color:#F0F0F0; border: #8F8F8F 1px solid;}</style></HEAD><BODY>");
            try
            {
                sb.Append("<FIELDSET><LEGEND><b>Calculated Results</b></LEGEND>");
                sb.Append("<div id=" + TAG_PREFIX + CALCULATION_SECTION + "></div></FIELDSET>");
                sb.Append("<FIELDSET><LEGEND><b>Calculation Criteria</b></LEGEND>");
                sb.Append("<div id=" + TAG_PREFIX + JACKET_SECTION + "></div>");
                sb.Append("<div id=" + TAG_PREFIX + CPL_SECTION + "></div></FIELDSET>");
                sb.Append("</BODY></HTML>");
                return sb.ToString();
            }
            catch (Exception)
            {
                return sb.ToString();
            }
            finally
            {
                sb.Clear();
            }
        }

        #endregion
    }

    public class JacketDetail
    {
        public int AgentNetProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public string AgentNetProductStatus { get; set; }
        public string AgentNetPolicyNumber { get; set; }
        public string NonEJacletPolicyNumber { get; set; }
        public decimal LiabilityAmount { get; set; }
        public string EffectiveDate { get; set; }
        public string PartyName { get; set; }
        public int AgentNetFileServiceJacketId;//used agentnetserivce product id since there will not any id generated for this.
        public JacketEndorsement[] JacketEndorsement;
        public String PolicySequence { get; set; }
        public string PolicyCategory { get; set; }
    }

    public class JacketEndorsement
    {
        public string EndorsementCode { get; set; }
        public string EndorsementType { get; set; }
        public string EndorsementName { get; set; }
    }

    public class CPLDetail
    {
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public int AgentNetProductId { get; set; }
        public int AgentNetServiceProductId { get; set; }
        public string ClosingDate { get; set; }//closing date is an effective date which is common for all the covered party's
        public CPLCoveredParty[] cplCoveredParty;
    }

    public class CPLCoveredParty
    {
        public string CoveredPartyId { get; set; }
        public string CoveredPartyName { get; set; }

    }

    public class GrandTotal
    {
        public Decimal GrossPremiumTotal { get; set; }
        public Decimal CalculatedPremiumTotal { get; set; }
        public Decimal OverrideAmountTotal { get; set; }
        public Decimal AgentRetentionTotal { get; set; }
        public Decimal NetPremiumTotal { get; set; }
        public Decimal TRIDPremiumTotal { get; set; }

        public GrandTotal()
        {
            this.GrossPremiumTotal = 0;
            this.CalculatedPremiumTotal = 0;
            this.AgentRetentionTotal = 0;
            this.OverrideAmountTotal = 0;
            this.NetPremiumTotal = 0;
            this.TRIDPremiumTotal = 0;
        }
    }

    public class PricingQuotationData
    {
        public String StateCode { get; set; }
        public String County { get; set; }
        public String UnderWriter { get; set; }
        public String PropertyType { get; set; }
        public List<CPLDetail> CPLDetails { get; set; }
        public List<JacketDetail> JacketDetails { get; set; }
    }
}

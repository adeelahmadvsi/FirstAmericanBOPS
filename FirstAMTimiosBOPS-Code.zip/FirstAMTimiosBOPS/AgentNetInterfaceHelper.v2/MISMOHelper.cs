﻿using System;
using System.Collections.Generic;

#if MISMO32
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
using www.firstam.com._2011._03.datacontract.agentnet;
namespace AgentNetInterfaceHelper.v1
#endif
{
    #region MISMOHelper static functions
    public class MISMOHelper
    {
        // static helper functions
        static public string GetNameValue(AGENTNET_NAME_VALUES values, string name)
        {
            string lname = name.ToLower();
            if (values != null && values.AGENTNET_NAME_VALUE != null && values.AGENTNET_NAME_VALUE.Length > 0)
            {
                foreach (AGENTNET_NAME_VALUE nv in values.AGENTNET_NAME_VALUE)
                {
                    if (nv.Name.ToLower() == lname)
                        return nv.Value;
                }
            }
            return "";
        }
        static public string GetPartyRoleIdentifier(PARTY p)
        {
#if MISMO32
            if (p.ROLES != null && p.ROLES.ROLE != null && p.ROLES.ROLE.Length > 0 && p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS != null && p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER != null && p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER.Length > 0)
                return p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0].PartyRoleIdentifier;

#else
            if (p.ROLES != null && p.ROLES.PARTY_ROLE_IDENTIFIERS != null && p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER != null && p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER.Length > 0)
                return p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0].PartyRoleIdentifier;
#endif
            return "";

        }
        static public void SetPartyRoleIdentifier(PARTY p, string value)
        {
#if MISMO32
            if (p.ROLES == null)
            {
                p.ROLES = new ROLES();
            }
            if (p.ROLES.ROLE == null)
            {
                p.ROLES.ROLE = new ROLE[1];
                p.ROLES.ROLE[0] = new ROLE();
            }
            if (p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS == null)
            {
                p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS = new PARTY_ROLE_IDENTIFIERS();
                p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER = new PARTY_ROLE_IDENTIFIER[1];
                p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0] = new PARTY_ROLE_IDENTIFIER();
            }
            p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0].PartyRoleIdentifier = value;
#else

            if (p.ROLES == null)
            {
                p.ROLES = new ROLES();
            }
            if (p.ROLES.PARTY_ROLE_IDENTIFIERS == null)
            {
                p.ROLES.PARTY_ROLE_IDENTIFIERS = new PARTY_ROLE_IDENTIFIERS();
                p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER = new PARTY_ROLE_IDENTIFIER[1];
                p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0] = new PARTY_ROLE_IDENTIFIER();
            }
            p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0].PartyRoleIdentifier = value;
#endif

        }
    }
    #endregion
    #region ServiceHelper classes
    public class ServiceHelper
    {
        private SERVICE m_s = null;
        public ServiceHelper(SERVICE s)
        {
            m_s = s;
        }
        public SERVICE SERVICE
        {
            get { return m_s; }
        }
    #endregion
    #region ServiceHelper Request
        public SERVICE_PRODUCT_REQUEST SERVICE_PRODUCT_REQUEST
        {
            get 
            { 
                if (m_s.SERVICE_PRODUCT != null && m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST != null)
                    return m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST;
                return null;
            }
        }
        public SERVICE_PRODUCT_RESPONSE SERVICE_PRODUCT_RESPONSE
        {
            get
            {
                if (m_s.SERVICE_PRODUCT != null && m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE != null)
                    return m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE;
                return null;
            }
        }
        public AGENTNET_PRODUCT_REQUEST AGENTNET_PRODUCT_REQUEST
        {
            get 
            { 
#if MISMO32
                if (m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER != null)
                    return m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST; 
                return null;
#else
                if (m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION != null)
                    return m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST; 
                return null;
#endif
            }
            set
            {
#if MISMO32
                if (m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER == null)
                    m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER = new SERVICE_PRODUCT_REQUEST_OTHER();
                m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST = value;
#else
                if (m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION == null)
                    m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION = new SERVICE_PRODUCT_REQUEST_EXTENSION();
                m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST = value;
#endif
            }
        }
        public string AgentNetServiceType
        {
            get 
            { 
                if (this.AGENTNET_PRODUCT_REQUEST != null)
                    return this.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType;
                return "";
            }
        }
        public string ServiceProductIdentifier
        {
            get 
            { 
                if (this.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL != null)
                    return this.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL.ServiceProductIdentifier; 
                return "";
            }
        }
        public string ServiceProductDescription
        {
            get 
            {
                if (this.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL != null)
                    return this.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL.ServiceProductDescription;
                return "";
            }
        }
        public string ProductStatus
        {
            get 
            { 
                if (this.AGENTNET_PRODUCT_REQUEST != null)
                    return this.AGENTNET_PRODUCT_REQUEST.ProductStatus; 
                return "";
            }
        }
#endregion
#region ServiceHelper Response
        public AGENTNET_PRODUCT_RESPONSE AGENTNET_PRODUCT_RESPONSE
        {
            get
            {
#if MISMO32
                if (m_s.SERVICE_PRODUCT != null && m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE != null && m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION!=null &&  m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER != null &&
                    m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE != null)
                    return m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE;
                return null;
#else
                if (m_s.SERVICE_PRODUCT != null && m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE != null && m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION != null &&
                    m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE != null)
                    return m_s.SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.AGENTNET_PRODUCT_RESPONSE;
                return null;
#endif
            }
        }
        public AGENTNET_PRODUCT_PRICING_RESPONSES AGENTNET_PRODUCT_PRICING_RESPONSES
        {
            get
            {
                if (this.AGENTNET_PRODUCT_RESPONSE != null && 
                    this.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE != null &&
                    AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES != null)
                    return AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_PRODUCT_PRICING_RESPONSES;
                return null;
            }
        }
#endregion
        public List<STATUS> STATUSes
        {
            get
            {
                if (m_s.STATUSES != null && m_s.STATUSES.STATUS != null && m_s.STATUSES.STATUS.Length > 0)
                {
                    List<STATUS> sts = new List<STATUS>();
                    sts.AddRange(m_s.STATUSES.STATUS);
                    return sts;
                }
                return null;
            }
        }
    }

    #region MessageHelper classes
    public class MessageHelper
    {
        private MESSAGE m_m;
        public MessageHelper(MESSAGE m)
        {
            m_m = m;
        }
        public MESSAGE MESSAGE
        {
            get { return m_m; }
        }
        public List<SERVICE> SERVICEs
        {
            get
            {
                List<SERVICE> list = new List<SERVICE>();
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE != null)
                    list.AddRange(m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].SERVICES.SERVICE);
                return list;
            }
        }
        public List<DEAL> DEALs
        {
            get
            {
                List<DEAL> list = new List<DEAL>();
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0)
                    list.AddRange(m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL);
                return list;
            }
        }
        public DEAL DEAL
        {
            get
            {
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0)
                   return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0];
                return null;
            }
        }
        public AGENTNET_REQUEST AGENTNET_REQUEST
        {
            get
            {
#if MISMO32
                if (this.DEAL != null && this.DEAL.EXTENSION.OTHER != null)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].EXTENSION.OTHER.AGENTNET_REQUEST;
#else
                if (this.DEAL != null && this.DEAL.EXTENSION != null)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].EXTENSION.AGENTNET_REQUEST;
#endif
                return null;
            }
        }
        public AGENTNET_RESPONSE AGENTNET_RESPONSE
        {
            get
            {
#if MISMO32
                if (this.DEAL != null && this.DEAL .EXTENSION.OTHER != null)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].EXTENSION.OTHER.AGENTNET_RESPONSE;
#else
                if (this.DEAL != null && this.DEAL.EXTENSION != null)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].EXTENSION.AGENTNET_RESPONSE;
#endif
                return null;
            }
        }
        public List<STATUS> STATUSes
        {
            get
            {
                List<STATUS> list = new List<STATUS>();
#if MISMO32
                if (this.DEAL != null && this.DEAL.EXTENSION.OTHER != null &&
                    this.DEAL.EXTENSION.OTHER.STATUSES != null && this.DEAL.EXTENSION.OTHER.STATUSES.STATUS != null &&
                    this.DEAL.EXTENSION.OTHER.STATUSES.STATUS.Length > 0)
                {
                    list.AddRange(this.DEAL.EXTENSION.OTHER.STATUSES.STATUS);
                }

                if (this.DEAL != null &&
                    this.DEAL.SERVICES != null &&
                    this.DEAL.SERVICES.SERVICE != null &&
                    this.DEAL.SERVICES.SERVICE.Length > 0 &&
                    this.DEAL.SERVICES.SERVICE[0].STATUSES != null &&
                    this.DEAL.SERVICES.SERVICE[0].STATUSES.STATUS != null)
                {
                    list.AddRange(this.DEAL.SERVICES.SERVICE[0].STATUSES.STATUS);
                }
#else
                if (this.DEAL != null && this.DEAL.EXTENSION != null &&
                    this.DEAL.EXTENSION.STATUSES != null && this.DEAL.EXTENSION.STATUSES.STATUS != null &&
                    this.DEAL.EXTENSION.STATUSES.STATUS.Length > 0)
                {
                    list.AddRange(this.DEAL.EXTENSION.STATUSES.STATUS);
                    return list;
                }
#endif
                if (list.Count > 0)
                {
                    return list;
                }

                return null;
            }
        }
        public bool isErrorExists
        {
            get { return DEALResponse.IsErrorsReturnedFromService(this.STATUSes.ToArray()); }
        }
        public PROPERTY PROPERTY
        {
            get 
            {
#if MISMO32
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL.Length > 0)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL[0].SUBJECT_PROPERTY;
#else
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL[0].PROPERTIES != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY.Length > 0)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY[0];
#endif
                return null;
            }
        }
        public decimal SalesPriceAmount
        {
            get

            {
                if (this.PROPERTY.SALES_CONTRACTS != null &&
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT != null &&
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT.Length > 0 &&
#if MISMO32
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL != null)
                    return this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL.SalesContractAmount;
#else
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT.Length > 0)
                    return this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0].PropertySalesPriceAmount;
#endif
                return 0;
            }
            set
            {
                 // this assumes the PROPERTY object exists
                if (this.PROPERTY.SALES_CONTRACTS == null)
                    this.PROPERTY.SALES_CONTRACTS = new SALES_CONTRACTS();
                if (this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT == null)
                {
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT = new SALES_CONTRACT[1];
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0] = new SALES_CONTRACT();
                }
#if MISMO32
                this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL = new SALES_CONTRACT_DETAIL();
                this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL.SalesContractAmount = value;
#else
                    this.PROPERTY.SALES_CONTRACTS.SALES_CONTRACT[0].PropertySalesPriceAmount = value;
#endif
            }
        }

        public LOAN LOAN
        {
            get
            {
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN.Length > 0)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN[0];
                return null;
            }
        }
        public CLOSING_INFORMATION CLOSING_INFORMATION
        {
            get
            {
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN.Length > 0)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN[0].CLOSING_INFORMATION;
                return null;
            }
        }
#if MISMO32
        public TERMS_OF_LOAN TERMS_OF_LOAN
        {
            get
            {
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN.Length > 0)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN[0].TERMS_OF_LOAN;
                return null;
            }
        }
#else   
        public TERMS_OF_MORTGAGE TERMS_OF_MORTGAGE
        {
            get
            {
                if (m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL != null && m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL.Length > 0 &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN != null &&
                    m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN.Length > 0)
                    return m_m.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0].LOANS.LOAN[0].TERMS_OF_MORTGAGE;
                return null;
            }
        }
#endif
    }
    #endregion 
    
    #region ContactPointhelper
    public class ContactPointhelper
    {
        private CONTACT_POINT m_cp = null;
        public ContactPointhelper(CONTACT_POINT cp)
        {
            m_cp = cp;
        }
        public string ContactPointEmailValue
        {
            get
            {
#if MISMO32
                if (m_cp == null)
                    return String.Empty;
                if (m_cp.CONTACT_POINT_EMAIL != null && m_cp.CONTACT_POINT_EMAIL.ContactPointEmailValue != null && m_cp.CONTACT_POINT_EMAIL.ContactPointEmailValue.Length > 0)
                    return m_cp.CONTACT_POINT_EMAIL.ContactPointEmailValue;
#else
                if (m_cp != null && m_cp.ContactPointEmailValue != null && m_cp.ContactPointEmailValue.Length > 0)
                    return m_cp.ContactPointEmailValue;
#endif
                return "";
            }
            set
            {
#if MISMO32
                if (value != null && value.Length > 0)
                {
                    if (m_cp != null)
                    {
                        if (m_cp.CONTACT_POINT_EMAIL == null)
                            m_cp.CONTACT_POINT_EMAIL = new CONTACT_POINT_EMAIL();
                        m_cp.CONTACT_POINT_EMAIL.ContactPointEmailValue = value;
                    }
                }
#else
                if (value != null && value.Length > 0)
                {
                    if (m_cp != null)
                        m_cp.ContactPointEmailValue = value;
                }
#endif
            }
        }
        public string ContactPointFaxValue 
        {
            get
            {
#if MISMO32
                if (m_cp == null)
                    return String.Empty;
                if (m_cp.CONTACT_POINT_TELEPHONE != null && m_cp.CONTACT_POINT_TELEPHONE.ContactPointFaxValue != null && m_cp.CONTACT_POINT_TELEPHONE.ContactPointFaxValue.Length > 0)
                    return m_cp.CONTACT_POINT_TELEPHONE.ContactPointFaxValue;
#else
                if (m_cp != null && m_cp.ContactPointFaxValue != null && m_cp.ContactPointFaxValue.Length > 0)
                    return m_cp.ContactPointFaxValue;
#endif
                return "";
            }
            set
            {
#if MISMO32
                if (value != null && value.Length > 0)
                {
                    if (m_cp != null)
                    {
                        if (m_cp.CONTACT_POINT_TELEPHONE == null)
                            m_cp.CONTACT_POINT_TELEPHONE = new CONTACT_POINT_TELEPHONE();
                        m_cp.CONTACT_POINT_TELEPHONE.ContactPointFaxValue = value;
                    }
                }
#else
                if (value != null && value.Length > 0)
                {
                    if (m_cp != null)
                        m_cp.ContactPointFaxValue = value;
                }
#endif
            }
        }
        public string ContactPointTelephoneValue
        {
            get
            {
#if MISMO32
                if (m_cp == null)
                    return String.Empty;
                if (m_cp.CONTACT_POINT_TELEPHONE != null && m_cp.CONTACT_POINT_TELEPHONE.ContactPointTelephoneValue != null && m_cp.CONTACT_POINT_TELEPHONE.ContactPointTelephoneValue.Length > 0)
                    return m_cp.CONTACT_POINT_TELEPHONE.ContactPointTelephoneValue;
#else
                if (m_cp != null && m_cp.ContactPointTelephoneValue != null && m_cp.ContactPointTelephoneValue.Length > 0)
                    return m_cp.ContactPointTelephoneValue;
#endif
                return "";
            }
            set
            {
#if MISMO32
                if (value != null && value.Length > 0)
                {
                    if (m_cp != null)
                    {
                        if (m_cp.CONTACT_POINT_TELEPHONE == null)
                            m_cp.CONTACT_POINT_TELEPHONE = new CONTACT_POINT_TELEPHONE();
                        m_cp.CONTACT_POINT_TELEPHONE.ContactPointTelephoneValue = value;
                    }
                }
#else
                if (value != null && value.Length > 0)
                {
                    if (m_cp != null)
                        m_cp.ContactPointTelephoneValue = value;
                }
#endif
            }
        }
    }
    #endregion
    #region LoanHelper
    public class LoanHelper
    {
        private LOAN m_l;
        public LoanHelper(LOAN l)
        {
            m_l = l;
        }
        public void Update(string LoanIdentifier, string LoanPurposeType, string MortgageType, decimal NoteAmount, DateTime NoteDate, DateTime LoanEstimatedClosingDate, DateTime ClosingDate, string ClosingAgentOrderNumberIdentifier)
        {
            if (m_l.CLOSING_INFORMATION == null)
            {
                m_l.CLOSING_INFORMATION = new CLOSING_INFORMATION();
                m_l.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL = new CLOSING_INFORMATION_DETAIL();
            }
            if (m_l.LOAN_IDENTIFIERS == null)
            {
                m_l.LOAN_IDENTIFIERS = new LOAN_IDENTIFIERS();
                m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER = new LOAN_IDENTIFIER[1];
                m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0] = new LOAN_IDENTIFIER();
            }
#if MISMO32
            m_l.TERMS_OF_LOAN.LoanPurposeType = LoanPurposeType;
            m_l.TERMS_OF_LOAN.NoteAmount = NoteAmount;
            m_l.TERMS_OF_LOAN.MortgageType = MortgageType;
            m_l.TERMS_OF_LOAN.NoteDate = NoteDate;
            m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0].LoanIdentifier = LoanIdentifier;
            
#else
            m_l.TERMS_OF_MORTGAGE.LoanPurposeType = LoanPurposeType;
            m_l.TERMS_OF_MORTGAGE.NoteAmount = NoteAmount;
            m_l.TERMS_OF_MORTGAGE.MortgageType = MortgageType;
            m_l.TERMS_OF_MORTGAGE.NoteDate = NoteDate;
            m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0].LoanIdentifierValue = LoanIdentifier;
#endif
            m_l.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL.LoanEstimatedClosingDate = LoanEstimatedClosingDate;
            m_l.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL.ClosingDate = ClosingDate;
            m_l.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL.ClosingAgentOrderNumberIdentifier = ClosingAgentOrderNumberIdentifier;
        }
#if MISMO32
        public TERMS_OF_LOAN TERMS_OF_LOAN
        {
            get
            {
                if (m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN;
                return null;
            }
        }
#else   
        public TERMS_OF_MORTGAGE TERMS_OF_MORTGAGE
        {
            get
            {
                if (m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE;
                return null;
            }
        }
#endif
        public LOAN_IDENTIFIER LOAN_IDENTIFIER
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.LOAN_IDENTIFIERS != null && m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER != null &&
                    m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER.Length > 0)
                    return m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0];
#else
                if (m_l != null && m_l.LOAN_IDENTIFIERS != null && m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER != null &&
                    m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER.Length > 0)
                    return m_l.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0];
#endif
                return null;
            }
        }
        public string LoanIdentifier
        {
            get
            {
                if (this.LOAN_IDENTIFIER != null)
#if MISMO32
                    return this.LOAN_IDENTIFIER.LoanIdentifier;
#else
                    return this.LOAN_IDENTIFIER.LoanIdentifierValue;
#endif
                return "";
            }
        }
        public string LoanPurposeType 
        { 
            get 
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.LoanPurposeType;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.LoanPurposeType;
#endif
                return "";
            } 
        }
        public string LoanPurposeTypeOtherDescription
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.LoanPurposeTypeOtherDescription;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.LoanPurposeTypeOtherDescription;
#endif
                return "";
            }
        }
        public string MortgageType
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.MortgageType;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.MortgageType;
#endif
                return "";
            }
        }
        public string MortgageTypeOtherDescription
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.MortgageTypeOtherDescription;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.MortgageTypeOtherDescription;
#endif
                return "";
            }
        }
        public decimal NoteAmount
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.NoteAmount;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.NoteAmount;
#endif
                return 0;
            }
        }
        public DateTime NoteDate
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.NoteDate;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.NoteDate;
#endif
                return DateTime.MinValue;
            }
        }
        public decimal NoteRatePercent
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.NoteRatePercent;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.NoteRatePercent;
#endif
                return 0;
            }
        }
        public decimal OriginalInterestRateDiscountPercent
        {
            get
            {
#if MISMO32
                if (m_l != null && m_l.TERMS_OF_LOAN != null)
                    return m_l.TERMS_OF_LOAN.OriginalInterestRateDiscountPercent;
#else
                if (m_l != null && m_l.TERMS_OF_MORTGAGE != null)
                    return m_l.TERMS_OF_MORTGAGE.OriginalInterestRateDiscountPercent;
#endif
                return 0;
            }
        }
                
    }
    #endregion
    #region AddressHelper
    public class AddressHelper
    {
        private ADDRESS m_a = null;
        public AddressHelper(ADDRESS a)
        {
            m_a = a;
        }

        public string AddressAdditionalLineText
        {
            get
            {
                return m_a.AddressAdditionalLineText;
            }
            set
            {
                m_a.AddressAdditionalLineText = value;
            }
        }
        public string AddressLineText
        {
            get
            {
                return m_a.AddressLineText;
            }
            set
            {
                m_a.AddressLineText = value;
            }
        }
        public string CityName
        {
            get
            {
                return m_a.CityName;
            }
            set
            {
                m_a.CityName = value;
            }
        }
        public string CountryName
        {
            get
            {
                return m_a.CountryName;
            }
            set
            {
                m_a.CountryName = value;
            }
        }
        public string CountyCode
        {
            get
            {
                return m_a.CountyCode;
            }
            set
            {
                m_a.CountyCode = value;
            }
        }
        public string CountyName
        {
            get
            {
                return m_a.CountyName;
            }
            set
            {
                m_a.CountyName = value;
            }
        }
        public string PlusFourZipCode
        {
            get
            {
#if MISMO32
                return m_a.PlusFourZipCode;
#else
                return m_a.PlusFourZipCodeNumber;
#endif
            }
            set
            {
#if MISMO32
                m_a.PlusFourZipCode = value;
#else
                m_a.PlusFourZipCodeNumber = value;
#endif
            }
        }
        public string PostalCode
        {
            get
            {
                return m_a.PostalCode;
            }
            set
            {
                m_a.PostalCode = value;
            }
        }
        public string StateCode
        {
            get
            {
                return m_a.StateCode;
            }
            set
            {
                m_a.StateCode = value;
            }
        }
    }
    #endregion

}

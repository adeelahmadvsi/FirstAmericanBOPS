using System;
using System.Collections.Generic;
using System.IO;

#if MISMO32
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
using www.firstam.com._2011._03.datacontract.agentnet;
namespace AgentNetInterfaceHelper.v1
#endif

{
    public class MISMONameSpace
    {
#if MISMO32
        public const string MISMO_NAMESPACE = "http://www.mismo.org/residential/2009/schemas/v32";
        public const string XLINK_NAMESPACE = "http://www.w3.org/1999/xlink";
        public const string AGENTNET_NAMESPACE = "http://services.firstam.com/entity/agentnet/v2.0";
#else
        public const string MISMO_NAMESPACE = "http://www.mismo.org/residential/2009/schemas";
        public const string XLINK_NAMESPACE = "http://www.w3.org/1999/xlink";
        public const string AGENTNET_NAMESPACE = "http://www.firstam.com/2011/03/datacontract/agentnet";
#endif
    
    }

    public class AgentNetActionTypeEnum
    {
        public const string VOID = "VOID";
        public const string UPDATE = "UPDATE";
        public const string SERVICE = "SERVICE";
        public const string GET_DATA = "GET_DATA";
        public const string CANCEL = "CANCEL";
        public const string PREPRICING = "PREPRICING";
        
    }
    public class AgentNetProductStatusEnum
    {
        public const string VOID = "VOID";
        public const string OPEN = "OPEN";
        public const string PENDING = "PENDING";
        public const string PENDING_VOID = "PENDING VOID";
    }

    public class AgentNetGetRequestEnum
    {
        public const string PRODUCT_TYPES = "GET_PRODUCT_TYPES";
        public const string JACKET_TYPES = "JACKET_TYPES";
        public const string JACKET_TYPE_FIELDS = "JACKET_TYPE_FIELDS";
        public const string JACKET_ENDORSEMENTS = "JACKET_ENDORSEMENTS";
        public const string CPL_TYPES = "CPL_TYPES";
        public const string VALIDATE_LOGIN = "VALIDATE_LOGIN";
        public const string CHANGE_PASSWORD = "CHANGE_PASSWORD";
        public const string PARTIES = "PARTIES";
        public const string UNDERWRITERS = "UNDERWRITERS";
        public const string ACCOUNTS = "ACCOUNTS";
        public const string GET_CPLS = "GET_CPLS";
        public const string GET_JACKETS = "GET_JACKETS";
        public const string GET_LAST_RESPONSE = "GET_LAST_RESPONSE";
        public const string FILE_STATUS = "FILE_STATUS";
        public const string PREVIOUS_FILE_DATA = "PREVIOUS_FILE_DATA";
        public const string GET_COUNTIES = "GET_COUNTIES";
        public const string VALIDATE_COUNTY = "VALIDATE_COUNTY";
        public const string BUSINESS_SEGMENTS = "BUSINESS_SEGMENTS";
        //public const string SDN_SEARCH = "SDN_SEARCH";//will be uncommeted when Ad hco search required.
        public const string GET_RATE_TYPES = "GET_RATE_TYPES";
        public const string GET_OVERRIDEREASONS = "GET_OVERRIDEREASONS";
        public const string GET_JACKETS_AND_CPLS = "GET_JACKETS_AND_CPLS";
        public const string GET_FIRMS = "GET_FIRMS";
        public const string GET_MULTI_TYPE_DATAS = "GET_MULTI_TYPE_DATAS";
        public const string GET_BOPRODUCTS_AND_PROPERTYTYPES = "GET_BOPRODUCTS_AND_PROPERTYTYPES";
        public const string GET_BOPRODUCTDETAIL = "GET_BOPRODUCTDETAIL";
        public const string CPL_FEE_STATES = "CPL_FEE_STATES";
        public const string GET_BOPS_UPLOADEDDOCS = "GET_BOPS_UPLOADEDDOCS";
        public const string BOPS_ORDERS_COMPLETED = "BOPS_ORDERS_COMPLETED";
        public const string BOPS_DOCUMENTS_LIST = "BOPS_DOCUMENTS_LIST";
        public const string GET_STATE_SPECIFIC_SIMUL_COUNT = "GET_STATE_SPECIFIC_SIMUL_COUNT";
        public const string GET_PROPERTY_TYPES = "GET_PROPERTY_TYPES";

        //public const string GET_SECOND_PARTY = "GET_SECOND_PARTY";
        public const string GET_SECOND_PARTY_STATES = "GET_SECOND_PARTY_STATES";
        public const string GET_SPECIAL_MESSAGE = "GET_SPECIAL_MESSAGE";
        public const string BOPS_ORDER_UPDATE_DETAILS = "BOPS_ORDER_UPDATE_DETAILS";
        public const string GET_GENERIC_SERVICE_TYPES = "GET_GENERIC_SERVICE_TYPES";
        public const string GET_ENDPOINT_BY_SERVICE = "GET_ENDPOINT_BY_SERVICE";
        public const string GET_UNDERWRITING_DOCUMENT_TYPES = "GET_UNDERWRITING_DOCUMENT_TYPES";
        public const string GET_UNDERWRITING_TRANSACTION_DETAILS = "GET_UNDERWRITING_TRANSACTION_DETAILS";
        public const string GET_UNDERWRITING_DOCUMENT = "GET_UNDERWRITING_DOCUMENT";
        
        public const string GET_TITLE_SEARCH_ORDER_DATA = "GET_TITLE_SEARCH_ORDER_DATA";
        public const string GET_SERVICE_ORDER_FIELDS = "GET_SERVICE_ORDER_FIELDS";
        public const string GET_RECORDINGFEES_CITIES_BY_COUNTYID = "GET_RECORDINGFEES_CITIES_BY_COUNTYID";
        public const string GET_RECORDINGFEES_DOCUMENT = "GET_RECORDINGFEES_DOCUMENT";
        public const string GET_RECORDING_DOCUMENT_NAMES = "GET_RECORDING_DOCUMENT_NAMES";
        public const string GET_TITLE_PRODUCTS = "GET_TITLE_PRODUCTS";
    }

    public class AgentNetServiceOrderElementsEnum
    {
        public const string TransactionType = "TransactionType";
        public const string BusinessSegment = "BusinessSegment";
        public const string Product = "Product";
        public const string FASTPropertyType = "FASTPropertyType";
        public const string EmailNotification = "EmailNotification";
        public const string DueDate = "DueDate";
        public const string SearchType = "SearchType";
        public const string MunicipalSearchType = "MunicipalSearchType";
        public const string Available = "Available";
        public const string Add = "Add";
        public const string Remove = "Remove";
        public const string Selected = "Selected";
        public const string CopyType = "CopyType";
        public const string Notes = "Notes";
        public const string NonInsuring = "NonInsuring";
        public const string IsDisclaimerAccepted = "IsDisclaimerAccepted";
        public const string Insuring = "Insuring";

    }

    public class AgentNetPartyTypeEnum
    {
        public const string APPROVED_ATTORNEY = "ApprovedAttorney";
        public const string CLOSING_ATTORNEY = "ClosingAttorney";
        public const string MY_CLOSING_ATTORNEY = "MyClosingAttorney";
        public const string OFFICE = "Office";
        public const string MY_LENDER = "MyLender";
        public const string DEFAULT_APPROVED_ATTORNEY = "DefaultApprovedAttorney";
        public const string FIRM = "Firm";
        public const string SIGNATORIES = "Signatories";
        // Change 2nd Party CPL
        public const string SECOND_PARTY = "SecondParty";
    }
    public class AgentNetProductTypeEnum
    {
        public const string GET_DATA = "GET_DATA";
        public const string Jacket = "JACKET";
        public const string CPL = "CPL";
        public const string BackTitle = "BACKTITLE";
        public const string RatesFees = "RATESFEES";
        public const string BackTitleDoc = "BACKTITLEDOC";
        public const string BackTitleDocAttach = "BACKTITLEDOCATTACH";
        public const string BackTitleDocDetach = "BACKTITLEDOCDETACH";
        public const string SDNSearch = "SDN";
        public const string PrePricing = "PREPRICING";
        public const string BOPSERVICE = "BOPSERVICE";
        public const string BOPSDOC = "BOPSDOC";
        public const string BOPSIMAGE = "BOPSIMAGE";
        public const string BOPSNOTES = "BOPSNOTES";
        public const string BOPSServiceInfo = "BOPSServiceInfo";
        public const string BOPSDocAttach = "BOPSDocAttach";
        public const string BOPSOrderUpdate = "BOPSOrderUpdate";
        public const string PolicyImageService = "PolicyImageService";
        public const string UWB = "UWB";
        public const string BOPSDynamic = "BOPSDYNAMIC";
        public const string RECORDINGFEES = "RECORDINGFEES";
        public const string PricingQuotation = "PRICINGQUOTATION";
    }
       
    public class AgentNetSpecialMessageTypeEnum
    {
        public const string BOPS_DISCLAIMER = "BOPSDisclaimer";
        public const string BOPS_NEW_DISCLAIMER = "BOPSNewDisclaimer";
    }
    public class AgentNetBackTitleFieldEnum
    {
        public const string Field_APN = "APN";
        public const string Field_LastName = "LastName";
        public const string Field_StreetNum = "StreetNumber";
        public const string Field_StreetName = "StreetName";
        public const string Field_City = "City";
        public const string Field_Zip = "ZipCode";
        public const string Field_CondoSubdiv = "CondoSubDivision";
        public const string Field_UnitLot = "UnitLot";
        public const string Field_BlockSqr = "BlockSquare";
        public const string Field_Section = "SectionAcreage";
        public const string Field_District = "District";
        public const string Field_PlatBook = "PlatBook";
        public const string Field_PlatPage = "PlatPage";
        public const string Field_BriefLegal = "BriefLegal";
        public const string Field_FileNumber = "FileNumber";
        public const string Field_PolicyNumber = "PolicyNumber";
        public const string Field_LoanNumber = "LoanNumber";
        public const string Field_OwnerNumber = "OwnerNumber";
        public const string Field_PolicyDateFrom = "PolicyDateFrom";
        public const string Field_PolicyDateTo = "PolicyDateTo";
        public const string Field_PropertyAddress = "PropertyAddress";
        public const string Field_Owners = "Owners";
        public const string Field_OrderId = "OrderId";
        public const string Field_EffectiveDate = "EffectiveDate";
        public const string Field_BackTitleServiceSearchId = "BackTitleServiceSearchId";
        public const string Field_County = "County";
        public const string Field_StateCode = "StateCode";
        // BackTitleDoc request
        public const string Field_DocumentType = "DocumentType";
        public const string Field_AdHocUID = "AdHocUID";
        public const string Field_AttachDoc = "AttachDoc";

    }
    public class AgentNetMyLenderFieldEnum
    {
        public const string LenderAttentionName = "LenderAttentionName";
        public const string LenderClause = "LenderClause";
        public const string LenderPhoneNumber = "LenderPhoneNumber";
        public const string LenderFaxNumber = "LenderFaxNumber";
        public const string LenderEmailAddress = "LenderEmailAddress";
        public const string LenderLocation = "LenderLocation";
    }

    public class AgentNetCPLFieldEnum
    {
        public const string ApprovedAttorney = "ApprovedAttorney";
        public const string ClosingAttorney = "ClosingAttorney";
        public const string MyClosingAttorney = "MyClosingAttorney";
        public const string AttachementA = "AttachementA";
        public const string ScheduleASignatory = "ScheduleASignatory";
        public const string ScheduleAFirmLocation = "ScheduleAFirmLocation";
        public const string UpdateMyLender = "UpdateMyLender";
        public const string AlternateFileNumber = "AlternateFileNumber";
        public const string UpdateMyClosingAttorney = "UpdateMyClosingAttorney";
        public const string UpdateCloserAttorney = "UpdateCloserAttorney";

        public const string LoanNumber = "LoanNumber";
        public const string LoanAmount = "LoanAmount";
        public const string ClosingDate = "ClosingDate";
        public const string AGYType = "AGYType";

        // Change 2nd Party CPL
        public const string SecondParty = "SecondParty";
        public const string SecondPartyOffice = "SecondPartyOffice";
        public const string SecondPartyOfficeName = "SecondPartyOfficeName";
        public const string SecondPartyRole = "SecondPartyRole";
    }
   
    public class AgentNetAdditionalPartyRoleTypeEnum
    {
        public const string Grantee = "Grantee";
        public const string Insured = "Insured";
        public const string RecordOwner = "RecordOwner";
        public const string GuaranteedParty = "GuaranteedParty";
        public const string VestedIn = "VestedIn";
        public const string ForeclosingLender = "ForeclosingLender";
        public const string OriginalPolicyInsurer = "OriginalPolicyInsurer";
        public const string NomineeVestee = "NomineeVestee";
        public const string CPLLender = "CPLLender";
        public const string CPLMyClosingAttorney = "CPLMyClosingAttorney";
        public const string CPLClosingAttorneyr = "CPLClosingAttorney";
           
    }
    public class AgentNetClientFileStatusEnum
    {
        public const string Open = "Open";
        public const string Closed = "Closed";
        public const string Cancelled = "Cancelled";
        public const string Unknown = "Unknown";
    }
    public class AgentNetAboutVersionTypeEnum
    {
        public const string AgentNet = "AgentNetWS";
        public const string ClientSystem = "ClientSystem";
        public const string FullVestingBorrower = "FullVestingBorrower";
    }
    public class AgentNetNameValueEnum
    {
        public const string IsDefaultOffice = "IsDefaultOffice";
        public const string IsLicensedInMissouri = "IsLicensedInMissouri";
        public const string FullVestingBorrower = "FullVestingBorrower";
        public const string MarketArea = "MarketArea";
        public const string Subdivision = "Subdivision";
        public const string MaxSimultaneousPolicyCount = "MaxSimultaneousPolicyCount";
        public const string AgentNetCopyTypeDescription = "AgentNetCopyTypeDescription";

        public const string TitleSearchOrderDueDate = "TitleSearchOrderDueDate";
        public const string TitleSearchOrderCopyType = "TitleSearchOrderCopyType";
        public const string TitleSearchOrderSearchType = "TitleSearchOrderSearchType";
        public const string TitleSearchOrderMunicipalSearchType = "TitleSearchOrderMunicipalSearchType";
    }
    public class AgentNetPropertyTypeCodeEnum
    {
        //TFS#104286 changed back to Residential & NonResidential
        public const string Residential = "Residential"; //TFS#103231-changed label names
        public const string NonResidential = "NonResidential";
        public const string Commercial = "Commercial";
    }
    public class AgentNetUWBNavigationEnum
    {
        //TFS#697581 
        public const int MainPage = 0;
        public const int Reopen = 1;
        public const int SummaryPage = 2;
        public const int EditPage = 3;
    }
    public class AgentNetAGYTypeCodeEnum
    {
        public const string FullAgent = "FullAgent";
        public const string PolicyWriter = "PolicyWriter";
        public const string ApprovedAttorney = "ApprovedAttorney";
    }
    public class RateFeeLineItemTypeEnum
    {
        public const string Fee = "Fee";
        public const string Tax = "Tax";
        public const string Endorsement = "Endorsement";
        public const string Jacket = "Jacket";
        public const string CPL = "CPL";
        public const string MiscEndorsement = "MiscEndorsement";
    }

    public class AgentNetMultiDatasTypeEnum
    {
        public const string BOPS_PRODUCTS_AND_PROPERTYTYPES = "BOPSProductsAndPropertyTypes";
        public const string BOPS_TRANS_AND_BUS_SEGMENTS = "BOPSTransAndBusSegments";
        public const string GET_RECORDING_FEES_COUNTY = "GET_RECORDING_FEES_COUNTY";
        //public const string GET_RECORDING_FEES_QUESTIONS = "GET_RECORDING_FEES_QUESTIONS";
    }

    public class AgentNetPolicyImageTypeEnum
    {
        public const string History = "History";
        public const string Errors = "Errors";
    }

    public class AgentNetPolicyImageActionEnum
    {
        public const string DownloadImage = "DownloadImage";
        public const string UploadImage = "UploadImage";
        public const string GetImages = "GetImages";
        public const string DeleteImage = "DeleteImage";
    }

    public class AgentNetPolicyImageServiceFieldEnum
    {
        public const string PolicyImageAction = "PolicyImageAction";
        public const string PolicyImageType = "PolicyImageType";
        public const string PolicyImageName = "PolicyImageName";
        public const string PolicyImageDateFrom = "PolicyImageDateFrom";
        public const string PolicyImageDateTo = "PolicyImageDateTo";
        public const string PolicyImageSearch = "PolicyImageSearch";
    }

    public class AgentNetBOServiceFieldEnum
    {
        public const string TransactionType = "TransactionType";
        public const string BusinessSegment = "BusinessSegment";
        public const string PropertyType = "PropertyType";
        public const string BOPSFileId = "BOPSFileId";
        public const string BOPSFileNotes = "BOPSFileNotes";
        public const string BOPSFileImageID = "BOPSFileImageID";
        public const string BOPSNotificationEmailAddress = "BOPSNotificationEmailAddress";
        public const string ANBOPSProductIds = "ANBOPSProductIds";
        public const string BOPSOrderRequestUpdate = "BOPSOrderRequestUpdate";
        public const string TSODueDate = "TSODueDate";
        public const string SearchTypeCdId = "SearchTypeCdId";
        public const string TSOMunicipalSearchType = "TSOMunicipalSearchType";
        public const string TSOCopyType = "TSOCopyType";
        public const string BOPSAPNMultiple = "BOPSAPNMultiple";
    }
    public class AgentNetRealtionshipType
    {
        public const string HusbandAndWife = "agentnet:HusbandAndWife"; // arcrole
    }


    public class AgentNetPricingType
    {

        public const int TitleRatesFees = 0;
        public const int RecordingFees = 1;
        public const int Both = 2;
    }
    public class DEALRequest
    {
        public const string INCREMENTAL_UPDATE = "IncrementalUpdate";
        public const string CONTACT_PHONE = "P";
        public const string CONTACT_FAX = "F";
        public const string CONTACT_EMAIL = "E";
        // Default values 
        private static string s_RequestingPartyName = "ABC Title";
        private static string s_RequestingPartyStreetAddress = "123 Main";
        private static string s_RequestingPartyCity = "Santa Ana";
        private static string s_RequestingPartyState = "CA";
        private static string s_RequestingPartyPostalCode = "92707";
        private static string s_DefaultUserId;
        private static string s_DefaultPassword;
        private static string s_SystemName = "Timios";
        public static string UNDERWRITERCODE = "FATIC";
        // to here
        private static string s_SystemVersion = "1.0.0";
        public static string AGENTNET_WS_VERION = "a.b.c";  // a = Major release, b =  minor release, c = build 
        private static string BOPSDynamicVersion = "2.3.0";
        // Override values 
        private string m_RequestingPartyName = null;
        private string m_RequestingPartyStreetAddress = null;
        private string m_RequestingPartyCity = null;
        private string m_RequestingPartyState = null;
        private string m_RequestingPartyPostalCode = null;
        public static string m_UnderwriterCode = null;
        // to here
        private MESSAGE m_Message = null;
        private DEAL m_Request = null;
        private string m_ActionType = AgentNetActionTypeEnum.UPDATE;
        private string m_LoginId = "";
        private string m_LoginPassword = "";
        private string m_PreviousFileNumber = "";
        private bool m_bLastBorrowerDeleted = false;
        private bool m_bLastSellerDeleted = false;
        private bool m_bSellerAddChg = false;
        private bool m_bBorrowerAddChg = false;
        static private Random s_Random = new Random();
        private string m_FirmName = string.Empty;
        private int m_FirmId;

        static DEALRequest()
        {
            s_RequestingPartyName = ANUtils.GetConfig("RequestingParty.Name", s_RequestingPartyName);
            s_RequestingPartyStreetAddress = ANUtils.GetConfig("RequestingParty.StreetAddress", s_RequestingPartyStreetAddress);
            s_RequestingPartyCity = ANUtils.GetConfig("RequestingParty.City", s_RequestingPartyCity);
            s_RequestingPartyState = ANUtils.GetConfig("RequestingParty.State", s_RequestingPartyState);
            s_RequestingPartyPostalCode = ANUtils.GetConfig("RequestingParty.PostalCode", s_RequestingPartyPostalCode);
            s_DefaultUserId = ANUtils.GetConfig("DefaultUserId");
            s_DefaultPassword = ANUtils.GetConfig("DefaultPassword");
            s_SystemName = ANUtils.GetConfig("SystemName", s_SystemName);
            AGENTNET_WS_VERION = ANUtils.GetConfig("AgentnetVersion", AGENTNET_WS_VERION);
            s_SystemVersion = ANUtils.GetConfig("SystemVersion", s_SystemVersion);
            UNDERWRITERCODE = ANUtils.GetConfig("UnderwriterCode", s_SystemName);

        }
        public static string DefaultLoginId
        {
            get { return s_DefaultUserId; }
            set { s_DefaultUserId = value; }
        }
        public static string DefaultLoginPassword
        {
            get { return s_DefaultPassword; }
            set { s_DefaultPassword = value; }
        }
        public static string ClientSystemName
        {
            get { return s_SystemName; }
            set { s_SystemName = value; }
        }
        public static Random Random
        {
            get { return s_Random; }
        }
        public string PreviousFileNumber
        { // TFS 96048
            get { return m_PreviousFileNumber; }
        }
        //HQ properties
        public string FirmName
        {
            get { return m_FirmName; }
            set { m_FirmName = value; }
        }
        public int FirmID
        {
            get { return m_FirmId; }
            set { m_FirmId = value; }
        }
        public DEALRequest(string actionType, string loginId, string password,
                            string requestingPartyName,
                            string requestingPartyStreetAddress,
                            string requestingPartyCity,
                            string requestingPartyState,
                            string requestingPartyPostalCode,
                            string underwriterCode)
        {
            m_ActionType = actionType;
            SetRequestingParty(loginId, password,
                            requestingPartyName,
                            requestingPartyStreetAddress,
                            requestingPartyCity,
                            requestingPartyState,
                            requestingPartyPostalCode,
                            underwriterCode);

            CreateBasicRequest();
        }
        public DEALRequest(MESSAGE req)
        {
            InitRequestingParty();
            m_Message = req;
            if (m_Message == null)
            {
                m_LoginId = s_DefaultUserId;
                m_LoginPassword = s_DefaultPassword;
                CreateBasicRequest();
            }
            else
            {
                m_Request = DEALRequest.GetDEAL(m_Message);
#if MISMO32
                m_LoginId = GetAgentNetRequest().LoginAccountIdentifier;
                m_LoginPassword = m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.LoginAccountPasswordText;
#else
                m_LoginId = GetSubmittingParty().ROLES.ROLE[0].SUBMITTING_PARTY.LoginAccountIdentifier;
                m_LoginPassword = GetSubmittingParty().ROLES.ROLE[0].SUBMITTING_PARTY.LoginAccountPasswordText;
#endif
                GetAgentNetRequest().SystemName = s_SystemName;
                  
            }
            m_PreviousFileNumber = this.FileNumber;
        }
        public DEALRequest()
        {
            InitRequestingParty();
            if (m_Request == null)
            {
                m_LoginId = s_DefaultUserId;
                m_LoginPassword = s_DefaultPassword;
                CreateBasicRequest();
            }

        }
        private void InitRequestingParty()
        {
            m_LoginId = s_DefaultUserId;
            m_LoginPassword = s_DefaultPassword;
            m_RequestingPartyName = s_RequestingPartyName;
            m_RequestingPartyStreetAddress = s_RequestingPartyStreetAddress;
            m_RequestingPartyCity = s_RequestingPartyCity;
            m_RequestingPartyState = s_RequestingPartyState;
            m_RequestingPartyPostalCode = s_RequestingPartyPostalCode;
            m_UnderwriterCode = UNDERWRITERCODE;
        }
        public void SetRequestingParty(string loginId, string password,
                            string requestingPartyName,
                            string requestingPartyStreetAddress,
                            string requestingPartyCity,
                            string requestingPartyState,
                            string requestingPartyPostalCode,
                            string underwriterCode)
        {
            InitRequestingParty();
            if (!String.IsNullOrEmpty(loginId))
                m_LoginId = loginId;
            if (!String.IsNullOrEmpty(password))
                m_LoginPassword = password;
            if (!String.IsNullOrEmpty(requestingPartyName))
                m_RequestingPartyName = requestingPartyName;
            if (!String.IsNullOrEmpty(requestingPartyStreetAddress))
                m_RequestingPartyStreetAddress = requestingPartyStreetAddress;
            if (!String.IsNullOrEmpty(requestingPartyCity))
                m_RequestingPartyCity = requestingPartyCity;
            if (!String.IsNullOrEmpty(requestingPartyState))
                m_RequestingPartyState = requestingPartyState;
            if (!String.IsNullOrEmpty(requestingPartyPostalCode))
                m_RequestingPartyPostalCode = requestingPartyPostalCode;
            if (!String.IsNullOrEmpty(underwriterCode))
                m_UnderwriterCode = underwriterCode;
        }

        #region Accessors
        public DEAL DEAL
        {
            get { return m_Request; }
        }
        public MESSAGE MESSAGE
        {
            get { return m_Message; }
        }
        public AGENTNET_REQUEST AGENTNET_REQUEST
        {
            get { return GetAgentNetRequest(); }
            set 
            {
#if MISMO32
                m_Request.EXTENSION.OTHER.AGENTNET_REQUEST = value;
#else
                m_Request.EXTENSION.AGENTNET_REQUEST = value;
#endif
            }
        }
        public string ActionType
        {
            get { return m_ActionType; }
            set { 
                m_ActionType = value;
                GetAgentNetRequest().ActionType = value;
            }
        }
        public string ClientFileStatusCode
        {
            get { return GetAgentNetRequest().ClientFileStatusCode; }
            set
            {
                GetAgentNetRequest().ClientFileStatusCode = value;
            }
        }
        public string LoginId
        {
            get { return m_LoginId; }
            set { m_LoginId = value; }
        }
        public string LoginPassword
        {
            get { return m_LoginPassword; }
            set { m_LoginPassword = value; }
        }
        public string FileNumber
        {
            get { return GetAgentNetRequest().FileNumber; }
            set { GetAgentNetRequest().FileNumber = value; }
        }
        public string UnderWriterCode
        {
            get { return GetAgentNetRequest().UnderwriterCode; }
            set { GetAgentNetRequest().UnderwriterCode = value; }
        }

        public string ClientFileId
        {
            get { return GetAgentNetRequest().ClientFileId; }
            set { GetAgentNetRequest().ClientFileId = value; }
        }
        public string SystemName
        {
            get { return GetAgentNetRequest().SystemName; }
            set { GetAgentNetRequest().SystemName = value; }
        }
        public string ClientRequestId
        {
            get { return GetSubmittingParty().ROLES.ROLE[0].SUBMITTING_PARTY.SubmittingPartyTransactionIdentifier; }
            set { GetSubmittingParty().ROLES.ROLE[0].SUBMITTING_PARTY.SubmittingPartyTransactionIdentifier = value; }
        }
        public string AccountNumber
        {//Optional
            get { return GetRequestingParty().ROLES.ROLE[0].REQUESTING_PARTY.InternalAccountIdentifier; }
            set { GetRequestingParty().ROLES.ROLE[0].REQUESTING_PARTY.InternalAccountIdentifier = value; }
        }
        public string OfficeId
        {// Optional
            get { return GetRequestingParty().ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier; }
            set { GetRequestingParty().ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier = value; }
        }
        public bool LastBorrowerDeleted
        {
            get { return m_bLastBorrowerDeleted; }
            set { m_bLastBorrowerDeleted = value; }
        }
        public bool LastSellerDeleted
        {
            get { return m_bLastSellerDeleted; }
            set { m_bLastSellerDeleted = value; }
        }
        public bool BorrowerAddChg
        {
            get { return m_bBorrowerAddChg; }
            set { m_bBorrowerAddChg = value; }
        }
        public bool SellerAddChg
        {
            get { return m_bSellerAddChg; }
            set { m_bSellerAddChg = value; }
        }
        public AGENTNET_REQUEST GetAgentNetRequest()
        {
#if MISMO32
            return m_Request.EXTENSION.OTHER.AGENTNET_REQUEST;
#else
            return m_Request.EXTENSION.AGENTNET_REQUEST;
#endif
        }
        public void AddNamedValueToRequest(AGENTNET_NAME_VALUE nv)
        {
            if (this.GetAgentNetRequest().AGENTNET_NAME_VALUES == null)
                this.GetAgentNetRequest().AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
            List<AGENTNET_NAME_VALUE> nameValues = new List<AGENTNET_NAME_VALUE>();
            if (this.GetAgentNetRequest().AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null)
                nameValues.AddRange(this.GetAgentNetRequest().AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE);
            foreach (AGENTNET_NAME_VALUE a_nv in nameValues)
            {
                if (a_nv.Name.ToLower().Equals(nv.Name.ToLower()))
                {
                    a_nv.Value = nv.Value;
                    return;
                }
            }
            nameValues.Add(nv);
            this.GetAgentNetRequest().AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = nameValues.ToArray();
        }
        public string GetRequestNamedValue(string name)
        {
            if (GetAgentNetRequest().AGENTNET_NAME_VALUES != null && GetAgentNetRequest().AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null)
            {
                foreach (AGENTNET_NAME_VALUE nv in GetAgentNetRequest().AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE)
                {
                    if (nv.Name.Trim().ToLower().Equals(name.ToLower().Trim()))
                    {
                        return nv.Value.Trim();
                    }
                }
            }
            return null;
        }
        public string GetPropertyAPN()
        {
            return GetPropertyAPNByType(false);
        }
        public string GetPropertyAlternateAPN()
        {
            return GetPropertyAPNByType(true);
        }
        public string GetFirmID(string firmID)
        {
            return GetRequestNamedValue(firmID);
        }
        public string GetFirmName(string firmName)
        {
            return GetRequestNamedValue(firmName);
        }
        private string GetPropertyAPNByType(bool alternate)
        {
            PROPERTY prop = GetProperty();
            if (prop.LEGAL_DESCRIPTIONS != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0] != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION.Length > 0)
            {
                foreach (PARCEL_IDENTIFICATION id in prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION)
                {
                    if (alternate)
                    {
                        if (id.ParcelIdentificationType != null && id.ParcelIdentificationType == ParcelIdentifierTypeEnumerated.Other)
                            return id.ParcelIdentifier;
                    }
                    else
                    {
                        if (id.ParcelIdentificationType == null || id.ParcelIdentificationType == ParcelIdentifierTypeEnumerated.ParcelIdentificationNumber)
                            return id.ParcelIdentifier;
                    }
                }
            }
            return "";
        }
        public PROPERTY GetProperty()
        {
#if MISMO32
            if (m_Request.COLLATERALS != null &&
                m_Request.COLLATERALS.COLLATERAL != null &&
                m_Request.COLLATERALS.COLLATERAL[0].SUBJECT_PROPERTY != null)
                return m_Request.COLLATERALS.COLLATERAL[0].SUBJECT_PROPERTY;
            m_Request.COLLATERALS = new COLLATERALS();
            m_Request.COLLATERALS.COLLATERAL = new COLLATERAL[1];
            m_Request.COLLATERALS.COLLATERAL[0] = new COLLATERAL();
            m_Request.COLLATERALS.COLLATERAL[0].SUBJECT_PROPERTY = new PROPERTY();
            m_Request.COLLATERALS.COLLATERAL[0].SUBJECT_PROPERTY.ADDRESS = new ADDRESS();
            return m_Request.COLLATERALS.COLLATERAL[0].SUBJECT_PROPERTY;
#else
            if (m_Request.COLLATERALS != null &&
                m_Request.COLLATERALS.COLLATERAL != null &&
                m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES != null &&
                m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY != null)
                return m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY[0];
            m_Request.COLLATERALS = new COLLATERALS();
            m_Request.COLLATERALS.COLLATERAL = new COLLATERAL[1];
            m_Request.COLLATERALS.COLLATERAL[0] = new COLLATERAL();
            m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES = new PROPERTIES();
            m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY = new PROPERTY[1];
            m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY[0] = new PROPERTY();
            m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY[0].ADDRESS = new ADDRESS();
            return m_Request.COLLATERALS.COLLATERAL[0].PROPERTIES.PROPERTY[0];
#endif

        }
        public void CreateddPropertyNodes()
        {
            PROPERTY prop = GetProperty();
            if (prop.LEGAL_DESCRIPTIONS == null)
                prop.LEGAL_DESCRIPTIONS = new LEGAL_DESCRIPTIONS();
            if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION == null)
            {
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION = new LEGAL_DESCRIPTION[1];
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0] = new LEGAL_DESCRIPTION();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS = new PARCEL_IDENTIFICATIONS();
            }
        }
        public void AddApnToProperty(string APN)
        {
            AddApnToPropertyByType(APN, false);
        }

        public void AddAlternateApnToProperty(string alternateAPN)
        {
            AddApnToPropertyByType(alternateAPN, true);
        }
        private void AddApnToPropertyByType(string APN, bool alternate)
        {
            CreateddPropertyNodes();
            PROPERTY prop = GetProperty();
            List<PARCEL_IDENTIFICATION> prop_list = new List<PARCEL_IDENTIFICATION>();
            PARCEL_IDENTIFICATION prop_id = null;
            if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION != null)
            {
                prop_list.AddRange(prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION);
                foreach (PARCEL_IDENTIFICATION pi in prop_list)
                {
                    if ((alternate && pi.ParcelIdentificationType == ParcelIdentifierTypeEnumerated.Other) ||
                        (!alternate && pi.ParcelIdentificationType == ParcelIdentifierTypeEnumerated.ParcelIdentificationNumber))
                    {
                        prop_id = pi;
                        break;
                    }
                }
            }
            if (prop_id == null)
            {
                prop_id = new PARCEL_IDENTIFICATION();
                if (alternate)
                {
                    prop_id.ParcelIdentificationType = ParcelIdentifierTypeEnumerated.Other;
                    prop_id.ParcelIdentificationTypeOtherDescription = "AlternateAPN"; // not required
                }
                else
                    prop_id.ParcelIdentificationType = ParcelIdentifierTypeEnumerated.ParcelIdentificationNumber;
                prop_list.Add(prop_id);
            }
            prop_id.ParcelIdentifier = APN;
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION = prop_list.ToArray();
        }
        public void AddAdditionalPropertyInfo(string condoUnit, string lotNumber, string blockNumber, string sectionName, string districtName)
        {
            AddAdditionalPropertyInfo(condoUnit,lotNumber, blockNumber, sectionName, districtName, "");
        }
        public void AddAdditionalPropertyInfo(string condoUnit, string lotNumber, string blockNumber, string sectionName, string districtName, string legalDescr)
        {
            CreateddPropertyNodes();
            PROPERTY prop = GetProperty();
            if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION == null)
            {
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION = new PARSED_LEGAL_DESCRIPTION();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS = new PLATTED_LANDS();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND = new PLATTED_LAND[1];
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0] = new PLATTED_LAND();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS = new UNPLATTED_LANDS();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND = new UNPLATTED_LAND[1];
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0] = new UNPLATTED_LAND();
            }
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0].PlatUnitIdentifier = condoUnit.Trim();
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0].PlatLotIdentifier = lotNumber.Trim();
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0].PlatBlockIdentifier = blockNumber.Trim();
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].SectionIdentifier = sectionName.Trim();
            if (districtName.Trim().Length > 0)
            {
                if (prop.LOCATION_IDENTIFIER == null)
                {
                    prop.LOCATION_IDENTIFIER = new LOCATION_IDENTIFIER();
                    prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER = new GENERAL_IDENTIFIER();
                }
                prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.MapReferenceSecondIdentifier = districtName.Trim();
            }
            if (legalDescr.Trim().Length > 0)
            {
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS == null)
                {
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS = new UNPARSED_LEGAL_DESCRIPTIONS();
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION = new UNPARSED_LEGAL_DESCRIPTION[1];
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0] = new UNPARSED_LEGAL_DESCRIPTION();
                }
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0].UnparsedLegalDescription = legalDescr.Trim();
            }
        }
        public void GetAdditionalPropertyInfo(out string condoUnit, out string lotNumber, out string blockNumber, out string sectionName, out string districtName, out string legalDescr)
        {
            lotNumber = blockNumber = sectionName = districtName = legalDescr = condoUnit = "";
            PROPERTY prop = GetProperty();
            if (prop.LEGAL_DESCRIPTIONS != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION.Length > 0 &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION != null)
            {
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND.Length > 0)
                {

                    PLATTED_LAND pl = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0];
                    if (pl.PlatBlockIdentifier != null)
                        blockNumber = pl.PlatBlockIdentifier;
                    if (pl.PlatLotIdentifier != null)
                        lotNumber = pl.PlatLotIdentifier;
                    if (pl.PlatUnitIdentifier != null)
                        condoUnit = pl.PlatUnitIdentifier;
                }
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND.Length > 0 &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].SectionIdentifier != null)
                {
                    sectionName = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].SectionIdentifier;
                }
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION.Length > 0)
                {
                    legalDescr = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0].UnparsedLegalDescription;
                }
            }
            if (prop.LOCATION_IDENTIFIER != null &&
                prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER != null &&
                prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.MapReferenceSecondIdentifier != null)
            {
                districtName = prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.MapReferenceSecondIdentifier;
            }
        }
        public void AddMoreAdditionalPropertyInfo(string longLegal, string censusTract, string censusBlock, string township, string townshiprange, string townshipSection,
            string mapReference, string tract, string subdivision, string legalBook, string legalPage, string schoolDistrict, string marketArea)
        {
            CreateddPropertyNodes();
            PROPERTY prop = GetProperty();
            if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION == null)
            {
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION = new PARSED_LEGAL_DESCRIPTION();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS = new PLATTED_LANDS();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND = new PLATTED_LAND[1];
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0] = new PLATTED_LAND();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS = new UNPLATTED_LANDS();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND = new UNPLATTED_LAND[1];
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0] = new UNPLATTED_LAND();
            }
            if (legalBook != null && legalBook.Trim().Length > 0)
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0].PlatBookIdentifier = legalBook.Trim();
            if (legalPage != null && legalPage.Trim().Length > 0)
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0].PlatPageIdentifier = legalPage.Trim();
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].TownshipIdentifier = township;
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].RangeIdentifier = townshiprange;
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].QuarterSectionIdentifier = townshipSection;
            prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].LegalTractIdentifier = tract;

            if (schoolDistrict != null && schoolDistrict.Trim().Length > 0)
            {
                if (prop.LOCATION_IDENTIFIER == null)
                {
                    prop.LOCATION_IDENTIFIER = new LOCATION_IDENTIFIER();
                }
                if (prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER == null)
                    prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER = new GENERAL_IDENTIFIER();
                prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.SchoolDistrictName = schoolDistrict.Trim();
            }
            if (mapReference != null && mapReference.Trim().Length > 0)
            {
                if (prop.LOCATION_IDENTIFIER == null)
                {
                    prop.LOCATION_IDENTIFIER = new LOCATION_IDENTIFIER();
                }
                if (prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER == null)
                    prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER = new GENERAL_IDENTIFIER();
                prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.MapReferenceIdentifier = mapReference.Trim();
            }
            if (censusTract != null && censusTract.Trim().Length > 0)
            {
                if (prop.LOCATION_IDENTIFIER == null)
                {
                    prop.LOCATION_IDENTIFIER = new LOCATION_IDENTIFIER();
                }
                if (prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION == null)
                    prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION = new CENSUS_INFORMATION();
                prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION.CensusTractIdentifier = censusTract.Trim();
            }
            if (censusBlock != null && censusBlock.Trim().Length > 0)
            {
                if (prop.LOCATION_IDENTIFIER == null)
                {
                    prop.LOCATION_IDENTIFIER = new LOCATION_IDENTIFIER();
                }
                if (prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION == null)
                    prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION = new CENSUS_INFORMATION();
                prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION.CensusBlockIdentifier = censusBlock.Trim();
            }
            if (subdivision != null && subdivision.Trim().Length > 0)
            {
                AGENTNET_NAME_VALUE nv = new AGENTNET_NAME_VALUE();
                nv.Name = AgentNetNameValueEnum.Subdivision;
                nv.Value = subdivision.Trim();
                AddNamedValueToRequest(nv);
            }
            if (marketArea != null && marketArea.Trim().Length > 0)
            {
                AGENTNET_NAME_VALUE nv = new AGENTNET_NAME_VALUE();
                nv.Name = AgentNetNameValueEnum.MarketArea;
                nv.Value = marketArea.Trim();
                AddNamedValueToRequest(nv);
            }
            
            // Handle the short and long legal descriptions
            // The Long Legal always go to the second occurance [1]
            // The short legal (legalDesc) always to the first one [0]
            if (longLegal != null && longLegal.Trim().Length > 0)
            {
                string legalDescr = "";

                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS == null)
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS = new UNPARSED_LEGAL_DESCRIPTIONS();
                else if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION.Length > 0)
                    legalDescr = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0].UnparsedLegalDescription;

                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION = new UNPARSED_LEGAL_DESCRIPTION[2];
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0] = new UNPARSED_LEGAL_DESCRIPTION();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0].UnparsedLegalDescription = "";
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[1] = new UNPARSED_LEGAL_DESCRIPTION();
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[1].UnparsedLegalDescription = longLegal.Trim();
                if (legalDescr != null && legalDescr.Trim().Length > 0)
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[0].UnparsedLegalDescription = legalDescr;
            }
        }
        public void GetMoreAdditionalPropertyInfo(out string longLegal, out string censusTract, out string censusBlock, out string township, out string townshiprange, out string townshipSection,
             out string mapReference, out string tract, out string subdivision, out string legalBook, out string legalPage, out string schoolDistrict, out string marketArea)
        {
            longLegal = censusTract = censusBlock = township = townshiprange = townshipSection  = "";
            mapReference = tract = subdivision = schoolDistrict = marketArea = legalBook = legalPage = "";
            PROPERTY prop = GetProperty();
            if (prop.LEGAL_DESCRIPTIONS != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION != null &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION.Length > 0 &&
                prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION != null)
            {
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND.Length > 0)
                {

                    PLATTED_LAND pl = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.PLATTED_LANDS.PLATTED_LAND[0];
                    legalBook = pl.PlatBookIdentifier;
                    legalPage = pl.PlatPageIdentifier;
                }
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND.Length > 0 &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].SectionIdentifier != null)
                {
                    township = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].TownshipIdentifier;
                    townshiprange = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].RangeIdentifier;
                    townshipSection = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].QuarterSectionIdentifier;
                    tract = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARSED_LEGAL_DESCRIPTION.UNPLATTED_LANDS.UNPLATTED_LAND[0].LegalTractIdentifier;
                }
                if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION != null &&
                    prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION.Length > 0)
                {
                    if (prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION.Length > 1)
                        longLegal = prop.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].UNPARSED_LEGAL_DESCRIPTIONS.UNPARSED_LEGAL_DESCRIPTION[1].UnparsedLegalDescription;
                }
            }
            if (prop.LOCATION_IDENTIFIER != null &&
                prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER != null) 
            {
                if (prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.SchoolDistrictName != null)
                    schoolDistrict = prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.SchoolDistrictName;
                if (prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.MapReferenceIdentifier != null)
                    mapReference = prop.LOCATION_IDENTIFIER.GENERAL_IDENTIFIER.MapReferenceIdentifier;
            }
            if (prop.LOCATION_IDENTIFIER != null &&
                prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION != null)
            {
                if (prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION.CensusBlockIdentifier != null)
                    censusBlock = prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION.CensusBlockIdentifier;
                if (prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION.CensusTractIdentifier != null)
                    censusTract = prop.LOCATION_IDENTIFIER.CENSUS_INFORMATION.CensusTractIdentifier;
            }
            string v = GetRequestNamedValue(AgentNetNameValueEnum.MarketArea);
            if (v != null)
                marketArea = v;
            v = GetRequestNamedValue(AgentNetNameValueEnum.Subdivision);
            if (v != null)
                subdivision = v;
        }

        public PARTY GetSubmittingParty()
        {
            return GetMessageParties(PartyRoleTypeEnumerated.SubmittingParty)[0];
        }
        public PARTY GetRequestingParty()
        {
            return GetMessageParties(PartyRoleTypeEnumerated.RequestingParty)[0];
        }
        public List<PARTY> GetBorrowers()
        {
            return GetParties(PartyRoleTypeEnumerated.Borrower);
        }
        public List<PARTY> GetSellers()
        {
            return GetParties(PartyRoleTypeEnumerated.PropertySeller);
        }
        public List<PARTY> GetAdditionalParties()
        {
            List<PARTY> parties = new List<PARTY>();
            if (m_Request.PARTIES.PARTY != null)
            {
                foreach (PARTY p in m_Request.PARTIES.PARTY)
                {
                    if (!(p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.Borrower ||
                            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.PropertySeller ||
                            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.Lender ||
                            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.SubmittingParty ||
                            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.RequestingParty ||
                            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.RespondingParty))
                    {
                        if (p.xlinklabel == null || p.xlinklabel.Length == 0)
                        {
                            int next = s_Random.Next();
                            p.xlinklabel = next.ToString();
                        }
                        parties.Add(p);
                    }
                }
            }
            return parties;
        }
        public List<PARTY> GetAdditionalPartiesForRole(string roleType)
        {
            List<PARTY> allParties = this.GetAdditionalParties();
            List<PARTY> parties = new List<PARTY>();
            foreach (PARTY p in allParties)
            {
                string thisType = p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType;
                if (thisType == roleType)
                    parties.Add(p);
                else if (thisType == PartyRoleTypeEnumerated.Other 
                        &&  p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleTypeOtherDescription == roleType)
                    parties.Add(p);
            }
            return parties;
        }

        public List<RELATIONSHIP> GetRelationships()
        {
            List<RELATIONSHIP> relations = new List<RELATIONSHIP>();
            if (m_Request.RELATIONSHIPS == null)
            {
                m_Request.RELATIONSHIPS = new RELATIONSHIPS();
                m_Request.RELATIONSHIPS.RELATIONSHIP = relations.ToArray();
            }
            else if (m_Request.RELATIONSHIPS.RELATIONSHIP == null)
                m_Request.RELATIONSHIPS.RELATIONSHIP = relations.ToArray();
            relations.AddRange(m_Request.RELATIONSHIPS.RELATIONSHIP);
            return relations;

        }
        public void UpdateRelationships(List<RELATIONSHIP> relations)
        {
            m_Request.RELATIONSHIPS.RELATIONSHIP = relations.ToArray();
        }
        public void AddRelationship(string fromLink, string toLink)
        {
            RELATIONSHIP r = new RELATIONSHIP();
            r.xlinkFrom = fromLink;
            r.xlinkTo = toLink;
            AddRelationship(r);
        }
        public void AddRelationship(RELATIONSHIP r)
        {
            List<RELATIONSHIP> relations = GetRelationships();
            relations.Add(r);
            m_Request.RELATIONSHIPS.RELATIONSHIP = relations.ToArray();

        }
        public void DeleteRelationship(RELATIONSHIP r)
        {
            List<RELATIONSHIP> relations = GetRelationships();
            relations.Remove(r);
            m_Request.RELATIONSHIPS.RELATIONSHIP = relations.ToArray();

        }
        public RELATIONSHIP FindHWRelationship(string xlink)
        {
            foreach (RELATIONSHIP r in GetRelationships())
            {
                if (r.xlinkArcrole == AgentNetRealtionshipType.HusbandAndWife && (r.xlinkFrom == xlink || r.xlinkTo == xlink))
                    return r;
            }
            return null;
        }
        public void AddHusbandAndWifeRealtionship(PARTY from, PARTY to)
        {
            // First make sure this does not already exist
            if (FindHWRelationship(from.xlinklabel) == null && FindHWRelationship(to.xlinklabel) == null)
                AddRelationship(new RELATIONSHIP() { xlinkFrom = from.xlinklabel, xlinkTo = to.xlinklabel, xlinkArcrole = AgentNetRealtionshipType.HusbandAndWife });

        }
        //public RELATIONSHIP FindToRelationship(string fromLink)
        //{
        //}
        //public RELATIONSHIP FindFromRelationship(string toLink)
        //{
        //}
        public PARTY GetLender(string loanlink)
        {
            //TFS 96293
            if (m_Request.PARTIES == null || m_Request.PARTIES.PARTY == null ||
                m_Request.PARTIES.PARTY.Length == 0)
                return null;
            string lenderLinkId = GetLinkFrom(loanlink);
            foreach (PARTY p in m_Request.PARTIES.PARTY)
            {
                if (p.xlinklabel == lenderLinkId)
                    return p;
            }
            // Look for 1st Lender and link to it
            foreach (PARTY p in m_Request.PARTIES.PARTY)
            {
                if (p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == PartyRoleTypeEnumerated.Lender)
                {
                    if (p.xlinklabel == null || p.xlinklabel.Trim().Length == 0)
                    {
                        int next = s_Random.Next();
                        p.xlinklabel = next.ToString();
                    }
                    this.AddRelationship(p.xlinklabel, loanlink);
                    return p;
                }
            }
            return null;
        }
        public List<PARTY> GetMessageParties(string type)
        {
            List<PARTY> parties = new List<PARTY>();
            foreach (PARTY p in m_Message.DEAL_SETS.PARTIES.PARTY)
            {
                // below logic is to support ASC support system
                if (p.ROLES.ROLE[0].ROLE_DETAIL == null && p.ROLES.ROLE[0].REQUESTING_PARTY != null &&
                    type == PartyRoleTypeEnumerated.RequestingParty)
                    parties.Add(p);
                else if (p.ROLES.ROLE[0].ROLE_DETAIL == null && p.ROLES.ROLE[0].SUBMITTING_PARTY != null &&
                    type == PartyRoleTypeEnumerated.SubmittingParty)
                    parties.Add(p);
                else if (p.ROLES.ROLE[0].ROLE_DETAIL != null && p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == type)
                {// to update previously created Party linklabel 
                    if (p.xlinklabel == null || p.xlinklabel.Length == 0)
                    {
                        int next = s_Random.Next();
                        p.xlinklabel = next.ToString();
                    }
                    parties.Add(p);
                }
            }
            return parties;
        }
        public List<PARTY> GetParties(string type)
        {
            List<PARTY> parties = new List<PARTY>();
            if (m_Request.PARTIES != null && m_Request.PARTIES.PARTY != null)
            {
                foreach (PARTY p in m_Request.PARTIES.PARTY)
                {
                    if (p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType == type)
                    {// to update previously created Party linklabel 
                        if (p.xlinklabel == null || p.xlinklabel.Length == 0)
                        {
                            int next = s_Random.Next();
                            p.xlinklabel = next.ToString();
                        }
                        parties.Add(p);
                    }
                }
            }
            return parties;
        }
        public void AddParty(PARTY p)
        {
            List<PARTY> parties = new List<PARTY>();

            // To avoid the Exceptional error on the below scenario
            // Step 1 : Enter the File Info without Borrower and click on Invoke AgentNet button, System would
            //          throw the error message "Borrower is missing"
            // Step 2 : When we add the Borrower information, System would throw the error. Because m_Request.PARTIES.PARTY is null.
            if (m_Request.PARTIES.PARTY != null && m_Request.PARTIES.PARTY.Length > 0)
                parties.AddRange(m_Request.PARTIES.PARTY);

            if (p.xlinklabel == null || p.xlinklabel.Trim().Length == 0)
            {
                int next = s_Random.Next();
                p.xlinklabel = next.ToString();                
            }
            parties.Add(p);
            m_Request.PARTIES.PARTY = parties.ToArray();

        }
        public void DeleteParty(PARTY p)
        {
            List<PARTY> parties = new List<PARTY>();
            parties.AddRange(m_Request.PARTIES.PARTY);
            parties.Remove(p);
            // remove all the relations for this Party
            this.RemovRelationships(p.xlinklabel);
            m_Request.PARTIES.PARTY = parties.ToArray();

        }
        public void DeleteService(SERVICE s)
        {
            List<SERVICE> services = GetServices();
            services.Remove(s);
            // remove all the relations for this SERVICE
            this.RemovRelationships(s.xlinklabel);
            m_Request.SERVICES.SERVICE = services.ToArray();

        }
        public void DeleteServiceWithRelationship(SERVICE s)
        {
            List<SERVICE> services = GetServices();
            services.Remove(s);
            // remove all the relations for this SERVICE
            //this.RemovRelationships(s.xlinklabel);
            m_Request.SERVICES.SERVICE = services.ToArray();

        }
        private void RemovRelationships(string xlinklabel)
        {
            List<RELATIONSHIP> new_relations = new List<RELATIONSHIP>();
            foreach (RELATIONSHIP r in this.GetRelationships())
            {
                if (r.xlinkTo == xlinklabel ||
                    r.xlinkFrom == xlinklabel) 
                    continue;
                new_relations.Add(r);
            }
            this.UpdateRelationships(new_relations);
        }
        public string GetLinkFrom(string toLink)
        {
            List<RELATIONSHIP> relations = this.GetRelationships();
            foreach (RELATIONSHIP r in relations)
            {
                if (r.xlinkTo == toLink)
                {
                    return r.xlinkFrom;
                }
            }
            return "";
        }
        public List<LOAN> GetLoans()
        {
            List<LOAN> loans = new List<LOAN>();
            if (m_Request.LOANS != null)
            {
                if (m_Request.LOANS.LOAN == null)
                    m_Request.LOANS.LOAN = loans.ToArray();
                loans.AddRange(m_Request.LOANS.LOAN);
                foreach (LOAN l in loans)
                {
                    if (l.CLOSING_INFORMATION == null)
                    {// below added since old test data did not have this node created
                        l.CLOSING_INFORMATION = new CLOSING_INFORMATION();
                        l.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL = new CLOSING_INFORMATION_DETAIL();
                    }
                    if (l.xlinklabel == null || l.xlinklabel.Trim().Length == 0)
                    {// below added since old test data did not have the link lebl
                        int next = s_Random.Next();
                        l.xlinklabel = next.ToString();
                    }
                }
            }
            return loans;
        }
        public LOAN GetLoan(string servicelink)
        {
            string loanLinkId = GetLinkFrom(servicelink);
            List<LOAN> loans = this.GetLoans();
            foreach (LOAN l in loans)
            {
                if (l.xlinklabel == loanLinkId)
                    return l;
            }
            return null;
        }
        public void AddLoan(LOAN l)
        {
            List<LOAN> loans = new List<LOAN>();
            if (m_Request.LOANS == null)
                m_Request.LOANS = new LOANS();
            if (m_Request.LOANS.LOAN == null)
                m_Request.LOANS.LOAN = loans.ToArray();
            loans.AddRange(m_Request.LOANS.LOAN);
            loans.Add(l);
            m_Request.LOANS.LOAN = loans.ToArray();

        }
        public void DeleteLoan(LOAN l)
        {
            List<LOAN> loans = new List<LOAN>();
            loans.AddRange(m_Request.LOANS.LOAN);
            loans.Remove(l);
            // remove all the relations for this LOAN
            this.RemovRelationships(l.xlinklabel);
            m_Request.LOANS.LOAN = loans.ToArray();
        }
        public LOAN CreateLoan()
        {// Only one loan is supported in this simulator
            LOAN loan = new LOAN();
            int next = s_Random.Next();
            loan.xlinklabel = next.ToString();
            loan.LOAN_IDENTIFIERS = new LOAN_IDENTIFIERS();
            loan.LOAN_IDENTIFIERS.LOAN_IDENTIFIER = new LOAN_IDENTIFIER[1];
            loan.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0] = new LOAN_IDENTIFIER();
#if MISMO32
            loan.TERMS_OF_LOAN = new TERMS_OF_LOAN();
            loan.TERMS_OF_LOAN.NoteDate = DateTime.Now;
#else
            loan.TERMS_OF_MORTGAGE = new TERMS_OF_MORTGAGE();
            loan.TERMS_OF_MORTGAGE.NoteDate = DateTime.Now;
#endif
            loan.CLOSING_INFORMATION = new CLOSING_INFORMATION();
            loan.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL = new CLOSING_INFORMATION_DETAIL();
            return loan;
        }
        public List<SERVICE> GetServices()
        {
            if (m_Request == null)
                return null;
            List<SERVICE> services = new List<SERVICE>();
            if (m_Request.SERVICES != null && m_Request.SERVICES.SERVICE != null)
            {
                services.AddRange(m_Request.SERVICES.SERVICE);
            }
            foreach (SERVICE s in services)
            {
                if (s.xlinklabel == null || s.xlinklabel.Length == 0)
                    s.xlinklabel = s_Random.Next().ToString();
            }
            return services;
        }
        public void AddService(SERVICE s)
        {
            List<SERVICE> services = this.GetServices();
            services.Add(s);
            if (m_Request.SERVICES == null)
                m_Request.SERVICES = new SERVICES();
            m_Request.SERVICES.SERVICE = services.ToArray();
            return ;
        }

        public void AddRateFeeService(SERVICE s)
        {
            SERVICE[] serv = new SERVICE[1];
            serv[0] = s;
            if (m_Request.SERVICES == null)
                m_Request.SERVICES = new SERVICES();
            m_Request.SERVICES.SERVICE = serv;

            return;
        }

        public string County
        {
            get
            {
                if (GetProperty() != null)
                    return GetProperty().ADDRESS.CountyName;
                return "";
            }
        }
        public string StateCode
        {
            get
            {
                if (GetProperty() != null)
                    return GetProperty().ADDRESS.StateCode;
                return "";
            }
        }
        #endregion
        public void SaveRequest()
        {
            // TFS 96048 - replace the previous file
            string key = this.LoginId.ToLower() + "_" + FileNumber.ToLower();
            if (m_PreviousFileNumber.Length > 0 &&  !m_PreviousFileNumber.Equals(this.FileNumber))
            {
                // need to rename the previous File
                string prev_key = this.LoginId.ToLower() + "_" + m_PreviousFileNumber.ToLower();
                ANUtils.FileRename(ANUtils.FileDataPath + "//" + prev_key + ".xml",
                    ANUtils.FileDataPath + "//" + key + ".xml");
                if (ANUtils.FileExists(ANUtils.FileDataPath + "//" + prev_key + "_Response.xml"))
                {
                    ANUtils.FileRename(ANUtils.FileDataPath + "//" + prev_key + "_Response.xml",
                        ANUtils.FileDataPath + "//" + key + "_Response.xml");
                }
                m_PreviousFileNumber = this.FileNumber;
            }

            // save the request as MISMO XML
            string requestXML = ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Message);
            requestXML = ANUtils.FormatXML(requestXML);
            ANUtils.StringToFile(ANUtils.FileDataPath + "//" + key + ".xml", requestXML);
        }

        //zzzzz
        public void SaveRequest_ZZ(string fname)
        {
            // save the request as MISMO XML
            string requestXML = ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Message);
            
            //requestXML = ANUtils.FormatXML(requestXML);
            File.WriteAllText(fname, requestXML);
        }

        private void CreateBasicRequest()
        {

            m_Message = new MESSAGE();
            m_Message.ABOUT_VERSIONS = new ABOUT_VERSIONS();
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION = new ABOUT_VERSION[2];
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[0] = new ABOUT_VERSION();
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[0].AboutVersionIdentifier = AgentNetAboutVersionTypeEnum.AgentNet;
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[0].DataVersionName = AgentNetAboutVersionTypeEnum.AgentNet;
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[0].DataVersionIdentifier = AGENTNET_WS_VERION;
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[0].CreatedDatetime = DateTime.Now;
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[1] = new ABOUT_VERSION();
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[1].AboutVersionIdentifier = AgentNetAboutVersionTypeEnum.ClientSystem;
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[1].DataVersionName = s_SystemName; // Client System Name
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[1].DataVersionIdentifier = s_SystemVersion; // Client System's Version
            m_Message.ABOUT_VERSIONS.ABOUT_VERSION[1].CreatedDatetime = DateTime.Now;
            m_Message.DEAL_SETS = new DEAL_SETS();
            m_Message.DEAL_SETS.PARTIES = new PARTIES();
            List<PARTY> parties = new List<PARTY>();
            ADDRESS a = new ADDRESS();
            a.CityName = m_RequestingPartyCity;
            a.PostalCode = m_RequestingPartyPostalCode;
            a.StateCode = m_RequestingPartyState;
            a.AddressLineText = m_RequestingPartyStreetAddress;
            parties.Add(this.CreateEntityParty(PartyRoleTypeEnumerated.RequestingParty, m_RequestingPartyName, a));
            parties.Add(this.CreateEntityParty(PartyRoleTypeEnumerated.SubmittingParty, m_RequestingPartyName, a));

            m_Message.DEAL_SETS.PARTIES.PARTY = parties.ToArray();
            m_Message.DEAL_SETS.DEAL_SET = new DEAL_SET[1];
            m_Message.DEAL_SETS.DEAL_SET[0] = new DEAL_SET();
            m_Message.DEAL_SETS.DEAL_SET[0].DEALS = new DEALS();
            m_Message.DEAL_SETS.DEAL_SET[0].DEALS.DEAL = new DEAL[1];
            CreateDealRequest();
            m_Message.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0] = m_Request;


        }
#if MISMO32
        private void CreateDealRequest()
        {
            m_Request = new DEAL();
            m_Request.EXTENSION = new DEAL_EXTENSION();
            m_Request.EXTENSION.OTHER = new DEAL_OTHER();
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST = new AGENTNET_REQUEST();
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.ActionType = this.ActionType;
            int next = s_Random.Next();
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.ClientRequestId = next.ToString();
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.FileNumber = "";
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.AccountNumber = "";
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.SystemName = s_SystemName;
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.LoginAccountIdentifier = m_LoginId;
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.LoginAccountPasswordText = m_LoginPassword;
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.OfficeId = OfficeId;     //AZ: Added this.
            m_Request.PARTIES = new PARTIES();
            m_Request.PARTIES.PARTY = new PARTY[0];
        }
#else
        private void CreateDealRequest()
        {
            m_Request = new DEAL();
            m_Request.EXTENSION = new DEAL_EXTENSION();
            m_Request.EXTENSION.AGENTNET_REQUEST = new AGENTNET_REQUEST();
            m_Request.EXTENSION.AGENTNET_REQUEST.ActionType = this.ActionType;
            int next = s_Random.Next();
            m_Request.EXTENSION.AGENTNET_REQUEST.ClientRequestId = next.ToString();
            m_Request.EXTENSION.AGENTNET_REQUEST.FileNumber = "";
            m_Request.EXTENSION.AGENTNET_REQUEST.AccountNumber = "";
            m_Request.EXTENSION.AGENTNET_REQUEST.SystemName = s_SystemName;
            m_Request.PARTIES = new PARTIES();
            m_Request.PARTIES.PARTY = new PARTY[0];

        }
#endif
        #region HelperFunctions
        public string GenerateXML()
        {
            string requestXML = ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Message);
            return ANUtils.FormatXML(requestXML);
        }
        public DEAL GetDEAL()
        {
            return m_Request;
        }
#if MISMO32
        static public DEALRequest CloneRequest(DEALRequest reqToClone)
        {
            DEALRequest req = new DEALRequest();
            req.DEAL.SERVICES = new SERVICES();
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.FileNumber = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.FileNumber;
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.FileId = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.FileId;
            //TFS 97500
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.OfficeId = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.OfficeId;
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.UnderwriterCode = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.UnderwriterCode;
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.ClientFileStatusCode = AgentNetClientFileStatusEnum.Open;
            // yoshi
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.ClientRequestId = DEALRequest.Random.Next().ToString();
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.SystemName = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.SystemName;
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.PropertyTypeCode = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.PropertyTypeCode;
            if(reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AGENTNET_NAME_VALUES != null && reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null && reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
            {
                req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
                List<AGENTNET_NAME_VALUE> values = new List<AGENTNET_NAME_VALUE>();
                foreach(AGENTNET_NAME_VALUE v in reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE)
                {
                    AGENTNET_NAME_VALUE nv = new AGENTNET_NAME_VALUE();
                    nv.Name = v.Name;
                    nv.Value = v.Value;
                    values.Add(nv);
                }
                req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = values.ToArray();
            }
            //
            req.DEAL.LOANS = reqToClone.DEAL.LOANS;
            req.DEAL.COLLATERALS = reqToClone.DEAL.COLLATERALS;
            req.DEAL.PARTIES = reqToClone.DEAL.PARTIES;
            // Get the current Account Number of the requesting XML
            req.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AccountNumber = reqToClone.DEAL.EXTENSION.OTHER.AGENTNET_REQUEST.AccountNumber;
            req.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.InternalAccountIdentifier
                = reqToClone.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.InternalAccountIdentifier;
            //TFS 97500
            req.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier 
                = reqToClone.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier;

            return req;
        }
#else
        static public DEALRequest CloneRequest(DEALRequest reqToClone)
        {
            DEALRequest req = new DEALRequest();
            req.DEAL.SERVICES = new SERVICES();
            req.DEAL.EXTENSION.AGENTNET_REQUEST.FileNumber = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.FileNumber;
            req.DEAL.EXTENSION.AGENTNET_REQUEST.FileId = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.FileId;
            //TFS 97500
            req.DEAL.EXTENSION.AGENTNET_REQUEST.OfficeId = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.OfficeId;
            req.DEAL.EXTENSION.AGENTNET_REQUEST.UnderwriterCode = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.UnderwriterCode;
            req.DEAL.EXTENSION.AGENTNET_REQUEST.ClientFileStatusCode = AgentNetClientFileStatusEnum.Open;
            // yoshi
            req.DEAL.EXTENSION.AGENTNET_REQUEST.ClientRequestId = DEALRequest.Random.Next().ToString();
            req.DEAL.EXTENSION.AGENTNET_REQUEST.SystemName = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.SystemName;
            req.DEAL.EXTENSION.AGENTNET_REQUEST.PropertyTypeCode = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.PropertyTypeCode;
            if (reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.AGENTNET_NAME_VALUES != null && reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE != null && reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE.Length > 0)
            {
                req.DEAL.EXTENSION.AGENTNET_REQUEST.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
                List<AGENTNET_NAME_VALUE> values = new List<AGENTNET_NAME_VALUE>();
                foreach (AGENTNET_NAME_VALUE v in reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE)
                {
                    AGENTNET_NAME_VALUE nv = new AGENTNET_NAME_VALUE();
                    nv.Name = v.Name;
                    nv.Value = v.Value;
                    values.Add(nv);
                }
                req.DEAL.EXTENSION.AGENTNET_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = values.ToArray();
            }
            //
            req.DEAL.LOANS = reqToClone.DEAL.LOANS;
            req.DEAL.COLLATERALS = reqToClone.DEAL.COLLATERALS;
            req.DEAL.PARTIES = reqToClone.DEAL.PARTIES;
            // Get the current Account Number of the requesting XML
            req.DEAL.EXTENSION.AGENTNET_REQUEST.AccountNumber = reqToClone.DEAL.EXTENSION.AGENTNET_REQUEST.AccountNumber;
            req.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.InternalAccountIdentifier
                = reqToClone.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.InternalAccountIdentifier;
            //TFS 97500
            req.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier
                = reqToClone.MESSAGE.DEAL_SETS.PARTIES.PARTY[0].ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier;

            return req;
        }
#endif
        static public List<string> GetMISMONameSpaces()
        {
            List<string> ns = new List<string>();
            ns.Add("xsi," + "http://www.w3.org/2001/XMLSchema-instance");
            ns.Add("xlink," + MISMONameSpace.XLINK_NAMESPACE);
            ns.Add("agentnet," + MISMONameSpace.AGENTNET_NAMESPACE);
            return ns;
            
        }
        public PARTY CreateEntityParty(string roleType, string partyName, ADDRESS a)
        {
            PARTY p = new PARTY();
            p.LEGAL_ENTITY = new LEGAL_ENTITY();
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL = new LEGAL_ENTITY_DETAIL();
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.LegalEntityType = "Corporation";
            p.ROLES = new ROLES();
            p.ROLES.ROLE = new ROLE[1];
            p.ROLES.ROLE[0] = new ROLE();
            p.ROLES.ROLE[0].ROLE_DETAIL = new ROLE_DETAIL();
            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = roleType;
            if (roleType == PartyRoleTypeEnumerated.RequestingParty)
            {
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = partyName;
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.RequiredSignatoryCount = 1;   //AZ: Added this
                p.ROLES.ROLE[0].REQUESTING_PARTY = new REQUESTING_PARTY();
#if MISMO32
                //p.ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartyBranchIdentifier = "6402539";   //AZ: Added this
                p.ROLES.ROLE[0].REQUESTING_PARTY.RequestingPartySequenceNumber = 1;
#endif
                p.ADDRESSES = new ADDRESSES();
                p.ADDRESSES.ADDRESS = new ADDRESS[1];
                p.ADDRESSES.ADDRESS[0] = a;
            }
            else if (roleType == PartyRoleTypeEnumerated.SubmittingParty)
            {
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = partyName;
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.RequiredSignatoryCount = 0;   //AZ: Added this
                p.ROLES.ROLE[0].SUBMITTING_PARTY = new SUBMITTING_PARTY();
#if MISMO32
                p.ROLES.ROLE[0].SUBMITTING_PARTY.SubmittingPartySequenceNumber = 1;
#else
                p.ROLES.ROLE[0].SUBMITTING_PARTY.LoginAccountIdentifier = this.LoginId;
                p.ROLES.ROLE[0].SUBMITTING_PARTY.LoginAccountPasswordText = this.LoginPassword;
#endif
            }

            return p;
        }
        public PARTY CreateBorrowerIndividualParty(string firstName, string middleName, string lastName, string fullName, string maritalStatus = null)
        {
            return CreateParty(firstName, middleName, lastName, fullName, true, PartyRoleTypeEnumerated.Borrower, maritalStatus);
        }
        public PARTY CreateBorrowerEntityParty(string entityName, string entityType = null)
        {
            return CreateParty("", "", "", entityName, false, PartyRoleTypeEnumerated.Borrower, null, entityType);
        }
        public PARTY CreateSellerIndividualParty(string firstName, string middleName, string lastName, string fullName, string maritalStatus = null)
        {
            return CreateParty(firstName, middleName, lastName, fullName, true, PartyRoleTypeEnumerated.PropertySeller, maritalStatus);
        }
        public PARTY CreateSellerEntityParty(string entityName, string entityType = null)
        {
            return CreateParty("", "", "", entityName, false, PartyRoleTypeEnumerated.PropertySeller, null, entityType);
        }
        public PARTY CreateParty(string firstName, string middleName, string lastName, string entityName, bool bIndividual, string roleType, string maritalStatus = null, string entityType = null)
        {
            PARTY p = new PARTY();
            if (bIndividual)
            {
                p.INDIVIDUAL = new INDIVIDUAL();
                p.INDIVIDUAL.NAME = new NAME();
                p.INDIVIDUAL.NAME.FirstName = firstName;
                p.INDIVIDUAL.NAME.LastName = lastName;
                p.INDIVIDUAL.NAME.MiddleName = middleName;
                p.INDIVIDUAL.NAME.FullName = entityName;
            }
            else
            {
                p.LEGAL_ENTITY = new LEGAL_ENTITY();
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL = new LEGAL_ENTITY_DETAIL();
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = entityName;
                if (!string.IsNullOrEmpty(entityType))
                    p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.LegalEntityType = entityType;
            }

            p.ROLES = new ROLES();
            p.ROLES.ROLE = new ROLE[1];
            p.ROLES.ROLE[0] = new ROLE();
            p.ROLES.ROLE[0].ROLE_DETAIL = new ROLE_DETAIL();
            if (roleType == PartyRoleTypeEnumerated.Borrower)
            {
                p.ROLES.ROLE[0].BORROWER = new BORROWER();
                p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.Borrower;
                if (!string.IsNullOrEmpty(maritalStatus))
                {
                    p.ROLES.ROLE[0].BORROWER.BORROWER_DETAIL = new BORROWER_DETAIL();
                    p.ROLES.ROLE[0].BORROWER.BORROWER_DETAIL.MaritalStatusType = maritalStatus;
                }
            }
            else if (roleType == PartyRoleTypeEnumerated.PropertySeller)
            {
                p.ROLES.ROLE[0].PROPERTY_SELLER = new PROPERTY_SELLER();
                //p.ROLES.ROLE[0].PROPERTY_SELLER.MaritalStatusType = "Married";
                p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.PropertySeller;
                if (!string.IsNullOrEmpty(maritalStatus))
                {
                    p.ROLES.ROLE[0].PROPERTY_SELLER.MaritalStatusType = maritalStatus;
                }
            }
            else 
            {// This section used for Additional Parties 
                if (roleType == PartyRoleTypeEnumerated.Grantee)
                    p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.Grantee;
                else
                {
                    p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.Other;
                    p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleTypeOtherDescription = roleType;
                }
            }

            return p;
        }
        public PARTY UpdateIndividualParty(PARTY p, string firstName, string middleName, string lastName, string fullName, string maritalStatus = null)
        {
            return UpdateParty(true, p, firstName, middleName, lastName, fullName,maritalStatus);
        }
        public PARTY UpdateEntityParty(PARTY p, string entityName, string entityType = null)
        {
            return UpdateParty(false, p, "", "", "", entityName, null, entityType);
        }
        public PARTY UpdateParty(bool bIndividual, PARTY p, string firstName, string middleName, string lastName, string entityName, string maritalStatus = null, string entityType = null)
        {
            if (bIndividual)
            {
                if (p.INDIVIDUAL == null)
                {
                    p.LEGAL_ENTITY = null;
                    p.INDIVIDUAL = new INDIVIDUAL();
                    p.INDIVIDUAL.NAME = new NAME();
                }
                p.INDIVIDUAL.NAME.LastName = lastName;
                p.INDIVIDUAL.NAME.FirstName = firstName;
                p.INDIVIDUAL.NAME.MiddleName = middleName;
                p.INDIVIDUAL.NAME.FullName = entityName;
                // added Marital Status Ehancement
                if (maritalStatus != null)
                {
                    if (p.ROLES.ROLE[0].BORROWER != null)
                    {
                        if (p.ROLES.ROLE[0].BORROWER.BORROWER_DETAIL == null)
                            p.ROLES.ROLE[0].BORROWER.BORROWER_DETAIL = new BORROWER_DETAIL();
                        p.ROLES.ROLE[0].BORROWER.BORROWER_DETAIL.MaritalStatusType = maritalStatus;
                    }
                    else if (p.ROLES.ROLE[0].PROPERTY_SELLER != null)
                    {
                        p.ROLES.ROLE[0].PROPERTY_SELLER.MaritalStatusType = maritalStatus;
                    }
                }
            }
            else
            {
                if (p.LEGAL_ENTITY == null)
                {
                    p.INDIVIDUAL = null;
                    p.LEGAL_ENTITY = new LEGAL_ENTITY();
                    p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL = new LEGAL_ENTITY_DETAIL();
                    if (entityType != null)
                        p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.LegalEntityType = entityType;
                }
                p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = entityName;
            }
            return p;
        }

        public PARTY UpdateLenderParty(PARTY p, string entityName, string addressLine, string cityName, string stateCode, string zip, string CountyName)
        {
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = entityName;
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.LegalEntityType = "Corporation";
            p.ADDRESSES.ADDRESS[0].AddressLineText = addressLine;
            p.ADDRESSES.ADDRESS[0].CityName = cityName;
            p.ADDRESSES.ADDRESS[0].CountryName = "USA";
            p.ADDRESSES.ADDRESS[0].CountyName = CountyName;
            DEALRequest.UpdatePostalZip(p.ADDRESSES.ADDRESS[0], zip);
            p.ADDRESSES.ADDRESS[0].StateCode = stateCode;
            return p;
        }
#if MISMO32
        public PARTY CreateLenderParty(string entityName, string addressLine, string cityName, string stateCode, string zip, string CountyName)
        {// there may be a case that the "lender" is not a corporation but for this example, it is assumed that a lender is a corporation

            int next = s_Random.Next();
            string uniqueLenderId = next.ToString();

            PARTY p = new PARTY();
            p.xlinklabel = uniqueLenderId;
            p.LEGAL_ENTITY = new LEGAL_ENTITY();
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL = new LEGAL_ENTITY_DETAIL();
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = entityName;
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.LegalEntityType = "Corporation";
            p.ROLES = new ROLES();
            //p.ROLES.PARTY_ROLE_IDENTIFIERS = new PARTY_ROLE_IDENTIFIERS();
            //p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER = new PARTY_ROLE_IDENTIFIER[1];
            //p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0] = new PARTY_ROLE_IDENTIFIER();
            //p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0].PartyRoleIdentifier = uniqueLenderId; // Lender ID to tie back to Loan for now
            p.ROLES.ROLE = new ROLE[1];
            p.ROLES.ROLE[0] = new ROLE();
            p.ROLES.ROLE[0].LENDER = new LENDER();
            //p.ROLES.ROLE[0].LENDER.LENDER_DETAIL = new LENDER_DETAIL();
            //p.ROLES.ROLE[0].LENDER.LENDER_DETAIL.LenderFunderName = entityName;
            p.ROLES.ROLE[0].ROLE_DETAIL = new ROLE_DETAIL();
            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.Lender;
            p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS = new PARTY_ROLE_IDENTIFIERS();
            p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER = new PARTY_ROLE_IDENTIFIER[1];
            p.ROLES.ROLE[0].PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0] = new PARTY_ROLE_IDENTIFIER();
            p.ADDRESSES = new ADDRESSES();
            p.ADDRESSES.ADDRESS = new ADDRESS[1];
            p.ADDRESSES.ADDRESS[0] = new ADDRESS();
            p.ADDRESSES.ADDRESS[0].AddressLineText = addressLine;
            p.ADDRESSES.ADDRESS[0].CityName = cityName;
            p.ADDRESSES.ADDRESS[0].CountryName = "USA";
            p.ADDRESSES.ADDRESS[0].CountyName = CountyName;
            DEALRequest.UpdatePostalZip(p.ADDRESSES.ADDRESS[0], zip);
            p.ADDRESSES.ADDRESS[0].StateCode = stateCode;
            return p;
        }
        public LOAN CreateLoan(string loanNumber, DateTime loanDate, decimal loanAmount, string loanPurposeType) //, string mortgageType)
        {
            int next = s_Random.Next();
            string uniqueLoanId = next.ToString();
            LOAN ln = new LOAN();
            ln.xlinklabel = uniqueLoanId;
            ln.LOAN_IDENTIFIERS = new LOAN_IDENTIFIERS();
            ln.LOAN_IDENTIFIERS.LOAN_IDENTIFIER = new LOAN_IDENTIFIER[1];
            ln.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0] = new LOAN_IDENTIFIER();
            ln.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0].LoanIdentifier = loanNumber;
            ln.TERMS_OF_LOAN = new TERMS_OF_LOAN();
            ln.TERMS_OF_LOAN.LoanPurposeType = loanPurposeType;// LoanPurposeEnum.Purchase;
            ln.TERMS_OF_LOAN.MortgageType = MortgageTypeEnumerated.Conventional;
            ln.TERMS_OF_LOAN.NoteAmount = loanAmount;
            ln.TERMS_OF_LOAN.NoteDate = loanDate;
            return ln;

        }
#else
        public PARTY CreateLenderParty(string entityName, string addressLine, string cityName, string stateCode, string zip, string CountyName)
        {// there may be a case that the "lender" is not a corporation but for this example, it is assumed that a lender is a corporation

            int next = s_Random.Next();
            string uniqueLenderId = next.ToString();

            PARTY p = new PARTY();
            p.xlinklabel = uniqueLenderId;
            p.LEGAL_ENTITY = new LEGAL_ENTITY();
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL = new LEGAL_ENTITY_DETAIL();
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.FullName = entityName;
            p.LEGAL_ENTITY.LEGAL_ENTITY_DETAIL.LegalEntityType = "Corporation";
            p.ROLES = new ROLES();
            p.ROLES.PARTY_ROLE_IDENTIFIERS = new PARTY_ROLE_IDENTIFIERS();
            p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER = new PARTY_ROLE_IDENTIFIER[1];
            p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0] = new PARTY_ROLE_IDENTIFIER();
            p.ROLES.PARTY_ROLE_IDENTIFIERS.PARTY_ROLE_IDENTIFIER[0].PartyRoleIdentifier = uniqueLenderId; // Lender ID to tie back to Loan for now
            p.ROLES.ROLE = new ROLE[1];
            p.ROLES.ROLE[0] = new ROLE();
            p.ROLES.ROLE[0].LENDER = new LENDER();
            p.ROLES.ROLE[0].LENDER.LENDER_DETAIL = new LENDER_DETAIL();
            p.ROLES.ROLE[0].LENDER.LENDER_DETAIL.LenderFunderName = entityName;
            p.ROLES.ROLE[0].ROLE_DETAIL = new ROLE_DETAIL();
            p.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.Lender;
            //PARTY_ROLE_IDENTIFIERS
            p.ADDRESSES = new ADDRESSES();
            p.ADDRESSES.ADDRESS = new ADDRESS[1];
            p.ADDRESSES.ADDRESS[0] = new ADDRESS();
            p.ADDRESSES.ADDRESS[0].AddressLineText = addressLine;
            p.ADDRESSES.ADDRESS[0].CityName = cityName;
            p.ADDRESSES.ADDRESS[0].CountryName = "USA";
            p.ADDRESSES.ADDRESS[0].CountyName = CountyName;
            p.ADDRESSES.ADDRESS[0].PostalCode = zip;
            p.ADDRESSES.ADDRESS[0].StateCode = stateCode;
            return p;
        }
        public LOAN CreateLoan(string loanNumber, DateTime loanDate, decimal loanAmount, string loanPurposeType) //, string mortgageType)
        {
            int next = s_Random.Next();
            string uniqueLoanId = next.ToString();
            LOAN ln = new LOAN();
            ln.xlinklabel = uniqueLoanId;
            ln.LOAN_IDENTIFIERS = new LOAN_IDENTIFIERS();
            ln.LOAN_IDENTIFIERS.LOAN_IDENTIFIER = new LOAN_IDENTIFIER[1];
            ln.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0] = new LOAN_IDENTIFIER();
            ln.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0].LoanIdentifierValue = loanNumber;
            ln.TERMS_OF_MORTGAGE = new TERMS_OF_MORTGAGE();
            ln.TERMS_OF_MORTGAGE.LoanPurposeType = loanPurposeType;// LoanPurposeEnum.Purchase;
            ln.TERMS_OF_MORTGAGE.MortgageType = MortgageTypeEnumerated.Conventional;
            ln.TERMS_OF_MORTGAGE.NoteAmount = loanAmount;
            ln.TERMS_OF_MORTGAGE.NoteDate = loanDate;
            return ln;

        }
#endif
        public SERVICE CreateServiceProduct(string serviceType, string productId, string productDescr, List<SERVICE> services)
        {
            SERVICE s = new SERVICE();
            s.SERVICE_PRODUCT = new SERVICE_PRODUCT();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST = new SERVICE_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION = new SERVICE_PRODUCT_REQUEST_EXTENSION();
#if MISMO32
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER = new SERVICE_PRODUCT_REQUEST_OTHER();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST = new AGENTNET_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType = serviceType;
#else
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST = new AGENTNET_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType = serviceType;
#endif
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL = new SERVICE_PRODUCT_DETAIL();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL.ServiceProductIdentifier = productId;
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL.ServiceProductDescription = productDescr;
            if (services != null && services.Count > 0)
            {
                List<AGENTNET_NAME_VALUE> keyValues = new List<AGENTNET_NAME_VALUE>();
#if MISMO32
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE
                    = keyValues.ToArray();
#else
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE
                    = keyValues.ToArray();
#endif
            }
            return s;

        }
        public COLLATERAL CreatePropertyCollateral(string streetLine1, string streetLine2, string cityName, string stateCode, string zipCode,
           string countyName, string apnNumber)
        {
            COLLATERAL c = new COLLATERAL();
            PROPERTY property = new PROPERTY();
            property.ADDRESS = new ADDRESS();
            property.ADDRESS.AddressLineText = streetLine1;
            property.ADDRESS.AddressAdditionalLineText = streetLine2;
            property.ADDRESS.CityName = cityName;
            property.ADDRESS.CountryName = "USA";
            property.ADDRESS.CountyName = countyName;
            DEALRequest.UpdatePostalZip(property.ADDRESS, zipCode);
            property.ADDRESS.StateCode = stateCode;
            property.LEGAL_DESCRIPTIONS = new LEGAL_DESCRIPTIONS();
            property.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION = new LEGAL_DESCRIPTION[1];
            property.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0] = new LEGAL_DESCRIPTION();
            property.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS = new PARCEL_IDENTIFICATIONS();
            property.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION = new PARCEL_IDENTIFICATION[1];
            property.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION[0] = new PARCEL_IDENTIFICATION();
            property.LEGAL_DESCRIPTIONS.LEGAL_DESCRIPTION[0].PARCEL_IDENTIFICATIONS.PARCEL_IDENTIFICATION[0].ParcelIdentifier = apnNumber;
#if MISMO32
            c.SUBJECT_PROPERTY = property;
#else
            c.PROPERTIES.PROPERTY[0] = property;
#endif
            return c;
        }
#if MISMO32
        public void CreateGetDataBase(AGENTNET_GET_DATA agentNetGetDataObj)
        {
            SERVICE s = new SERVICE();
            s.SERVICE_PRODUCT = new SERVICE_PRODUCT();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST = new SERVICE_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION = new SERVICE_PRODUCT_REQUEST_EXTENSION();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER = new SERVICE_PRODUCT_REQUEST_OTHER();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST = new AGENTNET_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType = AgentNetActionTypeEnum.GET_DATA;
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_GET_DATA = agentNetGetDataObj;
            m_Request.SERVICES = new SERVICES();
            m_Request.SERVICES.SERVICE = new SERVICE[1];
            m_Request.SERVICES.SERVICE[0] = s;
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.ActionType = AgentNetActionTypeEnum.GET_DATA; 
            return;
        }
        public MESSAGE CreateSpecialRequestService(string serviceType, string productServiceId, string productStatus, List<AGENTNET_NAME_VALUE> nameValues)
        {
            SERVICE  s = CreateServiceProduct(serviceType, productServiceId, "", null);
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AgentNetProductServiceId = productServiceId;
            if (nameValues != null)
            {
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = nameValues.ToArray();
            }
            if (m_Request.SERVICES == null)
                m_Request.SERVICES = new SERVICES();
            m_Request.SERVICES.SERVICE = new SERVICE[1];
            m_Request.SERVICES.SERVICE[0] = s;
            return m_Message;
        }

#else
        public void CreateGetDataBase(AGENTNET_GET_DATA agentNetGetDataObj)
        {
            SERVICE s = new SERVICE();
            s.SERVICE_PRODUCT = new SERVICE_PRODUCT();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST = new SERVICE_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION = new SERVICE_PRODUCT_REQUEST_EXTENSION();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST = new AGENTNET_PRODUCT_REQUEST();
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType = AgentNetActionTypeEnum.GET_DATA;
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_GET_DATA = agentNetGetDataObj;
            m_Request.SERVICES = new SERVICES();
            m_Request.SERVICES.SERVICE = new SERVICE[1];
            m_Request.SERVICES.SERVICE[0] = s;
            m_Request.EXTENSION.AGENTNET_REQUEST.ActionType = AgentNetActionTypeEnum.GET_DATA; 
            return;
        }
        public MESSAGE CreateSpecialRequestService(string serviceType, string productServiceId, string productStatus, List<AGENTNET_NAME_VALUE> nameValues)
        {
            SERVICE  s = CreateServiceProduct(serviceType, productServiceId, "", null);
            s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AgentNetProductServiceId = productServiceId;
            if (nameValues != null)
            {
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();
                s.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = nameValues.ToArray();
            }
            if (m_Request.SERVICES == null)
                m_Request.SERVICES = new SERVICES();
            m_Request.SERVICES.SERVICE = new SERVICE[1];
            m_Request.SERVICES.SERVICE[0] = s;
            return m_Message;
        }
#endif
        public MESSAGE CreateGetJacketTypes(string stateCode, string underwriterCode, string vendorSystemName)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.JACKET_TYPES;
            getReq.Parm = new string[3];
            getReq.Parm[0] = stateCode;
            getReq.Parm[1] = underwriterCode;
            getReq.Parm[2] = vendorSystemName;
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetRecordingFees_Cities_By_CountyID(Int32 CountyId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_RECORDINGFEES_CITIES_BY_COUNTYID ;
            getReq.Parm = new string[1];
            getReq.Parm[0] = Convert.ToString(CountyId);
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetRecordingFeesDocument()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_RECORDINGFEES_DOCUMENT ;
 
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetUWBDocumentTypes()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_UNDERWRITING_DOCUMENT_TYPES;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetUWBDocumentByDocumentId(int DocumentId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_UNDERWRITING_DOCUMENT;
            getReq.Parm = new string[1];
            getReq.Parm[0] = Convert.ToString(DocumentId);
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetUWBRequestByTransactionId(Int32 requestId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_UNDERWRITING_TRANSACTION_DETAILS;
            getReq.Parm = new string[1];
            getReq.Parm[0] = Convert.ToString( requestId);            
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetPropertyTypes()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_PROPERTY_TYPES;
            getReq.Parm = new string[0];
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetRecordingDocumentNames()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_RECORDING_DOCUMENT_NAMES;
            //getReq.Parm = new string[1];
            //getReq.Parm[0] = classTypeId.ToString();
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGenericService()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_GENERIC_SERVICE_TYPES;
            getReq.Parm = new string[0];
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetPolicySimulCountByState(string stateCode, string MinEffDate)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_STATE_SPECIFIC_SIMUL_COUNT;
            getReq.Parm = new string[2];
            getReq.Parm[0] = stateCode;
            getReq.Parm[1] = MinEffDate;

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetEndpointByService(string LoginId, string password, string fileNumber, string fileId, string serviceName)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_ENDPOINT_BY_SERVICE;
            getReq.Parm = new string[4];
            getReq.Parm[0] = fileNumber;
            getReq.Parm[1] = fileId;
            getReq.Parm[2] = serviceName;
            getReq.Parm[3] = LoginId;

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetTitleSearchOrderData(string LoginId, string password, string FileId, string OrderId, string Statecode)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_TITLE_SEARCH_ORDER_DATA;
            getReq.Parm = new string[3];
            getReq.Parm[0] = FileId;
            getReq.Parm[1] = OrderId;
            getReq.Parm[2] = Statecode;

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateRateTypes(string productId, string stateCode, string underWriterCode, string effectiveDate, bool isExtendedCoverage, string vendorName, string officeId, string agentNetProductServiceId, string county, string accountNumuber, string businesssegment)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_RATE_TYPES;
            getReq.Parm = new string[11];

            getReq.Parm[0] = productId;
            getReq.Parm[1] = stateCode;
            getReq.Parm[2] = underWriterCode;
            getReq.Parm[3] = effectiveDate;

            if (isExtendedCoverage)
                getReq.Parm[4] = "true";
            else
                getReq.Parm[4] = "false";

            getReq.Parm[5] = vendorName;
            getReq.Parm[6] = county;
            getReq.Parm[7] = accountNumuber;
            // Modified for version 2.4 - BusinessSegment change
            getReq.Parm[8] = businesssegment;
            //originally below parameters are name value pairs but will be changed to optional params later.
            getReq.Parm[9] = officeId;
            getReq.Parm[10] = agentNetProductServiceId;

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateBOUploadedDocuments(string fileId, string orderId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_BOPS_UPLOADEDDOCS;
            getReq.Parm = new string[2];

            getReq.Parm[0] = fileId;
            getReq.Parm[1] = orderId;
           
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetServiceOrderFieldsPost(String[] parms)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_SERVICE_ORDER_FIELDS;
            getReq.Parm = parms;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateBOPSUpdateOrderDetails(string orderId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.BOPS_ORDER_UPDATE_DETAILS;
            getReq.Parm = new string[1];
            getReq.Parm[0] = orderId;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateMultiTypeDatas(string multiType, params string[] parms)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_MULTI_TYPE_DATAS;
          
            int length = 1;
            if (parms != null)
            {
                length += parms.Length;
            }

            getReq.Parm = new string[length];
            getReq.Parm[0] = multiType;

            if (parms != null)
            {
                int i = 1;
                foreach (string s in parms)
                    getReq.Parm[i++] = s;
            }

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateFileStatus(string[] parms)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.FILE_STATUS;
            getReq.Parm = parms;
            CreateGetDataBase(getReq);
            return m_Message;
        }
       
        public MESSAGE ValidateLogin(string loginUserId,string password)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.VALIDATE_LOGIN;
            CreateGetDataBase(getReq);
            CreateSubmittingParty(loginUserId, password);
            m_Message.DEAL_SETS.PARTIES.PARTY = m_Request.PARTIES.PARTY;
            return m_Message;
        }

        public MESSAGE ValidateCounty(string stateCode, string countyName)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.VALIDATE_COUNTY;
            getReq.Parm = new string[2];
            getReq.Parm[0] = stateCode;
            getReq.Parm[1] = countyName;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE ChangePassword(string loginUserId, string currentPassword,string newPassword)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.CHANGE_PASSWORD;
            getReq.Parm = new string[2];
            getReq.Parm[0] = newPassword;
            CreateGetDataBase(getReq);
            CreateSubmittingParty(loginUserId, currentPassword);
            m_Message.DEAL_SETS.PARTIES.PARTY = m_Request.PARTIES.PARTY;
            return m_Message;
        }
#if MISMO32
        public void CreateSubmittingParty(string loginUserId, string password)
        {
            SUBMITTING_PARTY submittingParty = new SUBMITTING_PARTY();
            submittingParty.SubmittingPartySequenceNumber = 1;// mismo 3.2 REQUIREMENT
            m_Request.PARTIES = new PARTIES();
            m_Request.PARTIES.PARTY = new PARTY[1];
            m_Request.PARTIES.PARTY[0] = new PARTY();
            m_Request.PARTIES.PARTY[0].ROLES = new ROLES();
            m_Request.PARTIES.PARTY[0].ROLES.ROLE = new ROLE[1];
            m_Request.PARTIES.PARTY[0].ROLES.ROLE[0] = new ROLE();
            m_Request.PARTIES.PARTY[0].ROLES.ROLE[0].SUBMITTING_PARTY = submittingParty;
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.LoginAccountIdentifier = loginUserId;
            m_Request.EXTENSION.OTHER.AGENTNET_REQUEST.LoginAccountPasswordText = password;
        }
#else
        public void CreateSubmittingParty(string loginUserId, string password)
        {
            SUBMITTING_PARTY submittingParty = new SUBMITTING_PARTY();
            submittingParty.LoginAccountIdentifier = loginUserId;
            submittingParty.LoginAccountPasswordText = password;
            m_Request.PARTIES = new PARTIES();
            m_Request.PARTIES.PARTY = new PARTY[1];
            m_Request.PARTIES.PARTY[0] = new PARTY();
            m_Request.PARTIES.PARTY[0].ROLES = new ROLES();
            m_Request.PARTIES.PARTY[0].ROLES.ROLE = new ROLE[1];
            m_Request.PARTIES.PARTY[0].ROLES.ROLE[0] = new ROLE();
            m_Request.PARTIES.PARTY[0].ROLES.ROLE[0].SUBMITTING_PARTY = submittingParty;
        }
#endif
        public MESSAGE CreateGetCPLTypes(string stateCode, string underwriterCode)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.CPL_TYPES;
            getReq.Parm = new string[2];
            getReq.Parm[0] = stateCode;
            getReq.Parm[1] = underwriterCode;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetProductTypes(string VendorSystemName, string StateCode, string county, string UnderwriterCode, string PropertyType)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_TITLE_PRODUCTS;

            getReq.Parm = new string[5];
            getReq.Parm[0] = VendorSystemName;
            getReq.Parm[1] = StateCode;
            getReq.Parm[2] = county;
            getReq.Parm[3] = UnderwriterCode;
            getReq.Parm[4] = PropertyType;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetCounties(string stateCode)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_COUNTIES;
            getReq.Parm = new string[1];
            getReq.Parm[0] = stateCode;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetPreviousFileData(string strFile,string officeId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.PREVIOUS_FILE_DATA;
            getReq.Parm = new string[2];
            getReq.Parm[0] = strFile;
            getReq.Parm[1] = officeId;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetJacketsByFileNumber(string fileNumber)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_JACKETS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = fileNumber;
            getReq.Parm[1] = "";
            getReq.Parm[2] = "";
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetJacketsByFileId(string fileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_JACKETS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = "";
            getReq.Parm[1] = fileId;
            getReq.Parm[2] = "";
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetJacketsByClientFileId(string clientFileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_JACKETS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = "";
            getReq.Parm[1] = "";
            getReq.Parm[2] = clientFileId;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetJacketsAndCplsByFileNumber(string fileNumber)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_JACKETS_AND_CPLS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = fileNumber;
            CreateGetDataBase(getReq);

            return m_Message;
        }

        public MESSAGE CreateGetJacketsAndCplsByFileId(string fileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_JACKETS_AND_CPLS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = "";
            getReq.Parm[1] = fileId;
            getReq.Parm[2] = "";

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetJacketsAndCplsByClientFileId(string clientFileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_JACKETS_AND_CPLS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = "";
            getReq.Parm[1] = "";
            getReq.Parm[2] = clientFileId;

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetCPLsByFileNumber(string fileNumber)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_CPLS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = fileNumber;
            getReq.Parm[1] = "";
            getReq.Parm[2] = "";

            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetCPLsByFileId(string fileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_CPLS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = "";
            getReq.Parm[1] = fileId;
            getReq.Parm[2] = "";

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetCPLsByClientFileId(string clientFileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_CPLS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = "";
            getReq.Parm[1] = "";
            getReq.Parm[2] = clientFileId;

            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetLastResponse(string clientRequestId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_LAST_RESPONSE;
            getReq.Parm = new string[1];
            getReq.Parm[0] = clientRequestId;

            CreateGetDataBase(getReq);
            return m_Message;
        }

       
        public MESSAGE CreateGetJacketEndorsements(string jackeTypeId, string stateCode, string underwriterCode)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.JACKET_ENDORSEMENTS;
            getReq.Parm = new string[3];
            getReq.Parm[0] = jackeTypeId;
            getReq.Parm[1] = stateCode;
            getReq.Parm[2] = underwriterCode;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetAccount(string firmlocationId, string firmId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.ACCOUNTS;
            getReq.Parm = new string[2];
            getReq.Parm[0] = firmlocationId;
            getReq.Parm[1] = firmId;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetJacketTypeFields(string jackeTypeId, string stateCode, string underwriterCode,string officeId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.JACKET_TYPE_FIELDS;
            getReq.Parm = new string[4];
            getReq.Parm[0] = jackeTypeId;
            getReq.Parm[1] = stateCode;
            getReq.Parm[2] = underwriterCode;
            getReq.Parm[3] = officeId;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetUnderwriters(string firmId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.UNDERWRITERS;
            getReq.Parm = new string[1];
            getReq.Parm[0] = firmId;
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetBusinessSegments(string stateCode, string NAICPropertyType, string FileNumber, int OfficeId, int FileId)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.BUSINESS_SEGMENTS;
            getReq.Parm = new string[5];
            getReq.Parm[0] = stateCode;
            getReq.Parm[1] = NAICPropertyType;
            getReq.Parm[2] = FileNumber;
            getReq.Parm[3] = OfficeId.ToString();
            getReq.Parm[4] = FileId.ToString();
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetSecondPartyState(string stateCode, string secondPartyRole)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_SECOND_PARTY_STATES;
            getReq.Parm = new string[2];
            getReq.Parm[0] = stateCode;
            getReq.Parm[1] = secondPartyRole;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateOverrideReasons()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_OVERRIDEREASONS;
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetCPLFeeStates()
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.CPL_FEE_STATES;
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetBOPSOrdersCompleted(bool IsGetAll)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.BOPS_ORDERS_COMPLETED;
            if (IsGetAll)
            {
                getReq.Parm = new string[1];
                getReq.Parm[0] = "True";
            }
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetBOPSDocumentsList(int OrderId, bool bAllDocs = false)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.BOPS_DOCUMENTS_LIST;
            if (bAllDocs)
                getReq.Parm = new string[2];
            else
                getReq.Parm = new string[1];
            getReq.Parm[0] = OrderId.ToString();
            if (bAllDocs)
                getReq.Parm[1] = "True";
            CreateGetDataBase(getReq);
            return m_Message;
        }
        public MESSAGE CreateGetParties(string PartyType, params string[] SearchParam)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.PARTIES;
            int length=0;
            if(SearchParam!=null)
              length= SearchParam.Length;

            getReq.Parm = new string[length + 1];
            getReq.Parm[0] = PartyType;   
            for (int i = 0; i < length; i++)
            {
                getReq.Parm[i+1] = SearchParam[i];
            }
            CreateGetDataBase(getReq);
            return m_Message;
        }

        public MESSAGE CreateGetSpecialMessage(string MessageType)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_SPECIAL_MESSAGE;

            getReq.Parm = new string[1];
            getReq.Parm[0] = MessageType;
            CreateGetDataBase(getReq);

            return m_Message;
        }

        public MESSAGE CreateGetServiceOrderDisclaimer(string MessageType, string ProductId, string ProductName, string FileId, string OrderNumber, bool IsRequestUpdate)
        {
            AGENTNET_GET_DATA getReq = new AGENTNET_GET_DATA();
            getReq.GetRequestType = AgentNetGetRequestEnum.GET_SPECIAL_MESSAGE;

            getReq.Parm = new string[6];
            getReq.Parm[0] = MessageType;
            getReq.Parm[1] = ProductId ?? String.Empty;
            getReq.Parm[2] = ProductName ?? String.Empty;
            getReq.Parm[3] = FileId ?? String.Empty;
            getReq.Parm[4] = OrderNumber ?? String.Empty;
            getReq.Parm[5] = IsRequestUpdate.ToString();
            CreateGetDataBase(getReq);

            return m_Message;
        }

        public SERVICE CreateNewServiceProduct(string ServiceType, string ProductTypeId, string ProductTypeName, string typeCode)
        {
            SERVICE service = new SERVICE();
            int next = DEALRequest.Random.Next();
            service.xlinklabel = next.ToString();
            service.SERVICE_PRODUCT = new SERVICE_PRODUCT();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST = new SERVICE_PRODUCT_REQUEST();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL = new SERVICE_PRODUCT_DETAIL();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL.ServiceProductIdentifier = ProductTypeId;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.SERVICE_PRODUCT_DETAIL.ServiceProductDescription = ProductTypeName;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION = new SERVICE_PRODUCT_REQUEST_EXTENSION();
#if MISMO32
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER = new SERVICE_PRODUCT_REQUEST_OTHER();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST = new AGENTNET_PRODUCT_REQUEST();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType = ServiceType;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.ProductTypeCode = typeCode;
#else
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST = new AGENTNET_PRODUCT_REQUEST();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AgentNetServiceType = ServiceType;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.ProductTypeCode = typeCode;
#endif
            return service;
        }
#if MISMO32
        public SERVICE AddNamedValuesToService(SERVICE service, List<AGENTNET_NAME_VALUE> namedvalues)
        {
            if (service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES == null)
                service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES
                    = new AGENTNET_NAME_VALUES();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = namedvalues.ToArray();
            return service;
        }
        public SERVICE AddPricingRequestToService(SERVICE service, List<AGENTNET_PRODUCT_PRICING_REQUEST> pricingRequests, AGENTNET_NAME_VALUE[] nameValues,DateTime rateEffectiveDate, Boolean isSimultaneousPrice,Boolean isAutoReportOnHold, DateTime policyComplianceDate, Boolean isPolicyComplianceDateNull)
        {

            if (service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS == null)
                service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS = new AGENTNET_PRODUCT_PRICING_REQUESTS();

            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.IsSimultaniousPrice = isSimultaneousPrice;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST = pricingRequests.ToArray();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.RateEffectiveDate = rateEffectiveDate;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.IsAutoReportOnHold = isAutoReportOnHold;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.IsPolicyComplianceDateNull = isPolicyComplianceDateNull;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.PolicyComplianceDate = policyComplianceDate;
            //if (nameValues != null)
            //{
            if (service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_NAME_VALUES == null)
                service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();

            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.OTHER.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = nameValues;
            //}
            return service;
        }
#else
        public SERVICE AddNamedValuesToService(SERVICE service, List<AGENTNET_NAME_VALUE> namedvalues)
        {
            if (service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES == null)
                service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES
                    = new AGENTNET_NAME_VALUES();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = namedvalues.ToArray();
            return service;
        }
        public SERVICE AddPricingRequestToService(SERVICE service, List<AGENTNET_PRODUCT_PRICING_REQUEST> pricingRequests, AGENTNET_NAME_VALUE[] nameValues, DateTime rateEffectiveDate, bool isSimultaneousPrice, bool isAutoReportOnHold, DateTime policyComplianceDate, bool ispolicyComplianceDateNull)
        {

            if (service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS == null)
                service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS = new AGENTNET_PRODUCT_PRICING_REQUESTS();

            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.IsSimultaniousPrice = isSimultaneousPrice;
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_PRODUCT_PRICING_REQUEST = pricingRequests.ToArray();
            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.RateEffectiveDate = rateEffectiveDate;
			service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.IsAutoReportOnHold = isAutoReportOnHold;
            
        //if (nameValues != null)
            //{
            if (service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_NAME_VALUES == null)
                service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_NAME_VALUES = new AGENTNET_NAME_VALUES();

            service.SERVICE_PRODUCT.SERVICE_PRODUCT_REQUEST.EXTENSION.AGENTNET_PRODUCT_REQUEST.AGENTNET_PRODUCT_PRICING_REQUESTS.AGENTNET_NAME_VALUES.AGENTNET_NAME_VALUE = nameValues;
            //}
            return service;
        }
#endif
        public void AddSalesPriceAmount(PROPERTY prop, decimal salesPriceAmt)
        {
            prop.SALES_CONTRACTS = new SALES_CONTRACTS();
            prop.SALES_CONTRACTS.SALES_CONTRACT = new SALES_CONTRACT[1];
            prop.SALES_CONTRACTS.SALES_CONTRACT[0] = new SALES_CONTRACT();
#if MISMO32
            prop.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL = new SALES_CONTRACT_DETAIL();
            prop.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL.SalesContractAmount = salesPriceAmt;
#else
            prop.SALES_CONTRACTS.SALES_CONTRACT[0].PropertySalesPriceAmount = salesPriceAmt;
#endif
        }
        public decimal GetSalesPriceAmount()
        {
            PROPERTY prop = GetProperty();
            if (prop.SALES_CONTRACTS != null &&
                prop.SALES_CONTRACTS.SALES_CONTRACT != null &&
                prop.SALES_CONTRACTS.SALES_CONTRACT.Length > 0 &&
#if MISMO32
                prop.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL != null)
                return prop.SALES_CONTRACTS.SALES_CONTRACT[0].SALES_CONTRACT_DETAIL.SalesContractAmount;
#else
                prop.SALES_CONTRACTS.SALES_CONTRACT.Length > 0)
                return prop.SALES_CONTRACTS.SALES_CONTRACT[0].PropertySalesPriceAmount;
#endif
            return 0;
        }

        public static DEAL GetDEAL(MESSAGE msg)
        {
            return msg.DEAL_SETS.DEAL_SET[0].DEALS.DEAL[0];
        }
        

        public static void UpdatePostalZip(ADDRESS a, string zipCode)
        {
            string zip = zipCode.Replace("-", "");
            if (zip.Length > 5)
            {
                a.PostalCode = zip.Substring(0, 5);
#if MISMO32
                a.PlusFourZipCode = zip.Substring(5);
#else
                a.PlusFourZipCodeNumber = zip.Substring(5);
#endif
            }
            else
                a.PostalCode = zip;
        }
        
        public static string GetCurrentAgentNetVersion()
        {
            return ANUtils.GetConfig("AgentnetVersion","1.0.0");
        }
        
        
        #endregion

    }
}

using System.Runtime.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE_PRODUCT_NAME", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE_PRODUCT_NAME
{
	//[XmlElement("SERVICE_PRODUCT_NAME_ADD_ONS")]
	//[DataMember]
	//public  SERVICE_PRODUCT_NAME_ADD_ONS { get; set; }
	//[XmlElement("SERVICE_PRODUCT_NAME_DETAIL")]
	//[DataMember]
	//public  SERVICE_PRODUCT_NAME_DETAIL { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

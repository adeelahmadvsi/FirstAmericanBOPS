using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LEGAL_ENTITY", Namespace = DEAL.MISMO_NAMESPACE)]
public class LEGAL_ENTITY
{
	//[XmlElement("ALIASES")]
	//[DataMember]
	//public  ALIASES { get; set; }
	[XmlElement("CONTACTS")]
	[DataMember]
    public CONTACTS CONTACTS { get; set; }
	[XmlElement("LEGAL_ENTITY_DETAIL")]
	[DataMember]
	public LEGAL_ENTITY_DETAIL LEGAL_ENTITY_DETAIL { get; set; }
	//[XmlElement("LICENSES")]
	//[DataMember]
	//public  LICENSES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

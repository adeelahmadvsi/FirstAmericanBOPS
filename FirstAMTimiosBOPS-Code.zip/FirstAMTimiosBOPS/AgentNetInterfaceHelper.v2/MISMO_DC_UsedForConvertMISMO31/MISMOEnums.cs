namespace MISMOTypes
{
	public class LegalEntityTypeEnumerated
	{
		public const string Corporation = "Corporation";
		public const string CorporationSole = "CorporationSole";
		public const string GovernmentEntity = "GovernmentEntity";
		public const string Estate = "Estate";
		public const string JointVenture = "JointVenture";
		public const string LimitedLiabilityCompany = "LimitedLiabilityCompany";
		public const string LimitedPartnership = "LimitedPartnership";
		public const string NonProfitCorporation = "NonProfitCorporation";
		public const string Other = "Other";
		public const string Partnership = "Partnership";
		public const string SoleProprietorship = "SoleProprietorship";
		public const string Trust = "Trust";
	}
	public class LoanPurposeTypeEnumerated
	{
		public const string MortgageModification = "MortgageModification";
		public const string Other = "Other";
		public const string Purchase = "Purchase";
		public const string Refinance = "Refinance";
		public const string Unknown = "Unknown";
	}
	public class MaritalStatusTypeEnumerated
	{
		public const string Married = "Married";
		public const string NotProvided = "NotProvided";
		public const string Separated = "Separated";
		public const string Unknown = "Unknown";
		public const string Unmarried = "Unmarried";
	}
	public class MortgageTypeEnumerated
	{
		public const string Conventional = "Conventional";
		public const string FHA = "FHA";
		public const string HELOC = "HELOC";
		public const string LocalAgency = "LocalAgency";
		public const string Other = "Other";
		public const string StateAgency = "StateAgency";
		public const string USDARuralHousing = "USDARuralHousing";
		public const string VA = "VA";
	}
	public class PartyRoleTypeEnumerated
	{
		public const string Appraiser = "Appraiser";
		public const string AppraiserSupervisor = "AppraiserSupervisor";
		public const string AssignFrom = "AssignFrom";
		public const string AssignTo = "AssignTo";
		public const string Attorney = "Attorney";
		public const string AuthorizedRepresentative = "AuthorizedRepresentative";
		public const string BeneficialInterestParty = "BeneficialInterestParty";
		public const string BillToParty = "BillToParty";
		public const string Borrower = "Borrower";
		public const string Builder = "Builder";
		public const string Client = "Client";
		public const string ClosingAgent = "ClosingAgent";
		public const string CorrespondentLender = "CorrespondentLender";
		public const string Cosigner = "Cosigner";
		public const string CustodianNotePayTo = "CustodianNotePayTo";
		public const string DeliverRecissionTo = "DeliverRecissionTo";
		public const string DocumentCustodian = "DocumentCustodian";
		public const string ENoteController = "ENoteController";
		public const string FHASponsor = "FHASponsor";
		public const string FloodCertificateProvider = "FloodCertificateProvider";
		public const string FulfillmentParty = "Fulfillment Party";
		public const string Grantee = "Grantee";
		public const string Grantor = "Grantor";
		public const string HazardInsuranceAgent = "HazardInsuranceAgent";
		public const string HazardInsuranceCompany = "HazardInsuranceCompany";
		public const string Interviewer = "Interviewer";
		public const string InterviewerEmployer = "InterviewerEmployer";
		public const string Investor = "Investor";
		public const string LawFirm = "LawFirm";
		public const string Lender = "Lender";
		public const string LenderBranch = "LenderBranch";
		public const string LienHolder = "LienHolder";
		public const string LoanDeliveryFilePreparer = "LoanDeliveryFilePreparer";
		public const string LoanOriginationCompany = "LoanOriginationCompany";
		public const string LoanOriginator = "LoanOriginator";
		public const string LoanSeller = "LoanSeller";
		public const string LossPayee = "LossPayee";
		public const string ManagementCompany = "ManagementCompany";
		public const string MERS = "MERS";
		public const string MICompany = "MI Company";
		public const string MortgageBroker = "MortgageBroker";
		public const string Notary = "Notary";
		public const string NotePayTo = "NotePayTo";
		public const string NotePayToRecipient = "NotePayToRecipient";
		public const string Other = "Other";
		public const string Payee = "Payee";
		public const string PowerOfAttorney = "PowerOfAttorney";
		public const string PreparedBy = "PreparedBy";
		public const string ProjectManagementAgent = "ProjectManagementAgent";
		public const string ProjectDeveloper = "ProjectDeveloper";
		public const string PropertyOwner = "PropertyOwner";
		public const string PropertySeller = "PropertySeller";
		public const string ReceivingParty = "ReceivingParty";
		public const string RealEstateAgent = "RealEstateAgent";
		public const string RegulatoryAgency = "RegulatoryAgency";
		public const string RequestingParty = "RequestingParty";
		public const string RespondToParty = "RespondToParty";
		public const string RespondingParty = "RespondingParty";
		public const string ReviewAppraiser = "ReviewAppraiser";
		public const string ServiceProvider = "ServiceProvider";
		public const string Servicer = "Servicer";
		public const string ServicerPaymentCollection = "ServicerPaymentCollection";
		public const string ServicingTransferor = "ServicingTransferor";
		public const string ServicingTransferee = "ServicingTransferee";
		public const string Spouse = "Spouse";
		public const string SubmittingParty = "SubmittingParty";
		public const string Subservicer = "Subservicer";
		public const string TaxServicer = "TaxServicer";
		public const string TaxableParty = "TaxableParty";
		public const string ThirdPartyInvestor = "ThirdPartyInvestor";
		public const string ThirdPartyOriginator = "ThirdPartyOriginator";
		public const string TitleCompany = "TitleCompany";
		public const string TitleHolder = "TitleHolder";
		public const string Trust = "Trust";
		public const string TrustBeneficiary = "TrustBeneficiary";
		public const string Trustee = "Trustee";
		public const string TrustGrantor = "TrustGrantor";
		public const string WarehouseLender = "WarehouseLender";
		public const string Witness = "Witness";
	}
	public class PropertyUsageTypeEnumerated
	{
		public const string Investment = "Investment";
		public const string SecondHome = "SecondHome";
		public const string PrimaryResidence = "PrimaryResidence";
		public const string Other = "Other";
	}
    public class ParcelIdentifierTypeEnumerated
    {
        public const string ParcelIdentificationNumber = "ParcelIdentificationNumber";
        public const string TaxMapIdentifier = "TaxMapIdentifier"; // not used
        public const string TaxParcelIdentifier = "TaxParcelIdentifier"; // not used
        public const string AssessorUnformattedIdentifier = "AssessorUnformattedIdentifier"; // not used
        public const string TorrensCertificateIdentifier = "TorrensCertificateIdentifier"; // not used
        public const string Other = "Other";
    }
}

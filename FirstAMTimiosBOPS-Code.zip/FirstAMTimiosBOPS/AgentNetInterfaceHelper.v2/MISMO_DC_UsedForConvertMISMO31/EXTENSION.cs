using System.Runtime.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "EXTENSION", Namespace = DEAL.MISMO_NAMESPACE)]
    public class EXTENSION 
    {
        private System.Xml.XmlNode[] anyField;
        public System.Xml.XmlNode[] Any
        {
            get { return this.anyField; }
            set { this.anyField = value; }
        }
    }
}
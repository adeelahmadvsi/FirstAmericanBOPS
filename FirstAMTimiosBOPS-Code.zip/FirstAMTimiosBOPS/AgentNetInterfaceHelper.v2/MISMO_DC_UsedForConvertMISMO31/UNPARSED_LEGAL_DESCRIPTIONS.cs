using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "UNPARSED_LEGAL_DESCRIPTIONS", Namespace = DEAL.MISMO_NAMESPACE)]
public class UNPARSED_LEGAL_DESCRIPTIONS
{
	[XmlElement("UNPARSED_LEGAL_DESCRIPTION")]
	[DataMember]
	public UNPARSED_LEGAL_DESCRIPTION[] UNPARSED_LEGAL_DESCRIPTION { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

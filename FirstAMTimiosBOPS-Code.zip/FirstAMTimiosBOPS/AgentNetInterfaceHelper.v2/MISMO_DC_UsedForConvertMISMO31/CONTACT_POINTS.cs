using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CONTACT_POINTS", Namespace = DEAL.MISMO_NAMESPACE)]
public class CONTACT_POINTS
{
	[XmlElement("CONTACT_POINT")]
	[DataMember]
	public CONTACT_POINT[] CONTACT_POINT { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

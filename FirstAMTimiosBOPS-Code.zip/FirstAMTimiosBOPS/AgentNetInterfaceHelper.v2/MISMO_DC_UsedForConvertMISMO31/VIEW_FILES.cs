using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "VIEW_FILES", Namespace = DEAL.MISMO_NAMESPACE)]
public class VIEW_FILES
{
	[XmlElement("VIEW_FILE")]
	[DataMember]
	public VIEW_FILE[] VIEW_FILE { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

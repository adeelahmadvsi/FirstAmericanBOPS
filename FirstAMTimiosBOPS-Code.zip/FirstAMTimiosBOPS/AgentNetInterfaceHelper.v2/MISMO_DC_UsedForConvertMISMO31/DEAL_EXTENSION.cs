﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "DEAL_EXTENSION", Namespace = DEAL.MISMO_NAMESPACE)]
    public class DEAL_EXTENSION 
    {
        // DEAL for Request
        [XmlElement(ElementName = "AGENTNET_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_REQUEST AGENTNET_REQUEST { get; set; }
        // DEAL for Response
        [XmlElement(ElementName = "AGENTNET_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RESPONSE AGENTNET_RESPONSE { get; set; }
        // Root level errors
        [XmlElement("STATUSES")]
        [DataMember]
        public STATUSES STATUSES { get; set; }

    }
}

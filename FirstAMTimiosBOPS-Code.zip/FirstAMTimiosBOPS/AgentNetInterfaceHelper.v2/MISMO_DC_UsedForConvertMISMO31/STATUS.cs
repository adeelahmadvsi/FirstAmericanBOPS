using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "STATUS", Namespace = DEAL.MISMO_NAMESPACE)]
public class STATUS
{
	[XmlElement("StatusCode")]
	[DataMember]
	public string StatusCode { get; set; }
	[XmlElement("StatusConditionDescription")]
	[DataMember]
	public string StatusConditionDescription { get; set; }
	[XmlElement("StatusDescription")]
	[DataMember]
	public string StatusDescription { get; set; }
	[XmlElement("StatusName")]
	[DataMember]
	public string StatusName { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SALES_CONTRACT", Namespace = "http://www.mismo.org/residential/2009/schemas")]
public class SALES_CONTRACT: BaseDataContract
{
    //[XmlElement("AnalysisOfCurrentSalesContractDescription")]
    //[DataMember]
    //public string AnalysisOfCurrentSalesContractDescription { get; set; }
    //[XmlElement("ArmsLengthIndicator")]
    //[DataMember]
    //public bool ArmsLengthIndicator { get; set; }
    //[XmlElement("PersonalPropertyIncludedIndicator")]
    //[DataMember]
    //public bool PersonalPropertyIncludedIndicator { get; set; }
    //[XmlElement("PropertySalesAgreementDate")]
    //[DataMember]
    //public DateTime PropertySalesAgreementDate { get; set; }
	[XmlElement("PropertySalesPriceAmount")]
	[DataMember]
	public decimal PropertySalesPriceAmount { get; set; }
    //[XmlElement("SalesConcessionAmount")]
    //[DataMember]
    //public decimal SalesConcessionAmount { get; set; }
    //[XmlElement("SalesConcessionDescription")]
    //[DataMember]
    //public string SalesConcessionDescription { get; set; }
    //[XmlElement("SalesConcessionIndicator")]
    //[DataMember]
    //public bool SalesConcessionIndicator { get; set; }
	//[XmlElement("SalesConcessionType")]
	//[DataMember]
	//public  SalesConcessionType { get; set; }
    //[XmlElement("SalesConcessionTypeOtherDescription")]
    //[DataMember]
    //public string SalesConcessionTypeOtherDescription { get; set; }
    //[XmlElement("SalesConditionsOfSaleDescription")]
    //[DataMember]
    //public string SalesConditionsOfSaleDescription { get; set; }
    //[XmlElement("SalesContractAmount")]
    //[DataMember]
    //public decimal SalesContractAmount { get; set; }
    //[XmlElement("SalesContractDate")]
    //[DataMember]
    //public DateTime SalesContractDate { get; set; }
    //[XmlElement("SalesContractInvoiceRevewCommentDescription")]
    //[DataMember]
    //public string SalesContractInvoiceRevewCommentDescription { get; set; }
    //[XmlElement("SalesContractInvoiceReviewedIndicator")]
    //[DataMember]
    //public bool SalesContractInvoiceReviewedIndicator { get; set; }
    //[XmlElement("SalesContractRetailerName")]
    //[DataMember]
    //public string SalesContractRetailerName { get; set; }
    //[XmlElement("SalesContractReviewCommentDescription")]
    //[DataMember]
    //public string SalesContractReviewCommentDescription { get; set; }
    //[XmlElement("SalesContractReviewDescription")]
    //[DataMember]
    //public string SalesContractReviewDescription { get; set; }
    //[XmlElement("SalesContractReviewedIndicator")]
    //[DataMember]
    //public bool SalesContractReviewedIndicator { get; set; }
    //[XmlElement("SalesContractTermsAndConditionsConsistentWithTheLocalMarketIndicator")]
    //[DataMember]
    //public bool SalesContractTermsAndConditionsConsistentWithTheLocalMarketIndicator { get; set; }
	//[XmlElement("SaleType")]
	//[DataMember]
	//public  SaleType { get; set; }
    //[XmlElement("SaleTypeOtherDescription")]
    //[DataMember]
    //public string SaleTypeOtherDescription { get; set; }
    //[XmlElement("SellerIsOwnerIndicator")]
    //[DataMember]
    //public bool SellerIsOwnerIndicator { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

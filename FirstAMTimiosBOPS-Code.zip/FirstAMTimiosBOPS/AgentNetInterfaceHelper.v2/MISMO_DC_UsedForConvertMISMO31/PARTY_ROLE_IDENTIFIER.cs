using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PARTY_ROLE_IDENTIFIER", Namespace = DEAL.MISMO_NAMESPACE)]
public class PARTY_ROLE_IDENTIFIER
{
	[XmlElement("PartyRoleIdentifier")]
	[DataMember]
	public string PartyRoleIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "REFERENCE", Namespace = DEAL.MISMO_NAMESPACE)]
public class REFERENCE
{
	//[XmlElement("LocationURL")]
	//[DataMember]
	//public  LocationURL { get; set; }
	//[XmlElement("LocationXPath")]
	//[DataMember]
	//public  LocationXPath { get; set; }
	[XmlElement("OriginalCreatorDigestValue")]
	[DataMember]
	public string OriginalCreatorDigestValue { get; set; }
} // class
} // namespace

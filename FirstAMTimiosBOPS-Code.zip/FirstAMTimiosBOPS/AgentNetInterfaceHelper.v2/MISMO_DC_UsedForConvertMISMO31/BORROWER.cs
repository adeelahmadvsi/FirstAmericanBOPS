using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "BORROWER", Namespace = DEAL.MISMO_NAMESPACE)]
public class BORROWER
{
	//[XmlElement("BANKRUPTCY")]
	//[DataMember]
	//public  BANKRUPTCY { get; set; }
	[XmlElement("BORROWER_DETAIL")]
	[DataMember]
	public BORROWER_DETAIL BORROWER_DETAIL { get; set; }
	//[XmlElement("COUNSELING_CONFIRMATION")]
	//[DataMember]
	//public  COUNSELING_CONFIRMATION { get; set; }
	//[XmlElement("CREDIT_SCORES")]
	//[DataMember]
	//public  CREDIT_SCORES { get; set; }
	//[XmlElement("CURRENT_INCOME")]
	//[DataMember]
	//public  CURRENT_INCOME { get; set; }
	//[XmlElement("DECLARATION")]
	//[DataMember]
	//public  DECLARATION { get; set; }
	//[XmlElement("DEPENDENTS")]
	//[DataMember]
	//public  DEPENDENTS { get; set; }
	//[XmlElement("EMPLOYERS")]
	//[DataMember]
	//public  EMPLOYERS { get; set; }
	//[XmlElement("GOVERNMENT_BORROWER")]
	//[DataMember]
	//public  GOVERNMENT_BORROWER { get; set; }
	//[XmlElement("GOVERNMENT_MONITORING")]
	//[DataMember]
	//public  GOVERNMENT_MONITORING { get; set; }
	//[XmlElement("HARDSHIP_DECLARATION")]
	//[DataMember]
	//public  HARDSHIP_DECLARATION { get; set; }
	//[XmlElement("MILITARY_SERVICES")]
	//[DataMember]
	//public  MILITARY_SERVICES { get; set; }
	//[XmlElement("NEAREST_LIVING_RELATIVE")]
	//[DataMember]
	//public  NEAREST_LIVING_RELATIVE { get; set; }
	//[XmlElement("PRESENT_HOUSING_EXPENSES")]
	//[DataMember]
	//public  PRESENT_HOUSING_EXPENSES { get; set; }
	//[XmlElement("PREVIOUS_LOANS")]
	//[DataMember]
	//public  PREVIOUS_LOANS { get; set; }
	//[XmlElement("RESIDENCES")]
	//[DataMember]
	//public  RESIDENCES { get; set; }
	//[XmlElement("SOLICITATION_PREFERENCES")]
	//[DataMember]
	//public  SOLICITATION_PREFERENCES { get; set; }
	//[XmlElement("SUMMARIES")]
	//[DataMember]
	//public  SUMMARIES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

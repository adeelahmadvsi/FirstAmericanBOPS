using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE_PRODUCT_NAMES", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE_PRODUCT_NAMES
{
	[XmlElement("SERVICE_PRODUCT_NAME")]
	[DataMember]
	public SERVICE_PRODUCT_NAME[] SERVICE_PRODUCT_NAME { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

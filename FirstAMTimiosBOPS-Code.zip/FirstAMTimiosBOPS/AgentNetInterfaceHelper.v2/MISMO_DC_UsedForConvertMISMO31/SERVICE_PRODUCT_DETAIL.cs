using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE_PRODUCT_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE_PRODUCT_DETAIL
{
	[XmlElement("ServiceProductDescription")]
	[DataMember]
	public string ServiceProductDescription { get; set; }
	[XmlElement("ServiceProductIdentifier")]
	[DataMember]
	public string ServiceProductIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

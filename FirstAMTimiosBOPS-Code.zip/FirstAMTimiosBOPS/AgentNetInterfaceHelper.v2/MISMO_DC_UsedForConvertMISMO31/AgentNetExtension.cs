using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "BaseDataContract", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BaseDataContract : IExtensibleDataObject
    {
        public const string AGENTNET_NAMESPACE = "http://www.firstam.com/2011/03/datacontract/agentnet";
        // To implement the IExtensibleDataObject interface, you must also
        // implement the ExtensionData property.
        private ExtensionDataObject extensionDataObjectValue = null;
        //public BaseDataContract() 
        //{
        //}
        [XmlElement("ExtensionData")]
       // [DataMember]
        public ExtensionDataObject ExtensionData
        {
            get
            {
                return extensionDataObjectValue;
            }
            set
            {
                extensionDataObjectValue = value;
            }
        }

    }
    [DataContract(Name = "BaseResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BaseResponse : BaseDataContract
    {
        public BaseResponse()
        {
            STATUS = new STATUS();
        }
        [DataMember]
        public bool Result { get; set; }
        [DataMember]
        public STATUS STATUS { get; set; }
    }
    [DataContract(Name = "AgentNetActionTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetActionTypeEnum 
    {
        //public const string NEW = "NEW";
        public const string UPDATE = "UPDATE";
        public const string SERVICE = "SERVICE";
        public const string GET_DATA = "GET_DATA";
        public const string CANCEL = "CANCEL";
        public const string VOID = "VOID";
        public const string PREPRICING = "PREPRICING";
    }
    [DataContract(Name = "AgentNetProductStatusEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetProductStatusEnum
    {
        public const string VOID = "VOID";
        public const string OPEN = "OPEN";
        public const string PENDING = "PENDING";
    }
    [DataContract(Name = "AgentNetGetRequestEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetGetRequestEnum
    {
        public const string PRODUCT_TYPES = "GET_PRODUCT_TYPES";
        public const string JACKET_TYPES = "JACKET_TYPES";
        public const string JACKET_TYPE_FIELDS = "JACKET_TYPE_FIELDS";
        public const string JACKET_ENDORSEMENTS = "JACKET_ENDORSEMENTS";
        public const string CPL_TYPES = "CPL_TYPES";
        public const string VALIDATE_LOGIN = "VALIDATE_LOGIN";
        public const string CHANGE_PASSWORD = "CHANGE_PASSWORD";
        public const string PARTIES = "PARTIES";
        public const string ACCOUNTS = "ACCOUNTS";
        public const string UNDERWRITERS = "UNDERWRITERS";
        public const string GET_CPLS = "GET_CPLS";
        public const string GET_JACKETS = "GET_JACKETS";
        public const string GET_LAST_RESPONSE = "GET_LAST_RESPONSE";
        public const string FILE_STATUS = "FILE_STATUS";
        public const string PREVIOUS_FILE_DATA = "PREVIOUS_FILE_DATA";
        public const string GET_OVERRIDEREASONS = "GET_OVERRIDEREASONS";
        public const string GET_COUNTIES = "GET_COUNTIES";
        public const string VALIDATE_COUNTY = "VALIDATE_COUNTY";
        //public const string SDN_SEARCH = "SDN_SEARCH";
        public const string GET_FIRMS = "GET_FIRMS";
        public const string GET_RATE_TYPES = "GET_RATE_TYPES";

        public const string GET_JACKETS_AND_CPLS = "GET_JACKETS_AND_CPLS";
        public const string CPL_FEE_STATES = "CPL_FEE_STATES";
        public const string GET_GENERIC_SERVICE_TYPES = "GET_GENERIC_SERVICE_TYPES";
    }

    [DataContract(Name = "AgentNetProductTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetProductTypeEnum
    {
        public const string GET_DATA = "GET_DATA";
        public const string Jacket = "JACKET";
        public const string CPL = "CPL";
        public const string BackTitle = "BACKTITLE";
        public const string BackTitleDoc = "BACKTITLEDOC";
        public const string BackTitleDocAttach = "BACKTITLEDOCATTACH";
        public const string RatesFees = "RATESFEES";
        public const string SDNSearch = "SDN";
        public const string PrePricing = "PREPRICING";

    }

    [DataContract(Name = "AgentNetPartyTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetPartyTypeEnum
    {
        public const string APPROVED_ATTORNEY = "ApprovedAttorney";
        public const string CLOSING_ATTORNEY = "ClosingAttorney";
        public const string MY_CLOSING_ATTORNEY = "MyClosingAttorney";
        public const string OFFICE = "Office";
        public const string MY_LENDER = "MyLender";
        public const string DEFAULT_APPROVED_ATTORNEY = "DefaultApprovedAttorney";
        public const string FIRM = "Firm";
            // Change 2nd Party CPL
        public const string SECOND_PARTY = "SecondParty";
    }

    [DataContract(Name = "AgentNetBackTitleFieldEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetBackTitleFieldEnum
    {
        public const string Field_APN = "APN";
        public const string Field_LastName = "LastName";
        public const string Field_StreetNum = "StreetNumber";
        public const string Field_StreetName = "StreetName";
        public const string Field_City = "City";
        public const string Field_Zip = "ZipCode";
        public const string Field_CondoSubdiv = "CondoSubDivision";
        public const string Field_UnitLot = "UnitLot";
        public const string Field_BlockSqr = "BlockSquare";
        public const string Field_Section = "SectionAcreage";
        public const string Field_District = "District";
        public const string Field_PlatBook = "PlatBook";
        public const string Field_PlatPage = "PlatPage";
        public const string Field_BriefLegal = "BriefLegal";
        public const string Field_FileNumber = "FileNumber";
        public const string Field_PolicyNumber = "PolicyNumber";
        public const string Field_LoanNumber = "LoanNumber";
        public const string Field_OwnerNumber = "OwnerNumber";
        public const string Field_PolicyDateFrom = "PolicyDateFrom";
        public const string Field_PolicyDateTo = "PolicyDateTo";
        // BackTitleDoc request
        public const string Field_DocumentType = "DocumentType";
        public const string Field_AdHocUID = "AdHocUID";
        public const string Field_AttachDoc = "AttachDoc";
    }
    [DataContract(Name = "AgentNetAdditionalPartyRoleTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetAdditionalPartyRoleTypeEnum
    {
        public const string Grantee = "Grantee";
        public const string Insured = "Insured";
        public const string RecordOwner = "RecordOwner";
        public const string GuaranteedParty = "GuaranteedParty";
        public const string VestedIn = "VestedIn";
        public const string ForeclosingLender = "ForeclosingLender";
        public const string OriginalPolicyInsurer = "OriginalPolicyInsurer";
        public const string NomineeVestee = "NomineeVestee";
        public const string CPLLender = "CPLLender";
        public const string CPLMyClosingAttorney = "CPLMyClosingAttorney";
        public const string CPLClosingAttorney = "CPLClosingAttorney";
      
    }

    [DataContract(Name = "AgentNetMyLenderFieldEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetMyLenderFieldEnum
    {
        public const string LenderAttentionName = "LenderAttentionName";
        public const string LenderClause = "LenderClause";
        public const string LenderPhoneNumber = "LenderPhoneNumber";
        public const string LenderFaxNumber = "LenderFaxNumber";
        public const string LenderEmailAddress = "LenderEmailAddress";
        public const string LenderLocation = "LenderLocation";
    }
    public class AgentNetCPLFieldEnum
    {
        public const string ApprovedAttorney = "ApprovedAttorney";
        public const string ClosingAttorney = "ClosingAttorney";
        public const string MyClosingAttorney = "MyClosingAttorney";
        public const string AttachementA = "AttachementA";
        public const string ScheduleASignatory = "ScheduleASignatory";
        public const string ScheduleAFirmLocation = "ScheduleAFirmLocation";
        public const string UpdateMyLender = "UpdateMyLender";
        public const string AlternateFileNumber = "AlternateFileNumber";
        public const string UpdateMyClosingAttorney = "UpdateMyClosingAttorney";
        public const string UpdateCloserAttorney = "UpdateCloserAttorney";

        public const string LoanNumber = "LoanNumber";
        public const string LoanAmount = "LoanAmount";
        public const string ClosingDate = "ClosingDate";
        public const string Preview = "Preview";
        public const string AGYType = "AGYType";
    }
    public class AgentNetAGYTypeCodeEnum
    {
        public const string FullAgent = "FullAgent";
        public const string PolicyWriter = "PolicyWriter";
        public const string ApprovedAttorney = "ApprovedAttorney";
    }
    public class AgentNetAboutVersionTypeEnum
    {
        public const string AgentNet = "AgentNetWS";
        public const string ClientSystem = "ClientSystem";
    }
    public class AgentNetNameValueEnum
    {
        public const string IsDefaultOffice = "IsDefaultOffice";
        public const string IsLicensedInMissouri = "IsLicensedInMissouri";
        public const string FullVestingBorrower = "FullVestingBorrower";
        public const string Subdivision = "Subdivision";
        public const string MarketArea = "MarketArea";
    }
    public class AgentNetClientFileStatusEnum
    {
        public const string Open = "Open";
        public const string Closed = "Closed";
        public const string Cancelled = "Cancelled";
        public const string OpenInError = "OpenInError";
        public const string Unknown = "Unknown";
    }
    public class AgentNetPropertyTypeCodeEnum
    {
        //TFS#104286 changed back to Residential & NonResidential
        public const string Residential = "Residential"; //TFS#103231-changed label names
        public const string NonResidential = "NonResidential";
    }

    public class RateFeeLineItemTypeEnum
    {
        public const string Fee = "Fee";
        public const string Tax = "Tax";
        public const string Endorsement = "Endorsement";
        public const string Jacket = "Jacket";
        public const string CPL = "CPL";
        public const string MiscEndorsement = "MiscEndorsement";
    }
    [DataContract(Name = "AGENTNET_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_REQUEST : BaseDataContract
    {
        [XmlElement("ActionType")]
        [DataMember]
        public string ActionType { get; set; }
        [XmlElement("ClientRequestId")]
        [DataMember]
        public string ClientRequestId { get; set; }
        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }
        [XmlElement("FileId")]
        [DataMember]
        public string FileId { get; set; }
        [XmlElement("ClientFileId")]
        [DataMember]
        public string ClientFileId { get; set; }
        [XmlElement("AccountNumber")]
        [DataMember]
        public string AccountNumber { get; set; }
        [XmlElement("SystemName")]
        [DataMember]
        public string SystemName { get; set; }

        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }

        [XmlElement("OfficeId")]
        [DataMember]
        public string OfficeId { get; set; }

        [XmlElement("ClientFileStatusCode")]
        [DataMember]
        public string ClientFileStatusCode { get; set; }

        [XmlElement("PropertyTypeCode")]
        [DataMember]
        public string PropertyTypeCode { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_REQUEST : BaseDataContract
    {
        [XmlElement("AgentNetServiceType")]
        [DataMember]
        public string AgentNetServiceType { get; set; } // AgentNetProductTypeEnum

        [XmlElement("ProductStatus")]
        [DataMember]
        public string ProductStatus { get; set; }

        [XmlElement("AgentNetProductServiceId")]
        [DataMember]
        public string AgentNetProductServiceId { get; set; }

        [XmlElement("ProductTypeCode")]
        [DataMember]
        public string ProductTypeCode { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

        [XmlElement(ElementName = "AGENTNET_GET_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_GET_DATA AGENTNET_GET_DATA { get; set; }
        [XmlElement(ElementName = "AGENTNET_SDN_SEARCH_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_REQUEST AGENTNET_SDN_SEARCH_REQUEST { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REQUESTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REQUESTS AGENTNET_PRODUCT_PRICING_REQUESTS { get; set; }

    }
    [DataContract(Name = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_NAME_VALUES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_NAME_VALUE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUE[] AGENTNET_NAME_VALUE { get; set; }
    }

    [DataContract(Name = "AGENTNET_NAME_VALUE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_NAME_VALUE : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string Name { get; set; }
        [XmlElement("Value")]
        [DataMember]
        public string Value { get; set; }
    }

    [DataContract(Name = "AGENTNET_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_RESPONSE : BaseDataContract
    {
        [XmlElement("SessionId")]
        [DataMember]
        public string SessionId { get; set; }
        [XmlElement("ClientRequestId")]
        [DataMember]
        public string ClientRequestId { get; set; }
        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }
        [XmlElement("FileId")]
        [DataMember]
        public string FileId { get; set; }
        [XmlElement("ClientFileId")]
        [DataMember]
        public string ClientFileId { get; set; }
        [XmlElement("FirmId")]
        [DataMember]
        public string FirmId { get; set; }
        [XmlElement("OfficeId")]
        [DataMember]
        public string OfficeId { get; set; }
        [XmlElement("AccountNumber")]
        [DataMember]
        public string AccountNumber { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("UnderwriterName")]
        [DataMember]
        public string UnderwriterName { get; set; }
        [XmlElement("LoginId")]
        [DataMember]
        public string LoginId { get; set; }

        [XmlElement("IsAutoReportOnHold")]
        [DataMember]
        public bool IsAutoReportOnHold { get; set; }

        [XmlElement("RequestCompletionDate")]
        [DataMember]
        public DateTime RequestCompletionDate { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RESPONSE : BaseDataContract
    {

        [XmlElement("AgentNetServiceType")]
        [DataMember]
        public string AgentNetServiceType { get; set; } // AgentNetProductTypeEnum

        [XmlElement(ElementName = "AGENTNET_PRODUCT_DETAIL_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_DETAIL_RESPONSE AGENTNET_PRODUCT_DETAIL_RESPONSE { get; set; }

        [XmlElement(ElementName = "AGENTNET_GET_DATA_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_GET_DATA_RESPONSE AGENTNET_GET_DATA_RESPONSE { get; set; }

        [XmlElement(ElementName = "STATUSES", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public STATUSES STATUSES { get; set; }

        //[XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        //[DataMember]
        //public AGENTNET_PRODUCT_PRICING_RESPONSES AGENTNET_PRODUCT_PRICING_RESPONSES { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_DETAIL_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_DETAIL_RESPONSE : BaseDataContract
    {

        [XmlElement("ProductResponseId")]
        [DataMember]
        public string ProductResponseId { get; set; }

        [XmlElement("ProductStatus")]
        [DataMember]
        public string ProductStatus { get; set; }

        [XmlElement(ElementName = "AGENTNET_JACKET_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_JACKET_DETAIL AGENTNET_JACKET_DETAIL { get; set; }

        [XmlElement(ElementName = "AGENTNET_CPL_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CPL_DETAIL AGENTNET_CPL_DETAIL { get; set; }

        //[XmlElement(ElementName = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        //[DataMember]
        //public AGENTNET_RATE_FEES AGENTNET_RATE_FEES { get; set; }

        [XmlElement(ElementName = "AGENTNET_BACKTITLE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BACKTITLE_DETAILS AGENTNET_BACKTITLE_DETAILS { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

        [XmlElement(ElementName = "AGENTNET_SDN_SEARCH_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSES AGENTNET_SDN_SEARCH_RESPONSES { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_RESPONSES AGENTNET_PRODUCT_PRICING_RESPONSES { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRICING_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRICING_ENDORSEMENT
    {
        [XmlElement("AgentNetEndorCode")]
        [DataMember]
        public string AgentNetEndorCode { get; set; }

        [XmlElement("EndorsementName")]
        [DataMember]
        public string EndorsementName { get; set; }

        [XmlElement("ClientEndorCode")]
        [DataMember]
        public string ClientEndorCode { get; set; }

        [XmlElement("IsPreSelected")]
        [DataMember]
        public bool IsPreSelected { get; set; }

        [XmlElement("IsBidirectional")]
        [DataMember]
        public bool IsBidirectional { get; set; }

        [XmlElement("IsMultipleEndorsement")]
        [DataMember]
        public bool IsMultipleEndorsement { get; set; }
    }

    [DataContract(Name = "AGENTNET_GET_DATA_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_GET_DATA_RESPONSE : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_SERVICE_FIELDS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_SERVICE_FIELDS AGENTNET_PRODUCT_SERVICE_FIELDS { get; set; }

        [XmlElement(ElementName = "AGENTNET_JACKET_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENTS AGENTNET_JACKET_ENDORSEMENTS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRICING_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRICING_ENDORSEMENTS AGENTNET_PRICING_ENDORSEMENTS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PARTIES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PARTIES AGENTNET_PARTIES { get; set; }

        [XmlElement(ElementName = "AGENTNET_ACCOUNTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ACCOUNTS AGENTNET_ACCOUNTS { get; set; }
        [XmlElement(ElementName = "AGENTNET_SDN_SEARCH_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSES AGENTNET_SDN_SEARCH_RESPONSES { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

    }
    [DataContract(Name = "AGENTNET_GET_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_GET_DATA : BaseDataContract
    {
        [XmlElement("GetRequestType")]
        [DataMember]
        public string GetRequestType { get; set; }
        [XmlElement("Parm")]
        [DataMember]
        public string[] Parm { get; set; }
    }
    [DataContract(Name = "AGENTNET_JACKET_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_JACKET_DETAIL : BaseDataContract
    {
        [XmlElement("FileServiceJacketId")]
        [DataMember]
        public string FileServiceJacketId { get; set; }

        [XmlElement("JacketTypeId")]
        [DataMember]
        public string JacketTypeId { get; set; }

        [XmlElement("PolicyTypeCategory")]
        [DataMember]
        public string PolicyTypeCategory { get; set; }

        [XmlElement("PolicyNumber")]
        [DataMember]
        public string PolicyNumber { get; set; }

        [XmlElement("PolicyAmount")]
        [DataMember]
        public decimal PolicyAmount { get; set; }

        //Newly added field for RF
        [XmlElement("EffectiveDate")]
        [DataMember]
        public DateTime EffectiveDate { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }

    [DataContract(Name = "AGENTNET_SDN_SEARCH_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SDN_SEARCH_REQUEST : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string[] Name { get; set; }
    }

    [DataContract(Name = "AGENTNET_SDN_SEARCH_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SDN_SEARCH_RESPONSES : BaseDataContract
    {
        [XmlElement("AGENTNET_SDN_SEARCH_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSE[] AGENTNET_SDN_SEARCH_RESPONSE { get; set; }

    }

    [DataContract(Name = "AGENTNET_SDN_SEARCH_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SDN_SEARCH_RESPONSE : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string Name { get; set; }

        [XmlElement("SearchDate")]
        [DataMember]
        public string SearchDate { get; set; }

        [XmlElement("Result")]
        [DataMember]
        public string Result { get; set; }

    }

    [DataContract(Name = "AGENTNET_PARTIES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PARTIES
    {
        [XmlElement(ElementName = "AGENTNET_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PARTY[] AGENTNET_PARTY { get; set; }
    }
    [DataContract(Name = "AGENTNET_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PARTY : BaseDataContract
    {
        [XmlElement("PartyId")]
        [DataMember]
        public string PartyId { get; set; }
        [XmlElement("PartyName")]
        [DataMember]
        public string PartyName { get; set; }
        [XmlElement("AddressLineText")]
        [DataMember]
        public string AddressLineText { get; set; }
        [XmlElement("AddressAdditionalLineText")]
        [DataMember]
        public string AddressAdditionalLineText { get; set; }
        [XmlElement("CityName")]
        [DataMember]
        public string CityName { get; set; }
        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }
        [XmlElement("PostalCode")]
        [DataMember]
        public string PostalCode { get; set; }
        [XmlElement("PlusFourZipCode")]
        [DataMember]
        public string PlusFourZipCode { get; set; }
        [XmlElement("CountyName")]
        [DataMember]
        public string CountyName { get; set; }
        [XmlElement("CountryName")]
        [DataMember]
        public string CountryName { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

    }
    /*GET_DATA WEB-SERVICES USE
     * These are used only for GET_DATA web-service calls
     * */
    [DataContract(Name = "AgentNetTypeDataItemsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetTypeDataItemsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TYPE_DATA[] AGENTNET_TYPE_DATA { get; set; }
    }

    [DataContract(Name = "AgentNetGetDataResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetGetDataResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_GET_DATA_RESPONSE AGENTNET_GET_DATA_RESPONSE { get; set; }
    }

    [DataContract(Name = "SDNSearchResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class SDNSearchResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSES AGENTNET_SDN_SEARCH_RESPONSES { get; set; }
    }

    [DataContract(Name = "AgentNetCPLDetailResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetCPLDetailResponse : BaseResponse
    {
        [DataMember]
        public SERVICE[] SERVICE { get; set; }
    }

    [DataContract(Name = "AgentNetJacketDetailResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetJacketDetailResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_JACKET_DETAIL[] AGENTNET_JACKET_DETAIL { get; set; }
    }

    [DataContract(Name = "ProductServiceFieldItemsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class ProductServiceFieldItemsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_PRODUCT_SERVICE_FIELD[] AGENTNET_PRODUCT_SERVICE_FIELD { get; set; }

        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENT[] AGENTNET_JACKET_ENDORSEMENT { get; set; }
    }
    [DataContract(Name = "JacketEndorsementsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class JacketEndorsementsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENT[] AGENTNET_JACKET_ENDORSEMENT { get; set; }
    }
    [DataContract(Name = "PartiesResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class PartiesResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_PARTY[] AGENTNET_PARTIES { get; set; }
    }
    [DataContract(Name = "AccountsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AccountsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_ACCOUNT[] AGENTNET_ACCOUNTS { get; set; }
    }
    [DataContract(Name = "AgentNetStatusResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetStatusResponse : BaseResponse
    {

    }
    /*GET_DATA WEB-SERVICES USE To Here */
    [DataContract(Name = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TYPE_DATAS
    {
        [XmlElement(ElementName = "AGENTNET_TYPE_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATA[] AGENTNET_TYPE_DATA { get; set; }
    }
    [DataContract(Name = "AGENTNET_TYPE_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TYPE_DATA
    {
        [XmlElement("TypeId")]
        [DataMember]
        public string TypeId { get; set; }
        [XmlElement("ClientTypeId")]
        [DataMember]
        public string ClientTypeId { get; set; }
        [XmlElement("TypeCode")]
        [DataMember]
        public string TypeCode { get; set; }
        [XmlElement("Description")]
        [DataMember]
        public string Description { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_SERVICE_FIELDS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_SERVICE_FIELDS
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_SERVICE_FIELD", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_SERVICE_FIELD[] AGENTNET_PRODUCT_SERVICE_FIELD { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_SERVICE_FIELD", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_SERVICE_FIELD
    {
        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("ProductTypeId")]
        [DataMember]
        public string ProductTypeId { get; set; }
        [XmlElement("ProductTypeName")]
        [DataMember]
        public string ProductTypeName { get; set; }
        [XmlElement("FieldName")]
        [DataMember]
        public string FieldName { get; set; }
        [XmlElement("FieldType")]
        [DataMember]
        public string FieldType { get; set; } // string,int,decimal(?),select (option values required)
        [XmlElement("IsRequired")]
        [DataMember]
        public bool IsRequired { get; set; }

        [XmlElement("FieldText")]
        [DataMember]
        public string FieldText { get; set; }

        [XmlElement("GroupName")]
        [DataMember]
        public string GroupName { get; set; }

        [XmlElement("IsChecked")]
        [DataMember]
        public bool IsChecked { get; set; }

        [XmlElement("IsMultiLine")]
        [DataMember]
        public bool IsMultiLine { get; set; }

        [XmlElement("OptionValues")]
        [DataMember]
        public string[] OptionValues { get; set; }
    }
    [DataContract(Name = "AGENTNET_JACKET_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_JACKET_ENDORSEMENTS
    {
        [XmlElement(ElementName = "AGENTNET_JACKET_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENT[] AGENTNET_JACKET_ENDORSEMENT { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRICING_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRICING_ENDORSEMENTS
    {
        [XmlElement(ElementName = "AGENTNET_PRICING_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRICING_ENDORSEMENT[] AGENTNET_PRICING_ENDORSEMENT { get; set; }
    }

    [DataContract(Name = "AGENTNET_JACKET_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_JACKET_ENDORSEMENT 
    {
        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("ProductTypeId")]
        [DataMember]
        public string ProductTypeId { get; set; }
        [XmlElement("EndorsementId")]
        [DataMember]
        public string EndorsementId { get; set; }
        [XmlElement("EndorsementName")]
        [DataMember]
        public string EndorsementName { get; set; }
        
        [XmlElement("IsPreSelected")]
        [DataMember]
        public bool IsPreSelected { get; set; }

        [XmlElement(ElementName = "AGENTNET_CONTROLS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CONTROLS AGENTNET_CONTROLS { get; set; }

        //below fields are same as pricing endorsements
        [XmlElement("AgentNetEndorCode")]
        [DataMember]
        public string AgentNetEndorCode { get; set; }

        [XmlElement("ClientEndorCode")]
        [DataMember]
        public string ClientEndorCode { get; set; }

    }
    [DataContract(Name = "AGENTNET_CONTROLS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CONTROLS
    {
        [XmlElement(ElementName = "AGENTNET_CONTROL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CONTROL[] AGENTNET_CONTROL { get; set; }
    }
    [DataContract(Name = "AGENTNET_CONTROL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CONTROL
    {
        [XmlElement("ControlId")]
        [DataMember]
        public string ControlId { get; set; }
        
        [XmlElement("ControlType")]
        [DataMember]
        public string ControlType { get; set; } 

        [XmlElement("IsRequired")]
        [DataMember]
        public bool IsRequired { get; set; }

        [XmlElement("ControlValue")]
        [DataMember]
        public string ControlValue { get; set; }

        [XmlElement("IsChecked")]
        [DataMember]
        public bool IsChecked { get; set; }

        [XmlElement("IsMultiLine")]
        [DataMember]
        public bool IsMultiLine { get; set; }

        [XmlElement("IsSameLine")]
        [DataMember]
        public bool IsSameLine { get; set; }
        
        [XmlElement("IsProtected")]
        [DataMember]
        public bool IsProtected { get; set; }

        [XmlElement("GroupName")]
        [DataMember]
        public string GroupName { get; set; }
    }
    [DataContract(Name = "AGENTNET_ACCOUNTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ACCOUNTS
    {
        [XmlElement(ElementName = "AGENTNET_ACCOUNT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ACCOUNT[] AGENTNET_ACCOUNT { get; set; }
    }
    [DataContract(Name = "AGENTNET_ACCOUNT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ACCOUNT
    {
        [XmlElement("OfficeId")]
        [DataMember]
        public int OfficeId { get; set; }
        [XmlElement("FirmId")]
        [DataMember]
        public int FirmID { get; set; }
        [XmlElement("AccountNumber")]
        [DataMember]
        public int AccountNumber { get; set; }
        [XmlElement("JurisdictionStateCode")]
        [DataMember]
        public string JurisdictionStateCode { get; set; }
        [XmlElement("UnderwriterId")]
        [DataMember]
        public int UnderwriterID { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("UnderwriterName")]
        [DataMember]
        public string UnderwriterName { get; set; }
    }

    [DataContract(Name = "AGENTNET_CPL_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CPL_DETAIL : BaseDataContract
    {

        [XmlElement("FileServiceCPLId")]
        [DataMember]
        public string FileServiceCPLId { get; set; }

        [XmlElement("CplGroupId")]
        [DataMember]
        public string CplGroupId { get; set; }

        //Closing Date newly added for to get closing date for the CPL.
        [XmlElement("ClosingDate")]
        [DataMember]
        public DateTime ClosingDate { get; set; }//Closing date.

        [XmlElement(ElementName = "AGENTNET_CPL_COVERRED_PARTIES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CPL_COVERRED_PARTIES AGENTNET_CPL_COVERRED_PARTIES { get; set; }
    }
    [DataContract(Name = "AGENTNET_CPL_COVERRED_PARTYS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CPL_COVERRED_PARTIES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_CPL_COVERRED_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CPL_COVERRED_PARTY[] AGENTNET_CPL_COVERRED_PARTY { get; set; }
    }
    [DataContract(Name = "AGENTNET_CPL_COVERRED_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CPL_COVERRED_PARTY : BaseDataContract
    {

        [XmlElement("CoveredPartyId")]
        [DataMember]
        public string CoveredPartyId { get; set; }

        [XmlElement("CoveredPartyTypeName")]
        [DataMember]
        public string CoveredPartyTypeName { get; set; }

        [XmlElement("CoveredPartyName")]
        [DataMember]
        public string CoveredPartyName { get; set; }

        [XmlElement("CPLTypeId")] // CPLId internally in AgentNet
        [DataMember]
        public string CPLTypeId { get; set; }

        [XmlElement("CPLItemNumber")] // STARSItemNumber internally in AgentNet
        [DataMember]
        public string CPLItemNumber { get; set; }

        [XmlElement("EffectiveDate")]
        [DataMember]
        public string EffectiveDate { get; set; }

        [XmlElement("CPLSerialNumber")] // STARSSerialNumber internally in AgentNet
        [DataMember]
        public string CPLSerialNumber { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

    }
    [DataContract(Name = "AGENTNET_BACKTITLE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BACKTITLE_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_BACKTITLE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BACKTITLE_DETAIL[] AGENTNET_BACKTITLE_DETAIL { get; set; }

    }
    [DataContract(Name = "AGENTNET_BACKTITLE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BACKTITLE_DETAIL : BaseDataContract
    {
        [XmlElement("FileServiceBackTitleSearchId")]
        [DataMember]
        public string FileServiceBackTitleSearchId { get; set; }

        [XmlElement("OrderId")]
        [DataMember]
        public string OrderId { get; set; }

        [XmlElement("DocumentType")]
        [DataMember]
        public string DocumentType { get; set; }

        [XmlElement("DocumentNumber")]
        [DataMember]
        public string DocumentNumber { get; set; }

        [XmlElement("DocumentEffectiveDate")]
        [DataMember]
        public string DocumentEffectiveDate { get; set; }

        [XmlElement("OwnerNames")]
        [DataMember]
        public string OwnerNames { get; set; }

        [XmlElement("OwnerPolicyNumber")]
        [DataMember]
        public string OwnerPolicyNumber { get; set; }

        [XmlElement("LoanPolicyNumber")]
        [DataMember]
        public string LoanPolicyNumber { get; set; }

        [XmlElement("UnitLotNumber")]
        [DataMember]
        public string UnitLotNumber { get; set; }

        [XmlElement("CondoSubdivision")]
        [DataMember]
        public string CondoSubdivision { get; set; }

        [XmlElement("StreetNumber")]
        [DataMember]
        public string StreetNumber { get; set; }

        [XmlElement("StreetName")]
        [DataMember]
        public string StreetName { get; set; }

        [XmlElement("CityName")]
        [DataMember]
        public string CityName { get; set; }

        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }

        [XmlElement("PostalCode")]
        [DataMember]
        public string PostalCode { get; set; }

        [XmlElement("CountyName")]
        [DataMember]
        public string CountyName { get; set; }

        [XmlElement("AdhocUId")]
        [DataMember]
        public string AdhocUId { get; set; }

        [XmlElement("HasLegalDescription")]
        [DataMember]
        public bool HasLegalDescription { get; set; }

        [XmlElement("IsDocRestricted")]
        [DataMember]
        public bool IsDocRestricted { get; set; }

        [XmlElement("CartridgeNumber")]
        [DataMember]
        public string CartridgeNumber { get; set; }

        [XmlElement("CartridgeBlip")]
        [DataMember]
        public string CartridgeBlip { get; set; }
        [XmlElement("FastOrderNumber")]
        [DataMember]
        public string FastOrderNumber { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_RESPONSES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REPONSE[] AGENTNET_PRODUCT_PRICING_REPONSE { get; set; }
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }
        [XmlElement("IsAutoReportOnHold")]
        [DataMember]
        public bool IsAutoReportOnHold { get; set; }
        [XmlElement("RateEffectiveDate")]
        [DataMember]
        public DateTime RateEffectiveDate { get; set; }
        [XmlElement(ElementName = "AGENTNET_CALCULATION_NOTES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CALCULATION_NOTES AGENTNET_CALCULATION_NOTES { get; set; }
        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

    }

    [DataContract(Name = "AGENTNET_CALCULATION_NOTES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CALCULATION_NOTES : BaseDataContract
    {
        [XmlElement("Notes")]
        [DataMember]
        public string[] Notes { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_REPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_REPONSE : BaseDataContract
    {
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }

        [XmlElement("ProductID")]
        [DataMember]
        public string ProductID { get; set; }

        [XmlElement("ProductName")]//CPL/Jacket
        [DataMember]
        public string ProductName { get; set; }

        [XmlElement("ProductType")]
        [DataMember]
        public string ProductType { get; set; }

        [XmlElement("ProductResponseId")]
        [DataMember]
        public string ProductResponseId { get; set; }

        [XmlElement("RateType")]
        [DataMember]
        public string RateType { get; set; }

        [XmlElement("LiabilityAmount")]
        [DataMember]
        public decimal LiabilityAmount { get; set; }

        [XmlElement("EffectiveDate")]
        [DataMember]
        public DateTime EffectiveDate { get; set; }

        [XmlElement("IsExtendedCoverage")]
        [DataMember]
        public bool IsExtendedCoverage { get; set; }

        [XmlElement("StatisticalCode")]
        [DataMember]
        public string StatisticalCode { get; set; }
        
        [XmlElement("IsOverride")]
        [DataMember]
        public bool IsOverride { get; set; }

        [XmlElement("OverrideAmount")]
        [DataMember]
        public decimal OverrideAmount { get; set; }

        [XmlElement("OverrideReason")]
        [DataMember]
        public string OverrideReason { get; set; }

        [XmlElement("PriorPolicyNumber")]
        [DataMember]
        public string PriorPolicyNumber { get; set; }

        [XmlElement("NonEJacketPolicyNumber")]
        [DataMember]
        public string NonEJacketPolicyNumber { get; set; }

        [XmlElement("AgentNetProductServiceId")]
        [DataMember]
        public string AgentNetProductServiceId { get; set; }

        [XmlElement("LinkedProductServiceId")]
        [DataMember]
        public string LinkedProductServiceId { get; set; }

        [XmlElement("PolicySequence")]
        [DataMember]
        public string PolicySequence { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_LINEITEM_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_LINEITEM_DETAILS AGENTNET_PRODUCT_LINEITEM_DETAILS { get; set; }
                
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

        [XmlElement(ElementName = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RATE_FEES AGENTNET_RATE_FEES { get; set; }
                
        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }
                 
    }
    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_REQUESTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_REQUESTS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REQUEST[] AGENTNET_PRODUCT_PRICING_REQUEST { get; set; }
        [XmlElement("RateEffectiveDate")]
        [DataMember]
        public DateTime RateEffectiveDate { get; set; }
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }
        [XmlElement("IsAutoReportOnHold")]
        [DataMember]
        public bool IsAutoReportOnHold { get; set; }
        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_REQUEST : BaseDataContract
    {
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }

        [XmlElement("ProductID")]
        [DataMember]
        public string ProductID { get; set; }

        [XmlElement("ProductName")]//CPL/Jacket
        [DataMember]
        public string ProductName { get; set; }

        [XmlElement("ProductType")]//alta loan/standard
        [DataMember]
        public string ProductType { get; set; }

        [XmlElement("AgentNetProductServiceId")]
        [DataMember]
        public string AgentNetProductServiceId { get; set; }

        [XmlElement("RateType")]
        [DataMember]
        public string RateType { get; set; }

        [XmlElement("LiabilityAmount")]
        [DataMember]
        public decimal LiabilityAmount { get; set; }

        [XmlElement("EffectiveDate")]
        [DataMember]
        public DateTime EffectiveDate { get; set; }

        [XmlElement("IsExtendedCoverage")]
        [DataMember]
        public bool IsExtendedCoverage { get; set; }

        [XmlElement("StatisticalCode")]
        [DataMember]
        public string StatisticalCode { get; set; }
        
        [XmlElement("IsOverride")]
        [DataMember]
        public bool IsOverride { get; set; }

        [XmlElement("OverrideAmount")]
        [DataMember]
        public decimal OverrideAmount { get; set; }

        [XmlElement("OverrideReason")]
        [DataMember]
        public string OverrideReason { get; set; }

        [XmlElement("PriorPolicyNumber")]
        [DataMember]
        public string PriorPolicyNumber { get; set; }

        [XmlElement("NonEJacketPolicyNumber")]
        [DataMember]
        public string NonEJacketPolicyNumber { get; set; }

        [XmlElement("LinkedProductServiceId")]
        [DataMember]
        public string LinkedProductServiceId { get; set; }

        [XmlElement("PolicySequence")]
        [DataMember]
        public string PolicySequence { get; set; }

        [XmlElement("PolicyCategory")]
        [DataMember]
        public string PolicyCategory { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_LINEITEM_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_LINEITEM_DETAILS AGENTNET_PRODUCT_LINEITEM_DETAILS { get; set; }

        //later will be uncommented when jacket functionality implimented.
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

    }
    [DataContract(Name = "AGENTNET_PRODUCT_LINEITEM_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_LINEITEM_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_LINEITEM_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_LINEITEM_DETAIL[] AGENTNET_PRODUCT_LINEITEM_DETAIL { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_LINEITEM_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_LINEITEM_DETAIL : BaseDataContract
    {
        [XmlElement("LineItemID")]
        [DataMember]
        public string LineItemID { get; set; }

        [XmlElement("LineItemType")]
        [DataMember]
        public string LineItemType { get; set; }

        [XmlElement("LineItemDescr")]
        [DataMember]
        public string LineItemDescr { get; set; }

        [XmlElement("IsOverride")]
        [DataMember]
        public bool IsOverride { get; set; }

        [XmlElement("OverrideAmount")]
        [DataMember]
        public decimal OverrideAmount { get; set; }

        [XmlElement("OverrideReason")]
        [DataMember]
        public string OverrideReason { get; set; }

        [XmlElement("StatisticalCode")]
        [DataMember]
        public string StatisticalCode { get; set; }

        [XmlElement("MiscEndorsmentAmount")]
        [DataMember]
        public decimal MiscEndorsmentAmount { get; set; }

        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

        [XmlElement(ElementName = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RATE_FEES AGENTNET_RATE_FEES { get; set; }

        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }
    }

    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTIONS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTION", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTION[] AGENTNET_ADDITIONAL_QUESTION { get; set; }
    }
    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTION", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTION : BaseDataContract
    {
        [XmlElement("QuestionID")]
        [DataMember]
        public string QuestionID { get; set; }

        [XmlElement("QuestionType")]
        [DataMember]
        public string QuestionType { get; set; }

        [XmlElement("QuestionDescr")]
        [DataMember]
        public string QuestionDescr { get; set; }

        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTION_ANSWERS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTION_ANSWERS AGENTNET_ADDITIONAL_QUESTION_ANSWERS { get; set; }
    }

    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTION_ANSWERS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTION_ANSWERS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTION_ANSWER", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTION_ANSWER[] AGENTNET_ADDITIONAL_QUESTION_ANSWER { get; set; }
    }
    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTION_ANSWER", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTION_ANSWER : BaseDataContract
    {
        [XmlElement("AnswerID")]
        [DataMember]
        public string AnswerID { get; set; }

        [XmlElement("AnswerType")]
        [DataMember]
        public string AnswerType { get; set; }

        [XmlElement("AnswerDescr")]
        [DataMember]
        public string AnswerDescr { get; set; }
        [XmlElement("AnswerDataType")]
        [DataMember]
        public string AnswerDataType { get; set; }

    }


    [DataContract(Name = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_RATE_FEES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_RATE_FEE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RATE_FEE[] AGENTNET_RATE_FEE { get; set; }
    }
    [DataContract(Name = "AGENTNET_RATE_FEE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_RATE_FEE : BaseDataContract
    {
        [XmlElement("RateFeeId")]
        [DataMember]
        public string RateFeeId { get; set; }

        [XmlElement("RateFeeType")]
        [DataMember]
        public string RateFeeType { get; set; }

        [XmlElement("RateFeeDscr")]
        [DataMember]
        public string RateFeeDscr { get; set; }

        [XmlElement("RefNumber")]
        [DataMember]
        public string RefNumber { get; set; }

        [XmlElement("GrossAmount")]//it will have an override amount.
        [DataMember]
        public decimal GrossAmount { get; set; }

        [XmlElement("NetAmount")]
        [DataMember]
        public decimal NetAmount { get; set; }

        [XmlElement("CalculatedAmount")]
        [DataMember]
        public decimal CalculatedAmount { get; set; }//premium received from FACC

        [XmlElement("AgentRetentionAmount")]
        [DataMember]
        public decimal AgentRetentionAmount { get; set; }

        [XmlElement("TaxAmount")]
        [DataMember]
        public decimal TaxAmount { get; set; }

    }

   }

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE
{
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "label")]
    [DataMemberAttribute]
    public string xlinklabel { get; set; }
    /* xsd:choise node found with the following: */
	//	[XmlElement("AUS")]
	//[DataMember]
	//	public  AUS { get; set; }
	//	[XmlElement("CREDIT")]
	//[DataMember]
	//	public  CREDIT { get; set; }
	//	[XmlElement("DATA_CHANGE")]
	//[DataMember]
	//	public  DATA_CHANGE { get; set; }
	//	[XmlElement("DOCUMENT_MANAGEMENT")]
	//[DataMember]
	//	public  DOCUMENT_MANAGEMENT { get; set; }
	//	[XmlElement("FLOOD")]
	//[DataMember]
	//	public  FLOOD { get; set; }
	//	[XmlElement("FRAUD")]
	//[DataMember]
	//	public  FRAUD { get; set; }
	//	[XmlElement("LOAN_DELIVERY")]
	//[DataMember]
	//	public  LOAN_DELIVERY { get; set; }
	//	[XmlElement("MERS_SERVICE")]
	//[DataMember]
	//	public  MERS_SERVICE { get; set; }
	//	[XmlElement("MI")]
	//[DataMember]
	//	public  MI { get; set; }
	//	[XmlElement("PRIA")]
	//[DataMember]
	//	public  PRIA { get; set; }
	//	[XmlElement("SERVICE_PRODUCT_FULFILLMENT")]
	//[DataMember]
	//	public  SERVICE_PRODUCT_FULFILLMENT { get; set; }
	//	[XmlElement("TAX")]
	//[DataMember]
	//	public  TAX { get; set; }
	//	[XmlElement("TITLE")]
	//[DataMember]
	//	public  TITLE { get; set; }
	//	[XmlElement("VALUATION")]
	//[DataMember]
	//	public  VALUATION { get; set; }
	//[XmlElement("REPORTING_INFORMATION")]
	//[DataMember]
	//public  REPORTING_INFORMATION { get; set; }
	//[XmlElement("SERVICE_PAYMENTS")]
	//[DataMember]
	//public  SERVICE_PAYMENTS { get; set; }
	[XmlElement("SERVICE_PRODUCT")]
	[DataMember]
	public SERVICE_PRODUCT SERVICE_PRODUCT { get; set; }
	[XmlElement("STATUSES")]
	[DataMember]
	public STATUSES STATUSES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

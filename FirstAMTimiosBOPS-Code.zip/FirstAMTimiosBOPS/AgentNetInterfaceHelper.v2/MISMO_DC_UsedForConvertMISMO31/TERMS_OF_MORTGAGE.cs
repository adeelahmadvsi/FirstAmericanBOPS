using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "TERMS_OF_MORTGAGE", Namespace = DEAL.MISMO_NAMESPACE)]
public class TERMS_OF_MORTGAGE
{
    //[XmlElement("DisclosedFullyIndexedRatePercent")]
    //[DataMember]
    //public decimal DisclosedFullyIndexedRatePercent { get; set; }
    //[XmlElement("DisclosedIndexRatePercent")]
    //[DataMember]
    //public decimal DisclosedIndexRatePercent { get; set; }
    //[XmlElement("DisclosedMarginRatePercent")]
    //[DataMember]
    //public decimal DisclosedMarginRatePercent { get; set; }
	//[XmlElement("LienPriorityType")]
	//[DataMember]
	//public  LienPriorityType { get; set; }
    //[XmlElement("LienPriorityTypeOtherDescription")]
    //[DataMember]
    //public string LienPriorityTypeOtherDescription { get; set; }
	[XmlElement("LoanPurposeType")]
	[DataMember]
	public string LoanPurposeType { get; set; }
	[XmlElement("LoanPurposeTypeOtherDescription")]
	[DataMember]
	public string LoanPurposeTypeOtherDescription { get; set; }
	[XmlElement("MortgageType")]
	[DataMember]
	public string MortgageType { get; set; }
	[XmlElement("MortgageTypeOtherDescription")]
	[DataMember]
	public string MortgageTypeOtherDescription { get; set; }
	[XmlElement("NoteAmount")]
	[DataMember]
	public decimal NoteAmount { get; set; }
    [XmlElement(ElementName = "NoteDate", DataType = "date", Type = typeof(DateTime))]
	[DataMember]
	public DateTime NoteDate { get; set; }
	[XmlElement("NoteRatePercent")]
	[DataMember]
	public decimal NoteRatePercent { get; set; }
	[XmlElement("OriginalInterestRateDiscountPercent")]
	[DataMember]
	public decimal OriginalInterestRateDiscountPercent { get; set; }
	//[XmlElement("UPBChangeFrequencyType")]
	//[DataMember]
	//public  UPBChangeFrequencyType { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

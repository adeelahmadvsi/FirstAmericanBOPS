using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "ROLE", Namespace = DEAL.MISMO_NAMESPACE)]
public class ROLE
{
	/* xsd:choise node found with the following: */
	//	[XmlElement("APPRAISER")]
	//[DataMember]
	//	public  APPRAISER { get; set; }
	//	[XmlElement("APPRAISER_SUPERVISOR")]
	//[DataMember]
	//	public  APPRAISER_SUPERVISOR { get; set; }
	[XmlElement("BORROWER")]
	[DataMember]
	public BORROWER BORROWER { get; set; }
	//	[XmlElement("BUILDER")]
	//[DataMember]
	//	public  BUILDER { get; set; }
	//	[XmlElement("CLOSING_AGENT")]
	//[DataMember]
	//	public  CLOSING_AGENT { get; set; }
	//	[XmlElement("FULFILLMENT_PARTY")]
	//[DataMember]
	//	public  FULFILLMENT_PARTY { get; set; }
	[XmlElement("LENDER")]
	[DataMember]
	public LENDER LENDER { get; set; }
	//	[XmlElement("LIEN_HOLDER")]
	//[DataMember]
	//	public  LIEN_HOLDER { get; set; }
	//	[XmlElement("LOAN_ORIGINATION_COMPANY")]
	//[DataMember]
	//	public  LOAN_ORIGINATION_COMPANY { get; set; }
	//	[XmlElement("LOAN_ORIGINATOR")]
	//[DataMember]
	//	public  LOAN_ORIGINATOR { get; set; }
	//	[XmlElement("LOSS_PAYEE")]
	//[DataMember]
	//	public  LOSS_PAYEE { get; set; }
	//	[XmlElement("MANAGEMENT_COMPANY")]
	//[DataMember]
	//	public  MANAGEMENT_COMPANY { get; set; }
	//	[XmlElement("MORTGAGE_BROKER")]
	//[DataMember]
	//	public  MORTGAGE_BROKER { get; set; }
	//	[XmlElement("NOTARY")]
	//[DataMember]
	//	public  NOTARY { get; set; }
	//	[XmlElement("PAYEE")]
	//[DataMember]
	//	public  PAYEE { get; set; }
	//	[XmlElement("POWER_OF_ATTORNEY")]
	//[DataMember]
	//	public  POWER_OF_ATTORNEY { get; set; }
	//	[XmlElement("PROPERTY_OWNER")]
	//[DataMember]
	//	public  PROPERTY_OWNER { get; set; }
	[XmlElement("PROPERTY_SELLER")]
	[DataMember]
	public PROPERTY_SELLER PROPERTY_SELLER { get; set; }
	//	[XmlElement("REAL_ESTATE_AGENT")]
	//[DataMember]
	//	public  REAL_ESTATE_AGENT { get; set; }
	//	[XmlElement("REGULATORY_AGENCY")]
	//[DataMember]
	//	public  REGULATORY_AGENCY { get; set; }
	[XmlElement("REQUESTING_PARTY")]
	[DataMember]
	public REQUESTING_PARTY REQUESTING_PARTY { get; set; }
	[XmlElement("RESPONDING_PARTY")]
	[DataMember]
	public RESPONDING_PARTY RESPONDING_PARTY { get; set; }
	//	[XmlElement("RETURN_TO")]
	//[DataMember]
	//	public  RETURN_TO { get; set; }
	//	[XmlElement("REVIEW_APPRAISER")]
	//[DataMember]
	//	public  REVIEW_APPRAISER { get; set; }
	//	[XmlElement("SERVICER")]
	//[DataMember]
	//	public  SERVICER { get; set; }
	//	[XmlElement("SERVICING_TRANSFEROR")]
	//[DataMember]
	//	public  SERVICING_TRANSFEROR { get; set; }
	[XmlElement("SUBMITTING_PARTY")]
	[DataMember]
	public SUBMITTING_PARTY SUBMITTING_PARTY { get; set; }
	//	[XmlElement("TRUST")]
	//[DataMember]
	//	public  TRUST { get; set; }
	//	[XmlElement("TRUSTEE")]
	//[DataMember]
	//	public  TRUSTEE { get; set; }
	[XmlElement("ROLE_DETAIL")]
	[DataMember]
	public ROLE_DETAIL ROLE_DETAIL { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

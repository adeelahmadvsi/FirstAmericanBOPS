using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LOAN_IDENTIFIERS", Namespace = DEAL.MISMO_NAMESPACE)]
public class LOAN_IDENTIFIERS
{
	[XmlElement("LOAN_IDENTIFIER")]
	[DataMember]
	public LOAN_IDENTIFIER[] LOAN_IDENTIFIER { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

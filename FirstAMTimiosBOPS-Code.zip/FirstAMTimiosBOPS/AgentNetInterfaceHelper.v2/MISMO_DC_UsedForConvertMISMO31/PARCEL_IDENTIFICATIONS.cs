using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PARCEL_IDENTIFICATIONS", Namespace = DEAL.MISMO_NAMESPACE)]
public class PARCEL_IDENTIFICATIONS
{
	[XmlElement("PARCEL_IDENTIFICATION")]
	[DataMember]
	public PARCEL_IDENTIFICATION[] PARCEL_IDENTIFICATION { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

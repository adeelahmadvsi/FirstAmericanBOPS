using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "STATUSES", Namespace = DEAL.MISMO_NAMESPACE)]
public class STATUSES
{
	[XmlElement("STATUS")]
	[DataMember]
	public STATUS[] STATUS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

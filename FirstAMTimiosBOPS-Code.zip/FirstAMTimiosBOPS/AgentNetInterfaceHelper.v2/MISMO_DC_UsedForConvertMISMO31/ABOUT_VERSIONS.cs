using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "ABOUT_VERSIONS", Namespace = DEAL.MISMO_NAMESPACE)]
public class ABOUT_VERSIONS
{
	[XmlElement("ABOUT_VERSION")]
	[DataMember]
	public ABOUT_VERSION[] ABOUT_VERSION { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

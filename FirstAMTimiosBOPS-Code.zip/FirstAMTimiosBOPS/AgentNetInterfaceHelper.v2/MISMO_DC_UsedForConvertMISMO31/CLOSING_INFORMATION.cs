using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CLOSING_INFORMATION", Namespace = DEAL.MISMO_NAMESPACE)]
public class CLOSING_INFORMATION
{
	//[XmlElement("CLOSING_COSTS")]
	//[DataMember]
	//public  CLOSING_COSTS { get; set; }
	[XmlElement("CLOSING_INFORMATION_DETAIL")]
	[DataMember]
	public CLOSING_INFORMATION_DETAIL CLOSING_INFORMATION_DETAIL { get; set; }
	//[XmlElement("CLOSING_INSTRUCTION")]
	//[DataMember]
	//public  CLOSING_INSTRUCTION { get; set; }
	//[XmlElement("COLLECTED_OTHER_FUNDS")]
	//[DataMember]
	//public  COLLECTED_OTHER_FUNDS { get; set; }
	//[XmlElement("COMPENSATIONS")]
	//[DataMember]
	//public  COMPENSATIONS { get; set; }
	//[XmlElement("INTERIM_INTERESTS")]
	//[DataMember]
	//public  INTERIM_INTERESTS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "INDIVIDUAL", Namespace = DEAL.MISMO_NAMESPACE)]
public class INDIVIDUAL
{
	//[XmlElement("ALIASES")]
	//[DataMember]
	//public  ALIASES { get; set; }
	[XmlElement("CONTACT_POINTS")]
	[DataMember]
    public CONTACT_POINTS CONTACT_POINTS { get; set; }
	//[XmlElement("IDENTIFICATION_VERIFICATION")]
	//[DataMember]
	//public  IDENTIFICATION_VERIFICATION { get; set; }
	//[XmlElement("LICENSES")]
	//[DataMember]
	//public  LICENSES { get; set; }
	[XmlElement("NAME")]
	[DataMember]
	public NAME NAME { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

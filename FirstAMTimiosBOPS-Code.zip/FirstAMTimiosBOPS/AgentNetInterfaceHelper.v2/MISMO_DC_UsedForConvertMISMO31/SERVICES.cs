using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICES", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICES
{
	[XmlElement("SERVICE")]
	[DataMember]
	public SERVICE[] SERVICE { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

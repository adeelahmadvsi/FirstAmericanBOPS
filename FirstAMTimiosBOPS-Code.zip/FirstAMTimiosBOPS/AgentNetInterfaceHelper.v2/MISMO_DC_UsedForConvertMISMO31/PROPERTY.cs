using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PROPERTY", Namespace = DEAL.MISMO_NAMESPACE)]
public class PROPERTY
{
	[XmlElement("ADDRESS")]
	[DataMember]
	public ADDRESS ADDRESS { get; set; }
	//[XmlElement("COMPARABLE")]
	//[DataMember]
	//public  COMPARABLE { get; set; }
	//[XmlElement("DATA_SOURCES")]
	//[DataMember]
	//public  DATA_SOURCES { get; set; }
	//[XmlElement("FLOOD_DETERMINATION")]
	//[DataMember]
	//public  FLOOD_DETERMINATION { get; set; }
	//[XmlElement("HAZARD_INSURANCES")]
	//[DataMember]
	//public  HAZARD_INSURANCES { get; set; }
	//[XmlElement("HOMEOWNERS_ASSOCIATION")]
	//[DataMember]
	//public  HOMEOWNERS_ASSOCIATION { get; set; }
	//[XmlElement("IMPROVEMENT")]
	//[DataMember]
	//public  IMPROVEMENT { get; set; }
	[XmlElement("LEGAL_DESCRIPTIONS")]
	[DataMember]
	public LEGAL_DESCRIPTIONS LEGAL_DESCRIPTIONS { get; set; }
	//[XmlElement("LISTING_INFORMATIONS")]
	//[DataMember]
	//public  LISTING_INFORMATIONS { get; set; }
	[XmlElement("LOCATION_IDENTIFIER")]
	[DataMember]
    public LOCATION_IDENTIFIER LOCATION_IDENTIFIER { get; set; }
	//[XmlElement("MANUFACTURED_HOME")]
	//[DataMember]
	//public  MANUFACTURED_HOME { get; set; }
	//[XmlElement("NEIGHBORHOOD")]
	//[DataMember]
	//public  NEIGHBORHOOD { get; set; }
	//[XmlElement("PROJECT")]
	//[DataMember]
	//public  PROJECT { get; set; }
    //[XmlElement("PROPERTY_DETAIL")]
    //[DataMember]
    //public PROPERTY_DETAIL PROPERTY_DETAIL { get; set; }
	//[XmlElement("PROPERTY_HISTORY")]
	//[DataMember]
	//public  PROPERTY_HISTORY { get; set; }
    //[XmlElement("PROPERTY_TAXES")]
    //[DataMember]
    //public PROPERTY_TAXES PROPERTY_TAXES { get; set; }
	//[XmlElement("PROPERTY_TITLE")]
	//[DataMember]
	//public  PROPERTY_TITLE { get; set; }
	//[XmlElement("PROPERTY_UNITS")]
	//[DataMember]
	//public  PROPERTY_UNITS { get; set; }
	//[XmlElement("PROPERTY_VALUATIONS")]
	//[DataMember]
	//public  PROPERTY_VALUATIONS { get; set; }
	[XmlElement("SALES_CONTRACTS")]
	[DataMember]
    public SALES_CONTRACTS SALES_CONTRACTS { get; set; }
	//[XmlElement("SITE")]
	//[DataMember]
	//public  SITE { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

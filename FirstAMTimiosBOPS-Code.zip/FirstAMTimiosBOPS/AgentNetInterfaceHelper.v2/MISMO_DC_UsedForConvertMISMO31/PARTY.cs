using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PARTY", Namespace = DEAL.MISMO_NAMESPACE)]
public class PARTY
{
    //   [XmlAttribute(Namespace = "xlink", AttributeName = "label")]
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "label")]
    [DataMemberAttribute]
    public string xlinklabel { get; set; }
    /* xsd:choise node found with the following: */
	[XmlElement("REFERENCE")]
	[DataMember]
	public REFERENCE REFERENCE { get; set; }
	/* xsd:choise node found with the following: */
	[XmlElement("INDIVIDUAL")]
	[DataMember]
	public INDIVIDUAL INDIVIDUAL { get; set; }
	[XmlElement("LEGAL_ENTITY")]
	[DataMember]
	public LEGAL_ENTITY LEGAL_ENTITY { get; set; }
	[XmlElement("ADDRESSES")]
	[DataMember]
	public ADDRESSES ADDRESSES { get; set; }
	[XmlElement("ROLES")]
	[DataMember]
	public ROLES ROLES { get; set; }
	//[XmlElement("TAXPAYER_IDENTIFIERS")]
	//[DataMember]
	//public  TAXPAYER_IDENTIFIERS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PARCEL_IDENTIFICATION", Namespace = DEAL.MISMO_NAMESPACE)]
public class PARCEL_IDENTIFICATION
{
	[XmlElement("ParcelIdentificationType")]
	[DataMember]
	public string ParcelIdentificationType { get; set; }
	[XmlElement("ParcelIdentificationTypeOtherDescription")]
	[DataMember]
	public string ParcelIdentificationTypeOtherDescription { get; set; }
	[XmlElement("ParcelIdentifier")]
	[DataMember]
	public string ParcelIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PLATTED_LAND", Namespace = DEAL.MISMO_NAMESPACE)]
public class PLATTED_LAND
{
	[XmlElement("AppurtenanceDescription")]
	[DataMember]
	public string AppurtenanceDescription { get; set; }
	[XmlElement("AppurtenanceIdentifier")]
	[DataMember]
	public string AppurtenanceIdentifier { get; set; }
	//[XmlElement("AppurtenanceType")]
	//[DataMember]
	//public  AppurtenanceType { get; set; }
	[XmlElement("AppurtenanceTypeOtherDescription")]
	[DataMember]
	public string AppurtenanceTypeOtherDescription { get; set; }
	[XmlElement("PlatBlockIdentifier")]
	[DataMember]
	public string PlatBlockIdentifier { get; set; }
	[XmlElement("PlatBookIdentifier")]
	[DataMember]
	public string PlatBookIdentifier { get; set; }
	[XmlElement("PlatBuildingIdentifier")]
	[DataMember]
	public string PlatBuildingIdentifier { get; set; }
	[XmlElement("PlatIdentifier")]
	[DataMember]
	public string PlatIdentifier { get; set; }
	[XmlElement("PlatInstrumentIdentifier")]
	[DataMember]
	public string PlatInstrumentIdentifier { get; set; }
	[XmlElement("PlatLotIdentifier")]
	[DataMember]
	public string PlatLotIdentifier { get; set; }
	[XmlElement("PlatName")]
	[DataMember]
	public string PlatName { get; set; }
	[XmlElement("PlatPageIdentifier")]
	[DataMember]
	public string PlatPageIdentifier { get; set; }
	//[XmlElement("PlatType")]
	//[DataMember]
	//public  PlatType { get; set; }
	[XmlElement("PlatTypeOtherDescription")]
	[DataMember]
	public string PlatTypeOtherDescription { get; set; }
	[XmlElement("PlatUnitIdentifier")]
	[DataMember]
	public string PlatUnitIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

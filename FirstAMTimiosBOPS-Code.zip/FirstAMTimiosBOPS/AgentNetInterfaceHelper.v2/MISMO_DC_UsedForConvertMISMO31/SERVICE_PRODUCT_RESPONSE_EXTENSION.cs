﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace MISMOTypes
{
    [DataContract(Name = "SERVICE_PRODUCT_RESPONSE_EXTENSION", Namespace = DEAL.MISMO_NAMESPACE)]
    public class SERVICE_PRODUCT_RESPONSE_EXTENSION
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RESPONSE AGENTNET_PRODUCT_RESPONSE { get; set; }

        //[XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        //[DataMember]
        //public AGENTNET_PRODUCT_PRICING_RESPONSES AGENTNET_PRODUCT_PRICING_RESPONSES { get; set; }
    }
}

﻿
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "RELATIONSHIP", Namespace = DEAL.MISMO_NAMESPACE)]
public class RELATIONSHIP
{
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "from")]
    [DataMemberAttribute]
    public string xlinkFrom { get; set; }
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "to")]
    [DataMemberAttribute]
    public string xlinkTo { get; set; }
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "arcrole")]
    [DataMemberAttribute]
    public string xlinkArcrole { get; set; }
} // class
} // namespace

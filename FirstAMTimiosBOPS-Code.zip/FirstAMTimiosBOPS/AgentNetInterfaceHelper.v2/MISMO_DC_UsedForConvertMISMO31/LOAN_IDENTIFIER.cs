using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LOAN_IDENTIFIER", Namespace = DEAL.MISMO_NAMESPACE)]
public class LOAN_IDENTIFIER
{
	/* xsd:choise node found with the following: */
	//	[XmlElement("AgencyCaseIdentifier")]
	//[DataMember]
	//	public string AgencyCaseIdentifier { get; set; }
	//	[XmlElement("InvestorCommitmentIdentifier")]
	//[DataMember]
	//	public string InvestorCommitmentIdentifier { get; set; }
	//	[XmlElement("InvestorContractIdentifier")]
	//[DataMember]
	//	public string InvestorContractIdentifier { get; set; }
	//	[XmlElement("InvestorLoanIdentifier")]
	//[DataMember]
	//	public string InvestorLoanIdentifier { get; set; }
	//	[XmlElement("LenderCaseIdentifier")]
	//[DataMember]
	//	public string LenderCaseIdentifier { get; set; }
	//	[XmlElement("LenderLoanIdentifier")]
	//[DataMember]
	//	public string LenderLoanIdentifier { get; set; }
	//	[XmlElement("MERS_MINIdentifier")]
	//[DataMember]
	//	public string MERS_MINIdentifier { get; set; }
	//	[XmlElement("NewServicerLoanIdentifier")]
	//[DataMember]
	//	public string NewServicerLoanIdentifier { get; set; }
	//	[XmlElement("PriceLockIdentifier")]
	//[DataMember]
	//	public string PriceLockIdentifier { get; set; }
	//	[XmlElement("PriceQuoteIdentifier")]
	//[DataMember]
	//	public string PriceQuoteIdentifier { get; set; }
	//	[XmlElement("PriceRequestIdentifier")]
	//[DataMember]
	//	public string PriceRequestIdentifier { get; set; }
	//	[XmlElement("PriceResponseIdentifier")]
	//[DataMember]
	//	public string PriceResponseIdentifier { get; set; }
	//	[XmlElement("SellerLoanIdentifier")]
	//[DataMember]
	//	public string SellerLoanIdentifier { get; set; }
	//	[XmlElement("ServicerLoanIdentifier")]
	//[DataMember]
	//	public string ServicerLoanIdentifier { get; set; }
	//	[XmlElement("WholesaleLenderLoanIdentifier")]
	//[DataMember]
	//	public string WholesaleLenderLoanIdentifier { get; set; }
	[XmlElement("LoanIdentifierValue")]
	[DataMember]
	public string LoanIdentifierValue { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

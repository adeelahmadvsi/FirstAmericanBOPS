using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "ADDRESSES", Namespace = DEAL.MISMO_NAMESPACE)]
public class ADDRESSES
{
	[XmlElement("ADDRESS")]
	[DataMember]
	public ADDRESS[] ADDRESS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

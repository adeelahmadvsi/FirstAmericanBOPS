using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PARTY_ROLE_IDENTIFIERS", Namespace = DEAL.MISMO_NAMESPACE)]
public class PARTY_ROLE_IDENTIFIERS
{
	[XmlElement("PARTY_ROLE_IDENTIFIER")]
	[DataMember]
	public PARTY_ROLE_IDENTIFIER[] PARTY_ROLE_IDENTIFIER { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

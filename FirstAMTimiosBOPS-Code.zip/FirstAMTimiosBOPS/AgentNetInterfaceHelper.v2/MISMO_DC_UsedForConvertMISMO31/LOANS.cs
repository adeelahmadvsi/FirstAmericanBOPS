using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LOANS", Namespace = DEAL.MISMO_NAMESPACE)]
public class LOANS
{
	//[XmlElement("COMBINED_LTVS")]
	//[DataMember]
	//public  COMBINED_LTVS { get; set; }
	[XmlElement("LOAN")]
	[DataMember]
	public LOAN[] LOAN { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

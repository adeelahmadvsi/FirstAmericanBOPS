using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CONTACT", Namespace = DEAL.MISMO_NAMESPACE)]
public class CONTACT
{
	//[XmlElement("CONTACT_DETAIL")]
	//[DataMember]
	//public  CONTACT_DETAIL { get; set; }
	[XmlElement("CONTACT_POINTS")]
	[DataMember]
	public CONTACT_POINTS CONTACT_POINTS { get; set; }
	[XmlElement("NAME")]
	[DataMember]
	public NAME NAME { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

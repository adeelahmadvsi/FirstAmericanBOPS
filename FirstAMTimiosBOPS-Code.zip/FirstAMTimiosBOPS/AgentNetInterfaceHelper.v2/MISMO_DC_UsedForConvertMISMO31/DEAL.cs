using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "DEAL", Namespace = DEAL.MISMO_NAMESPACE)]
public class DEAL
{
    public const string MISMO_NAMESPACE = "http://www.mismo.org/residential/2009/schemas";
    public const string XLINK_NAMESPACE = "http://www.w3.org/1999/xlink";
    /* xsd:choise node found with the following: */
	[XmlElement("REFERENCE")]
	[DataMember]
	public REFERENCE REFERENCE { get; set; }
	[XmlElement("ABOUT_VERSIONS")]
	[DataMember]
	public ABOUT_VERSIONS ABOUT_VERSIONS { get; set; }
	//[XmlElement("ASSETS")]
	//[DataMember]
	//public  ASSETS { get; set; }
	[XmlElement("COLLATERALS")]
	[DataMember]
	public COLLATERALS COLLATERALS { get; set; }
	//[XmlElement("EXPENSES")]
	//[DataMember]
	//public  EXPENSES { get; set; }
	//[XmlElement("LIABILITIES")]
	//[DataMember]
	//public  LIABILITIES { get; set; }
	[XmlElement("LOANS")]
	[DataMember]
	public LOANS LOANS { get; set; }
	[XmlElement("PARTIES")]
	[DataMember]
	public PARTIES PARTIES { get; set; }
    [XmlElement("RELATIONSHIPS")]
    [DataMember]
    public RELATIONSHIPS RELATIONSHIPS { get; set; }
	[XmlElement("SERVICES")]
	[DataMember]
	public SERVICES SERVICES { get; set; }
	[XmlElement("EXTENSION")]
	[DataMember]
    public DEAL_EXTENSION EXTENSION { get; set; }
} // class
} // namespace

using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "ABOUT_VERSION", Namespace = DEAL.MISMO_NAMESPACE)]
public class ABOUT_VERSION
{
	[XmlElement("AboutVersionIdentifier")]
	[DataMember]
	public string AboutVersionIdentifier { get; set; }
	[XmlElement("CreatedDatetime")]
	[DataMember]
	public DateTime CreatedDatetime { get; set; }
	[XmlElement("DataVersionIdentifier")]
	[DataMember]
	public string DataVersionIdentifier { get; set; }
	[XmlElement("DataVersionName")]
	[DataMember]
	public string DataVersionName { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

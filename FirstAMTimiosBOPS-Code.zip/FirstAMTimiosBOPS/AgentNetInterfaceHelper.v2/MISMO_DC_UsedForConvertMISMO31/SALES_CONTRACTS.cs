using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SALES_CONTRACTS", Namespace = "http://www.mismo.org/residential/2009/schemas")]
public class SALES_CONTRACTS: BaseDataContract
{
	[XmlElement("SALES_CONTRACT")]
	[DataMember]
	public SALES_CONTRACT[] SALES_CONTRACT { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

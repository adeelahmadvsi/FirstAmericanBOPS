using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "BORROWER_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
public class BORROWER_DETAIL
{
	[XmlElement("BorrowerAgeAtApplicationYearsCount")]
	[DataMember]
	public int BorrowerAgeAtApplicationYearsCount { get; set; }
	[XmlElement("BorrowerApplicationSignedDate")]
	[DataMember]
	public DateTime BorrowerApplicationSignedDate { get; set; }
	[XmlElement("BorrowerBirthDate")]
	[DataMember]
	public DateTime BorrowerBirthDate { get; set; }
	[XmlElement("BorrowerCanadianSocialInsuranceNumberIdentifier")]
	[DataMember]
	public string BorrowerCanadianSocialInsuranceNumberIdentifier { get; set; }
	//[XmlElement("BorrowerCharacteristicType")]
	//[DataMember]
	//public  BorrowerCharacteristicType { get; set; }
	[XmlElement("BorrowerCharacteristicTypeOtherDescription")]
	[DataMember]
	public string BorrowerCharacteristicTypeOtherDescription { get; set; }
	//[XmlElement("BorrowerClassificationType")]
	//[DataMember]
	//public  BorrowerClassificationType { get; set; }
	[XmlElement("BorrowerIsCosignerIndicator")]
	[DataMember]
	public bool BorrowerIsCosignerIndicator { get; set; }
	[XmlElement("BorrowerMailToAddressSameAsPropertyIndicator")]
	[DataMember]
	public bool BorrowerMailToAddressSameAsPropertyIndicator { get; set; }
	[XmlElement("BorrowerQualifyingIncomeAmount")]
	[DataMember]
	public decimal BorrowerQualifyingIncomeAmount { get; set; }
	//[XmlElement("BorrowerRelationshipTitleType")]
	//[DataMember]
	//public  BorrowerRelationshipTitleType { get; set; }
	[XmlElement("BorrowerRelationshipTitleTypeOtherDescription")]
	[DataMember]
	public string BorrowerRelationshipTitleTypeOtherDescription { get; set; }
	[XmlElement("BorrowerSameAsBuilderIndicator")]
	[DataMember]
	public bool BorrowerSameAsBuilderIndicator { get; set; }
	[XmlElement("BorrowerTotalMortgagedPropertiesCount")]
	[DataMember]
	public int BorrowerTotalMortgagedPropertiesCount { get; set; }
	[XmlElement("CreditFileBorrowerAgeYearsCount")]
	[DataMember]
	public int CreditFileBorrowerAgeYearsCount { get; set; }
	[XmlElement("CreditReportAuthorizationIndicator")]
	[DataMember]
	public bool CreditReportAuthorizationIndicator { get; set; }
	[XmlElement("CreditReportIdentifier")]
	[DataMember]
	public string CreditReportIdentifier { get; set; }
	[XmlElement("DependentCount")]
	[DataMember]
	public int DependentCount { get; set; }
	//[XmlElement("JointAssetLiabilityReportingType")]
	//[DataMember]
	//public  JointAssetLiabilityReportingType { get; set; }
	[XmlElement("MaritalStatusType")]
	[DataMember]
	public string MaritalStatusType { get; set; }
	[XmlElement("SchoolingYearsCount")]
	[DataMember]
	public int SchoolingYearsCount { get; set; }
	[XmlElement("SignedAuthorizationToRequestTaxRecordsIndicator")]
	[DataMember]
	public bool SignedAuthorizationToRequestTaxRecordsIndicator { get; set; }
	[XmlElement("SSNCertificationIndicator")]
	[DataMember]
	public bool SSNCertificationIndicator { get; set; }
	[XmlElement("TaxRecordsObtainedIndicator")]
	[DataMember]
	public bool TaxRecordsObtainedIndicator { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "RELATIONSHIPS", Namespace = DEAL.MISMO_NAMESPACE)]
public class RELATIONSHIPS
{
    [XmlElement("RELATIONSHIP")]
    [DataMember]
    public RELATIONSHIP[] RELATIONSHIP  { get; set; }
} // class
} // namespace

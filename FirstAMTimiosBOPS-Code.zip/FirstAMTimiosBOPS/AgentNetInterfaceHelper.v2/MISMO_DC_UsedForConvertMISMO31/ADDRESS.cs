using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "ADDRESS", Namespace = DEAL.MISMO_NAMESPACE)]
public class ADDRESS
{
	[XmlElement("AddressAdditionalLineText")]
	[DataMember]
	public string AddressAdditionalLineText { get; set; }
	[XmlElement("AddressLineText")]
	[DataMember]
	public string AddressLineText { get; set; }
	//[XmlElement("AddressType")]
	//[DataMember]
	//public  AddressType { get; set; }
    //[XmlElement("AddressTypeOtherDescription")]
    //[DataMember]
    //public string AddressTypeOtherDescription { get; set; }
	//[XmlElement("AddressUnitDesignatorType")]
	//[DataMember]
	//public  AddressUnitDesignatorType { get; set; }
    //[XmlElement("AddressUnitDesignatorTypeOtherDescription")]
    //[DataMember]
    //public string AddressUnitDesignatorTypeOtherDescription { get; set; }
    //[XmlElement("AddressUnitIdentifier")]
    //[DataMember]
    //public string AddressUnitIdentifier { get; set; }
    //[XmlElement("CarrierRouteCode")]
    //[DataMember]
    //public string CarrierRouteCode { get; set; }
	[XmlElement("CityName")]
	[DataMember]
	public string CityName { get; set; }
    //[XmlElement("CountryCode")]
    //[DataMember]
    //public string CountryCode { get; set; }
    [XmlElement("CountryName")]
    [DataMember]
    public string CountryName { get; set; }
    [XmlElement("CountyCode")]
    [DataMember]
    public string CountyCode { get; set; }
	[XmlElement("CountyName")]
	[DataMember]
	public string CountyName { get; set; }
    //[XmlElement("DeliveryPointBarCodeCheckNumber")]
    //[DataMember]
    //public string DeliveryPointBarCodeCheckNumber { get; set; }
    //[XmlElement("DeliveryPointBarCodeNumber")]
    //[DataMember]
    //public string DeliveryPointBarCodeNumber { get; set; }
    //[XmlElement("MailStopCode")]
    //[DataMember]
    //public string MailStopCode { get; set; }
	[XmlElement("PlusFourZipCodeNumber")]
	[DataMember]
	public string PlusFourZipCodeNumber { get; set; }
	[XmlElement("PostalCode")]
	[DataMember]
	public string PostalCode { get; set; }
    //[XmlElement("PostOfficeBoxIdentifier")]
    //[DataMember]
    //public string PostOfficeBoxIdentifier { get; set; }
    //[XmlElement("RuralRouteIdentifier")]
    //[DataMember]
    //public string RuralRouteIdentifier { get; set; }
	[XmlElement("StateCode")]
	[DataMember]
	public string StateCode { get; set; }
    //[XmlElement("StateName")]
    //[DataMember]
    //public string StateName { get; set; }
    //[XmlElement("StreetName")]
    //[DataMember]
    //public string StreetName { get; set; }
    //[XmlElement("StreetPostDirectionalText")]
    //[DataMember]
    //public string StreetPostDirectionalText { get; set; }
    //[XmlElement("StreetPreDirectionalText")]
    //[DataMember]
    //public string StreetPreDirectionalText { get; set; }
    //[XmlElement("StreetPrimaryNumberText")]
    //[DataMember]
    //public string StreetPrimaryNumberText { get; set; }
    //[XmlElement("StreetSuffixText")]
    //[DataMember]
    //public string StreetSuffixText { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PARSED_LEGAL_DESCRIPTION", Namespace = DEAL.MISMO_NAMESPACE)]
public class PARSED_LEGAL_DESCRIPTION
{
	[XmlElement("PLATTED_LANDS")]
	[DataMember]
	public PLATTED_LANDS PLATTED_LANDS { get; set; }
	[XmlElement("UNPLATTED_LANDS")]
	[DataMember]
	public UNPLATTED_LANDS UNPLATTED_LANDS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

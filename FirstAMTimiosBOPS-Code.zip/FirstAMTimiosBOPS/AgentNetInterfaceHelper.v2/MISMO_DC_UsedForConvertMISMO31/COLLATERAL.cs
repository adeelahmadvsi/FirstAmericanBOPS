using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "COLLATERAL", Namespace = DEAL.MISMO_NAMESPACE)]
public class COLLATERAL
{
	//[XmlElement("COLLATERAL_DETAIL")]
	//[DataMember]
	//public  COLLATERAL_DETAIL { get; set; }
	//[XmlElement("PLEDGED_ASSETS")]
	//[DataMember]
	//public  PLEDGED_ASSETS { get; set; }
	[XmlElement("PROPERTIES")]
	[DataMember]
	public PROPERTIES PROPERTIES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "VIEW_FILE", Namespace = DEAL.MISMO_NAMESPACE)]
public class VIEW_FILE
{
	[XmlElement("FOREIGN_OBJECT")]
	[DataMember]
	public FOREIGN_OBJECT FOREIGN_OBJECT { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

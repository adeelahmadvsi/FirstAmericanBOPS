using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LENDER_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
public class LENDER_DETAIL
{
	[XmlElement("LenderDocumentsOrderedByName")]
	[DataMember]
	public string LenderDocumentsOrderedByName { get; set; }
	[XmlElement("LenderFunderName")]
	[DataMember]
	public string LenderFunderName { get; set; }
	[XmlElement("RegulatoryAgencyLenderIdentifier")]
	[DataMember]
	public string RegulatoryAgencyLenderIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

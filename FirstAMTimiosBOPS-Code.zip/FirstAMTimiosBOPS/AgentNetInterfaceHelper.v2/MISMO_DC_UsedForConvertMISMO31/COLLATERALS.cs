using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "COLLATERALS", Namespace = DEAL.MISMO_NAMESPACE)]
public class COLLATERALS
{
	[XmlElement("COLLATERAL")]
	[DataMember]
	public COLLATERAL[] COLLATERAL { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "RESPONDING_PARTY", Namespace = DEAL.MISMO_NAMESPACE)]
public class RESPONDING_PARTY
{
	[XmlElement("RespondingPartyTransactionIdentifier")]
	[DataMember]
	public string RespondingPartyTransactionIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PROPERTY_SELLER", Namespace = DEAL.MISMO_NAMESPACE)]
public class PROPERTY_SELLER
{
	[XmlElement("MaritalStatusType")]
	[DataMember]
	public string MaritalStatusType { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

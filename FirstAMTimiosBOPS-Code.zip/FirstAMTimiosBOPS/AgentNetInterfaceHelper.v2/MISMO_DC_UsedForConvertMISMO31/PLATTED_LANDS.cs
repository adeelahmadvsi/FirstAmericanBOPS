using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "PLATTED_LANDS", Namespace = DEAL.MISMO_NAMESPACE)]
public class PLATTED_LANDS
{
	[XmlElement("PLATTED_LAND")]
	[DataMember]
	public PLATTED_LAND[] PLATTED_LAND { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "ROLE_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
public class ROLE_DETAIL
{
	[XmlElement("PartyRoleType")]
	[DataMember]
	public string PartyRoleType { get; set; }
	[XmlElement("PartyRoleTypeOtherDescription")]
	[DataMember]
	public string PartyRoleTypeOtherDescription { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

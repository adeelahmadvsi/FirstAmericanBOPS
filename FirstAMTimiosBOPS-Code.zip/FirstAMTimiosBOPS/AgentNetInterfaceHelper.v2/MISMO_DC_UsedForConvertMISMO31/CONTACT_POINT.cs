using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CONTACT_POINT", Namespace = DEAL.MISMO_NAMESPACE)]
public class CONTACT_POINT
{
	/* xsd:choise node found with the following: */
	[XmlElement("ContactPointEmailValue")]
    [DataMember]
    public string ContactPointEmailValue { get; set; }
    [XmlElement("ContactPointFaxValue")]
    [DataMember]
    public string ContactPointFaxValue { get; set; }
    [XmlElement("ContactPointTelephoneValue")]
    [DataMember]
    public string ContactPointTelephoneValue { get; set; }
    [XmlElement("ContactPointOtherValue")]
    [DataMember]
    public string ContactPointOtherValue { get; set; }
    [XmlElement("ContactPointOtherValueDescription")]
    [DataMember]
    public string ContactPointOtherValueDescription { get; set; }
    [XmlElement("ContactPointRoleType")]
    [DataMember]
    public string ContactPointRoleType { get; set; }
    [XmlElement("ContactPointRoleTypeOtherDescription")]
    [DataMember]
    public string ContactPointRoleTypeOtherDescription { get; set; }
    [XmlElement("ContactPointPreferenceIndicator")]
    [DataMember]
    public bool ContactPointPreferenceIndicator { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

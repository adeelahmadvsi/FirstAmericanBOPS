using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CENSUS_INFORMATION", Namespace = DEAL.MISMO_NAMESPACE)]
public class CENSUS_INFORMATION
{
	[XmlElement("CensusBlockGroupIdentifier")]
	[DataMember]
	public string CensusBlockGroupIdentifier { get; set; }
	[XmlElement("CensusBlockIdentifier")]
	[DataMember]
	public string CensusBlockIdentifier { get; set; }
	[XmlElement("CensusTractBaseIdentifier")]
	[DataMember]
	public string CensusTractBaseIdentifier { get; set; }
	[XmlElement("CensusTractIdentifier")]
	[DataMember]
	public string CensusTractIdentifier { get; set; }
	[XmlElement("CensusTractSuffixIdentifier")]
	[DataMember]
	public string CensusTractSuffixIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

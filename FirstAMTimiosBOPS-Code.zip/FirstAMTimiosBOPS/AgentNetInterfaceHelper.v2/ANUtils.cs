﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
#if MISMO32
namespace AgentNetInterfaceHelper.v2
#else
namespace AgentNetInterfaceHelper.v1
#endif
{
    public class ANUtils
    {
        private static int TIMEOUT_VALUE = 200000; //200000;

        /* Constacts used */
        #region PropertyUsageTypes
        public const string C_UsageType_Investment = "Investment";
        public const string C_UsageType_PrimaryResidence = "PrimaryResidence";
        public const string C_UsageType_SecondHome = "SecondHome";
        #endregion
        #region LoanTypes
        public const string C_LoanType_Purchase = "Purchase";
        public const string C_LoanType_Refinance = "Refinance";
        public const string C_LoanType_ConstructionOnly = "ConstructionOnly";
        public const string C_LoanType_ConstructionToPermanent = "ConstructionToPermanent";
        public const string C_LoanType_MortgageModification = "MortgageModification";
        public const string C_LoanType_Unknown = "Unknown";
        public const string C_LoanType_Other = "Other";
        #endregion

        #region MortgageTypes
        public const string C_MortgageType_Conventional = "Conventional";
        public const string C_MortgageType_FarmersHomeAdministration = "FarmersHomeAdministration";
        public const string C_MortgageType_FHA = "FHA";
        public const string C_MortgageType_Other = "Other";
        public const string C_MortgageType_VA = "VA";
        public const string C_MortgageType_HELOC = "HELOC";
        public const string C_MortgageType_StateAgency = "StateAgency";
        public const string C_MortgageType_LocalAgency = "LocalAgency";
        #endregion
        #region ServiceTypes
        public const string C_ServiceType_JACKET = "JACKET";
        public const string C_ServiceType_CPL = "CPL";
        public const string C_ServiceType_BACKTITLE = "BACKTITLE";
        public const string C_ServiceType_RATESFEES = "RATESFEES";
        public const string C_ServiceType_SDN = "SDN";
        public const string C_ServiceType_PREPRICING = "PREPRICING";
        public const string C_ServiceType_BOPSERVICE = "BOPSERVICE";
        public const string C_ServiceType_UWB = "UNDERWRITING REQUEST";
        #endregion



        //public const string CF_ControlFilesBase = "ControlFilesBase";
        public const string CF_FileDataBase = "FileDataBase";

        private static string s_FileBasePath;
        private static string s_FileDataPath;

        /* ALL files reads are based on the below base ffolder */
        static ANUtils()
        {
            ///zzzzz commented
            //s_FileBasePath = GetConfig(CF_ControlFilesBase, "c:\\ControlFiles");
            //if (!Directory.Exists(s_FileBasePath))
            //{
            //    Directory.CreateDirectory(s_FileBasePath);
            //}
            //s_FileDataPath = GetConfig(CF_FileDataBase, "FileDataBase");
            //if (!Directory.Exists(s_FileBasePath + "\\" + s_FileDataPath))
            //{
            //    Directory.CreateDirectory(s_FileBasePath + "\\" + s_FileDataPath);
            //}
        }
        
        #region GetConfig
        /* GetConfig related functions:
         * - GetConfig returns a config value and return an empty string if it does not exist  
         * - 2nd GetConfig return a default value if it does not exist
         * - GetConfigInt return an integer value and zero if it does not exists
         * - 2nd GetConfigInt return a defualt value iof it does not exist
        * */
        public static string GetConfig(string key)
        {

            if (ConfigurationManager.AppSettings[key] != null)
            {
                return ConfigurationManager.AppSettings[key];
            }
            return "";

        }
        public static string GetConfig(string key, string defaultValue)
        {
            if (ConfigurationManager.AppSettings[key] != null)
            {
                return ConfigurationManager.AppSettings[key];
            }
            return defaultValue;

        }
        public static int GetConfigInt(string key, int defaultValue)
        {
            if (ConfigurationManager.AppSettings[key] != null)
            {
                return Convert.ToInt32(ConfigurationManager.AppSettings[key]);
            }

            return defaultValue;
        }
        public static int GetConfigInt(string key)
        {
            if (ConfigurationManager.AppSettings[key] != null)
            {
                return Convert.ToInt32(ConfigurationManager.AppSettings[key]);
            }
            return 0;
        }
        #endregion

        #region FileToXXXX_xxxxToFile 
        /* FileToString:
         * This is a simple utility function to read a file into a string.
         * */
        public static string FileBasePath
        {
            get { return s_FileBasePath; }
            set { s_FileBasePath = value; } // should not use this is a regular basis
        }
        public static string FileDataPath
        {
            get { return s_FileDataPath; }
        }
        public static string FileToString(string filePath, bool bNoBase = false)
        {
            try
            {

                StreamReader sr = null;
                if (!bNoBase && s_FileBasePath.Length > 0)
                    sr = File.OpenText(s_FileBasePath + "\\" + filePath);
                else
                    sr = File.OpenText(filePath);
                string input = sr.ReadToEnd();
                sr.Close();
                return input;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /* FileToList:
         * This is a simple utility function to read file into a List of line records. 
         * */
        public static List<string> FileToList(string filePath, bool bNoBase = false)
        {
            try
            {
                List<string> o = new List<string>();
                StreamReader sr = null;
                if (!bNoBase && s_FileBasePath.Length > 0)
                    sr = File.OpenText(s_FileBasePath + "\\" + filePath);
                else
                    sr = File.OpenText(filePath);
                string input = null;
                while ((input = sr.ReadLine()) != null)
                {
                    string rec = input.Trim();
                    if (rec.Length > 0)
                        o.Add(rec);
                }
                sr.Close();
                return o;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /* FileToDictionary:
         * This is a simple utility function to read a delimited file and create a "Key=Value"
         * dictionary.  
         * */
        public static Dictionary<string, string> FileToDictionaryToLower(string filePath, string del, bool bNoBase = false)
        {
            return FileToDictionary(filePath, del, 'l', bNoBase);
        }
        public static Dictionary<string, string> FileToDictionaryToUpper(string filePath, string del, bool bNoBase = false)
        {
            return FileToDictionary(filePath, del, 'u', bNoBase);
        }
        public static Dictionary<string, string> FileToDictionaryKeyUpper(string filePath, string del, bool bNoBase = false)
        {
            return FileToDictionary(filePath, del, 'k', bNoBase);
        }
        public static Dictionary<string, string> FileToDictionary(string filePath, string del, bool bNoBase = false)
        {
            return FileToDictionary(filePath, del, ' ', bNoBase);
        }
        public static Dictionary<string, string> FileToDictionary(string filePath, string del, char ct, bool bNoBase = false)
        {
            try
            {
                List<string> l = ANUtils.FileToList(filePath, bNoBase);
                Dictionary<string, string> nameValues = new Dictionary<string, string>();
                foreach (string s in l)
                {
                    int lp = s.IndexOf(del);
                    if (lp < 1)
                        throw new Exception(filePath + " file contains invalid format record: " + s);
                    string k = s.Substring(0, lp).Trim();
                    string v = s.Substring(lp + 1).Trim();
                    if (ct == 'l')
                    {
                        k = k.ToLower();
                        v = v.ToLower();
                    } 
                    else if (ct == 'u')
                    {
                        k = k.ToUpper();
                        v = v.ToUpper();
                    }
                    else if (ct == 'k')
                    {
                        k = k.ToUpper();
                    }

                    nameValues.Add(k, v);
                }
                return nameValues;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void StringToFile_Ori(string filePath, string data, bool bNoBase = false)
        {
            try
            {
                StreamWriter sw = null;
                if (bNoBase)
                    sw = new StreamWriter(filePath);
                else
                    sw = new StreamWriter(s_FileBasePath + "\\" + filePath);
                sw.Write(data);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //modified zz
        public static void StringToFile(string filePath, string data)
        {
            try
            {
                StreamWriter sw = null;

                string folder = GetConfig("LogFolder", "");

                sw = new StreamWriter(folder + filePath);
                sw.Write(data);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public static void DeleteFile(string filePath, bool bNoBase = false)
        {
            try
            {
                if (bNoBase)
                    File.Delete(filePath);
                else
                    File.Delete(s_FileBasePath + "\\" + filePath);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public static bool FileExists(string filePath, bool bNoBase = false)
        {
            try
            {
                if (bNoBase)
                    return File.Exists(filePath);
                else
                    return File.Exists(s_FileBasePath + "\\" + filePath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void FileRename(string prevFilePath, string newFilePath, bool bNoBase = false)
        {
            try
            {
                if (bNoBase)
                    File.Move(prevFilePath, newFilePath);
                else
                    File.Move(s_FileBasePath + "\\" + prevFilePath, s_FileBasePath + "\\" + newFilePath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void FileCreate(string filePath, bool bNoBase = false)
        {
            StreamWriter sw = null;
            if (bNoBase)
                sw = File.CreateText(filePath);
            else
                sw = File.CreateText(s_FileBasePath + "\\" + filePath);
            sw.Close();
        }
        public static void ListToFile(string filePath, List<string> lines, bool bNoBase = false)
        {
            try
            {
                StreamWriter sw = null;
                if (bNoBase)
                    sw = new StreamWriter(filePath);
                else
                    sw = new StreamWriter(s_FileBasePath + "\\" + filePath);
                foreach (string l in lines)
                {
                    sw.WriteLine(l);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region XmlUtils
        public static XmlNode GetDataNodeFor(XmlDocument xml, string tag)
        {
            //Vairavel:28/10/2010
            //Added the logic to check the xml and its first child is null or not.
            //NOTE: Once we conform that the xml will not be empty in Database we can remove this condition.
            if (xml == null)
            {
                return null;
            }
            else if (xml.FirstChild == null)
                return null;
            else
            {
                XmlNode rootNode = xml.FirstChild.NextSibling;
                if (rootNode == null)
                    rootNode = xml.FirstChild;
                return rootNode.SelectSingleNode(tag);
            }
        }
        public static void SetNodeValue(XmlDocument xmlDoc, string pathName, string value)
        {
            XmlNode n = ANUtils.GetDataNodeFor(xmlDoc, pathName);
            n.InnerText = value;
        }
        public static string XPathVal(XmlNode xmlNode, string xPath)
        {
            try
            {
                //Vairavel:28/10/2010
                //Added the logic to check the xmlNode and its first child is null or not.
                if (xmlNode != null)
                {
                    XmlNode node = xmlNode.SelectSingleNode(xPath);
                    if (node != null)
                    {
                        return node.InnerText;
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
                else
                {
                    return string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
        }
        public static XmlDocument StripDocumentNamespace(XmlDocument oldDom)
        {
            // some config files have a default namespace
            // we are going to get rid of that to simplify our xpath expressions
            if (oldDom.DocumentElement.NamespaceURI.Length > 0)
            {
                oldDom.DocumentElement.SetAttribute("xmlns", "");
                // must serialize and reload the DOM
                // before this will actually take effect
                XmlDocument newDom = new XmlDocument();
                newDom.LoadXml(oldDom.OuterXml);
                return newDom;
            }
            else return oldDom;
        }
        public static string XmlDocToString(XmlDocument xmlDoc)
        {
            StringWriter sw = new StringWriter();
            XmlTextWriter xw = new XmlTextWriter(sw);
            xmlDoc.WriteTo(xw);
            return sw.ToString();

        }
        public static string GetXmlAttributeValue(XmlNode n, string a)
        {
            try
            {
                XmlAttribute attr = n.Attributes[a];
                if (attr != null)
                {
                    return attr.Value;
                }
                else
                {
                    return string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }

        }
        public static string XmlEncode(string str)
        {
            string xmlEncoded = null;

            if (str != null)
            {
                xmlEncoded = ANUtils.ReplaceNoneASCIIWithSpace(str);
            }
            return xmlEncoded;
        }
        private static string xmlSerializeDCInternal(System.Type t, Object dcObj)
        {
            MemoryStream mstream = new MemoryStream();
            StreamWriter wr = new StreamWriter(mstream);
            string xmlStr = "";
            System.Xml.Serialization.XmlSerializer xmlSer =
                new System.Xml.Serialization.XmlSerializer(t);
            xmlSer.Serialize(wr, dcObj);
            mstream.Flush();
            mstream.Position = 0;
            using (StreamReader sr = new StreamReader(mstream))
            {
                xmlStr = sr.ReadToEnd();
            }
            mstream.Close();
            //
            // Below XmlDocument used to make the XmlSerializer created Xml text 
            // which contains a lot of white space to make it a little smaller
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlStr);
	        StringWriter sw = new StringWriter();
	        XmlTextWriter xw = new XmlTextWriter(sw);
	        xmlDoc.WriteTo(xw);
	        return sw.ToString();
        }
        private static Object xmlDeSerializeDCInternal(System.Type t, string xmlStr)
        {
            MemoryStream mstream = new MemoryStream();
            StreamWriter wr = new StreamWriter(mstream);
            wr.Write(xmlStr);
            wr.Flush();
            mstream.Position = 0;
            System.Xml.Serialization.XmlSerializer xmlSer = 
                new System.Xml.Serialization.XmlSerializer(t);
            Object dcObj = xmlSer.Deserialize(mstream);
            mstream.Close();
            return dcObj;
        }
        public static string SerializeObject(Object pObject, Type t, string defaultNamespace, List<string> nsPrefixName)
        {
            try
            {
                string xmlData = null;
                MemoryStream memoryStream = new MemoryStream();
                XmlSerializer xs = null;
                if (defaultNamespace.Length > 0)
                    xs = new XmlSerializer(t, defaultNamespace);
                else
                    xs = new XmlSerializer(t);
                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                foreach (string s in nsPrefixName)
                {
                    string[] ss = s.Split(',');
                    if (ss.Length != 2)
                        throw new Exception("nsPrefixName = " + s + "  BAD FORMAT should be prefix,name");
                    ns.Add(ss[0], ss[1]);
                }
                //XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Default);
                XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
                xs.Serialize(xmlTextWriter, pObject, ns);
                memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
                xmlData = UTF8ByteArrayToString(memoryStream.ToArray());
                // There is a problem with Encoding.UTF8 where .NET inserts a non-XML character in the 1st position
                // so the following logic (if (xmlData[0] != '<') has been added to mitigate that.  
                // UTF8 has to be used instead of Encoding.Default which does not cause that
                // problem BUT the special characters do not get handled correctly.
                if (xmlData[0] != '<')
                    return xmlData.Substring(1);
                return xmlData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string SerializeObject(Object pObject, Type t)
        {
            List<string> ns = new List<string>();
            ns.Add(",");
            return SerializeObject(pObject, t,"", ns);
        }
        public static object DeSerializeToObject(string xmlString, Type t, string defaultNamespace)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xmlString);
                XmlNodeReader reader = new XmlNodeReader(doc.DocumentElement);
                XmlSerializer ser = null; 
                if (defaultNamespace.Length == 0)
                    ser = new XmlSerializer(t);
                else
                    ser = new XmlSerializer(t, defaultNamespace);
                object obj = ser.Deserialize(reader);
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// ByteArray to string
        /// Author: Vairavel
        /// </summary>
        /// <param name="characters"></param>
        /// <returns></returns>
        private static String UTF8ByteArrayToString(Byte[] characters)
        {
            try
            {
                UTF8Encoding encoding = new UTF8Encoding();
                String constructedString = encoding.GetString(characters);
                return (constructedString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region StringHelpers
        public static string RemoveSpecialCharacters(string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9- ]+", "", RegexOptions.Compiled);
        }
        public static string RemoveAllSpecialCharacters(string str)
        {
            return Regex.Replace(str, "[^a-zA-Z0-9, ]+", "", RegexOptions.Compiled);
        }
        public static string ReplaceNoneASCIIWithSpace(string str)
        {
            StringBuilder rstr = new StringBuilder();
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] > 127)
                    rstr.Append(' ');
                else
                    rstr.Append(str[i]);
            }
            return rstr.ToString();
        }
         /*
         * ReplaceParamVals function allows a string text to have "%s" in the text and each %s will be replaced
         * by the correspoding vals.  Id debug compile, "[?]" will be returned in place of the value is
         * "vals" valeu is not provided.
         * */
        public static string ReplaceParamVals(string s, params Object[] vals)
        {
            StringBuilder newStr = new StringBuilder();
            string ns = s.Replace("%S", "%s");
            int i = 0, j = 0;
            while (i < ns.Length)
            {
                int pos = ns.IndexOf("%s", i);
                if (pos < 0)
                {
                    newStr.Append(s.Substring(i));
                    break;
                }
                newStr.Append(s.Substring(i, pos - i));
                if (j < vals.Length)
                    newStr.Append(vals[j++].ToString());
                else
                {
#if DEBUG
                    newStr.Append("[?]"); // replace with ? if in Debug build
#else
                    newStr.Append(" "); // replace with blank
#endif

                }
                i = pos + 2;
            }
            return newStr.ToString();
        }
        public static List<Object> CopyObjArray(Object[] fromObjs, Type toType)
        {
            if (fromObjs == null)
                return null;
            List<Object> newlist = new List<Object>();
            foreach (Object fromObj in fromObjs)
            {
                newlist.Add(CopyObjValues(fromObj, toType));
            }
            return newlist;
        }
        public static Object CopyObjValues(Object fromObj, Type toType)
        {
            FieldInfo[] toProperties = toType.GetFields();
            PropertyInfo[] fromProperties = fromObj.GetType().GetProperties();
            Dictionary<string, PropertyInfo> fromPropNames = new Dictionary<string, PropertyInfo>();
            foreach (PropertyInfo p in fromProperties)
                fromPropNames.Add(p.Name, p);

            Object toObject = Activator.CreateInstance(toType);
            foreach (FieldInfo prop in toProperties)
            {
                if (!fromPropNames.ContainsKey(prop.Name)) // YTsunehara to allow DC to have more properties than BO
                    continue;
                PropertyInfo fromProperty = fromPropNames[prop.Name];
                string typeName = fromProperty.PropertyType.Name.ToLower();
                if (typeName == "string" || typeName == "decimal" ||
                    typeName == "int" || typeName == "long" || typeName == "datetime")
                    prop.SetValue(toObject, fromProperty.GetValue(fromObj, null));
            }
            return toObject;
        }
        public static string HTTPPost(string url, string postData, Dictionary<string,string> requestParms)
        {
            string urlStr = url;
            if (requestParms != null && requestParms.Count > 0)
            {
                StringBuilder queryStr = new StringBuilder();
                foreach (string k in requestParms.Keys)
                {
                    if (queryStr.Length == 0)
                        queryStr.Append("?");
                    else
                        queryStr.Append("&");
                    queryStr.Append(k + "=" + requestParms[k]);
                }
                urlStr = url + queryStr.ToString();
            }
            return HTTPPost(urlStr, postData);
        }

        public static string HTTPPost(string url, string postData)
        {
            HttpWebRequest request = null;
            Uri uri = new Uri(url);
            request = (HttpWebRequest)WebRequest.Create(uri);
            request.Timeout = TIMEOUT_VALUE;
            request.KeepAlive = true;

            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] bytes = encoding.GetBytes(postData);
            request.ContentLength = bytes.Length;
            using (Stream writeStream = request.GetRequestStream())
            {
                writeStream.Write(bytes, 0, bytes.Length);
                writeStream.Close();
            }
            string result = string.Empty;
            HttpWebResponse res = (HttpWebResponse)request.GetResponse();
            using (StreamReader sr = new StreamReader(res.GetResponseStream()))
            {
                result = sr.ReadToEnd();
            }
            return result;
        }
        public static string FormatXML(string xmlData)
        {
            string returnValue = string.Empty;

            MemoryStream memoryStream = null;
            XmlTextWriter xmlTextWriter = null;
            XmlDocument xmlDocument = null;

            try
            {
                memoryStream = new MemoryStream();
                xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
                xmlDocument = new XmlDocument();

                // Load the XmlDocument with the XML.
                xmlDocument.LoadXml(xmlData);

                xmlTextWriter.Formatting = Formatting.Indented;

                // Write the XML into a formatting XmlTextWriter
                xmlDocument.WriteContentTo(xmlTextWriter);
                xmlTextWriter.Flush();
                memoryStream.Flush();

                // Have to rewind the MemoryStream in order to read
                // its contents.
                memoryStream.Position = 0;

                // Read MemoryStream contents into a StreamReader.
                StreamReader streamReader = new StreamReader(memoryStream);

                // Extract the text from the StreamReader.
                String FormattedXML = streamReader.ReadToEnd();

                returnValue = FormattedXML;
            }
            catch (XmlException)
            {
                return xmlData;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("Unexpected error formatting XML document: {0}", xmlData), ex);
            }
            finally
            {
                if (memoryStream != null)
                {
                    memoryStream.Close();
                }

                if (xmlTextWriter != null)
                {
                    xmlTextWriter.Close();
                }
            }

            return returnValue;
        }
        #endregion

        #region NumericHelpers
        /// <summary>
        /// Validates the amount is valid for US.
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public static bool IsValidUSAmount(string amount)
        {
            float num;
            return float.TryParse(amount, NumberStyles.Currency, CultureInfo.GetCultureInfo("en-US"), out num);
        }
        #endregion
        public static string[] GetStateCodes()
        {
            List<string> states = new List<string>();
            states.Add("AK");
            states.Add("AL");
            states.Add("AR");
            states.Add("AZ");
            states.Add("CA");
            states.Add("CO");
            states.Add("CT");
            states.Add("DC");
            states.Add("DE");
            states.Add("FL");
            states.Add("GA");
            states.Add("HI");
            states.Add("IA");
            states.Add("ID");
            states.Add("IL");
            states.Add("IN");
            states.Add("KS");
            states.Add("KY");
            states.Add("LA");
            states.Add("MA");
            states.Add("MD");
            states.Add("ME");
            states.Add("MI");
            states.Add("MN");
            states.Add("MO");
            states.Add("MS");
            states.Add("MT");
            states.Add("NC");
            states.Add("ND");
            states.Add("NE");
            states.Add("NH");
            states.Add("NJ");
            states.Add("NM");
            states.Add("NV");
            states.Add("NY");
            states.Add("OH");
            states.Add("OK");
            states.Add("OR");
            states.Add("PA");
            states.Add("PR");
            states.Add("RI");
            states.Add("SC");
            states.Add("SD");
            states.Add("TN");
            states.Add("TX");
            states.Add("UT");
            states.Add("VA");
            states.Add("VI");
            states.Add("VT");
            states.Add("WA");
            states.Add("WI");
            states.Add("WV");
            states.Add("WY");
            return states.ToArray();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgentNetInterfaceHelper.v2
{
    public class TimiosAPI
    {
        public string CompanyId;
        public string OrderNo;
        public string TitleNo;
        public string RequestType;

        public string ResponseId;
        public string OfficeId;
        public string LenderName;
        public string LenderClause;
        public string CoveredPartyType;
        public string DocName;

        public string ImageData;
        public string ImageLocation;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgentNetInterfaceHelper.v2
{
    public class DocField
    {
        public string FieldName { get; set; }
        public string FieldCode { get; set; }
        public string FieldValue { get; set; }
    }
    public class DocPhrase
    {
        public string PhaseName { get; set; }
        public string PhaseCode { get; set; }
        public string PhaseText { get; set; }
    }
    public class BOPSXMLDocument
    {
        public BOPSXMLDocument(string xmlDoc)
        {
            // create XmlDocument object from the xml string and parse it
        }
        public DocField[] Fields  { get; set; }
        public DocPhrase[] RequirementPhrases { get; set; }
        public DocPhrase[] ExceptionPhrases { get; set; }
    }
}

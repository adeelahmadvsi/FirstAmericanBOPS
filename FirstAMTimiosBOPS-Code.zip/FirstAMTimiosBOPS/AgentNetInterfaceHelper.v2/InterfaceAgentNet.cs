﻿using System;
#if MISMO32
using www.mismo.org.residential._2009.schemas.v32;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
namespace AgentNetInterfaceHelper.v1
#endif

{
    public class InterfaceAgentNet
    {
        private static bool s_bUseHTTPPOST = false;
        private static string s_HTTPPostUrl = "";
        private MESSAGE m_Request = null;
        private string m_LastRespXml = "";

        public string errMessage = "";
        public string m_xml1 = "";
        public string m_xml2 = "";

        static InterfaceAgentNet()
        {
#if MISMO32
            s_HTTPPostUrl = ANUtils.GetConfig("PostUrl");
#else
            s_HTTPPostUrl = ANUtils.GetConfig("PostUrl.v1");
#endif
            string usePost = ANUtils.GetConfig("UsePOST", "no").ToLower();
            if (usePost == "yes")
                s_bUseHTTPPOST = true;

        }
        public static bool IsPOSTSet
        {
            get { return s_bUseHTTPPOST; }
            set { s_bUseHTTPPOST = value; }
        }
        public static string POSTurl
        {
            get { return s_HTTPPostUrl; }
        }
        public string LastResponseXml
        {
            get { return m_LastRespXml; }
        }
        public InterfaceAgentNet(MESSAGE req)
        {
            m_Request = req;

            m_xml1 = "";
            m_xml2 = "";
        }

        public MESSAGE HTTPPost()
        {
            string requestXml = ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Request);

            m_xml1 = requestXml;
#if MISMO32
            //ANUtils.StringToFile("MISMO_32_Request.xml", requestXml);

            try
            {
                m_LastRespXml = ANUtils.HTTPPost(s_HTTPPostUrl, requestXml);
                m_xml2 = m_LastRespXml;
            }
            catch(Exception ex)
            {
                errMessage = ex.Message;
                return null;
            }
            //ANUtils.StringToFile("MISMO_32_Response.xml", m_LastRespXml);
#else
            ANUtils.StringToFile("MISMO_31_Request.xml", requestXml);
            m_LastRespXml = ANUtils.HTTPPost(s_HTTPPostUrl, requestXml);
            ANUtils.StringToFile("MISMO_31_Response.xml", m_LastRespXml);
#endif

            if (m_LastRespXml.StartsWith("FAILED:"))
                return null;

            return ConverterMISMOObjects.ConvertMISMO_XML_to_MESSAGE(m_LastRespXml);
        }
        public MESSAGE Invoke()
        {
            if (s_bUseHTTPPOST)
                return HTTPPost();
            MESSAGE resp = null;
            string reqXML = ANUtils.SerializeObject((Object)m_Request, typeof(MESSAGE), MISMONameSpace.MISMO_NAMESPACE, DEALRequest.GetMISMONameSpaces());
            reqXML = ANUtils.FormatXML(reqXML);
            ANUtils.StringToFile("last_request.xml", reqXML);
#if MISMO32
            AgentNetWSProcessV20Client service = new AgentNetWSProcessV20Client();
#else
            AgentNetWSClient service = new AgentNetWSClient();
#endif
           resp = service.ProcessRequest(m_Request);
            string respXML = ANUtils.SerializeObject((Object)resp, typeof(MESSAGE), MISMONameSpace.MISMO_NAMESPACE, DEALRequest.GetMISMONameSpaces());
            respXML = ANUtils.FormatXML(respXML);
            ANUtils.StringToFile("last_respponse.xml", respXML);
            return resp;

        }
    }
}

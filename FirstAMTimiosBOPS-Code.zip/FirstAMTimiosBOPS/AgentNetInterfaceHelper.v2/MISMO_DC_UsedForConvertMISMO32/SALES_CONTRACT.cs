using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SALES_CONTRACT", Namespace = DEAL.MISMO_NAMESPACE)]
public class SALES_CONTRACT
{
	//[XmlElement("SALES_CONCESSIONS")]
	//[DataMember]
	//public  SALES_CONCESSIONS { get; set; }
	[XmlElement("SALES_CONTRACT_DETAIL")]
	[DataMember]
	public SALES_CONTRACT_DETAIL SALES_CONTRACT_DETAIL { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

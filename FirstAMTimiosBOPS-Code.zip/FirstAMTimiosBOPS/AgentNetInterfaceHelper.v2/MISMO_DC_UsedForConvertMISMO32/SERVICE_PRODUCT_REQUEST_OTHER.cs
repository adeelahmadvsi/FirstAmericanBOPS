﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace MISMOTypes
{
    [DataContract(Name = "SERVICE_PRODUCT_REQUEST_OTHER", Namespace = DEAL.MISMO_NAMESPACE)]
    public class SERVICE_PRODUCT_REQUEST_OTHER 
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_REQUEST AGENTNET_PRODUCT_REQUEST { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REQUESTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REQUESTS AGENTNET_PRODUCT_PRICING_REQUESTS { get; set; }
    }
}

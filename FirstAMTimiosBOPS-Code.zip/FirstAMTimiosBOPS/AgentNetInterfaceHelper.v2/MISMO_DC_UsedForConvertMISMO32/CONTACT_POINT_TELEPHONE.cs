using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CONTACT_POINT_TELEPHONE", Namespace = DEAL.MISMO_NAMESPACE)]
public class CONTACT_POINT_TELEPHONE
{
	/* xsd:choise node found with the following: */
	[XmlElement("ContactPointFaxExtensionValue")]
	[DataMember]
	public string ContactPointFaxExtensionValue { get; set; }
	[XmlElement("ContactPointFaxValue")]
	[DataMember]
	public string ContactPointFaxValue { get; set; }
	[XmlElement("ContactPointTelephoneExtensionValue")]
	[DataMember]
	public string ContactPointTelephoneExtensionValue { get; set; }
	[XmlElement("ContactPointTelephoneValue")]
	[DataMember]
	public string ContactPointTelephoneValue { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

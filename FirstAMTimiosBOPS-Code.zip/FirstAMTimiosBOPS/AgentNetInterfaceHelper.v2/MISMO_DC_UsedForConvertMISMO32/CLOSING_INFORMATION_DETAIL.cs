using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "CLOSING_INFORMATION_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
    public class CLOSING_INFORMATION_DETAIL
    {
        [XmlElement("ClosingAgentOrderNumberIdentifier")]
        [DataMember]
        public string ClosingAgentOrderNumberIdentifier { get; set; }
        [XmlElement(ElementName = "ClosingDate", DataType = "date", Type = typeof(DateTime))]
        [DataMember]
        public DateTime ClosingDate { get; set; }
        //[XmlElement(ElementName = "ClosingDocumentReceivedDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime ClosingDocumentReceivedDate { get; set; }
        //[XmlElement(ElementName = "CurrentRateSetDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime CurrentRateSetDate { get; set; }
        //[XmlElement(ElementName = "DisbursementDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime DisbursementDate { get; set; }
        //[XmlElement("DocumentOrderClassificationType")]
        //[DataMember]
        //public string DocumentOrderClassificationType { get; set; }
        //[XmlElement(ElementName = "DocumentPreparationDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime DocumentPreparationDate { get; set; }
        //[XmlElement("EstimatedPrepaidDaysCount")]
        //[DataMember]
        //public int EstimatedPrepaidDaysCount { get; set; }
        //[XmlElement("EstimatedPrepaidDaysPaidByType")]
        //[DataMember]
        //public string EstimatedPrepaidDaysPaidByType { get; set; }
        //[XmlElement("EstimatedPrepaidDaysPaidByTypeOtherDescription")]
        //[DataMember]
        //public string EstimatedPrepaidDaysPaidByTypeOtherDescription { get; set; }
        //[XmlElement(ElementName = "FundByDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime FundByDate { get; set; }
        [XmlElement(ElementName = "LoanEstimatedClosingDate", DataType = "date", Type = typeof(DateTime))]
        [DataMember]
        public DateTime LoanEstimatedClosingDate { get; set; }
        //[XmlElement(ElementName = "LoanScheduledClosingDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime LoanScheduledClosingDate { get; set; }
        //[XmlElement(ElementName = "RescissionDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime RescissionDate { get; set; }
        //[XmlElement("EXTENSION")]
        //[DataMember]
        //public  EXTENSION { get; set; }
    } // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SALES_CONTRACTS", Namespace = DEAL.MISMO_NAMESPACE)]
public class SALES_CONTRACTS
{
	[XmlElement("SALES_CONTRACT")]
	[DataMember]
	public SALES_CONTRACT[] SALES_CONTRACT { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

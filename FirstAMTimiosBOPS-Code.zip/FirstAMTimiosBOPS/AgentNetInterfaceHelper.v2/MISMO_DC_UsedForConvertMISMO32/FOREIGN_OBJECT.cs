using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "FOREIGN_OBJECT", Namespace = DEAL.MISMO_NAMESPACE)]
public class FOREIGN_OBJECT 
{
	/* xsd:choise node found with the following: */
	[XmlElement("REFERENCE")]
    [DataMember]
    public REFERENCE[] REFERENCE { get; set; }
	/* xsd:choise node found with the following: */
	[XmlElement("ObjectURI")]
    [DataMember]
    public string ObjectURI { get; set; }
	[XmlElement("EmbeddedContentXML")]
    [DataMember]
    public string EmbeddedContentXML { get; set; }
	[XmlElement("CharacterEncodingSetType")]
    [DataMember]
    public string CharacterEncodingSetType { get; set; }
	[XmlElement("CharacterEncodingSetTypeOtherDescription")]
    [DataMember]
    public string CharacterEncodingSetTypeOtherDescription { get; set; }
	[XmlElement("MIMETypeIdentifier")]
    [DataMember]
    public string MIMETypeIdentifier { get; set; }
	[XmlElement("ObjectCreatedDatetime")]
    [DataMember]
    public DateTime ObjectCreatedDatetime { get; set; }
	[XmlElement("ObjectDescription")]
    [DataMember]
    public string ObjectDescription { get; set; }
	[XmlElement("ObjectEncodingType")]
    [DataMember]
    public string ObjectEncodingType { get; set; }
	[XmlElement("ObjectEncodingTypeOtherDescription")]
    [DataMember]
    public string ObjectEncodingTypeOtherDescription { get; set; }
	[XmlElement("OriginalCreatorDigestValue")]
    [DataMember]
    public string OriginalCreatorDigestValue { get; set; }
	[XmlElement("ObjectName")]
    [DataMember]
    public string ObjectName { get; set; }
    //[XmlElement("EXTENSION")]
    //[DataMember]
    //public EXTENSION EXTENSION { get; set; }
} // class
} // namespace

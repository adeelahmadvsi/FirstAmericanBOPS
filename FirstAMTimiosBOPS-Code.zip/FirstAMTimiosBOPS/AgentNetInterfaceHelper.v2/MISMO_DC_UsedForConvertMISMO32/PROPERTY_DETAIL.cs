using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "PROPERTY_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
    public class PROPERTY_DETAIL
    {
        [XmlElement("AttachmentType")]
        [DataMember]
        public string AttachmentType { get; set; }
        [XmlElement("BorrowerContinuesToOwnPropertyIndicator")]
        [DataMember]
        public bool BorrowerContinuesToOwnPropertyIndicator { get; set; }
        [XmlElement("CommunityLandTrustIndicator")]
        [DataMember]
        public bool CommunityLandTrustIndicator { get; set; }
        [XmlElement("CommunityReinvestmentActDelineatedCommunityIndicator")]
        [DataMember]
        public bool CommunityReinvestmentActDelineatedCommunityIndicator { get; set; }
        [XmlElement("ConstructionMethodType")]
        [DataMember]
        public string ConstructionMethodType { get; set; }
        [XmlElement("ConstructionMethodTypeOtherDescription")]
        [DataMember]
        public string ConstructionMethodTypeOtherDescription { get; set; }
        [XmlElement("ConstructionStatusType")]
        [DataMember]
        public string ConstructionStatusType { get; set; }
        [XmlElement("ConstructionStatusTypeOtherDescription")]
        [DataMember]
        public string ConstructionStatusTypeOtherDescription { get; set; }
        [XmlElement("DeedRestrictionIndicator")]
        [DataMember]
        public bool DeedRestrictionIndicator { get; set; }
        [XmlElement("EarthquakeInsuranceRequiredIndicator")]
        [DataMember]
        public bool EarthquakeInsuranceRequiredIndicator { get; set; }
        [XmlElement("FinancedUnitCount")]
        [DataMember]
        public int FinancedUnitCount { get; set; }
        [XmlElement("GrossLivingAreaSquareFeetNumber")]
        [DataMember]
        public long GrossLivingAreaSquareFeetNumber { get; set; }
        [XmlElement("GroupHomeIndicator")]
        [DataMember]
        public bool GroupHomeIndicator { get; set; }
        [XmlElement("InvestorREOPropertyIdentifier")]
        [DataMember]
        public string InvestorREOPropertyIdentifier { get; set; }
        [XmlElement("LandTrustType")]
        [DataMember]
        public string LandTrustType { get; set; }
        [XmlElement("LandTrustTypeOtherDescription")]
        [DataMember]
        public string LandTrustTypeOtherDescription { get; set; }
        [XmlElement("LandUseDescription")]
        [DataMember]
        public string LandUseDescription { get; set; }
        [XmlElement("LandUseType")]
        [DataMember]
        public string LandUseType { get; set; }
        [XmlElement("LandUseTypeOtherDescription")]
        [DataMember]
        public string LandUseTypeOtherDescription { get; set; }
        [XmlElement("LenderDesignatedDecliningMarketIdentifier")]
        [DataMember]
        public string LenderDesignatedDecliningMarketIdentifier { get; set; }
        [XmlElement("NativeAmericanLandsType")]
        [DataMember]
        public string NativeAmericanLandsType { get; set; }
        [XmlElement("NativeAmericanLandsTypeOtherDescription")]
        [DataMember]
        public string NativeAmericanLandsTypeOtherDescription { get; set; }
        [XmlElement("PriorSaleInLastTwelveMonthsIndicator")]
        [DataMember]
        public bool PriorSaleInLastTwelveMonthsIndicator { get; set; }
        [XmlElement(ElementName = "PropertyAcquiredDate", DataType = "date", Type = typeof(DateTime))]
        [DataMember]
        public DateTime PropertyAcquiredDate { get; set; }
        //[XmlElement("PropertyAcquiredYear")]
        //[DataMember]
        //public  PropertyAcquiredYear { get; set; }
        [XmlElement("PropertyAcreageNumber")]
        [DataMember]
        public long PropertyAcreageNumber { get; set; }
        [XmlElement("PropertyConditionDescription")]
        [DataMember]
        public string PropertyConditionDescription { get; set; }
        [XmlElement("PropertyCurrentOccupancyType")]
        [DataMember]
        public string PropertyCurrentOccupancyType { get; set; }
        [XmlElement("PropertyCurrentOccupantName")]
        [DataMember]
        public string PropertyCurrentOccupantName { get; set; }
        [XmlElement("PropertyEarthquakeInsuranceIndicator")]
        [DataMember]
        public bool PropertyEarthquakeInsuranceIndicator { get; set; }
        [XmlElement("PropertyEstateType")]
        [DataMember]
        public string PropertyEstateType { get; set; }
        [XmlElement("PropertyEstateTypeOtherDescription")]
        [DataMember]
        public string PropertyEstateTypeOtherDescription { get; set; }
        [XmlElement("PropertyEstimatedValueAmount")]
        [DataMember]
        public decimal PropertyEstimatedValueAmount { get; set; }
        [XmlElement("PropertyExistingLienAmount")]
        [DataMember]
        public decimal PropertyExistingLienAmount { get; set; }
        [XmlElement("PropertyFloodInsuranceIndicator")]
        [DataMember]
        public bool PropertyFloodInsuranceIndicator { get; set; }
        [XmlElement(ElementName = "PropertyGroundLeaseExpirationDate", DataType = "date", Type = typeof(DateTime))]
        [DataMember]
        public DateTime PropertyGroundLeaseExpirationDate { get; set; }
        [XmlElement("PropertyGroundLeasePerpetualIndicator")]
        [DataMember]
        public bool PropertyGroundLeasePerpetualIndicator { get; set; }
        [XmlElement("PropertyInclusionaryZoningIndicator")]
        [DataMember]
        public bool PropertyInclusionaryZoningIndicator { get; set; }
        [XmlElement("PropertyOccupancyStatusType")]
        [DataMember]
        public string PropertyOccupancyStatusType { get; set; }
        [XmlElement("PropertyOriginalCostAmount")]
        [DataMember]
        public decimal PropertyOriginalCostAmount { get; set; }
        [XmlElement("PropertyPreviouslyOccupiedIndicator")]
        [DataMember]
        public bool PropertyPreviouslyOccupiedIndicator { get; set; }
        //[XmlElement("PropertyStructureBuiltYear")]
        //[DataMember]
        //public  PropertyStructureBuiltYear { get; set; }
        [XmlElement("PropertyStructureBuiltYearEstimatedIndicator")]
        [DataMember]
        public bool PropertyStructureBuiltYearEstimatedIndicator { get; set; }
        [XmlElement("PropertyStructureHabitableYearRoundIndicator")]
        [DataMember]
        public bool PropertyStructureHabitableYearRoundIndicator { get; set; }
        [XmlElement("PropertyUsageType")]
        [DataMember]
        public string PropertyUsageType { get; set; }
        [XmlElement("PropertyUsageTypeOtherDescription")]
        [DataMember]
        public string PropertyUsageTypeOtherDescription { get; set; }
        [XmlElement("PUDIndicator")]
        [DataMember]
        public bool PUDIndicator { get; set; }
        [XmlElement("UniqueDwellingType")]
        [DataMember]
        public string UniqueDwellingType { get; set; }
        [XmlElement("UniqueDwellingTypeOtherDescription")]
        [DataMember]
        public string UniqueDwellingTypeOtherDescription { get; set; }
        [XmlElement("WindstormInsuranceRequiredIndicator")]
        [DataMember]
        public bool WindstormInsuranceRequiredIndicator { get; set; }
        //[XmlElement("EXTENSION")]
        //[DataMember]
        //public  EXTENSION { get; set; }
    } // class
} // namespace

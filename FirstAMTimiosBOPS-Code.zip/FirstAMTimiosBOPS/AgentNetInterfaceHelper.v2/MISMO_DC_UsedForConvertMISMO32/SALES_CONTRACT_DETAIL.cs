using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "SALES_CONTRACT_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
    public class SALES_CONTRACT_DETAIL
    {
        //[XmlElement("ArmsLengthIndicator")]
        //[DataMember]
        //public bool ArmsLengthIndicator { get; set; }
        //[XmlElement("NetSaleProceedsAmount")]
        //[DataMember]
        //public decimal NetSaleProceedsAmount { get; set; }
        //[XmlElement("PersonalPropertyIncludedIndicator")]
        //[DataMember]
        //public bool PersonalPropertyIncludedIndicator { get; set; }
        //[XmlElement(ElementName = "PreForeclosureSaleClosingDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime PreForeclosureSaleClosingDate { get; set; }
        //[XmlElement("PreForeclosureSaleIndicator")]
        //[DataMember]
        //public bool PreForeclosureSaleIndicator { get; set; }
        //[XmlElement("ProposedFinancingDescription")]
        //[DataMember]
        //public string ProposedFinancingDescription { get; set; }
        //[XmlElement("SalesConcessionDescription")]
        //[DataMember]
        //public string SalesConcessionDescription { get; set; }
        //[XmlElement("SalesConcessionIndicator")]
        //[DataMember]
        //public bool SalesConcessionIndicator { get; set; }
        //[XmlElement("SalesConditionsOfSaleDescription")]
        //[DataMember]
        //public string SalesConditionsOfSaleDescription { get; set; }
        [XmlElement("SalesContractAmount")]
        [DataMember]
        public decimal SalesContractAmount { get; set; }
        //[XmlElement("SalesContractAnalysisDescription")]
        //[DataMember]
        //public string SalesContractAnalysisDescription { get; set; }
        //[XmlElement(ElementName = "SalesContractDate", DataType = "date", Type = typeof(DateTime))]
        //[DataMember]
        //public DateTime SalesContractDate { get; set; }
        //[XmlElement("SalesContractInvoiceRevewCommentDescription")]
        //[DataMember]
        //public string SalesContractInvoiceRevewCommentDescription { get; set; }
        //[XmlElement("SalesContractInvoiceReviewedIndicator")]
        //[DataMember]
        //public bool SalesContractInvoiceReviewedIndicator { get; set; }
        //[XmlElement("SalesContractRetailerName")]
        //[DataMember]
        //public string SalesContractRetailerName { get; set; }
        //[XmlElement("SalesContractReviewCommentDescription")]
        //[DataMember]
        //public string SalesContractReviewCommentDescription { get; set; }
        //[XmlElement("SalesContractReviewDescription")]
        //[DataMember]
        //public string SalesContractReviewDescription { get; set; }
        //[XmlElement("SalesContractReviewedIndicator")]
        //[DataMember]
        //public bool SalesContractReviewedIndicator { get; set; }
        //[XmlElement("SalesContractTermsConsistentWithMarketIndicator")]
        //[DataMember]
        //public bool SalesContractTermsConsistentWithMarketIndicator { get; set; }
        //[XmlElement("SaleType")]
        //[DataMember]
        //public string SaleType { get; set; }
        //[XmlElement("SaleTypeOtherDescription")]
        //[DataMember]
        //public string SaleTypeOtherDescription { get; set; }
        //[XmlElement("SellerIsOwnerIndicator")]
        //[DataMember]
        //public bool SellerIsOwnerIndicator { get; set; }
        //[XmlElement("TotalSalesConcessionAmount")]
        //[DataMember]
        //public decimal TotalSalesConcessionAmount { get; set; }
        //[XmlElement("EXTENSION")]
        //[DataMember]
        //public  EXTENSION { get; set; }
    } // class
} // namespace

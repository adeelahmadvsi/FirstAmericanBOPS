using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LOAN", Namespace = DEAL.MISMO_NAMESPACE)]
public class LOAN
{
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "label")]
    [DataMemberAttribute]
    public string xlinklabel { get; set; }
    //[XmlElement("ACH")]
	//[DataMember]
	//public  ACH { get; set; }
	//[XmlElement("ADJUSTMENT")]
	//[DataMember]
	//public  ADJUSTMENT { get; set; }
	//[XmlElement("AFFORDABLE_LENDING")]
	//[DataMember]
	//public  AFFORDABLE_LENDING { get; set; }
	//[XmlElement("AMORTIZATION")]
	//[DataMember]
	//public  AMORTIZATION { get; set; }
	//[XmlElement("ASSUMABILITY")]
	//[DataMember]
	//public  ASSUMABILITY { get; set; }
	//[XmlElement("BILLING_ADDRESS")]
	//[DataMember]
	//public  BILLING_ADDRESS { get; set; }
	//[XmlElement("BUYDOWN")]
	//[DataMember]
	//public  BUYDOWN { get; set; }
	[XmlElement("CLOSING_INFORMATION")]
	[DataMember]
	public CLOSING_INFORMATION CLOSING_INFORMATION { get; set; }
	//[XmlElement("CONSTRUCTION")]
	//[DataMember]
	//public  CONSTRUCTION { get; set; }
	//[XmlElement("CREDIT_ENHANCEMENTS")]
	//[DataMember]
	//public  CREDIT_ENHANCEMENTS { get; set; }
	//[XmlElement("DOCUMENT_SPECIFIC_DATA_SETS")]
	//[DataMember]
	//public  DOCUMENT_SPECIFIC_DATA_SETS { get; set; }
	//[XmlElement("DOCUMENTATIONS")]
	//[DataMember]
	//public  DOCUMENTATIONS { get; set; }
	//[XmlElement("DOWN_PAYMENTS")]
	//[DataMember]
	//public  DOWN_PAYMENTS { get; set; }
	//[XmlElement("DRAW")]
	//[DataMember]
	//public  DRAW { get; set; }
	//[XmlElement("ESCROW")]
	//[DataMember]
	//public  ESCROW { get; set; }
	//[XmlElement("FEE_INFORMATION")]
	//[DataMember]
	//public  FEE_INFORMATION { get; set; }
	//[XmlElement("GOVERNMENT_LOAN")]
	//[DataMember]
	//public  GOVERNMENT_LOAN { get; set; }
	//[XmlElement("HELOC")]
	//[DataMember]
	//public  HELOC { get; set; }
	//[XmlElement("HMDA_LOAN")]
	//[DataMember]
	//public  HMDA_LOAN { get; set; }
	//[XmlElement("INTEREST_CALCULATION")]
	//[DataMember]
	//public  INTEREST_CALCULATION { get; set; }
	//[XmlElement("INTEREST_ONLY")]
	//[DataMember]
	//public  INTEREST_ONLY { get; set; }
	//[XmlElement("INVESTOR_FEATURES")]
	//[DataMember]
	//public  INVESTOR_FEATURES { get; set; }
	//[XmlElement("INVESTOR_LOAN_INFORMATION")]
	//[DataMember]
	//public  INVESTOR_LOAN_INFORMATION { get; set; }
	//[XmlElement("LATE_CHARGE")]
	//[DataMember]
	//public  LATE_CHARGE { get; set; }
	//[XmlElement("LOAN_COMMENTS")]
	//[DataMember]
	//public  LOAN_COMMENTS { get; set; }
	//[XmlElement("LOAN_DETAIL")]
	//[DataMember]
	//public  LOAN_DETAIL { get; set; }
	[XmlElement("LOAN_IDENTIFIERS")]
	[DataMember]
	public LOAN_IDENTIFIERS LOAN_IDENTIFIERS { get; set; }
	//[XmlElement("LOAN_LEVEL_CREDIT")]
	//[DataMember]
	//public  LOAN_LEVEL_CREDIT { get; set; }
	//[XmlElement("LOAN_PRODUCT")]
	//[DataMember]
	//public  LOAN_PRODUCT { get; set; }
	//[XmlElement("LOAN_PROGRAMS")]
	//[DataMember]
	//public  LOAN_PROGRAMS { get; set; }
	//[XmlElement("LOAN_STATE")]
	//[DataMember]
	//public  LOAN_STATE { get; set; }
	//[XmlElement("LOAN_STATUSES")]
	//[DataMember]
	//public  LOAN_STATUSES { get; set; }
	//[XmlElement("LTV")]
	//[DataMember]
	//public  LTV { get; set; }
	//[XmlElement("MATURITY")]
	//[DataMember]
	//public  MATURITY { get; set; }
	//[XmlElement("MERS_REGISTRATIONS")]
	//[DataMember]
	//public  MERS_REGISTRATIONS { get; set; }
	//[XmlElement("MI_DATA")]
	//[DataMember]
	//public  MI_DATA { get; set; }
	//[XmlElement("MODIFICATIONS")]
	//[DataMember]
	//public  MODIFICATIONS { get; set; }
	//[XmlElement("MORTGAGE_SCORES")]
	//[DataMember]
	//public  MORTGAGE_SCORES { get; set; }
	//[XmlElement("NEGATIVE_AMORTIZATION")]
	//[DataMember]
	//public  NEGATIVE_AMORTIZATION { get; set; }
	//[XmlElement("OPTIONAL_PRODUCTS")]
	//[DataMember]
	//public  OPTIONAL_PRODUCTS { get; set; }
	//[XmlElement("ORIGINATION_FUNDS")]
	//[DataMember]
	//public  ORIGINATION_FUNDS { get; set; }
	//[XmlElement("ORIGINATION_SYSTEMS")]
	//[DataMember]
	//public  ORIGINATION_SYSTEMS { get; set; }
	//[XmlElement("PAYMENT")]
	//[DataMember]
	//public  PAYMENT { get; set; }
	//[XmlElement("PREPAYMENT_PENALTY")]
	//[DataMember]
	//public  PREPAYMENT_PENALTY { get; set; }
	//[XmlElement("PROPOSED_HOUSING_EXPENSES")]
	//[DataMember]
	//public  PROPOSED_HOUSING_EXPENSES { get; set; }
	//[XmlElement("PURCHASE_CREDITS")]
	//[DataMember]
	//public  PURCHASE_CREDITS { get; set; }
	//[XmlElement("QUALIFICATION")]
	//[DataMember]
	//public  QUALIFICATION { get; set; }
	//[XmlElement("REFINANCE")]
	//[DataMember]
	//public  REFINANCE { get; set; }
	//[XmlElement("REHABILITATION")]
	//[DataMember]
	//public  REHABILITATION { get; set; }
	//[XmlElement("SERVICING")]
	//[DataMember]
	//public  SERVICING { get; set; }
	[XmlElement("TERMS_OF_LOAN")]
	[DataMember]
    public TERMS_OF_LOAN TERMS_OF_LOAN { get; set; }
	//[XmlElement("UNDERWRITING")]
	//[DataMember]
	//public  UNDERWRITING { get; set; }
	//[XmlElement("WORKOUTS")]
	//[DataMember]
	//public  WORKOUTS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

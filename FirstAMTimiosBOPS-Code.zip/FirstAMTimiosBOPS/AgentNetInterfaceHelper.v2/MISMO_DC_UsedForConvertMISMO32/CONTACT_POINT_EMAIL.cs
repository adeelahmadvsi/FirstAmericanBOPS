using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CONTACT_POINT_EMAIL", Namespace = DEAL.MISMO_NAMESPACE)]
public class CONTACT_POINT_EMAIL
{
	[XmlElement("ContactPointEmailValue")]
	[DataMember]
	public string ContactPointEmailValue { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

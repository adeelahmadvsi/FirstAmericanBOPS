using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "MESSAGE", Namespace = DEAL.MISMO_NAMESPACE)]
public class MESSAGE
{
	[XmlElement("ABOUT_VERSIONS")]
	[DataMember]
	public ABOUT_VERSIONS ABOUT_VERSIONS { get; set; }
	[XmlElement("DEAL_SETS")]
	[DataMember]
	public DEAL_SETS DEAL_SETS { get; set; }
	//[XmlElement("DOCUMENT_SETS")]
	//[DataMember]
	//public  DOCUMENT_SETS { get; set; }
	//[XmlElement("RELATIONSHIPS")]
	//[DataMember]
	//public  RELATIONSHIPS { get; set; }
	//[XmlElement("SYSTEM_SIGNATURES")]
	//[DataMember]
	//public  SYSTEM_SIGNATURES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

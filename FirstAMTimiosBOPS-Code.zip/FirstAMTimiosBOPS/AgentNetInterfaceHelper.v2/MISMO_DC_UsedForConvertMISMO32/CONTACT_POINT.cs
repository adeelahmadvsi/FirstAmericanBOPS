using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "CONTACT_POINT", Namespace = DEAL.MISMO_NAMESPACE)]
public class CONTACT_POINT
{
	/* xsd:choise node found with the following: */
	[XmlElement("CONTACT_POINT_EMAIL")]
	[DataMember]
	public CONTACT_POINT_EMAIL CONTACT_POINT_EMAIL { get; set; }
	//	[XmlElement("CONTACT_POINT_SOCIAL_MEDIA")]
	//[DataMember]
	//	public  CONTACT_POINT_CONTACT_POINT_SOCIAL_MEDIA { get; set; }
	[XmlElement("CONTACT_POINT_TELEPHONE")]
	[DataMember]
	public CONTACT_POINT_TELEPHONE CONTACT_POINT_TELEPHONE { get; set; }
	//	[XmlElement("OTHER_CONTACT_POINT")]
	//[DataMember]
	//	public  CONTACT_POINT_OTHER_CONTACT_POINT { get; set; }
	//[XmlElement("CONTACT_POINT_DETAIL")]
	//[DataMember]
	//public  CONTACT_POINT_DETAIL { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

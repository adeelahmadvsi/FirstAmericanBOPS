using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LEGAL_DESCRIPTION", Namespace = DEAL.MISMO_NAMESPACE)]
public class LEGAL_DESCRIPTION
{
	[XmlElement("PARCEL_IDENTIFICATIONS")]
	[DataMember]
	public PARCEL_IDENTIFICATIONS PARCEL_IDENTIFICATIONS { get; set; }
	[XmlElement("PARSED_LEGAL_DESCRIPTION")]
	[DataMember]
	public PARSED_LEGAL_DESCRIPTION PARSED_LEGAL_DESCRIPTION { get; set; }
	[XmlElement("UNPARSED_LEGAL_DESCRIPTIONS")]
	[DataMember]
    public UNPARSED_LEGAL_DESCRIPTIONS UNPARSED_LEGAL_DESCRIPTIONS { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "GENERAL_IDENTIFIER", Namespace = DEAL.MISMO_NAMESPACE)]
public class GENERAL_IDENTIFIER
{
	[XmlElement("CongressionalDistrictIdentifier")]
	[DataMember]
	public string CongressionalDistrictIdentifier { get; set; }
	[XmlElement("CoreBasedStatisticalAreaCode")]
	[DataMember]
	public string CoreBasedStatisticalAreaCode { get; set; }
	[XmlElement("CoreBasedStatisticalAreaDivisionCode")]
	[DataMember]
	public string CoreBasedStatisticalAreaDivisionCode { get; set; }
	[XmlElement("JudicialDistrictName")]
	[DataMember]
	public string JudicialDistrictName { get; set; }
	[XmlElement("JudicialDivisionName")]
	[DataMember]
	public string JudicialDivisionName { get; set; }
	[XmlElement("MapReferenceIdentifier")]
	[DataMember]
	public string MapReferenceIdentifier { get; set; }
	[XmlElement("MapReferenceSecondIdentifier")]
	[DataMember]
	public string MapReferenceSecondIdentifier { get; set; }
	[XmlElement("MSAIdentifier")]
	[DataMember]
	public string MSAIdentifier { get; set; }
	[XmlElement("MunicipalityName")]
	[DataMember]
	public string MunicipalityName { get; set; }
	[XmlElement("RecordingJurisdictionName")]
	[DataMember]
	public string RecordingJurisdictionName { get; set; }
	[XmlElement("RecordingJurisdictionType")]
	[DataMember]
	public string RecordingJurisdictionType { get; set; }
	[XmlElement("RecordingJurisdictionTypeOtherDescription")]
	[DataMember]
	public string RecordingJurisdictionTypeOtherDescription { get; set; }
	[XmlElement("SchoolDistrictName")]
	[DataMember]
	public string SchoolDistrictName { get; set; }
	[XmlElement("UnincorporatedAreaName")]
	[DataMember]
	public string UnincorporatedAreaName { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

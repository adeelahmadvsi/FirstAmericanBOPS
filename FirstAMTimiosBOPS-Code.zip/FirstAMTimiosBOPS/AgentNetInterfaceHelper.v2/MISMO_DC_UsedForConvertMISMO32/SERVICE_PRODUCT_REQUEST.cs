using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE_PRODUCT_REQUEST", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE_PRODUCT_REQUEST
{
	[XmlElement("SERVICE_PRODUCT_DETAIL")]
	[DataMember]
	public SERVICE_PRODUCT_DETAIL SERVICE_PRODUCT_DETAIL { get; set; }
	[XmlElement("SERVICE_PRODUCT_NAMES")]
	[DataMember]
	public SERVICE_PRODUCT_NAMES SERVICE_PRODUCT_NAMES { get; set; }
    [XmlElement("EXTENSION")]
    [DataMember]
    public SERVICE_PRODUCT_REQUEST_EXTENSION EXTENSION { get; set; }
} // class
} // namespace

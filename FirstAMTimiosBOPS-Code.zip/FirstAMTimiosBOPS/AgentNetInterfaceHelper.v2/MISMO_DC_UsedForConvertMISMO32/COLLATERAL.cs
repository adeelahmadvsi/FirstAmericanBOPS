using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "COLLATERAL", Namespace = DEAL.MISMO_NAMESPACE)]
public class COLLATERAL
{
	/* xsd:choise node found with the following: */
	//	[XmlElement("PLEDGED_ASSET")]
	//[DataMember]
	//	public  COLLATERAL_PLEDGED_ASSET { get; set; }
	[XmlElement("SUBJECT_PROPERTY")]
	[DataMember]
	public PROPERTY SUBJECT_PROPERTY { get; set; }
	//[XmlElement("COLLATERAL_DETAIL")]
	//[DataMember]
	//public  COLLATERAL_DETAIL { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

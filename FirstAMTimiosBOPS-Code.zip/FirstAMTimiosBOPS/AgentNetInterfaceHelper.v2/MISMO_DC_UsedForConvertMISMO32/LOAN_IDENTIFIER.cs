using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LOAN_IDENTIFIER", Namespace = DEAL.MISMO_NAMESPACE)]
public class LOAN_IDENTIFIER
{
	[XmlElement("LoanIdentifier")]
	[DataMember]
	public string LoanIdentifier { get; set; }
	[XmlElement("LoanIdentifierType")]
	[DataMember]
	public string LoanIdentifierType { get; set; }
	[XmlElement("LoanIdentifierTypeOtherDescription")]
	[DataMember]
	public string LoanIdentifierTypeOtherDescription { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

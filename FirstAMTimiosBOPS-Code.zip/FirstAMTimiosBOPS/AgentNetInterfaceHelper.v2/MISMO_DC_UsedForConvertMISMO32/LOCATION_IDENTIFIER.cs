using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LOCATION_IDENTIFIER", Namespace = DEAL.MISMO_NAMESPACE)]
public class LOCATION_IDENTIFIER
{
	[XmlElement("CENSUS_INFORMATION")]
	[DataMember]
	public CENSUS_INFORMATION CENSUS_INFORMATION { get; set; }
	//[XmlElement("FIPS_INFORMATION")]
	//[DataMember]
	//public  FIPS_INFORMATION { get; set; }
	[XmlElement("GENERAL_IDENTIFIER")]
	[DataMember]
	public GENERAL_IDENTIFIER GENERAL_IDENTIFIER { get; set; }
	//[XmlElement("GEOSPATIAL_INFORMATION")]
	//[DataMember]
	//public  GEOSPATIAL_INFORMATION { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

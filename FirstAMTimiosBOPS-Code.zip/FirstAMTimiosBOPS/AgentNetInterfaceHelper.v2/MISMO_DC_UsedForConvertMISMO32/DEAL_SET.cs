using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "DEAL_SET", Namespace = DEAL.MISMO_NAMESPACE)]
public class DEAL_SET
{
	//[XmlElement("ACH")]
	//[DataMember]
	//public  ACH { get; set; }
	//[XmlElement("CASH_REMITTANCE_SUMMARY_NOTIFICATION")]
	//[DataMember]
	//public  CASH_REMITTANCE_SUMMARY_NOTIFICATION { get; set; }
	[XmlElement("DEALS")]
	[DataMember]
	public DEALS DEALS { get; set; }
	//[XmlElement("INVESTOR_FEATURES")]
	//[DataMember]
	//public  INVESTOR_FEATURES { get; set; }
	[XmlElement("PARTIES")]
	[DataMember]
	public PARTIES PARTIES { get; set; }
	//[XmlElement("POOL")]
	//[DataMember]
	//public  POOL { get; set; }
	//[XmlElement("RELATIONSHIPS")]
	//[DataMember]
	//public  RELATIONSHIPS { get; set; }
	//[XmlElement("SERVICER_REPORTING")]
	//[DataMember]
	//public  SERVICER_REPORTING { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

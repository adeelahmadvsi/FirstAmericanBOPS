using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "ROLE", Namespace = DEAL.MISMO_NAMESPACE)]
    public class ROLE
    {
        /* xsd:choise node found with the following: */
        //[XmlElement("APPRAISER")]
        //[DataMember]
        //	public  ROLE_APPRAISER { get; set; }
        //[XmlElement("APPRAISER_SUPERVISOR")]
        //[DataMember]
        //	public  ROLE_APPRAISER_SUPERVISOR { get; set; }
        //[XmlElement("ATTORNEY")]
        //[DataMember]
        //	public  ROLE_ATTORNEY { get; set; }
        //[XmlElement("ATTORNEY_IN_FACT")]
        //[DataMember]
        //	public  ROLE_ATTORNEY_IN_FACT { get; set; }
        [XmlElement("BORROWER")]
        [DataMember]
        public BORROWER BORROWER { get; set; }
        //[XmlElement("CLOSING_AGENT")]
        //[DataMember]
        //	public  ROLE_CLOSING_AGENT { get; set; }
        //[XmlElement("FULFILLMENT_PARTY")]
        //[DataMember]
        //	public  ROLE_FULFILLMENT_PARTY { get; set; }
        [XmlElement("LENDER")]
        [DataMember]
        public LENDER LENDER { get; set; }
        //[XmlElement("LIEN_HOLDER")]
        //[DataMember]
        //	public  ROLE_LIEN_HOLDER { get; set; }
        //[XmlElement("LOAN_ORIGINATOR")]
        //[DataMember]
        //	public  ROLE_LOAN_ORIGINATOR { get; set; }
        //[XmlElement("LOSS_PAYEE")]
        //[DataMember]
        //	public  ROLE_LOSS_PAYEE { get; set; }
        //[XmlElement("NOTARY")]
        //[DataMember]
        //	public  ROLE_NOTARY { get; set; }
        //[XmlElement("PAYEE")]
        //[DataMember]
        //	public  ROLE_PAYEE { get; set; }
        //[XmlElement("PROPERTY_OWNER")]
        //[DataMember]
        //	public  ROLE_PROPERTY_OWNER { get; set; }
        [XmlElement("PROPERTY_SELLER")]
        [DataMember]
        public PROPERTY_SELLER PROPERTY_SELLER { get; set; }
        //[XmlElement("REAL_ESTATE_AGENT")]
        //[DataMember]
        //	public  ROLE_REAL_ESTATE_AGENT { get; set; }
        //[XmlElement("REGULATORY_AGENCY")]
        //[DataMember]
        //	public  ROLE_REGULATORY_AGENCY { get; set; }
        [XmlElement("REQUESTING_PARTY")]
        [DataMember]
        public REQUESTING_PARTY REQUESTING_PARTY { get; set; }
        [XmlElement("RESPONDING_PARTY")]
        [DataMember]
        public RESPONDING_PARTY RESPONDING_PARTY { get; set; }
        //[XmlElement("RETURN_TO")]
        //[DataMember]
        //	public  ROLE_RETURN_TO { get; set; }
        //[XmlElement("REVIEW_APPRAISER")]
        //[DataMember]
        //	public  ROLE_REVIEW_APPRAISER { get; set; }
        //[XmlElement("SERVICER")]
        //[DataMember]
        //	public  ROLE_SERVICER { get; set; }
        //[XmlElement("SERVICING_TRANSFEROR")]
        //[DataMember]
        //	public  ROLE_SERVICING_TRANSFEROR { get; set; }
        [XmlElement("SUBMITTING_PARTY")]
        [DataMember]
        public SUBMITTING_PARTY SUBMITTING_PARTY { get; set; }
        //[XmlElement("TRUST")]
        //[DataMember]
        //	public  ROLE_TRUST { get; set; }
        //[XmlElement("TRUSTEE")]
        //[DataMember]
        //	public  ROLE_TRUSTEE { get; set; }
        //[XmlElement("LICENSES")]
        //[DataMember]
        //public  LICENSES { get; set; }
        [XmlElement("PARTY_ROLE_IDENTIFIERS")]
        [DataMember]
        public PARTY_ROLE_IDENTIFIERS PARTY_ROLE_IDENTIFIERS { get; set; }
        [XmlElement("ROLE_DETAIL")]
        [DataMember]
        public ROLE_DETAIL ROLE_DETAIL { get; set; }
        //[XmlElement("EXTENSION")]
        //[DataMember]
        //public  EXTENSION { get; set; }
    } // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "VIEW", Namespace = DEAL.MISMO_NAMESPACE)]
    public class VIEW
    {
        /* xsd:choise node found with the following: */
        [XmlElement("VIEW_FILES")]
        [DataMember]
        public VIEW_FILES VIEW_FILES { get; set; }
        //[XmlElement("VIEW_PAGES")]
        //[DataMember]
        //	public  VIEW_VIEW_PAGES { get; set; }
        //[XmlElement("VIEW_FIELDS")]
        //[DataMember]
        //public  VIEW_FIELDS { get; set; }
        //[XmlElement("EXTENSION")]
        //[DataMember]
        //public  EXTENSION { get; set; }
    } // class
} // namespace

using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SUBMITTING_PARTY", Namespace = DEAL.MISMO_NAMESPACE)]
public class SUBMITTING_PARTY
{
	[XmlElement("SubmittingPartySequenceNumber")]
	[DataMember]
	public long SubmittingPartySequenceNumber { get; set; }
	[XmlElement("SubmittingPartyTransactionIdentifier")]
	[DataMember]
	public string SubmittingPartyTransactionIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

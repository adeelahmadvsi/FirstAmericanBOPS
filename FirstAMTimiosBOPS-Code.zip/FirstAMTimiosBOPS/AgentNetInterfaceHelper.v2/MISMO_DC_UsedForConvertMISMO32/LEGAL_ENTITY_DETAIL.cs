using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LEGAL_ENTITY_DETAIL", Namespace = DEAL.MISMO_NAMESPACE)]
public class LEGAL_ENTITY_DETAIL
{
	//[XmlElement("EntityHomePageURL")]
	//[DataMember]
	//public  EntityHomePageURL { get; set; }
	[XmlElement("FullName")]
	[DataMember]
	public string FullName { get; set; }
	[XmlElement("LegalEntityLicensingTypeDescription")]
	[DataMember]
	public string LegalEntityLicensingTypeDescription { get; set; }
	[XmlElement("LegalEntityOrganizedUnderTheLawsOfJurisdictionName")]
	[DataMember]
	public string LegalEntityOrganizedUnderTheLawsOfJurisdictionName { get; set; }
	[XmlElement("LegalEntitySuccessorClauseTextDescription")]
	[DataMember]
	public string LegalEntitySuccessorClauseTextDescription { get; set; }
	[XmlElement("LegalEntityType")]
	[DataMember]
	public string LegalEntityType { get; set; }
	[XmlElement("LegalEntityTypeOtherDescription")]
	[DataMember]
	public string LegalEntityTypeOtherDescription { get; set; }
	[XmlElement("MERSOrganizationIdentifier")]
	[DataMember]
	public string MERSOrganizationIdentifier { get; set; }
	//[XmlElement("RegisteredDomainNameURI")]
	//[DataMember]
	//public  RegisteredDomainNameURI { get; set; }
	[XmlElement("RequiredSignatoryCount")]
	[DataMember]
	public int RequiredSignatoryCount { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

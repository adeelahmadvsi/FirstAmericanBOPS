using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "DEAL_SETS", Namespace = DEAL.MISMO_NAMESPACE)]
public class DEAL_SETS
{
	[XmlElement("DEAL_SET")]
	[DataMember]
	public DEAL_SET[] DEAL_SET { get; set; }
	//[XmlElement("DEAL_SET_SERVICES")]
	//[DataMember]
	//public  DEAL_SET_SERVICES { get; set; }
	[XmlElement("PARTIES")]
	[DataMember]
	public PARTIES PARTIES { get; set; }
	//[XmlElement("VERIFICATION_DATA")]
	//[DataMember]
	//public  VERIFICATION_DATA { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

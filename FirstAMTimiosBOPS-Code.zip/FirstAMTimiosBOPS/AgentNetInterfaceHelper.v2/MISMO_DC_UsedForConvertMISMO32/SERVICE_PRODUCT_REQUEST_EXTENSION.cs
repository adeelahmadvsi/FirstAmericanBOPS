﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace MISMOTypes
{
    [DataContract(Name = "SERVICE_PRODUCT_REQUEST_EXTENSION", Namespace = DEAL.MISMO_NAMESPACE)]
    public class SERVICE_PRODUCT_REQUEST_EXTENSION 
    {
        [XmlElement("OTHER")]
        [DataMember]
        public SERVICE_PRODUCT_REQUEST_OTHER OTHER { get; set; }

    }
}

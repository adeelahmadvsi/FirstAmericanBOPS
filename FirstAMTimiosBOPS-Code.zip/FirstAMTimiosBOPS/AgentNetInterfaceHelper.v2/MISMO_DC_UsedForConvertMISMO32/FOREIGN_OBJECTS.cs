﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "FOREIGN_OBJECTS", Namespace = DEAL.MISMO_NAMESPACE)]
public class FOREIGN_OBJECTS
{
	[XmlElement("FOREIGN_OBJECT")]
	[DataMember]
	public FOREIGN_OBJECT[] FOREIGN_OBJECT { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

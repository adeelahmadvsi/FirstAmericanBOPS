using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "DEALS", Namespace = MISMOTypes.DEAL.MISMO_NAMESPACE)]
public class DEALS
{
	[XmlElement("DEAL")]
	[DataMember]
	public DEAL[] DEAL { get; set; }
	[XmlElement("PARTIES")]
	[DataMember]
	public PARTIES PARTIES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

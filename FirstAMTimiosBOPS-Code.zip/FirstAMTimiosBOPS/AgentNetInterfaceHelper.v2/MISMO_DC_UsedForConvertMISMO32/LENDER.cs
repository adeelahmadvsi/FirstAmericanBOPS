using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "LENDER", Namespace = DEAL.MISMO_NAMESPACE)]
public class LENDER
{
	[XmlElement("LenderDocumentsOrderedByName")]
	[DataMember]
	public string LenderDocumentsOrderedByName { get; set; }
	[XmlElement("LenderFunderName")]
	[DataMember]
	public string LenderFunderName { get; set; }
	[XmlElement("RegulatoryAgencyLenderIdentifier")]
	[DataMember]
	public string RegulatoryAgencyLenderIdentifier { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

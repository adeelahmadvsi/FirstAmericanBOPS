using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE
{
    [XmlAttribute(Namespace = DEAL.XLINK_NAMESPACE, AttributeName = "label")]
    [DataMemberAttribute]
    public string xlinklabel { get; set; }
    /* xsd:choise node found with the following: */
	//	[XmlElement("AUS")]
	//[DataMember]
	//	public  SERVICE_AUS { get; set; }
	//	[XmlElement("CREDIT")]
	//[DataMember]
	//	public  SERVICE_CREDIT { get; set; }
	//	[XmlElement("DATA_CHANGE")]
	//[DataMember]
	//	public  SERVICE_DATA_CHANGE { get; set; }
	//	[XmlElement("DOCUMENT_MANAGEMENT")]
	//[DataMember]
	//	public  SERVICE_DOCUMENT_MANAGEMENT { get; set; }
	//	[XmlElement("FLOOD")]
	//[DataMember]
	//	public  SERVICE_FLOOD { get; set; }
	//	[XmlElement("FRAUD")]
	//[DataMember]
	//	public  SERVICE_FRAUD { get; set; }
	//	[XmlElement("LOAN_DELIVERY")]
	//[DataMember]
	//	public  SERVICE_LOAN_DELIVERY { get; set; }
	//	[XmlElement("MERS_SERVICE")]
	//[DataMember]
	//	public  SERVICE_MERS_SERVICE { get; set; }
	//	[XmlElement("MI")]
	//[DataMember]
	//	public  SERVICE_MI { get; set; }
	//	[XmlElement("PRIA")]
	//[DataMember]
	//	public  SERVICE_PRIA { get; set; }
	//	[XmlElement("TAX")]
	//[DataMember]
	//	public  SERVICE_TAX { get; set; }
	//	[XmlElement("TITLE")]
	//[DataMember]
	//	public  SERVICE_TITLE { get; set; }
	//	[XmlElement("VALUATION")]
	//[DataMember]
	//	public  SERVICE_VALUATION { get; set; }
	//[XmlElement("REPORTING_INFORMATION")]
	//[DataMember]
	//public  REPORTING_INFORMATION { get; set; }
	//[XmlElement("SERVICE_PAYMENTS")]
	//[DataMember]
	//public  SERVICE_PAYMENTS { get; set; }
	[XmlElement("SERVICE_PRODUCT")]
	[DataMember]
	public SERVICE_PRODUCT SERVICE_PRODUCT { get; set; }
	//[XmlElement("SERVICE_PRODUCT_FULFILLMENT")]
	//[DataMember]
	//public  SERVICE_PRODUCT_FULFILLMENT { get; set; }
	[XmlElement("STATUSES")]
	[DataMember]
	public STATUSES STATUSES { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

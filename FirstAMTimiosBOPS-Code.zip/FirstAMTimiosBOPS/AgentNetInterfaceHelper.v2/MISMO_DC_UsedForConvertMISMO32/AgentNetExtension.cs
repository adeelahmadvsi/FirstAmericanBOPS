using System;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "BaseDataContract", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BaseDataContract : IExtensibleDataObject
    {
        public const string AGENTNET_NAMESPACE = "http://services.firstam.com/entity/agentnet/v2.0";
        // To implement the IExtensibleDataObject interface, you must also
        // implement the ExtensionData property.
        private ExtensionDataObject extensionDataObjectValue = null;
        //public BaseDataContract() 
        //{
        //}
        [XmlElement("ExtensionData")]
       // [DataMember]
        public ExtensionDataObject ExtensionData
        {
            get
            {
                return extensionDataObjectValue;
            }
            set
            {
                extensionDataObjectValue = value;
            }
        }

    }
    [DataContract(Name = "BaseResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BaseResponse : BaseDataContract
    {
        public BaseResponse()
        {
            STATUS = new STATUS();
        }
        [DataMember]
        public bool Result { get; set; }
        [DataMember]
        public STATUS STATUS { get; set; }
    }
    [DataContract(Name = "AgentNetActionTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetActionTypeEnum 
    {
        //public const string NEW = "NEW";
        public const string UPDATE = "UPDATE";
        public const string SERVICE = "SERVICE";
        public const string GET_DATA = "GET_DATA";
        public const string CANCEL = "CANCEL";
        public const string VOID = "VOID";
        public const string PREPRICING = "PREPRICING";
    }
    [DataContract(Name = "AgentNetProductStatusEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetProductStatusEnum
    {
        public const string VOID = "VOID";
        public const string OPEN = "OPEN";
        public const string PENDING = "PENDING";
    }
    [DataContract(Name = "AgentNetGetRequestEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetGetRequestEnum
    {
        public const string PRODUCT_TYPES = "GET_PRODUCT_TYPES";
        public const string JACKET_TYPES = "JACKET_TYPES";
        public const string JACKET_TYPE_FIELDS = "JACKET_TYPE_FIELDS";
        public const string JACKET_ENDORSEMENTS = "JACKET_ENDORSEMENTS";
        public const string CPL_TYPES = "CPL_TYPES";
        public const string VALIDATE_LOGIN = "VALIDATE_LOGIN";
        public const string CHANGE_PASSWORD = "CHANGE_PASSWORD";
        public const string PARTIES = "PARTIES";
        public const string ACCOUNTS = "ACCOUNTS";
        public const string UNDERWRITERS = "UNDERWRITERS";
        public const string GET_CPLS = "GET_CPLS";
        public const string GET_JACKETS = "GET_JACKETS";
        public const string GET_LAST_RESPONSE = "GET_LAST_RESPONSE";
        public const string FILE_STATUS = "FILE_STATUS";
        public const string PREVIOUS_FILE_DATA = "PREVIOUS_FILE_DATA";
        public const string GET_OVERRIDEREASONS = "GET_OVERRIDEREASONS";
        public const string GET_COUNTIES = "GET_COUNTIES";
        public const string VALIDATE_COUNTY = "VALIDATE_COUNTY";
        //public const string SDN_SEARCH = "SDN_SEARCH";
        public const string GET_FIRMS = "GET_FIRMS";
        public const string GET_RATE_TYPES = "GET_RATE_TYPES";

        public const string GET_JACKETS_AND_CPLS = "GET_JACKETS_AND_CPLS";
        public const string GET_MULTI_TYPE_DATAS = "GET_MULTI_TYPE_DATAS";
        public const string GET_BOPRODUCTDETAIL = "GET_BOPRODUCTDETAIL";
        public const string GET_BOPS_UPLOADEDDOCS = "GET_BOPS_UPLOADEDDOCS";
        public const string CPL_FEE_STATES = "CPL_FEE_STATES";
        public const string BOPS_ORDERS_COMPLETED = "BOPS_ORDERS_COMPLETED";
        public const string BOPS_DOCUMENTS_LIST = "BOPS_DOCUMENTS_LIST";
        public const string GET_SPECIAL_MESSAGE = "GET_SPECIAL_MESSAGE";
        public const string GET_GENERIC_SERVICE_TYPES = "GET_GENERIC_SERVICE_TYPES";
        public const string GET_SERVICE_ORDER_FIELDS = "GET_SERVICE_ORDER_FIELDS";
    }
    [DataContract(Name = "AgentNetMultTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetMultiDatasTypeEnum
    {
        public const string BOPS_PRODUCTS_AND_PROPERTYTYPES = "BOPSProductsAndPropertyTypes";
        public const string BOPS_TRANS_AND_BUS_SEGMENTS = "BOPSTransAndBusSegments";
        public const string GET_RECORDING_FEES_COUNTY = "GET_RECORDING_FEES_COUNTY";
    }

    [DataContract(Name = "AgentNetProductTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetProductTypeEnum
    {
        public const string GET_DATA = "GET_DATA";
        public const string Jacket = "JACKET";
        public const string CPL = "CPL";
        public const string BackTitle = "BACKTITLE";
        public const string BackTitleDoc = "BACKTITLEDOC";
        public const string BackTitleDocAttach = "BACKTITLEDOCATTACH";
        public const string RatesFees = "RATESFEES";
        public const string SDNSearch = "SDN";
        public const string PrePricing = "PREPRICING";

        public const string BOPSERVICE = "BOPSERVICE";
        public const string BOPSNOTES = "BOPSNOTES";
        public const string BOPSDOC = "BOPSDOC";
        public const string BOPSIMAGE = "BOPSIMAGE";
        public const string BOPSServiceInfo = "BOPSServiceInfo";
        public const string BOPSDocAttach = "BOPSDocAttach";
        public const string UWB = "UWB";
        public const string RECORDINGFEES = "RECORDINGFEES";
    }

    [DataContract(Name = "AgentNetPartyTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetPartyTypeEnum
    {
        public const string APPROVED_ATTORNEY = "ApprovedAttorney";
        public const string CLOSING_ATTORNEY = "ClosingAttorney";
        public const string MY_CLOSING_ATTORNEY = "MyClosingAttorney";
        public const string OFFICE = "Office";
        public const string MY_LENDER = "MyLender";
        public const string DEFAULT_APPROVED_ATTORNEY = "DefaultApprovedAttorney";
        public const string FIRM = "Firm";
        public const string SIGNATORIES = "Signatories";
        // Change 2nd Party CPL
        public const string SECOND_PARTY = "SecondParty";
    }
    
    [DataContract(Name = "AgentNetSpecialMessageTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetSpecialMessageTypeEnum
    {
        public const string BOPS_DESCLAIMER = "BOPSDesclaimer";
    }

    [DataContract(Name = "AgentNetBackTitleFieldEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetBackTitleFieldEnum
    {
        public const string Field_APN = "APN";
        public const string Field_LastName = "LastName";
        public const string Field_StreetNum = "StreetNumber";
        public const string Field_StreetName = "StreetName";
        public const string Field_City = "City";
        public const string Field_Zip = "ZipCode";
        public const string Field_CondoSubdiv = "CondoSubDivision";
        public const string Field_UnitLot = "UnitLot";
        public const string Field_BlockSqr = "BlockSquare";
        public const string Field_Section = "SectionAcreage";
        public const string Field_District = "District";
        public const string Field_PlatBook = "PlatBook";
        public const string Field_PlatPage = "PlatPage";
        public const string Field_BriefLegal = "BriefLegal";
        public const string Field_FileNumber = "FileNumber";
        public const string Field_PolicyNumber = "PolicyNumber";
        public const string Field_LoanNumber = "LoanNumber";
        public const string Field_OwnerNumber = "OwnerNumber";
        public const string Field_PolicyDateFrom = "PolicyDateFrom";
        public const string Field_PolicyDateTo = "PolicyDateTo";
        // BackTitleDoc request
        public const string Field_DocumentType = "DocumentType";
        public const string Field_AdHocUID = "AdHocUID";
        public const string Field_AttachDoc = "AttachDoc";
    }
    [DataContract(Name = "AgentNetAdditionalPartyRoleTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetAdditionalPartyRoleTypeEnum
    {
        public const string Grantee = "Grantee";
        public const string Insured = "Insured";
        public const string RecordOwner = "RecordOwner";
        public const string GuaranteedParty = "GuaranteedParty";
        public const string VestedIn = "VestedIn";
        public const string ForeclosingLender = "ForeclosingLender";
        public const string OriginalPolicyInsurer = "OriginalPolicyInsurer";
        public const string NomineeVestee = "NomineeVestee";
        public const string CPLLender = "CPLLender";
        public const string CPLMyClosingAttorney = "CPLMyClosingAttorney";
        public const string CPLClosingAttorney = "CPLClosingAttorney";

    }
    [DataContract(Name = "AgentNetOtherlPartyRoleTypeEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetOtherlPartyRoleTypeEnum
    {
        public const string TitleOffice = "TitleOffice";
        public const string EscrowOffice = "EscrowOffice";
        public const string TitleOfficer = "TitleOfficer";
        public const string EscrowOfficer = "EscrowOfficer";
    }

    [DataContract(Name = "AgentNetMyLenderFieldEnum", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetMyLenderFieldEnum
    {
        public const string LenderAttentionName = "LenderAttentionName";
        public const string LenderClause = "LenderClause";
        public const string LenderPhoneNumber = "LenderPhoneNumber";
        public const string LenderFaxNumber = "LenderFaxNumber";
        public const string LenderEmailAddress = "LenderEmailAddress";
        public const string LenderLocation = "LenderLocation";
    }
    public class AgentNetCPLFieldEnum
    {
        public const string ApprovedAttorney = "ApprovedAttorney";
        public const string ClosingAttorney = "ClosingAttorney";
        public const string MyClosingAttorney = "MyClosingAttorney";
        public const string AttachementA = "AttachementA";
        public const string ScheduleASignatory = "ScheduleASignatory";
        public const string ScheduleAFirmLocation = "ScheduleAFirmLocation";
        public const string UpdateMyLender = "UpdateMyLender";
        public const string AlternateFileNumber = "AlternateFileNumber";
        public const string UpdateMyClosingAttorney = "UpdateMyClosingAttorney";
        public const string UpdateCloserAttorney = "UpdateCloserAttorney";

        public const string LoanNumber = "LoanNumber";
        public const string LoanAmount = "LoanAmount";
        public const string ClosingDate = "ClosingDate";
        public const string Preview = "Preview";
        public const string AGYType = "AGYType";
    }
    public class AgentNetAGYTypeCodeEnum
    {
        public const string FullAgent = "FullAgent";
        public const string PolicyWriter = "PolicyWriter";
        public const string ApprovedAttorney = "ApprovedAttorney";
    }
    public class AgentNetAboutVersionTypeEnum
    {
        public const string AgentNet = "AgentNetWS";
        public const string ClientSystem = "ClientSystem";
    }
    public class AgentNetNameValueEnum
    {
        public const string IsDefaultOffice = "IsDefaultOffice";
        public const string IsLicensedInMissouri = "IsLicensedInMissouri";
        public const string FullVestingBorrower = "FullVestingBorrower";
        public const string Subdivision = "Subdivision";
        public const string MarketArea = "MarketArea";
    }
    public class AgentNetClientFileStatusEnum
    {
        public const string Open = "Open";
        public const string Closed = "Closed";
        public const string Cancelled = "Cancelled";
        public const string OpenInError = "OpenInError";
        public const string Unknown = "Unknown";
    }
    public class AgentNetPropertyTypeCodeEnum
    {
        //TFS#104286 changed back to Residential & NonResidential
        public const string Residential = "Residential"; //TFS#103231-changed label names
        public const string NonResidential = "NonResidential";
        public const string Commercial = "Commercial";
    }

    public class AgentNetUWBNavigationEnum
    {
        //TFS#697581 
        public const int MainPage = 0; 
        public const int Reopen = 1;
        public const int SummaryPage = 2;
        public const int EditPage = 3;
    }
    public class RateFeeLineItemTypeEnum
    {
        public const string Fee = "Fee";
        public const string Tax = "Tax";
        public const string Endorsement = "Endorsement";
        public const string Jacket = "Jacket";
        public const string CPL = "CPL";
        public const string MiscEndorsement = "MiscEndorsement";
    }
    public class AgentNetBOServiceFieldEnum
    {
        public const string TransactionType = "TransactionType";
        public const string BusinessSegment = "BusinessSegment";
        public const string PropertyType = "PropertyType";
        public const string BOPSFileId = "BOPSFileId";
        public const string BOPSFileNotes = "BOPSFileNotes";
        public const string BOPSFileImageID = "BOPSFileImageID";
        public const string BOPSNotificationEmailAddress = "BOPSNotificationEmailAddress";
        public const string ANBOPSProductIds = "ANBOPSProductIds";
    }
    public class AgentNetRealtionshipType
    {
        public const string HusbandAndWife = "agentnet:HusbandAndWife"; // arcrole
    }

    public class AgentNetPricingType
    {
       
        public const int TitleRatesFees = 0;
        public const int RecordingFees = 1;
        public const int Both = 2;
    }

    [DataContract(Name = "AGENTNET_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_REQUEST : BaseDataContract
    {
        [XmlElement("ActionType")]
        [DataMember]
        public string ActionType { get; set; }
        [XmlElement("ClientRequestId")]
        [DataMember]
        public string ClientRequestId { get; set; }
        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }
        [XmlElement("FileId")]
        [DataMember]
        public string FileId { get; set; }
        [XmlElement("ClientFileId")]
        [DataMember]
        public string ClientFileId { get; set; }
        [XmlElement("AccountNumber")]
        [DataMember]
        public string AccountNumber { get; set; }
        [XmlElement("SystemName")]
        [DataMember]
        public string SystemName { get; set; }

        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }

        [XmlElement("OfficeId")]
        [DataMember]
        public string OfficeId { get; set; }

        [XmlElement("ClientFileStatusCode")]
        [DataMember]
        public string ClientFileStatusCode { get; set; }

        [XmlElement("PropertyTypeCode")]
        [DataMember]
        public string PropertyTypeCode { get; set; }
        [XmlElement("KYTaxCode")]
        [DataMember]
        public string KYTaxCode { get; set; }
        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
        //velow added as part of 3.2 upgrade
        [XmlElement("LoginAccountIdentifier")]
        [DataMember]
        public string LoginAccountIdentifier { get; set; }
        [XmlElement("LoginAccountPasswordText")]
        [DataMember]
        public string LoginAccountPasswordText { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_REQUEST : BaseDataContract
    {
        [XmlElement("AgentNetServiceType")]
        [DataMember]
        public string AgentNetServiceType { get; set; } // AgentNetProductTypeEnum

        [XmlElement("ProductStatus")]
        [DataMember]
        public string ProductStatus { get; set; }

        [XmlElement("AgentNetProductServiceId")]
        [DataMember]
        public string AgentNetProductServiceId { get; set; }

        [XmlElement("ProductTypeCode")]
        [DataMember]
        public string ProductTypeCode { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

        [XmlElement(ElementName = "AGENTNET_GET_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_GET_DATA AGENTNET_GET_DATA { get; set; }
        [XmlElement(ElementName = "AGENTNET_SDN_SEARCH_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_REQUEST AGENTNET_SDN_SEARCH_REQUEST { get; set; }

        [XmlElement(ElementName = "AGENTNET_DOCUMENTS", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECTS AGENTNET_DOCUMENTS { get; set; }
        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REQUESTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REQUESTS AGENTNET_PRODUCT_PRICING_REQUESTS { get; set; }
        [XmlElement(ElementName = "AGENTNET_PRODUCT_UNDERWRITING_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_UNDERWRITING_REQUEST AGENTNET_PRODUCT_UNDERWRITING_REQUEST { get; set; }
        [XmlElement(ElementName = "AGENTNET_PRODUCT_RECORDING_FEES_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_REQUEST AGENTNET_PRODUCT_RECORDING_FEES_REQUEST { get; set; }
    }
    [DataContract(Name = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_NAME_VALUES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_NAME_VALUE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUE[] AGENTNET_NAME_VALUE { get; set; }
    }

    [DataContract(Name = "AGENTNET_NAME_VALUE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_NAME_VALUE : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string Name { get; set; }
        [XmlElement("Value")]
        [DataMember]
        public string Value { get; set; }
    }

    [DataContract(Name = "AGENTNET_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_RESPONSE : BaseDataContract
    {
        [XmlElement("SessionId")]
        [DataMember]
        public string SessionId { get; set; }
        [XmlElement("ClientRequestId")]
        [DataMember]
        public string ClientRequestId { get; set; }
        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }
        [XmlElement("FileId")]
        [DataMember]
        public string FileId { get; set; }
        [XmlElement("ClientFileId")]
        [DataMember]
        public string ClientFileId { get; set; }
        [XmlElement("FirmId")]
        [DataMember]
        public string FirmId { get; set; }
        [XmlElement("OfficeId")]
        [DataMember]
        public string OfficeId { get; set; }
        [XmlElement("AccountNumber")]
        [DataMember]
        public string AccountNumber { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("UnderwriterName")]
        [DataMember]
        public string UnderwriterName { get; set; }
        [XmlElement("LoginId")]
        [DataMember]
        public string LoginId { get; set; }

        [XmlElement("IsAutoReportOnHold")]
        [DataMember]
        public bool IsAutoReportOnHold { get; set; }
        [XmlElement("KYTaxCode")]
        [DataMember]
        public string KYTaxCode { get; set; }
        [XmlElement("RequestCompletionDate")]
        [DataMember]
        public DateTime RequestCompletionDate { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RESPONSE : BaseDataContract
    {

        [XmlElement("AgentNetServiceType")]
        [DataMember]
        public string AgentNetServiceType { get; set; } // AgentNetProductTypeEnum

        [XmlElement(ElementName = "AGENTNET_PRODUCT_DETAIL_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_DETAIL_RESPONSE AGENTNET_PRODUCT_DETAIL_RESPONSE { get; set; }

        [XmlElement(ElementName = "AGENTNET_GET_DATA_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_GET_DATA_RESPONSE AGENTNET_GET_DATA_RESPONSE { get; set; }

        [XmlElement(ElementName = "STATUSES", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public STATUSES STATUSES { get; set; }

        //[XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        //[DataMember]
        //public AGENTNET_PRODUCT_PRICING_RESPONSES AGENTNET_PRODUCT_PRICING_RESPONSES { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_DETAIL_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_DETAIL_RESPONSE : BaseDataContract
    {

        [XmlElement("ProductResponseId")]
        [DataMember]
        public string ProductResponseId { get; set; }

        [XmlElement("ProductStatus")]
        [DataMember]
        public string ProductStatus { get; set; }

        [XmlElement(ElementName = "AGENTNET_JACKET_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_JACKET_DETAIL AGENTNET_JACKET_DETAIL { get; set; }

        [XmlElement(ElementName = "AGENTNET_CPL_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CPL_DETAIL AGENTNET_CPL_DETAIL { get; set; }

        //[XmlElement(ElementName = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        //[DataMember]
        //public AGENTNET_RATE_FEES AGENTNET_RATE_FEES { get; set; }

        [XmlElement(ElementName = "AGENTNET_POLICY_IMAGE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_POLICY_IMAGE_DETAILS AGENTNET_POLICY_IMAGE_DETAILS { get; set; }

        [XmlElement(ElementName = "AGENTNET_BACKTITLE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BACKTITLE_DETAILS AGENTNET_BACKTITLE_DETAILS { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

        [XmlElement(ElementName = "AGENTNET_SDN_SEARCH_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSES AGENTNET_SDN_SEARCH_RESPONSES { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_RESPONSES AGENTNET_PRODUCT_PRICING_RESPONSES { get; set; }

        [XmlElement(ElementName = "AGENTNET_TITLE_SERVICE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_DETAIL AGENTNET_TITLE_SERVICE_DETAIL { get; set; }
        [XmlElement(ElementName = "AGENTNET_PRODUCT_UNDERWRITING_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_UNDERWRITING_RESPONSE AGENTNET_PRODUCT_UNDERWRITING_RESPONSE { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_RECORDING_FEES_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_RESPONSE AGENTNET_PRODUCT_RECORDING_FEES_RESPONSE { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRICING_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRICING_ENDORSEMENT
    {
        [XmlElement("AgentNetEndorCode")]
        [DataMember]
        public string AgentNetEndorCode { get; set; }

        [XmlElement("EndorsementName")]
        [DataMember]
        public string EndorsementName { get; set; }

        [XmlElement("ClientEndorCode")]
        [DataMember]
        public string ClientEndorCode { get; set; }

        [XmlElement("IsPreSelected")]
        [DataMember]
        public bool IsPreSelected { get; set; }

        [XmlElement("IsBidirectional")]
        [DataMember]
        public bool IsBidirectional { get; set; }

        [XmlElement("IsMultipleEndorsement")]
        [DataMember]
        public bool IsMultipleEndorsement { get; set; }
    }

    [DataContract(Name = "AGENTNET_GET_DATA_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_GET_DATA_RESPONSE : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_SERVICE_FIELDS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_SERVICE_FIELDS AGENTNET_PRODUCT_SERVICE_FIELDS { get; set; }

        [XmlElement(ElementName = "AGENTNET_SERVICE_ORDER_GROUPS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SERVICE_ORDER_GROUPS AGENTNET_SERVICE_ORDER_GROUPS { get; set; }
        
        [XmlElement(ElementName = "AGENTNET_JACKET_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENTS AGENTNET_JACKET_ENDORSEMENTS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRICING_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRICING_ENDORSEMENTS AGENTNET_PRICING_ENDORSEMENTS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PARTIES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PARTIES AGENTNET_PARTIES { get; set; }

        [XmlElement(ElementName = "AGENTNET_ACCOUNTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ACCOUNTS AGENTNET_ACCOUNTS { get; set; }
        [XmlElement(ElementName = "AGENTNET_SDN_SEARCH_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSES AGENTNET_SDN_SEARCH_RESPONSES { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS_MULTI", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS_MULTI AGENTNET_TYPE_DATAS_MULTI { get; set; }

        [XmlElement(ElementName = "AGENTNET_TITLE_SERVICE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_DETAIL AGENTNET_TITLE_SERVICE_DETAIL { get; set; }

        [XmlElement(ElementName = "AGENTNET_TITLE_SERVICE_COMPLS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_COMPLS AGENTNET_TITLE_SERVICE_COMPLS { get; set; }

        [XmlElement(ElementName = "m_AGENTNET_TITLE_SERVICE_DOCS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_DOCS AGENTNET_TITLE_SERVICE_DOCS { get; set; }

        [XmlElement(ElementName = "AGENTNET_TITLE_SERVICE_UPDATE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_UPDATE_DETAILS AGENTNET_TITLE_SERVICE_UPDATE_DETAILS { get; set; }
        
        [XmlElement(ElementName = "AGENTNET_PRODUCT_UNDERWRITING_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_UNDERWRITING_RESPONSE AGENTNET_PRODUCT_UNDERWRITING_RESPONSE { get; set; }

        [XmlElement(ElementName = "AGENTNET_DOCUMENT_OBJECTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECTS AGENTNET_DOCUMENT_OBJECTS { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS { get; set; }
    }

    [DataContract(Name = "AGENTNET_SERVICE_ORDER_FIELDS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SERVICE_ORDER_FIELDS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_SERVICE_ORDER_FIELD", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SERVICE_ORDER_FIELD[] AGENTNET_SERVICE_ORDER_FIELD { get; set; }
    }

    [DataContract(Name = "AGENTNET_SERVICE_ORDER_FIELD", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SERVICE_ORDER_FIELD : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string Name { get; set; }
        [XmlElement("Type")]
        [DataMember]
        public string Type { get; set; }
        [XmlElement("Label")]
        [DataMember]
        public string Label { get; set; }
        [XmlElement("IsRequired")]
        [DataMember]
        public bool IsRequired { get; set; }
        [XmlElement("Sequence")]
        [DataMember]
        public int Sequence { get; set; }
        [XmlElement("Text")]
        [DataMember]
        public string Text { get; set; }
        [XmlElement("IsMultiText")]
        [DataMember]
        public bool IsMultiText { get; set; }
        [XmlElement("IsChecked")]
        [DataMember]
        public bool IsChecked { get; set; }
        [XmlElement("IsDisabled")]
        [DataMember]
        public bool IsDisabled { get; set; }
        [XmlElement("DataFields")]
        [DataMember]
        public AGENTNET_TYPE_DATA[] DataFields { get; set; }
        [XmlElement("ChildElements")]
        [DataMember]
        public AGENTNET_SERVICE_ORDER_FIELD[] ChildElements { get; set; }
    }

    [DataContract(Name = "AGENTNET_SERVICE_ORDER_GROUPS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SERVICE_ORDER_GROUPS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_SERVICE_ORDER_GROUP", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SERVICE_ORDER_GROUP[] AGENTNET_SERVICE_ORDER_GROUP { get; set; }
    }

    [DataContract(Name = "AGENTNET_SERVICE_ORDER_GROUP", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SERVICE_ORDER_GROUP : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string Name { get; set; }
        [XmlElement("ServiceID")]
        [DataMember]
        public int ServiceID{ get; set; }
        [XmlElement("Type")]
        [DataMember]
        public string Type{ get; set; }
        [XmlElement("Text")]
        [DataMember]
        public string Text{ get; set; }
        [XmlElement("Sequence")]
        [DataMember]
        public int Sequence{ get; set; }
        [XmlElement(ElementName = "AGENTNET_SERVICE_ORDER_FIELDS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SERVICE_ORDER_FIELDS AGENTNET_SERVICE_ORDER_FIELDS{ get; set; }
    }

    [DataContract(Name = "AGENTNET_GET_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_GET_DATA : BaseDataContract
    {
        [XmlElement("GetRequestType")]
        [DataMember]
        public string GetRequestType { get; set; }
        [XmlElement("Parm")]
        [DataMember]
        public string[] Parm { get; set; }
    }
    [DataContract(Name = "AGENTNET_JACKET_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_JACKET_DETAIL : BaseDataContract
    {
        [XmlElement("FileServiceJacketId")]
        [DataMember]
        public string FileServiceJacketId { get; set; }

        [XmlElement("JacketTypeId")]
        [DataMember]
        public string JacketTypeId { get; set; }

        [XmlElement("PolicyTypeCategory")]
        [DataMember]
        public string PolicyTypeCategory { get; set; }

        [XmlElement("PolicyNumber")]
        [DataMember]
        public string PolicyNumber { get; set; }

        [XmlElement("PolicyAmount")]
        [DataMember]
        public decimal PolicyAmount { get; set; }

        //Newly added field for RF
        [XmlElement("EffectiveDate")]
        [DataMember]
        public DateTime EffectiveDate { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }

    [DataContract(Name = "AGENTNET_SDN_SEARCH_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SDN_SEARCH_REQUEST : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string[] Name { get; set; }
    }

   

    [DataContract(Name = "AGENTNET_SDN_SEARCH_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SDN_SEARCH_RESPONSES : BaseDataContract
    {
        [XmlElement("AGENTNET_SDN_SEARCH_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSE[] AGENTNET_SDN_SEARCH_RESPONSE { get; set; }

    }

    [DataContract(Name = "AGENTNET_SDN_SEARCH_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_SDN_SEARCH_RESPONSE : BaseDataContract
    {
        [XmlElement("Name")]
        [DataMember]
        public string Name { get; set; }

        [XmlElement("SearchDate")]
        [DataMember]
        public string SearchDate { get; set; }

        [XmlElement("Result")]
        [DataMember]
        public string Result { get; set; }

    }

    #region ANUWB

    [DataContract(Name = "AGENTNET_PRODUCT_UNDERWRITING_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_UNDERWRITING_REQUEST : BaseDataContract
    {
        [XmlElement("RequestName")]
        [DataMember]
        public string RequestName { get; set; }

        [XmlElement("ClosingDate")]
        [DataMember]
        public string ClosingDate { get; set; }

        [XmlElement("TotalLiability")]
        [DataMember]
        public string TotalLiability { get; set; }

        [XmlElement("UWB_PageEnum")]
        [DataMember]
        public int UWB_PageEnum { get; set; }

       
    }

    [DataContract(Name = "AGENTNET_PRODUCT_UNDERWRITING_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_UNDERWRITING_RESPONSE : BaseDataContract
    {
        [XmlElement("RequestId")]
        [DataMember]
        public int RequestId { get; set; }

        [XmlElement("RequestName")]
        [DataMember]
        public string RequestName { get; set; }

        [XmlElement("RequestStatus")]
        [DataMember]
        public string RequestStatus { get; set; }

        //[XmlElement("IsTransactionActive")]
        //[DataMember]
        //public bool IsTransactionActive { get; set; }

        [XmlElement("UWBSubmittedDate")]
        [DataMember]
        public DateTime UWBSubmittedDate { get; set; }

        [XmlElement("UWBClosingDate")]
        [DataMember]
        public DateTime UWBClosingDate { get; set; }

        [XmlElement("UWBModifiedDate")]
        [DataMember]
        public DateTime UWBModifiedDate { get; set; }

        [XmlElement("Liability")]
        [DataMember]
        public string Liability { get; set; }

        [XmlElement("LiabilityDecimal")]
        [DataMember]
        public decimal LiabilityDecimal { get; set; }

        // Commented but not deleted.May require in future. 

        //[XmlElement("ANUWBFileInfo")]
        //[DataMember]
        //public AGENTNET_PRODUCT_UNDERWRITING_FILEINFOS ANUWBFileInfo { get; set; }

        //[XmlElement("IsFileShared")]
        //[DataMember]
        //public bool IsFileShared { get; set; }

        //[XmlElement("ModifiedByUserName")]
        //[DataMember]
        //public string ModifiedByUserName { get; set; }

        //[XmlElement("IsTransactionReopen")]
        //[DataMember]
        //public bool IsTransactionReopen { get; set; }

        [XmlElement("ThirdPartyToken")]
        [DataMember]
        public string ThirdPartyToken { get; set; }

        [XmlElement("AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFOS")]
        [DataMember]
        public AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFOS AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFOS { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_UNDERWRITING_FILEINFO", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_UNDERWRITING_FILEINFO : BaseDataContract
    {
        [XmlElement("FileId")]
        [DataMember]
        public int FileId { get; set; }

        [XmlElement("FileServiceId")]
        [DataMember]
        public int FileServiceId { get; set; }

        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }

        [XmlElement("OfficeId")]
        [DataMember]
        public int OfficeId { get; set; }

        [XmlElement("OfficeName")]
        [DataMember]
        public string OfficeName { get; set; }

        [XmlElement("FileStatus")]
        [DataMember]
        public string FileStatus { get; set; }

        [XmlElement("OpenDate")]
        [DataMember]
        public string OpenDate { get; set; }

        [XmlElement("PropertyAddress")]
        [DataMember]
        public string PropertyAddress { get; set; }

        [XmlElement("Risk")]
        [DataMember]
        public string Risk { get; set; }

        [XmlElement("sourceFileTypeId")]
        [DataMember]
        public int sourceFileTypeId { get; set; }

        [XmlElement("sourceFileType")]
        [DataMember]
        public string sourceFileType { get; set; }

        [XmlElement("IsMasterFile")]
        [DataMember]
        public bool IsMasterFile { get; set; }

        [XmlElement("IsMechanicLien")]
        [DataMember]
        public bool IsMechanicLien { get; set; }

        [XmlElement("UWBFileId")]
        [DataMember]
        public int UWBFileId { get; set; }


        [XmlElement("FirmId")]
        [DataMember]
        public int FirmId { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_UNDERWRITING_FILEINFOS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_UNDERWRITING_FILEINFOS : BaseDataContract
    {
        [XmlElement("AGENTNET_PRODUCT_UNDERWRITING_FILEINFO", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_UNDERWRITING_FILEINFO[] AGENTNET_PRODUCT_UNDERWRITING_FILEINFO { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFO", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFO : BaseDataContract
    {

        [XmlElement("TransactionDocumentId")]
        [DataMember]
        public int TransactionDocumentId { get; set; }

        [XmlElement("TransactionId")]
        [DataMember]
        public int TransactionId { get; set; }

        [XmlElement("DocumentTypeCdId")]
        [DataMember]
        public int DocumentTypeCdId { get; set; }

        [XmlElement("DocumentTypeName")]
        [DataMember]
        public string DocumentTypeName { get; set; }

        [XmlElement("DocumentSourceTypeCdId")]
        [DataMember]
        public int DocumentSourceTypeCdId { get; set; }

        [XmlElement("DocumentName")]
        [DataMember]
        public string DocumentName { get; set; }

        [XmlElement("DocumentDescription")]
        [DataMember]
        public string DocumentDescription { get; set; }


        [XmlElement("CreatedDate")]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [XmlElement("ModifiedByUserName")]
        [DataMember]
        public string ModifiedByUserName { get; set; }

        [XmlElement("ModifiedDate")]
        [DataMember]
        public DateTime ModifiedDate { get; set; }

        [XmlElement("DocumentSize")]
        [DataMember]
        public string DocumentSize { get; set; }

        [XmlElement("FileExtension")]
        [DataMember]
        public string FileExtension { get; set; }


    }

    [DataContract(Name = "AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFOS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFOS : BaseDataContract
    {
        [XmlElement("AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFO", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFO[] AGENTNET_PRODUCT_UNDERWRITING_DOCUMENTINFO { get; set; }

    }
    #endregion ANUWB

    #region Recording Fees

    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_REQUEST : BaseDataContract
    {

        [XmlElement("IsSecondLevelRequest")]
        [DataMember]
        public bool IsSecondLevelRequest { get; set; }

        [XmlElement("Is_CostType_RecordingFees")]
        [DataMember]
        public bool Is_CostType_RecordingFees { get; set; }

        [XmlElement("RecordingCost")]
        [DataMember]
        public string RecordingCost { get; set; } 

        [XmlElement("PropertyState")]
        [DataMember]
        public string PropertyState { get; set; }

        [XmlElement("PropertyCounty")]
        [DataMember]
        public string PropertyCounty { get; set; }

        [XmlElement("PropertyCity")]
        [DataMember]
        public string PropertyCity { get; set; }       

        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS")]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS { get; set; }

    }


    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFO", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFO : BaseDataContract
    {

        [XmlElement("RecordingDocumentName")]
        [DataMember]
        public string RecordingDocumentName { get; set; }

        [XmlElement("EstNoOfPages")]
        [DataMember]
        public int EstNoOfPages { get; set; }

        [XmlElement("ConsiderationAmount")]
        [DataMember]
        public string ConsiderationAmount { get; set; }

        [XmlElement("AGENTNET_ADDITIONAL_QUESTIONS")]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS : BaseDataContract
    {
        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFO", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFO[] AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFO { get; set; }

    }


    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_RESPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_RESPONSE : BaseDataContract
    {
        [XmlElement("Phone")]
        [DataMember]
        public string Phone { get; set; }

        [XmlElement("Fax")]
        [DataMember]
        public string Fax { get; set; }

        [XmlElement("Website")]
        [DataMember]
        public string Website { get; set; }

        [XmlElement("BusinessHours")]
        [DataMember]
        public string BusinessHours { get; set; }

        [XmlElement("Total")]
        [DataMember]
        public string Total { get; set; }

        [XmlElement("TotalBuyer")]
        [DataMember]
        public string TotalBuyer { get; set; }

        [XmlElement("TotalSeller")]
        [DataMember]
        public string TotalSeller { get; set; }

        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS")]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS AGENTNET_PRODUCT_RECORDING_FEES_DOCUMENTINFOS { get; set; }

        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESSES")]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESSES AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESSES { get; set; }

        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_COSTS")]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_COSTS AGENTNET_PRODUCT_RECORDING_FEES_COSTS { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESS : BaseDataContract
    {

        [XmlElement("Address1")]
        [DataMember]
        public string Address1 { get; set; }

        [XmlElement("Address2")]
        [DataMember]
        public string Address2 { get; set; }

        [XmlElement("City")]
        [DataMember]
        public string City { get; set; }

        [XmlElement("State")]
        [DataMember]
        public string State { get; set; }

        [XmlElement("Type")]
        [DataMember]
        public string Type { get; set; }

        [XmlElement("Zip")]
        [DataMember]
        public string Zip { get; set; }

        [XmlElement("Attention")]
        [DataMember]
        public string Attention { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESSES : BaseDataContract
    {
        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESS[] AGENTNET_PRODUCT_RECORDING_FEES_OFFICE_ADDRESS { get; set; }

    }

    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_COST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_COST : BaseDataContract
    {

        [XmlElement("DocumentName")]
        [DataMember]
        public string DocumentName { get; set; }

        [XmlElement("DocumentKey")]
        [DataMember]
        public string DocumentKey { get; set; }

        [XmlElement("DocumentAmount")]
        [DataMember]
        public string DocumentAmount { get; set; }

        [XmlElement("DocumentAmountBuyer")]
        [DataMember]
        public string DocumentAmountBuyer { get; set; }

        [XmlElement("DocumentAmountSeller")]
        [DataMember]
        public string DocumentAmountSeller { get; set; }

        [XmlElement("DocumentPayableTo")]
        [DataMember]
        public string DocumentPayableTo { get; set; }

        [XmlElement("DocumentCostType")]
        [DataMember]
        public string DocumentCostType { get; set; }

        [XmlElement("DocumentTaxAssessedBy")]
        [DataMember]
        public string DocumentTaxAssessedBy { get; set; }

        [XmlElement(ElementName = "QuestionList", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS QuestionList { get; set; }

        [XmlElement(ElementName = "Notes", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS Notes { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_RECORDING_FEES_COSTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_RECORDING_FEES_COSTS : BaseDataContract
    {
        [XmlElement("AGENTNET_PRODUCT_RECORDING_FEES_COST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_RECORDING_FEES_COST[] AGENTNET_PRODUCT_RECORDING_FEES_COST { get; set; }

    }

    #endregion


    [DataContract(Name = "AGENTNET_PARTIES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PARTIES
    {
        [XmlElement(ElementName = "AGENTNET_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PARTY[] AGENTNET_PARTY { get; set; }
    }
    [DataContract(Name = "AGENTNET_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PARTY : BaseDataContract
    {
        [XmlElement("PartyId")]
        [DataMember]
        public string PartyId { get; set; }
        [XmlElement("PartyName")]
        [DataMember]
        public string PartyName { get; set; }
        [XmlElement("AddressLineText")]
        [DataMember]
        public string AddressLineText { get; set; }
        [XmlElement("AddressAdditionalLineText")]
        [DataMember]
        public string AddressAdditionalLineText { get; set; }
        [XmlElement("CityName")]
        [DataMember]
        public string CityName { get; set; }
        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }
        [XmlElement("PostalCode")]
        [DataMember]
        public string PostalCode { get; set; }
        [XmlElement("PlusFourZipCode")]
        [DataMember]
        public string PlusFourZipCode { get; set; }
        [XmlElement("CountyName")]
        [DataMember]
        public string CountyName { get; set; }
        [XmlElement("CountryName")]
        [DataMember]
        public string CountryName { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

    }
    /*GET_DATA WEB-SERVICES USE
     * These are used only for GET_DATA web-service calls
     * */
    [DataContract(Name = "AgentNetTypeDataItemsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetTypeDataItemsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TYPE_DATA[] AGENTNET_TYPE_DATA { get; set; }
    }

    [DataContract(Name = "AgentNetMultiTypeDatasResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetMultiTypeDatasResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TYPE_DATAS_MULTI AGENTNET_TYPE_DATAS_MULTI { get; set; }
    }

    [DataContract(Name = "AgentNetGetDataResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetGetDataResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_GET_DATA_RESPONSE AGENTNET_GET_DATA_RESPONSE { get; set; }
    }
   
    [DataContract(Name = "SDNSearchResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class SDNSearchResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_SDN_SEARCH_RESPONSES AGENTNET_SDN_SEARCH_RESPONSES { get; set; }
    }

    [DataContract(Name = "AgentNetCPLDetailResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetCPLDetailResponse : BaseResponse
    {
        [DataMember]
        public SERVICE[] SERVICE { get; set; }
    }

    [DataContract(Name = "AgentNetJacketDetailResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetJacketDetailResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_JACKET_DETAIL[] AGENTNET_JACKET_DETAIL { get; set; }
    }

    [DataContract(Name = "ProductServiceFieldItemsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class ProductServiceFieldItemsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_PRODUCT_SERVICE_FIELD[] AGENTNET_PRODUCT_SERVICE_FIELD { get; set; }

        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENT[] AGENTNET_JACKET_ENDORSEMENT { get; set; }
    }
    [DataContract(Name = "JacketEndorsementsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class JacketEndorsementsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENT[] AGENTNET_JACKET_ENDORSEMENT { get; set; }
    }

    [DataContract(Name = "AgentNetBOUploadedDocumentDetailsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetBOUploadedDocumentDetailsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TITLE_SERVICE_DETAIL AGENTNET_TITLE_SERVICE_DETAIL { get; set; }
    }
    [DataContract(Name = "PartiesResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class PartiesResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_PARTY[] AGENTNET_PARTIES { get; set; }
    }
    [DataContract(Name = "AccountsResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AccountsResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_ACCOUNT[] AGENTNET_ACCOUNTS { get; set; }
    }
    [DataContract(Name = "BOPSOrdersCompletedResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BOPSOrdersCompletedResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TITLE_SERVICE_COMPL[] AGENTNET_TITLE_SERVICE_COMPLS { get; set; }
    }
    [DataContract(Name = "BOPSOrderUpdateDetailResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BOPSOrderUpdateDetailResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TITLE_SERVICE_UPDATE_DETAIL[] AGENTNET_TITLE_SERVICE_UPDATE_DETAILS { get; set; }
    }

    [DataContract(Name = "BOPSDocumentsListResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class BOPSDocumentsListResponse : BaseResponse
    {
        [DataMember]
        public AGENTNET_TITLE_SERVICE_DOCS AGENTNET_TITLE_SERVICE_DOCS { get; set; }
    }
    [DataContract(Name = "AgentNetStatusResponse", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AgentNetStatusResponse : BaseResponse
    {

    }
    /*GET_DATA WEB-SERVICES USE To Here */
    [DataContract(Name = "AGENTNET_TYPE_DATAS_MULTI", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TYPE_DATAS_MULTI
    {
        [XmlElement(ElementName = "MultipleType", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public string MultipleType { get; set; }

        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS_COLL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS[] AGENTNET_TYPE_DATAS_COLL { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }
    [DataContract(Name = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TYPE_DATAS
    {
        [XmlElement(ElementName = "AGENTNET_TYPE_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATA[] AGENTNET_TYPE_DATA { get; set; }
    }

    [DataContract(Name = "AGENTNET_TYPE_DATA", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TYPE_DATA
    {
        [XmlElement("TypeId")]
        [DataMember]
        public string TypeId { get; set; }   
   
        [XmlElement("TypeCode")]
        [DataMember]
        public string TypeCode { get; set; }

        [XmlElement("ClientTypeId")]
        [DataMember]
        public string ClientTypeId { get; set; }
     
        [XmlElement("Description")]
        [DataMember]
        public string Description { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_SERVICE_FIELDS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_SERVICE_FIELDS
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_SERVICE_FIELD", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_SERVICE_FIELD[] AGENTNET_PRODUCT_SERVICE_FIELD { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_SERVICE_FIELD", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_SERVICE_FIELD
    {
        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("ProductTypeId")]
        [DataMember]
        public string ProductTypeId { get; set; }
        [XmlElement("ProductTypeName")]
        [DataMember]
        public string ProductTypeName { get; set; }
        [XmlElement("FieldName")]
        [DataMember]
        public string FieldName { get; set; }
        [XmlElement("FieldType")]
        [DataMember]
        public string FieldType { get; set; } // string,int,decimal(?),select (option values required)
        [XmlElement("IsRequired")]
        [DataMember]
        public bool IsRequired { get; set; }

        [XmlElement("FieldText")]
        [DataMember]
        public string FieldText { get; set; }

        [XmlElement("GroupName")]
        [DataMember]
        public string GroupName { get; set; }

        [XmlElement("IsChecked")]
        [DataMember]
        public bool IsChecked { get; set; }

        [XmlElement("IsMultiLine")]
        [DataMember]
        public bool IsMultiLine { get; set; }

        [XmlElement("OptionValues")]
        [DataMember]
        public string[] OptionValues { get; set; }
    }
    [DataContract(Name = "AGENTNET_JACKET_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_JACKET_ENDORSEMENTS
    {
        [XmlElement(ElementName = "AGENTNET_JACKET_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_JACKET_ENDORSEMENT[] AGENTNET_JACKET_ENDORSEMENT { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRICING_ENDORSEMENTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRICING_ENDORSEMENTS
    {
        [XmlElement(ElementName = "AGENTNET_PRICING_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRICING_ENDORSEMENT[] AGENTNET_PRICING_ENDORSEMENT { get; set; }
    }

    [DataContract(Name = "AGENTNET_JACKET_ENDORSEMENT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_JACKET_ENDORSEMENT 
    {
        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("ProductTypeId")]
        [DataMember]
        public string ProductTypeId { get; set; }
        [XmlElement("EndorsementId")]
        [DataMember]
        public string EndorsementId { get; set; }
        [XmlElement("EndorsementName")]
        [DataMember]
        public string EndorsementName { get; set; }
        
        [XmlElement("IsPreSelected")]
        [DataMember]
        public bool IsPreSelected { get; set; }

        [XmlElement(ElementName = "AGENTNET_CONTROLS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CONTROLS AGENTNET_CONTROLS { get; set; }

        //below fields are same as pricing endorsements
        [XmlElement("AgentNetEndorCode")]
        [DataMember]
        public string AgentNetEndorCode { get; set; }

        [XmlElement("ClientEndorCode")]
        [DataMember]
        public string ClientEndorCode { get; set; }

    }
    [DataContract(Name = "AGENTNET_CONTROLS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CONTROLS
    {
        [XmlElement(ElementName = "AGENTNET_CONTROL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CONTROL[] AGENTNET_CONTROL { get; set; }
    }
    [DataContract(Name = "AGENTNET_CONTROL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CONTROL
    {
        [XmlElement("ControlId")]
        [DataMember]
        public string ControlId { get; set; }
        
        [XmlElement("ControlType")]
        [DataMember]
        public string ControlType { get; set; } 

        [XmlElement("IsRequired")]
        [DataMember]
        public bool IsRequired { get; set; }

        [XmlElement("ControlValue")]
        [DataMember]
        public string ControlValue { get; set; }

        [XmlElement("IsChecked")]
        [DataMember]
        public bool IsChecked { get; set; }

        [XmlElement("IsMultiLine")]
        [DataMember]
        public bool IsMultiLine { get; set; }

        [XmlElement("IsSameLine")]
        [DataMember]
        public bool IsSameLine { get; set; }
        
        [XmlElement("IsProtected")]
        [DataMember]
        public bool IsProtected { get; set; }

        [XmlElement("GroupName")]
        [DataMember]
        public string GroupName { get; set; }
    }
    [DataContract(Name = "AGENTNET_ACCOUNTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ACCOUNTS
    {
        [XmlElement(ElementName = "AGENTNET_ACCOUNT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ACCOUNT[] AGENTNET_ACCOUNT { get; set; }
    }
    [DataContract(Name = "AGENTNET_ACCOUNT", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ACCOUNT
    {
        [XmlElement("OfficeId")]
        [DataMember]
        public int OfficeId { get; set; }
        [XmlElement("FirmId")]
        [DataMember]
        public int FirmID { get; set; }
        [XmlElement("AccountNumber")]
        [DataMember]
        public int AccountNumber { get; set; }
        [XmlElement("JurisdictionStateCode")]
        [DataMember]
        public string JurisdictionStateCode { get; set; }
        [XmlElement("UnderwriterId")]
        [DataMember]
        public int UnderwriterID { get; set; }
        [XmlElement("UnderwriterCode")]
        [DataMember]
        public string UnderwriterCode { get; set; }
        [XmlElement("UnderwriterName")]
        [DataMember]
        public string UnderwriterName { get; set; }
    }

    [DataContract(Name = "AGENTNET_CPL_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CPL_DETAIL : BaseDataContract
    {

        [XmlElement("FileServiceCPLId")]
        [DataMember]
        public string FileServiceCPLId { get; set; }

        [XmlElement("CplGroupId")]
        [DataMember]
        public string CplGroupId { get; set; }

        //Closing Date newly added for to get closing date for the CPL.
        [XmlElement("ClosingDate")]
        [DataMember]
        public DateTime ClosingDate { get; set; }//Closing date.

        [XmlElement(ElementName = "AGENTNET_CPL_COVERRED_PARTIES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CPL_COVERRED_PARTIES AGENTNET_CPL_COVERRED_PARTIES { get; set; }
    }
    [DataContract(Name = "AGENTNET_CPL_COVERRED_PARTYS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CPL_COVERRED_PARTIES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_CPL_COVERRED_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CPL_COVERRED_PARTY[] AGENTNET_CPL_COVERRED_PARTY { get; set; }
    }
    [DataContract(Name = "AGENTNET_CPL_COVERRED_PARTY", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CPL_COVERRED_PARTY : BaseDataContract
    {

        [XmlElement("CoveredPartyId")]
        [DataMember]
        public string CoveredPartyId { get; set; }

        [XmlElement("CoveredPartyTypeName")]
        [DataMember]
        public string CoveredPartyTypeName { get; set; }

        [XmlElement("CoveredPartyName")]
        [DataMember]
        public string CoveredPartyName { get; set; }

        [XmlElement("CPLTypeId")] // CPLId internally in AgentNet
        [DataMember]
        public string CPLTypeId { get; set; }

        [XmlElement("CPLItemNumber")] // STARSItemNumber internally in AgentNet
        [DataMember]
        public string CPLItemNumber { get; set; }

        [XmlElement("EffectiveDate")]
        [DataMember]
        public string EffectiveDate { get; set; }

        [XmlElement("CPLSerialNumber")] // STARSSerialNumber internally in AgentNet
        [DataMember]
        public string CPLSerialNumber { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

    }
    [DataContract(Name = "AGENTNET_BACKTITLE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BACKTITLE_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_BACKTITLE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BACKTITLE_DETAIL[] AGENTNET_BACKTITLE_DETAIL { get; set; }

    }
    [DataContract(Name = "AGENTNET_BACKTITLE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BACKTITLE_DETAIL : BaseDataContract
    {
        [XmlElement("FileServiceBackTitleSearchId")]
        [DataMember]
        public string FileServiceBackTitleSearchId { get; set; }

        [XmlElement("OrderId")]
        [DataMember]
        public string OrderId { get; set; }

        [XmlElement("DocumentType")]
        [DataMember]
        public string DocumentType { get; set; }

        [XmlElement("DocumentNumber")]
        [DataMember]
        public string DocumentNumber { get; set; }

        [XmlElement("DocumentEffectiveDate")]
        [DataMember]
        public string DocumentEffectiveDate { get; set; }

        [XmlElement("OwnerNames")]
        [DataMember]
        public string OwnerNames { get; set; }

        [XmlElement("OwnerPolicyNumber")]
        [DataMember]
        public string OwnerPolicyNumber { get; set; }

        [XmlElement("LoanPolicyNumber")]
        [DataMember]
        public string LoanPolicyNumber { get; set; }

        [XmlElement("UnitLotNumber")]
        [DataMember]
        public string UnitLotNumber { get; set; }

        [XmlElement("CondoSubdivision")]
        [DataMember]
        public string CondoSubdivision { get; set; }

        [XmlElement("StreetNumber")]
        [DataMember]
        public string StreetNumber { get; set; }

        [XmlElement("StreetName")]
        [DataMember]
        public string StreetName { get; set; }

        [XmlElement("CityName")]
        [DataMember]
        public string CityName { get; set; }

        [XmlElement("StateCode")]
        [DataMember]
        public string StateCode { get; set; }

        [XmlElement("PostalCode")]
        [DataMember]
        public string PostalCode { get; set; }

        [XmlElement("CountyName")]
        [DataMember]
        public string CountyName { get; set; }

        [XmlElement("AdhocUId")]
        [DataMember]
        public string AdhocUId { get; set; }

        [XmlElement("HasLegalDescription")]
        [DataMember]
        public bool HasLegalDescription { get; set; }

        [XmlElement("IsDocRestricted")]
        [DataMember]
        public bool IsDocRestricted { get; set; }

        [XmlElement("CartridgeNumber")]
        [DataMember]
        public string CartridgeNumber { get; set; }

        [XmlElement("CartridgeBlip")]
        [DataMember]
        public string CartridgeBlip { get; set; }
        [XmlElement("FastOrderNumber")]
        [DataMember]
        public string FastOrderNumber { get; set; }
    }
    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_RESPONSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_RESPONSES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REPONSE[] AGENTNET_PRODUCT_PRICING_REPONSE { get; set; }
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }
        [XmlElement("IsAutoReportOnHold")]
        [DataMember]
        public bool IsAutoReportOnHold { get; set; }
        [XmlElement("RateEffectiveDate")]
        [DataMember]
        public DateTime RateEffectiveDate { get; set; }
        [XmlElement(ElementName = "AGENTNET_CALCULATION_NOTES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_CALCULATION_NOTES AGENTNET_CALCULATION_NOTES { get; set; }

        [XmlElement(ElementName = "DOCUMENT", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECT DOCUMENT { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }

    }

    [DataContract(Name = "AGENTNET_CALCULATION_NOTES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_CALCULATION_NOTES : BaseDataContract
    {
        [XmlElement("Notes")]
        [DataMember]
        public string[] Notes { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_REPONSE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_REPONSE : BaseDataContract
    {
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }

        [XmlElement("ProductID")]
        [DataMember]
        public string ProductID { get; set; }

        [XmlElement("ProductName")]//CPL/Jacket
        [DataMember]
        public string ProductName { get; set; }

        [XmlElement("ProductType")]
        [DataMember]
        public string ProductType { get; set; }

        [XmlElement("ProductResponseId")]
        [DataMember]
        public string ProductResponseId { get; set; }

        [XmlElement("RateType")]
        [DataMember]
        public string RateType { get; set; }

        [XmlElement("LiabilityAmount")]
        [DataMember]
        public decimal LiabilityAmount { get; set; }

        [XmlElement("EffectiveDate")]
        [DataMember]
        public DateTime EffectiveDate { get; set; }

        [XmlElement("IsExtendedCoverage")]
        [DataMember]
        public bool IsExtendedCoverage { get; set; }

        [XmlElement("StatisticalCode")]
        [DataMember]
        public string StatisticalCode { get; set; }
        
        [XmlElement("IsOverride")]
        [DataMember]
        public bool IsOverride { get; set; }

        [XmlElement("OverrideAmount")]
        [DataMember]
        public decimal OverrideAmount { get; set; }

        [XmlElement("OverrideReason")]
        [DataMember]
        public string OverrideReason { get; set; }

        [XmlElement("PriorPolicyNumber")]
        [DataMember]
        public string PriorPolicyNumber { get; set; }

        [XmlElement("NonEJacketPolicyNumber")]
        [DataMember]
        public string NonEJacketPolicyNumber { get; set; }

        [XmlElement("IsDisplayTRIDAmount")]
        [DataMember]
        public bool IsDisplayTRIDAmount { get; set; }

        [XmlElement("LinkedProductServiceId")]
        [DataMember]
        public string LinkedProductServiceId { get; set; }

        [XmlElement("PolicySequence")]
        [DataMember]
        public string PolicySequence { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_LINEITEM_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_LINEITEM_DETAILS AGENTNET_PRODUCT_LINEITEM_DETAILS { get; set; }
                
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

        [XmlElement(ElementName = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RATE_FEES AGENTNET_RATE_FEES { get; set; }
                
        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }

        [XmlElement("PolicyComplianceDate")]
        [DataMember]
        public DateTime PolicyComplianceDate { get; set; }

        [XmlElement("IsPolicyComplianceDateAvailable")]
        [DataMember]
        public bool IsPolicyComplianceDateAvailable { get; set; }

        [XmlElement("IsPolicyComplianceDateNull")]
        [DataMember]
        public bool IsPolicyComplianceDateNull { get; set; }
      
                 
    }
    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_REQUESTS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_REQUESTS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_PRICING_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_PRICING_REQUEST[] AGENTNET_PRODUCT_PRICING_REQUEST { get; set; }
        [XmlElement("RateEffectiveDate")]
        [DataMember]
        public DateTime RateEffectiveDate { get; set; }
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }
        [XmlElement("IsAutoReportOnHold")]
        [DataMember]
        public bool IsAutoReportOnHold { get; set; }
        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
        [XmlElement("PolicyComplianceDate")]
        public DateTime PolicyComplianceDate { get; set; }

        [XmlElement("IsPolicyComplianceDateNull")]
        [DataMember]
        public bool IsPolicyComplianceDateNull { get; set; }
        
    }

    [DataContract(Name = "AGENTNET_PRODUCT_PRICING_REQUEST", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_PRICING_REQUEST : BaseDataContract
    {
        [XmlElement("IsSimultaniousPrice")]
        [DataMember]
        public bool IsSimultaniousPrice { get; set; }

        [XmlElement("ProductID")]
        [DataMember]
        public string ProductID { get; set; }

        [XmlElement("ProductName")]//CPL/Jacket
        [DataMember]
        public string ProductName { get; set; }

        [XmlElement("ProductType")]//alta loan/standard
        [DataMember]
        public string ProductType { get; set; }

        [XmlElement("AgentNetProductServiceId")]
        [DataMember]
        public string AgentNetProductServiceId { get; set; }

        [XmlElement("RateType")]
        [DataMember]
        public string RateType { get; set; }

        [XmlElement("LiabilityAmount")]
        [DataMember]
        public decimal LiabilityAmount { get; set; }

        [XmlElement("EffectiveDate")]
        [DataMember]
        public DateTime EffectiveDate { get; set; }

        [XmlElement("IsExtendedCoverage")]
        [DataMember]
        public bool IsExtendedCoverage { get; set; }

        [XmlElement("StatisticalCode")]
        [DataMember]
        public string StatisticalCode { get; set; }
        
        [XmlElement("IsOverride")]
        [DataMember]
        public bool IsOverride { get; set; }

        [XmlElement("OverrideAmount")]
        [DataMember]
        public decimal OverrideAmount { get; set; }

        [XmlElement("OverrideReason")]
        [DataMember]
        public string OverrideReason { get; set; }

        [XmlElement("PriorPolicyNumber")]
        [DataMember]
        public string PriorPolicyNumber { get; set; }

        [XmlElement("NonEJacketPolicyNumber")]
        [DataMember]
        public string NonEJacketPolicyNumber { get; set; }

        [XmlElement("LinkedProductServiceId")]
        [DataMember]
        public string LinkedProductServiceId { get; set; }

        [XmlElement("PolicySequence")]
        [DataMember]
        public string PolicySequence { get; set; }

        [XmlElement("PolicyCategory")]
        [DataMember]
        public string PolicyCategory { get; set; }

        [XmlElement(ElementName = "AGENTNET_PRODUCT_LINEITEM_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_LINEITEM_DETAILS AGENTNET_PRODUCT_LINEITEM_DETAILS { get; set; }

        //later will be uncommented when jacket functionality implimented.
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

    }
    [DataContract(Name = "AGENTNET_PRODUCT_LINEITEM_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_LINEITEM_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_PRODUCT_LINEITEM_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_PRODUCT_LINEITEM_DETAIL[] AGENTNET_PRODUCT_LINEITEM_DETAIL { get; set; }
    }

    [DataContract(Name = "AGENTNET_PRODUCT_LINEITEM_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_PRODUCT_LINEITEM_DETAIL : BaseDataContract
    {
        [XmlElement("LineItemID")]
        [DataMember]
        public string LineItemID { get; set; }

        [XmlElement("LineItemType")]
        [DataMember]
        public string LineItemType { get; set; }

        [XmlElement("LineItemDescr")]
        [DataMember]
        public string LineItemDescr { get; set; }

        [XmlElement("IsOverride")]
        [DataMember]
        public bool IsOverride { get; set; }

        [XmlElement("OverrideAmount")]
        [DataMember]
        public decimal OverrideAmount { get; set; }

        [XmlElement("OverrideReason")]
        [DataMember]
        public string OverrideReason { get; set; }

        [XmlElement("StatisticalCode")]
        [DataMember]
        public string StatisticalCode { get; set; }

        [XmlElement("MiscEndorsmentAmount")]
        [DataMember]
        public decimal MiscEndorsmentAmount { get; set; }

        [XmlElement("IsDisplayTRIDAmount")]
        [DataMember]
        public bool IsDisplayTRIDAmount { get; set; }

        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTIONS AGENTNET_ADDITIONAL_QUESTIONS { get; set; }

        [XmlElement(ElementName = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RATE_FEES AGENTNET_RATE_FEES { get; set; }

        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }
    }

    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTIONS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTIONS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTION", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTION[] AGENTNET_ADDITIONAL_QUESTION { get; set; }
    }
    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTION", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTION : BaseDataContract
    {
        [XmlElement("QuestionID")]
        [DataMember]
        public string QuestionID { get; set; }

        [XmlElement("QuestionType")]
        [DataMember]
        public string QuestionType { get; set; }

        [XmlElement("QuestionDescr")]
        [DataMember]
        public string QuestionDescr { get; set; }

        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTION_ANSWERS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTION_ANSWERS AGENTNET_ADDITIONAL_QUESTION_ANSWERS { get; set; }

        // For Recording Fees


        [XmlElement("IsDropDown")]
        [DataMember]
        public string IsDropDown { get; set; }

        [XmlElement("IsRequired")]
        [DataMember]
        public string IsRequired { get; set; }

        [XmlElement("AnswerValue")]
        [DataMember]
        public string AnswerValue { get; set; }

        [XmlElement("AnswerValueType")]
        [DataMember]
        public string AnswerValueType { get; set; }

        [XmlElement("QuestionCode")]
        [DataMember]
        public string QuestionCode { get; set; }

        [XmlElement(ElementName = "AGENTNET_TYPE_DATAS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TYPE_DATAS AGENTNET_TYPE_DATAS { get; set; }
    }

    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTION_ANSWERS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTION_ANSWERS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_ADDITIONAL_QUESTION_ANSWER", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_ADDITIONAL_QUESTION_ANSWER[] AGENTNET_ADDITIONAL_QUESTION_ANSWER { get; set; }
    }
    [DataContract(Name = "AGENTNET_ADDITIONAL_QUESTION_ANSWER", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_ADDITIONAL_QUESTION_ANSWER : BaseDataContract
    {
        [XmlElement("AnswerID")]
        [DataMember]
        public string AnswerID { get; set; }

        [XmlElement("AnswerType")]
        [DataMember]
        public string AnswerType { get; set; }

        [XmlElement("AnswerDescr")]
        [DataMember]
        public string AnswerDescr { get; set; }
        [XmlElement("AnswerDataType")]
        [DataMember]
        public string AnswerDataType { get; set; }

    }


    [DataContract(Name = "AGENTNET_RATE_FEES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_RATE_FEES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_RATE_FEE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_RATE_FEE[] AGENTNET_RATE_FEE { get; set; }
    }
    [DataContract(Name = "AGENTNET_RATE_FEE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_RATE_FEE : BaseDataContract
    {
        [XmlElement("RateFeeId")]
        [DataMember]
        public string RateFeeId { get; set; }

        [XmlElement("RateFeeType")]
        [DataMember]
        public string RateFeeType { get; set; }

        [XmlElement("RateFeeDscr")]
        [DataMember]
        public string RateFeeDscr { get; set; }

        [XmlElement("RefNumber")]
        [DataMember]
        public string RefNumber { get; set; }

        [XmlElement("GrossAmount")]//it will have an override amount.
        [DataMember]
        public decimal GrossAmount { get; set; }

        [XmlElement("NetAmount")]
        [DataMember]
        public decimal NetAmount { get; set; }

        [XmlElement("CalculatedAmount")]
        [DataMember]
        public decimal CalculatedAmount { get; set; }//premium received from FACC

        [XmlElement("AgentRetentionAmount")]
        [DataMember]
        public decimal AgentRetentionAmount { get; set; }

        [XmlElement("TaxAmount")]
        [DataMember]
        public decimal TaxAmount { get; set; }

        [XmlElement("TRIDAmount")]
        [DataMember]
        public decimal TRIDAmount { get; set; }

        [XmlElement("OverriddenTRIDAmount")]
        [DataMember]
        public decimal OverriddenTRIDAmount { get; set; }

    }
    [DataContract(Name = "AGENTNET_BOSERVICE_PROCESSE_STEPS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_PROCESSE_STEPS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_BOSERVICE_PROCESSE_STEP", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BOSERVICE_PROCESSE_STEP[] AGENTNET_BOSERVICE_PROCESSE_STEP { get; set; }

    }
    [DataContract(Name = "AGENTNET_BOSERVICE_PROCESSE_STEP", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_PROCESSE_STEP : BaseDataContract
    {
        [XmlElement("ProcessId")]
        [DataMember]
        public long ProcessId { get; set; }

        [XmlElement("ProcessName")]
        [DataMember]
        public string ProcessName { get; set; }

        [XmlElement("ProcessType")]
        [DataMember]
        public string ProcessType { get; set; }

        [XmlElement("ProcessTypeId")]
        [DataMember]
        public int ProcessTypeId { get; set; }

        [XmlElement("IsProcessTaskDueNow")]
        [DataMember]
        public bool IsProcessTaskDueNow { get; set; }

        [XmlElement("IsProcessCompleted")]
        [DataMember]
        public bool IsProcessCompleted { get; set; }

        [XmlElement(ElementName = "AGENTNET_BOSERVICE_STATUSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BOSERVICE_STATUSES AGENTNET_BOSERVICE_STATUSES { get; set; }
    }

    [DataContract(Name = "AGENTNET_BOSERVICE_STATUSES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_STATUSES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_BOSERVICE_STATUS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BOSERVICE_STATUS[] AGENTNET_BOSERVICE_STATUS { get; set; }

    }
    [DataContract(Name = "AGENTNET_BOSERVICE_STATUS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_STATUS : BaseDataContract
    {
        [XmlElement("TaskName")]
        [DataMember]
        public string TaskName { get; set; }

        [XmlElement("StartedDate")]
        [DataMember]
        public DateTime StartedDate { get; set; }

        [XmlElement("CompletedDate")]
        [DataMember]
        public DateTime CompletedDate { get; set; }

        [XmlElement("IsWaived")]
        [DataMember]
        public bool IsWaived { get; set; }

        [XmlElement("CommentsText")]
        [DataMember]
        public string CommentsText { get; set; }

    }
    [DataContract(Name = "AGENTNET_BOSERVICE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_BOSERVICE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BOSERVICE_DETAIL[] AGENTNET_BOSERVICE_DETAIL { get; set; }

    }
    [DataContract(Name = "AGENTNET_BOSERVICE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_DETAIL : BaseDataContract
    {
        [XmlElement("BOServiceAgentnetId")]
        [DataMember]
        public string BOServiceAgentnetId { get; set; }

        [XmlElement("BOServiceType")]
        [DataMember]
        public string BOServiceType { get; set; }

        [XmlElement("ProductName")]
        [DataMember]
        public string ProductName { get; set; }

        [XmlElement("OpenDate")]
        [DataMember]
        public DateTime OpenDate { get; set; }

        [XmlElement("ProviderProductName")]
        [DataMember]
        public string ProviderProductName { get; set; }

        [XmlElement("AGENTNET_BOSERVICE_PROCESSE_STEPS")]
        [DataMember]
        public AGENTNET_BOSERVICE_PROCESSE_STEPS AGENTNET_BOSERVICE_PROCESSE_STEPS { get; set; }

        [XmlElement(ElementName = "AGENTNET_NAME_VALUES", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_NAME_VALUES AGENTNET_NAME_VALUES { get; set; }
    }
    [DataContract(Name = "AGENTNET_BOSERVICE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_NOTES : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_BOSERVICE_NOTE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_BOSERVICE_NOTE[] AGENTNET_BOSERVICE_NOTE { get; set; }

    }
    [DataContract(Name = "AGENTNET_BOSERVICE_NOTE", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_BOSERVICE_NOTE : BaseDataContract
    {
        [XmlElement("CreatedDate")]
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [XmlElement("NoteText")]
        [DataMember]
        public string NoteText { get; set; }

    }
    [DataContract(Name = "AGENTNET_TITLE_SERVICE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TITLE_SERVICE_DETAIL : AGENTNET_BOSERVICE_DETAIL
    {
        [XmlElement("OrderId")]
        [DataMember]
        public string OrderId { get; set; }

        [XmlElement("OrderNumber")]
        [DataMember]
        public string OrderNumber { get; set; }

        [XmlElement("OrderStatus")]
        [DataMember]
        public string OrderStatus { get; set; }

        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }

        [XmlElement("TransactionType")]
        [DataMember]
        public string TransactionType { get; set; }

        [XmlElement("BusinessSegment")]
        [DataMember]
        public string BusinessSegment { get; set; }

        [XmlElement(ElementName = "PARTIES", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public PARTIES OWING_OFFICES { get; set; }

        [XmlElement(ElementName = "DOCUMENTS", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECTS DOCUMENTS { get; set; }

        [XmlElement(ElementName = "AGENTNET_BOSERVICE_NOTES")]
        [DataMember]
        public AGENTNET_BOSERVICE_NOTES NOTES { get; set; }
    }
    [DataContract(Name = "AGENTNET_TITLE_SERVICE_COMPLS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TITLE_SERVICE_COMPLS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_TITLE_SERVICE_COMPL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_COMPL[] AGENTNET_TITLE_SERVICE_COMPL { get; set; }

    }

    [DataContract(Name = "AGENTNET_TITLE_SERVICE_COMPL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TITLE_SERVICE_COMPL : BaseDataContract
    {
        [XmlElement("OrderId")]
        [DataMember]
        public string OrderId { get; set; }

        [XmlElement("OrderNumber")]
        [DataMember]
        public string OrderNumber { get; set; }

        [XmlElement("OrderStatus")]
        [DataMember]
        public string OrderStatus { get; set; }

        [XmlElement("FileNumber")]
        [DataMember]
        public string FileNumber { get; set; }

        [XmlElement("OrderCompletedDate")]
        [DataMember]
        public DateTime OrderCompletedDate { get; set; }

        [XmlElement("OfficeId")]
        [DataMember]
        public string OfficeId { get; set; }
    }
    [DataContract(Name = "AGENTNET_TITLE_SERVICE_DOCS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TITLE_SERVICE_DOCS : BaseDataContract
    {
        [XmlElement("OrderId")]
        [DataMember]
        public string OrderId { get; set; }

        [XmlElement("LastDocumentsListRetrivedDate")]
        [DataMember]
        public DateTime LastDocumentsListRetrivedDate { get; set; }

        [XmlElement(ElementName = "DOCUMENTS", Namespace = DEAL.MISMO_NAMESPACE)]
        [DataMember]
        public FOREIGN_OBJECTS DOCUMENTS { get; set; }


    }
    [DataContract(Name = "AGENTNET_TITLE_SERVICE_UPDATE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TITLE_SERVICE_UPDATE_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_TITLE_SERVICE_UPDATE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_TITLE_SERVICE_UPDATE_DETAIL[] AGENTNET_TITLE_SERVICE_UPDATE_DETAIL { get; set; }
    }

    [DataContract(Name = "AGENTNET_TITLE_SERVICE_UPDATE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_TITLE_SERVICE_UPDATE_DETAIL : BaseDataContract
    {
        [XmlElement("OrderId")]
        [DataMember]
        public string OrderId { get; set; }

        [XmlElement("OrderNumber")]
        [DataMember]
        public string OrderNumber { get; set; }

        [XmlElement("OrderStatus")]
        [DataMember]
        public string OrderStatus { get; set; }

        [XmlElement("Products")]
        [DataMember]
        public string Products { get; set; }

        [XmlElement("CreatedBy")]
        [DataMember]
        public string CreatedBy { get; set; }

        [XmlElement("CreatedDate")]
        [DataMember]
        public DateTime CreatedDate { get; set; }
    }

    [DataContract(Name = "AGENTNET_POLICY_IMAGE_DETAILS", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_POLICY_IMAGE_DETAILS : BaseDataContract
    {
        [XmlElement(ElementName = "AGENTNET_POLICY_IMAGE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
        [DataMember]
        public AGENTNET_POLICY_IMAGE_DETAIL[] AGENTNET_POLICY_IMAGE_DETAIL { get; set; }
    }

    [DataContract(Name = "AGENTNET_POLICY_IMAGE_DETAIL", Namespace = BaseDataContract.AGENTNET_NAMESPACE)]
    public class AGENTNET_POLICY_IMAGE_DETAIL
    {

        [XmlElement("FileId")]
        [DataMember]
        public int FileId { get; set; }

        [XmlElement("FileName")]
        [DataMember]
        public string FileName { get; set; }

        [XmlElement("UploadedDateTime")]
        [DataMember]
        public DateTime UploadedDateTime { get; set; }

        [XmlElement("Status")]
        [DataMember]
        public string Status { get; set; }

        [XmlElement("CanDelete")]
        [DataMember]
        public bool CanDelete { get; set; }
    }

}

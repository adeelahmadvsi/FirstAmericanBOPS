using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "SERVICE_PRODUCT", Namespace = DEAL.MISMO_NAMESPACE)]
public class SERVICE_PRODUCT
{
	[XmlElement("SERVICE_PRODUCT_REQUEST")]
	[DataMember]
	public SERVICE_PRODUCT_REQUEST SERVICE_PRODUCT_REQUEST { get; set; }
	[XmlElement("SERVICE_PRODUCT_RESPONSE")]
	[DataMember]
	public SERVICE_PRODUCT_RESPONSE SERVICE_PRODUCT_RESPONSE { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

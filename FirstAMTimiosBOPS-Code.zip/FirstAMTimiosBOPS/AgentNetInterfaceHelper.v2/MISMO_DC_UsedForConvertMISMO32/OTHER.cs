﻿using System.Runtime.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "OTHER", Namespace = DEAL.MISMO_NAMESPACE)]
    public class OTHER 
    {
        private System.Xml.XmlNode[] anyField;
        public System.Xml.XmlNode[] Any
        {
            get { return this.anyField; }
            set { this.anyField = value; }
        }
    }
}
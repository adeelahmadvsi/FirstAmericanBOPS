using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "NAME", Namespace = DEAL.MISMO_NAMESPACE)]
public class NAME
{
	[XmlElement("EducationalAchievementsDescription")]
	[DataMember]
	public string EducationalAchievementsDescription { get; set; }
	[XmlElement("FirstName")]
	[DataMember]
	public string FirstName { get; set; }
	[XmlElement("FullName")]
	[DataMember]
	public string FullName { get; set; }
	[XmlElement("FunctionalTitleDescription")]
	[DataMember]
	public string FunctionalTitleDescription { get; set; }
	[XmlElement("IndividualTitleDescription")]
	[DataMember]
	public string IndividualTitleDescription { get; set; }
	[XmlElement("LastName")]
	[DataMember]
	public string LastName { get; set; }
	[XmlElement("MiddleName")]
	[DataMember]
	public string MiddleName { get; set; }
	[XmlElement("PrefixName")]
	[DataMember]
	public string PrefixName { get; set; }
	[XmlElement("SuffixName")]
	[DataMember]
	public string SuffixName { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

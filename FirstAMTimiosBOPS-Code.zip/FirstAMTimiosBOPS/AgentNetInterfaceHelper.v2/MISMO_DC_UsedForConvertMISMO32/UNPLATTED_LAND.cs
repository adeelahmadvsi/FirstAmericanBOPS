using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
[DataContract(Name = "UNPLATTED_LAND", Namespace = DEAL.MISMO_NAMESPACE)]
public class UNPLATTED_LAND
{
	[XmlElement("AbstractIdentifier")]
	[DataMember]
	public string AbstractIdentifier { get; set; }
	[XmlElement("BaseIdentifier")]
	[DataMember]
	public string BaseIdentifier { get; set; }
	[XmlElement("LegalTractIdentifier")]
	[DataMember]
	public string LegalTractIdentifier { get; set; }
	[XmlElement("MeridianIdentifier")]
	[DataMember]
	public string MeridianIdentifier { get; set; }
	[XmlElement("MetesAndBoundsRemainingDescription")]
	[DataMember]
	public string MetesAndBoundsRemainingDescription { get; set; }
	[XmlElement("QuarterSectionIdentifier")]
	[DataMember]
	public string QuarterSectionIdentifier { get; set; }
	[XmlElement("RangeIdentifier")]
	[DataMember]
	public string RangeIdentifier { get; set; }
	[XmlElement("SectionIdentifier")]
	[DataMember]
	public string SectionIdentifier { get; set; }
	[XmlElement("TownshipIdentifier")]
	[DataMember]
	public string TownshipIdentifier { get; set; }
	[XmlElement("UnplattedLandType")]
	[DataMember]
	public string UnplattedLandType { get; set; }
	[XmlElement("UnplattedLandTypeIdentifier")]
	[DataMember]
	public string UnplattedLandTypeIdentifier { get; set; }
	[XmlElement("UnplattedLandTypeOtherDescription")]
	[DataMember]
	public string UnplattedLandTypeOtherDescription { get; set; }
	//[XmlElement("EXTENSION")]
	//[DataMember]
	//public  EXTENSION { get; set; }
} // class
} // namespace

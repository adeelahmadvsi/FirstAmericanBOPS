﻿using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
namespace MISMOTypes
{
    [DataContract(Name = "DEAL_EXTENSION", Namespace = DEAL.MISMO_NAMESPACE)]
    public class DEAL_EXTENSION 
    {
        [XmlElement("OTHER")]
        [DataMember]
        public DEAL_OTHER OTHER { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Reflection;
#if MISMO32
using www.mismo.org.residential._2009.schemas.v32;
namespace AgentNetInterfaceHelper.v2
#else
using www.mismo.org.residential._2009.schemas;
using www.firstam.com._2011._03.datacontract.agentnet;
namespace AgentNetInterfaceHelper.v1
#endif
{
    /*This is a helper class to allow a MISMO 3.1 .NET Class Object from and to AgentNet .NET Webservice generated Proxy Objects.
     * 
     * This helper class was created since SVCUTIL.EXE generated propxy classes from WSDL, the generated classes don't serialize to a 
     * original MISMO 3.1 classes.
     * 
     * If you have a MISMO 3.1 mapped object, you can use this routine go to and from MISMO 3.1 o AgentNet WS MISMO 3.1
     * 
     * */
    public class ConverterMISMOObjects
    {
        public static string ConvertToMISMO_MESSAGE_XML(MESSAGE message)
        {
            MISMOTypes.MESSAGE mismoDeal = ConvertToMISMO31_MESSAGE(message);
            string xmlStr = ANUtils.SerializeObject((Object)mismoDeal, typeof(MISMOTypes.MESSAGE), MISMONameSpace.MISMO_NAMESPACE, DEALRequest.GetMISMONameSpaces());
            // special logic to mitigate the prefix so that schema validation does not fail
            return xmlStr.Replace("AGENTNET_DOCUMENTS", "agentnet:AGENTNET_DOCUMENTS");
        }
        public static MESSAGE ConvertMISMO_XML_to_MESSAGE(string xmlStr)
        {
            try
            {
                if (xmlStr.Contains("xmlns:mismo"))
                    xmlStr = xmlStr.Replace("xmlns:mismo", "xmlns");
                MISMOTypes.MESSAGE mismoMessage = (MISMOTypes.MESSAGE)ANUtils.DeSerializeToObject(xmlStr, typeof(MISMOTypes.MESSAGE), MISMONameSpace.MISMO_NAMESPACE);
                return ConverterMISMOObjects.ConvertToAgentNet_WS_MESSAGE(mismoMessage);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static MISMOTypes.MESSAGE ConvertToMISMO31_MESSAGE(MESSAGE message)
        {
            MISMOTypes.MESSAGE mdeal = (MISMOTypes.MESSAGE)GetMISMO_DC(message, typeof(MISMOTypes.MESSAGE));
            return mdeal;
        }
        public static MESSAGE ConvertToAgentNet_WS_MESSAGE(MISMOTypes.MESSAGE message)
        {
            //DEAL mdeal = (DEAL)GetAgentNetMISMO31DC(deal, typeof(DEAL));
            MESSAGE mdeal = (MESSAGE)GetMISMO_DC(message, typeof(MESSAGE));
            return mdeal;
        }
        /*
         * Funtion to handle an object:
         * This function copy the value from one object to another object by property name
         */
        public static Object GetMISMO_DC(Object from_obj, Type to_t)
        {
            Object dcObject = (Object)System.Activator.CreateInstance(to_t);
            PropertyInfo[] toProperties = to_t.GetProperties();
            PropertyInfo[] fromProperties = from_obj.GetType().GetProperties();
            List<string> fromPropNames = new List<string>();
            foreach (PropertyInfo p in fromProperties)
                fromPropNames.Add(p.Name);
            foreach (PropertyInfo prop in toProperties)
            {
                if (!fromPropNames.Contains(prop.Name)) // If a property is in FROM Object but not in to TO Object, skip it
                    continue;

                if (prop.Name == "ExtensionData")
                    continue;  // ExtensionData not used at this time

                //Property that returns an array object
                if (prop.PropertyType.IsSubclassOf(typeof(System.Array)))
                {
                    Object[] subColl = (Object[])from_obj.GetType().InvokeMember(prop.Name, BindingFlags.GetProperty, null, from_obj, null);
                    if (subColl != null)
                    {
                        Object[] dcSubMember = GetMISMO31DCs(subColl, prop.PropertyType.GetElementType());

                        to_t.InvokeMember(prop.Name, BindingFlags.SetProperty, null, dcObject,
                                                            new object[] { dcSubMember });
                    }
                }
                //Property that returns an Object 
                else if (prop.PropertyType.Namespace != "System" 
                            && prop.PropertyType.IsSubclassOf(typeof(Object)))
                {
                    Object subBO = (Object)from_obj.GetType().InvokeMember(prop.Name, BindingFlags.GetProperty, null, from_obj, null);
                    if (subBO != null)
                    {
                        Object dcSubMember = GetMISMO_DC(subBO, prop.PropertyType);
                        to_t.InvokeMember(prop.Name, BindingFlags.SetProperty, null, dcObject,
                            new object[] { dcSubMember });
                    }
                }
                //premitive Properties
                else
                {
                    PropertyInfo boProperty = from_obj.GetType().GetProperty(prop.Name);
                    prop.SetValue(dcObject, boProperty.GetValue(from_obj, null), null);
                }
            }
            return dcObject;
        }
        /*
         * Funtion to handle collections (arrays)
         */
        public static Object[] GetMISMO31DCs(Object[] from_obj, Type to_type)
        {

            long lIndex = 0;
            Array dcObjCollection = Array.CreateInstance(to_type, from_obj.Length);
            foreach (Object o in from_obj)
            {
                if (to_type.Namespace != "System")
                    dcObjCollection.SetValue(GetMISMO_DC(o, to_type), lIndex);
                else // do a simple set value for a premitive type array
                    dcObjCollection.SetValue(o, lIndex);

                lIndex++;
            }
            return ((Object[])dcObjCollection);
        }
  /*      public static BaseDataContract GetAgentNetMISMO31DC(MISMOTypes.BaseDataContract from_obj, Type to_t)
        {
            BaseDataContract dcObject = (BaseDataContract)System.Activator.CreateInstance(to_t);
            PropertyInfo[] toProperties = to_t.GetProperties();
            PropertyInfo[] fromProperties = from_obj.GetType().GetProperties();
            foreach (PropertyInfo prop in toProperties)
            {
                //Sub Collection && Make sure that it's base type DataContractBase
                if (prop.PropertyType.IsSubclassOf(typeof(System.Array)))
                {
                    MISMOTypes.BaseDataContract[] subColl = (MISMOTypes.BaseDataContract[])from_obj.GetType().InvokeMember(prop.Name, BindingFlags.GetProperty, null, from_obj, null);
                    if (subColl != null)
                    {
                        BaseDataContract[] dcSubMember = GetAgentNetMISMO31DCs(subColl, prop.PropertyType.GetElementType());

                        to_t.InvokeMember(prop.Name, BindingFlags.SetProperty, null, dcObject,
                                                            new object[] { dcSubMember });
                    }
                }
                //Sub Object 
                else if (prop.PropertyType.IsSubclassOf(typeof(BaseDataContract)))
                {
                    MISMOTypes.BaseDataContract subBO = (MISMOTypes.BaseDataContract)from_obj.GetType().InvokeMember(prop.Name, BindingFlags.GetProperty, null, from_obj, null);
                    if (subBO != null)
                    {
                        BaseDataContract dcSubMember = GetAgentNetMISMO31DC(subBO, prop.PropertyType);
                        to_t.InvokeMember(prop.Name, BindingFlags.SetProperty, null, dcObject,
                            new object[] { dcSubMember });
                    }
                }
                //Object Properties
                else
                {
                    PropertyInfo boProperty = from_obj.GetType().GetProperty(prop.Name);
                    prop.SetValue(dcObject, boProperty.GetValue(from_obj, null), null);
                }
            }
            return dcObject;
        }
        public static BaseDataContract[] GetAgentNetMISMO31DCs(MISMOTypes.BaseDataContract[] from_obj, Type to_type)
        {

            long lIndex = 0;
            Array dcObjCollection = Array.CreateInstance(to_type, from_obj.Length);
            foreach (MISMOTypes.BaseDataContract o in from_obj)
            {
                dcObjCollection.SetValue(GetAgentNetMISMO31DC(o, to_type), lIndex);
                lIndex++;
            }
            return ((BaseDataContract[])dcObjCollection);
        }*/
    }
}

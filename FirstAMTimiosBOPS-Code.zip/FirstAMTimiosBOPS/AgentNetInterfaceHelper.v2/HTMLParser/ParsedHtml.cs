using System;
using System.Collections;


#if MISMO32
namespace AgentNetInterfaceHelper.v2
#else
namespace AgentNetInterfaceHelper.v1
#endif
{
    /// <summary>
    /// Storage class for parsed HTML tag.
    /// TODO - support for attributes.
    /// </summary>
    public class ParsedHtml
    {
        #region Enumerations
        // List of HTML tags supported.
        public enum HtmlTag : short
        {
            Undefined,
            Text, Comments,
            TABLE, TR, TD, _TD, _TR, _TABLE,
            BR,
            BODY,
            FONT, _FONT
        }
        #endregion

        #region Local variables
        private string _value = string.Empty;
        private HtmlTag _type = HtmlTag.Undefined;
        //2008-Jan-28 Signature Fix
        private Hashtable _atts = new Hashtable();
        private int _seq = 0;
        //--
        #endregion

        #region Properties / access methods
        public string Value
        {
            get { return this._value; }
            set { this._value = value; }
        }

        public HtmlTag Type
        {
            get { return this._type; }
            set { this._type = value; }
        }

        //2008-Jan-28 Signature Fix
        public Hashtable Attributes
        {
            get { return this._atts; }
            set { this._atts = value; }
        }
        //--
        public int Seq
        {
            get { return this._seq; }
            set { this._seq = value; }
        }
        public string GetAttribute(string key)
        {
            if (this._atts.ContainsKey(key))
                return this._atts[key].ToString().Trim();
            return "";
        }
        public bool GetAttributeBool(string key)
        {
            if (this._atts.ContainsKey(key) && this._atts[key].ToString().ToLower() == "true")
               return true;
            return false;
        }
        public decimal GetAttributeDec(string key)
        {
            if (this._atts.ContainsKey(key))
            {
                string val = this._atts[key].ToString().Trim();
                val = val.Replace("$", "").Replace(",", ""); // if the decimal is formatted, remove the symbols
                decimal dec_val = 0;
                if (Decimal.TryParse(val, out dec_val))
                    return dec_val;
            }
            return 0;
        }
        public DateTime GetAttributeDate(string key)
        {
            if (this._atts.ContainsKey(key))
            {
                string val = this._atts[key].ToString().Trim();
                DateTime d_val = DateTime.MinValue;
                if (DateTime.TryParse(val, out d_val))
                    return d_val;
            }
            return DateTime.MinValue;
        }
        #endregion

        #region Default constructor
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="value"></param>
        public ParsedHtml(HtmlTag type, string value, int seq)
        {
            this._type = type;
            this._value = value;
            this._seq = seq;
        }

        //2008-Jan-28 Signature Fix
        public ParsedHtml(HtmlTag type, string value, Hashtable  attributes,int seq)
        {
            this._type = type;
            this._value = value;
            this._atts= attributes;
            this._seq = seq;
        }
        //--
        #endregion
    }
}

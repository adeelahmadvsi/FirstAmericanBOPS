using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
//using FAF.FrameworkBase;

#if MISMO32
namespace AgentNetInterfaceHelper.v2
#else
namespace AgentNetInterfaceHelper.v1
#endif
{
    /// <summary>
    /// Class parses HTML into tags and contents.
    /// </summary>
    public class HtmlParser
    {
        #region Local variables
        private List<ParsedHtml> _parsedHtml = null;
        private Dictionary<string, ParsedHtml> _parsedHtmlMap = null;
        private int _seq = 0;


        private string _html = string.Empty;
        private string _content = string.Empty;
        //2008-Jan-28 Signature Fix
        private Hashtable _atts = new Hashtable();
        //--
        private int _currentIndex = 0;
        //TimeLogger timer = new TimeLogger();
        #endregion

        #region Properties_access_methods
        public List<ParsedHtml> ParsedHtmlList
        {
            get { return this._parsedHtml; }
            set { this._parsedHtml = value; }
        }
        public ParsedHtml GetElementById(string id)
        {
            if (this._parsedHtmlMap.ContainsKey(id))
                return this._parsedHtmlMap[id];
            return null;
        }
        public List<ParsedHtml> GetOptionElements(ParsedHtml selectHtml)
        {
            List<ParsedHtml> list = new List<ParsedHtml>();
            // need to find all the options related 
            for (int i = selectHtml.Seq; i < _parsedHtml.Count; i++)
            {
                ParsedHtml p = _parsedHtml[i];
                if (p.Value == "OPTION")
                    list.Add(p);
                else if (p.Value == "/SELECT") // end of options section
                    return list;
           }
            return list;
        }
        public List<ParsedHtml> GetTABLEs()
        {
            List<ParsedHtml> list = new List<ParsedHtml>();
            foreach(ParsedHtml p in this._parsedHtml)
            {
                if (p.Value == "TABLE")
                    list.Add(p);
            }
            return list;
        }
        public List<ParsedHtml> GetTDElements(ParsedHtml tableHtml) 
        {
            List<ParsedHtml> list = new List<ParsedHtml>();
            for (int i = tableHtml.Seq; i < _parsedHtml.Count; i++)
            {
                ParsedHtml p = _parsedHtml[i];
                if (p.Value == "TD")
                    list.Add(p);
                else if (p.Value == "/TABLE") // end of current TABLE
                    return list;
            }
            return list;
        }
        public List<ParsedHtml> GetTRElements(ParsedHtml tableHtml)
        {
            List<ParsedHtml> list = new List<ParsedHtml>();
            for (int i = tableHtml.Seq; i < _parsedHtml.Count; i++)
            {
                ParsedHtml p = _parsedHtml[i];
                if (p.Value == "TR")
                    list.Add(p);
                else if (p.Value == "/TABLE") // end of current TABLE
                    return list;
            }
            return list;
        }


        #endregion

        #region Default constructor
        /// <summary>
        /// Default constructor - initialize HTML to be parsed.
        /// </summary>
        /// <param name="html">HTML to parse</param>
        public HtmlParser(string html)
        {
            this._html = html;
            this._html = this._html.Replace("\n", string.Empty);
            this._html = this._html.Replace("\t", string.Empty);
            this._html = this._html.Replace("\r", string.Empty);
            this._html = this._html.Replace("&nbsp;", " ");
            this.Parse();
        }
        #endregion

        #region Parse
        /// <summary>
        /// Main parse routine - parse HTML into tags and contents. 
        /// </summary>
        public void Parse()
        {
            //timer.Debug("Parse() Start...");
            char currentChar;

            this._parsedHtml = new List<ParsedHtml>();
            this._parsedHtmlMap = new Dictionary<string, ParsedHtml>();
            this._currentIndex = 0;

            while (this.EOF == false)
            {
                currentChar = this.GetCharacter();
                if (currentChar == '<')
                {
                    this.MoveForward(false);
                    currentChar = char.ToUpper(this.GetCharacter());
                    if ((currentChar >= 'A') && (currentChar <= 'Z') ||
                        (currentChar == '!') || (currentChar == '/'))
                    {
                        this.AddParsedItem(ParsedHtml.HtmlTag.Text);
                        this.ProcessTag();
                    }
                    else
                    {
                        this.MoveForward(false);
                    }
                }
                else
                {
                    this.MoveForward(true);
                }
            }
        }
        #endregion

        #region AddParsedItem
        /// <summary>
        /// Add item parsed into the list.
        /// </summary>
        /// <param name="tag">Type of item parsed</param>
        private void AddParsedItem(ParsedHtml.HtmlTag tag)
        {
            //timer.Debug("AddParsedItem() Start...");
            if (this._content.TrimEnd(new char[] { ' ' }) == string.Empty)
                return;

            //2008-Jan-28 Signature Fix
            //this._parsedHtml.Add(new ParsedHtml(tag, this._content));
            _seq++;
            ParsedHtml p = new ParsedHtml(tag, this._content, this._atts,_seq);
            //_parsedHtmlList.Add(_seq.ToString() + " - tag=[" + tag.ToString() + "] contect=[" + this._content.ToString() + "] " , p);
            this._parsedHtml.Add(p);
            this._atts = new Hashtable();
            //--
            this._content = string.Empty;
            try
            {
                if (p.Attributes != null && p.Attributes.Count > 0)
                {
                    if (p.Attributes.ContainsKey("id"))
                    {
                        string val = p.Attributes["id"].ToString();
                        if (!_parsedHtmlMap.ContainsKey(val))
                            _parsedHtmlMap.Add(val, p);
                    }
                }
            }
            catch (Exception)
            {
            }


        }
        #endregion

        #region ProcessTag
        /// <summary>
        /// A tag has been identified; process thru to get its attributes. 
        /// </summary>
        private void ProcessTag()
        {
            //timer.Debug("ProcessTag() Start...");
            string tag = string.Empty;
            //2008-Jan-28 Signature Fix
            string atts = string.Empty;
            //--
            char currentChar;

            if (this.ProcessComments() == true) return;

            while (this.EOF == false)
            {
                currentChar = this.GetCharacter();
                if ((this.IsWhiteSpace(currentChar) == true) || (currentChar == '>'))
                    break;
                tag += currentChar;
                this.MoveForward(false);
            }

            this.SkipWhiteSpace(false);

            // Process tag attributes.
            //2008-Jan-28 Signature Fix
            atts = string.Empty;
            while (this.GetCharacter() != '>')
            {
                currentChar = this.GetCharacter();
                atts += currentChar;
                this.MoveForward(false);
            }

            //Remove Extra space if any
            atts = atts.Replace(" = ", "=");

            //this.AddHtmlTag(tag, string.Empty);
            this.AddHtmlTag(tag, atts);
            //--

            this.MoveForward(false);
        }

        //2008-Jan-28 Signature Fix
        private List<string> SmartSplit(string s)
        {
            bool quoteInprog = false;
            List<string> list = new List<string>();
            StringBuilder currStr = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {

                if (s[i] == '\"')
                {
                    if (quoteInprog)
                    {
                        quoteInprog = false;
                        if (currStr.Length > 0)
                            list.Add(currStr.ToString());
                        currStr = new StringBuilder();
                    }
                    else
                        quoteInprog = true;
                }
                else if (!quoteInprog && s[i] == ' ')
                {
                    if (currStr.Length > 0)
                        list.Add(currStr.ToString());
                    currStr = new StringBuilder();
                }
                else
                    currStr.Append(s[i]);
            }
            if (currStr.Length > 0)
                list.Add(currStr.ToString());
            return list;
        }
        private void ProcessAttributes(string attributes)
        {
            //timer.Debug("ProcessAttributes() Start...", attributes);
            //string[] attrArray = attributes.Split(' ');
            List<string> attrArray = SmartSplit(attributes);
            string attrName = string.Empty , attrValue = string.Empty;

            this._atts = new Hashtable();

            foreach (string attr in attrArray)
            {
                string[] attrNameValue = attr.Split ('=');
                if (attrNameValue.Length > 1)
                {
                    attrName = attrNameValue[0];
                    attrValue = attrNameValue[1];
                    this._atts.Add(attrName, attrValue);
                }
                else if (attr.Length > 0)
                    this._atts.Add(attr, "true");
            }
        }
        //--
        #endregion

        #region AddHtmlTag
        /// <summary>
        /// Determin HTML tag type and add item to list of parsed tags.
        /// </summary>
        /// <param name="tag"></param>
        /// <param name="attributes"></param>
        private void AddHtmlTag(string tag, string attributes)
        {
            //timer.Debug("AddHtmlTag() Start...");
            ParsedHtml.HtmlTag type = ParsedHtml.HtmlTag.Undefined;
            switch (tag.ToUpper())
            {
                case "TABLE": type = ParsedHtml.HtmlTag.TABLE; break;
                case "TR": type = ParsedHtml.HtmlTag.TR; break;
                case "TD": type = ParsedHtml.HtmlTag.TD; break;
                case "/TD": type = ParsedHtml.HtmlTag._TD; break;
                case "/TR": type = ParsedHtml.HtmlTag._TR; break;
                case "/TABLE": type = ParsedHtml.HtmlTag._TABLE; break;
                case "BR": type = ParsedHtml.HtmlTag.BR; break;
                case "FONT": type = ParsedHtml.HtmlTag.FONT; break;
                case "/FONT": type = ParsedHtml.HtmlTag._FONT; break;
            }
            this._content = tag;
            //2008-Jan-28 Signature Fix
            this.ProcessAttributes(attributes);
            //--
            this.AddParsedItem(type);
        }
        #endregion

        #region ProcessComments
        /// <summary>
        /// Determine if content processed is comments.
        /// </summary>
        private bool ProcessComments()
        {
            //timer.Debug("ProcessComments() Start...");
            bool isComments = false;

            if ((this.GetCharacter() == '!') && (this.GetCharacter(1) == '-') &&
                (this.GetCharacter(2) == '-'))  // Process comments.
            {
                this.MoveForward(false); // Move pass '!'
                this.MoveForward(false); // Move pass '-'
                this.MoveForward(false); // Move pass '-'

                while (this.EOF == false)
                {
                    if ((this.GetCharacter() == '-') && (this.GetCharacter(1) == '-') &&
                        (this.GetCharacter(2) == '>'))
                        break;
                    this.MoveForward(true);
                }

                this.AddParsedItem(ParsedHtml.HtmlTag.Comments);
                isComments = true;
            }
            return isComments;
        }
        #endregion

        #region ProcessAttributes
        /// <summary>
        /// TODO
        /// </summary>
        private void ProcessAttributes()
        {
        }
        #endregion

        #region SkipWhiteSpace
        /// <summary>
        /// Process next character(s) until end of white space.
        /// </summary>
        /// <param name="processContent">Indicate whether to make processed character as part of content</param>
        private void SkipWhiteSpace(bool processContent)
        {
            //timer.Debug("SkipWhiteSpace() Start...");
            while (this.EOF == false)
            {
                if (this.IsWhiteSpace(this.GetCharacter()) == false)
                    break;
                this.MoveForward(processContent);
            }
        }
        #endregion

        #region IsWhiteSpace
        /// <summary>
        /// Determine if given character is a white space.
        /// </summary>
        /// <param name="ch">Character to check</param>
        /// <returns></returns>
        private bool IsWhiteSpace(char ch)
        {
            return ("\t\r\n ".IndexOf(ch) != -1);
        }
        #endregion

        #region GetCharacter
        /// <summary>
        /// Obtain current character.
        /// </summary>
        /// <returns>Current character</returns>
        private char GetCharacter()
        {
            return this._html[this._currentIndex];
        }        

        /// <summary>
        /// Obtain next character based on offset.
        /// </summary>
        /// <param name="offset">Offset amount</param>
        /// <returns>Character based on offset amount</returns>
        private char GetCharacter(int offset)
        {
            return this._html[this._currentIndex + offset];
        }
        #endregion

        #region MoveForward
        /// <summary>
        /// Move index to next character.
        /// </summary>
        /// <param name="processContent">Indicate whether to save character as content</param>
        private void MoveForward(bool processContent)
        {
            if (processContent == true)
                this._content += this._html[this._currentIndex];
            this._currentIndex = this._currentIndex + 1;
        }
        #endregion

        #region EOF
        /// <summary>
        /// Determine if End-of-File has been reached for HTML source.
        /// </summary>
        private bool EOF
        {
            get { return (this._currentIndex >= this._html.Length) ? true : false; }
        }
        #endregion
    }
}

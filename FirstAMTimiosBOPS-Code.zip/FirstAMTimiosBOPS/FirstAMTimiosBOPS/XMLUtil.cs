﻿using System;
using System.Collections;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;

namespace FirstAMTimiosWinApp
{
    public static class XMLUtil
    {
        public static string getXMLDoxElementValueByXPath(XDocument xdoc, string xpath)
        {
            string val = string.Empty;

            try
            {
                IEnumerable eleKey = (IEnumerable)xdoc.XPathEvaluate(xpath);
                val = eleKey.Cast<XElement>().FirstOrDefault() == null ?
                        string.Empty : eleKey.Cast<XElement>().FirstOrDefault().Value;
            }
            catch (Exception) { };

            return val;
        }

        public static int getCountByXPath(XDocument xdoc, string xpath)
        {
            int count = 0;

            try
            {
                IEnumerable eleKey = (IEnumerable)xdoc.XPathEvaluate(xpath);
                count = eleKey.Cast<XElement>().Count<XElement>();
            }
            catch (Exception) { };

            return count;
        }

        public static IEnumerable getXMLDoxElementValueByXPath2(XDocument xdoc, string xpath)
        {
            IEnumerable eleKey = null;

            try
            {
                eleKey = (IEnumerable)xdoc.XPathEvaluate(xpath);
                //val = eleKey.Cast<XElement>().FirstOrDefault() == null ?
                //        string.Empty : eleKey.Cast<XElement>().FirstOrDefault().Value;
            }
            catch (Exception) { };

            return eleKey;
        }


    }
}

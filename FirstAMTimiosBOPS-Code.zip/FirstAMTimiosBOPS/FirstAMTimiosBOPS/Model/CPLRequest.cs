﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstAMTimiosWinApp.Model
{
    public class TCPLRequest
    {
        public string FileNumber;
        public string ClientFileId;

        public string headquarter_id;
        public string headquarter_name;

        public string FirmPartyName;
        public string FirmPartyId;

        public string OfficeId;
        public string OffiecName;

        public string ActionType = "UPDATE";
        public string ClientFileStatus = "Open";

        public string OrderNumber;
        public string LoanNumber;
        public string LoanType;
        public string MortgageType;
        public string NoteAmount;
        public decimal PurchasePrice;
        public DateTime ClosingDate;
        public DateTime EstClosingDate;

        public string PropertyType;
        public string UnderWriterCode;

        public string AddressLine1;
        public string AddressLine2;
        public string City;
        public string StateCode;
        public string Zip;
        public string County;

        public string BorrowerFirstName;
        public string BorrowerMiddleName;
        public string BorrowerLastName;
        public string BorrowerName;
        public string BorrowerMaritalStatus;

        public string BorrowerFirstName2;
        public string BorrowerMiddleName2;
        public string BorrowerLastName2;
        public string BorrowerName2;
        public string BorrowerMaritalStatus2;

        public string BorrowerFirstName3;
        public string BorrowerMiddleName3;
        public string BorrowerLastName3;
        public string BorrowerName3;
        public string BorrowerMaritalStatus3;

        public string SellerFirstName;
        public string SellerMiddleName;
        public string SellerLastName;
        public string SellerName;
        public string SellerMaritalStatus;

        public string SellerFirstName2;
        public string SellerMiddleName2;
        public string SellerLastName2;
        public string SellerName2;
        public string SellerMaritalStatus2;

        public string SellerFirstName3;
        public string SellerMiddleName3;
        public string SellerLastName3;
        public string SellerName3;
        public string SellerMaritalStatus3;

        public string SelectedMyLenderPartyId;
        public bool bSaveMyLender;
        public string Lender_company_name;
        public string Lender_Address;
        public string Lender_Address2;
        public string Lender_city;
        public string Lender_state;
        public string Lender_zip_code;

        public string Lender_Attention;
        public string Lender_LenderClause;
        public string Lender_Phone;
        public string Lender_Fax;
        public string Lender_Email;

        public string CPL_Type_ID;
        public string CPL_Type_Desc;
        public List<string> CoveredParties = new List<string>();
        public Dictionary<string, string> dCoveredParties = new Dictionary<string, string>();

        public string ServiceRequestId;  //service xlink:label
        public DateTime dt;
    }

    public class TCPLResponse
    {
        public string Status;
        public string Status_Message;
        public string ProductStatus_OPEN;

        public string ServiceProductIdentifier;
        public string ServiceProductDescription;
        public string agentNetUniqueProductId;

        public string FileId;

        public List<TCPLCoveredParty> CoveredParties = new List<TCPLCoveredParty>();

        public string ServiceRequestId;
        public DateTime dt;
    }

    public class TCPLCoveredParty
    {
        public string TypeName;
        public string CPLTypeId;
        public string PartyName;
        public string EffectiveDate;

        public string Doc_ObjectURI;
    }

    public class TCPLService
    {
        [System.Xml.Serialization.XmlElement("TCPLRequest")]
        public TCPLRequest request;

        [System.Xml.Serialization.XmlElement("TCPLResponse")]
        public TCPLResponse response;
    }

    
}

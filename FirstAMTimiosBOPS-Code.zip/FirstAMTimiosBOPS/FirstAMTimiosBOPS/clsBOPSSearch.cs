﻿using System;
using System.Collections.Generic;
using System.Text;
using AgentNetInterfaceHelper.v2;
using services.firstam.com.entity.agentnet.v2._0;
using www.mismo.org.residential._2009.schemas.v32;
using System.IO;
using FirstAMTimiosWinApp.Model;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Xml.Linq;
using FirstAMTimiosWinApp;

namespace FirstAMTimiosBOPS
{
    class clsBOPSSearch
    {

        const string TypeCode = "Standard";
        const string COVERED_PARTY_TYPE = "CoveredPartyType";
        const string LEGAL_DESC = "Legal Desc";
        const string STARTER = "TRD";
        const string DOCUMENT_TYPE_POLICY = "PriorPolicy";

        private TCPLRequest BOPSReq = new TCPLRequest();

        private Dictionary<int, AGENTNET_PARTY> m_MyLenders = new Dictionary<int, AGENTNET_PARTY>();
        private List<TCPLResponse> m_lstExistCPLs = new List<TCPLResponse>();

        private List<string> m_AdHocUIDs = new List<string>();
        private List<string> m_FSSearchIds = new List<string>();
        private List<string> m_BackTitle_Desc = new List<string>();

        private List<string> m_AdHocUIDs_Legal = new List<string>();
        private List<string> m_FSSearchIds_Legal = new List<string>();
        private List<string> m_BackTitle_Desc_Legal = new List<string>();
        private List<string> m_SelectedVoidCPL = new List<string>();

        List<string> m_CPLRequiredField = new List<string>();
        List<string> m_CPLOptionalField = new List<string>();

        string gGUID = Guid.NewGuid().ToString().Substring(0, 8);

        string gGatorsOrderNo = string.Empty;
        string gOrderNo = string.Empty;

        string gCompanyId = string.Empty;
        string gTitleNo = string.Empty;

        string gFirmPartyName = string.Empty;
        string gFirmPartyId = string.Empty;

        string gFileNumber = string.Empty;
        string gClientFileId = string.Empty;

        string gActionType = string.Empty;
        string gClientFileStatus = string.Empty;

        string gLoanNumber = string.Empty;
        string gLoanType = string.Empty;
        string gMortgageType = string.Empty;
        decimal gNoteAmount = 0;
        decimal gPurchasePrice = 0;
        DateTime gClosingDate = DateTime.MinValue;
        DateTime gEstClosingDate = DateTime.MinValue;
        string gOrderNumber = string.Empty;
        string gTransactionType = string.Empty;
        string gBusinessSegment = string.Empty;
        string gTaskDescription = string.Empty;

        string gOfficeId = string.Empty;
        string gOffiecName = string.Empty;

        string gAddressLine1 = string.Empty;
        string gAddressLine2 = string.Empty;
        string gCity = string.Empty;
        string gStateCode = string.Empty;
        string gZip = string.Empty;
        string gCounty = string.Empty;

        string gPropertyType = string.Empty;
        string gUnderWriterCode = string.Empty;

        string gBorrowerFirstName = string.Empty;
        string gBorrowerMiddleName = string.Empty;
        string gBorrowerLastName = string.Empty;
        string gBorrowerName = string.Empty;
        string gBorrowerMaritalStatus = string.Empty;

        string gBorrowerFirstName2 = string.Empty;
        string gBorrowerMiddleName2 = string.Empty;
        string gBorrowerLastName2 = string.Empty;
        string gBorrowerName2 = string.Empty;
        string gBorrowerMaritalStatus2 = string.Empty;

        string gBorrowerFirstName3 = string.Empty;
        string gBorrowerMiddleName3 = string.Empty;
        string gBorrowerLastName3 = string.Empty;
        string gBorrowerName3 = string.Empty;
        string gBorrowerMaritalStatus3 = string.Empty;

        string gSellerFirstName = string.Empty;
        string gSellerMiddleName = string.Empty;
        string gSellerLastName = string.Empty;
        string gSellerName = string.Empty;
        string gSellerMaritalStatus = string.Empty;

        string gSellerFirstName2 = string.Empty;
        string gSellerMiddleName2 = string.Empty;
        string gSellerLastName2 = string.Empty;
        string gSellerName2 = string.Empty;
        string gSellerMaritalStatus2 = string.Empty;

        string gSellerFirstName3 = string.Empty;
        string gSellerMiddleName3 = string.Empty;
        string gSellerLastName3 = string.Empty;
        string gSellerName3 = string.Empty;
        string gSellerMaritalStatus3 = string.Empty;

        string gLender_company_name = string.Empty;
        string gLender_Address = string.Empty;
        string gLender_city = string.Empty;
        string gLender_state = string.Empty;
        string gLender_zip_code = string.Empty;

        static string xmlgators1 = @"<TimiosAPI>
  <OrderNo>{0}</OrderNo>
</TimiosAPI>
";
        public bool BOPSSearch()
        {

            logFile("BOPSSearch(): Start");

            BOPSReq.dt = PacificDT();
            BOPSReq.FileNumber = gCompanyId + "-" + gOrderNo;
            BOPSReq.FirmPartyName = gFirmPartyName;
            BOPSReq.FirmPartyId = gFirmPartyId;
            BOPSReq.ClientFileId = gClientFileId;
            BOPSReq.ActionType = gActionType;
            BOPSReq.ClientFileStatus = gClientFileStatus;
            BOPSReq.LoanNumber = gLoanNumber == "" ? gFileNumber : gLoanNumber;
            BOPSReq.LoanType = gLoanType;
            BOPSReq.MortgageType = gMortgageType;
            BOPSReq.NoteAmount = gNoteAmount.ToString();
            BOPSReq.PurchasePrice = gPurchasePrice;
            BOPSReq.ClosingDate = PacificDT().AddDays(30);
            BOPSReq.EstClosingDate = PacificDT().AddDays(30);
            BOPSReq.OrderNumber = gOrderNumber;
            BOPSReq.OfficeId = gOfficeId;
            BOPSReq.OffiecName = gOffiecName;
            BOPSReq.AddressLine1 = gAddressLine1;
            BOPSReq.AddressLine2 = gAddressLine2;
            BOPSReq.City = gCity;
            BOPSReq.StateCode = gStateCode;
            BOPSReq.Zip = gZip;
            BOPSReq.County = gCounty;
            BOPSReq.PropertyType = gPropertyType;
            BOPSReq.UnderWriterCode = gUnderWriterCode;
            BOPSReq.BorrowerFirstName = gBorrowerFirstName;
            BOPSReq.BorrowerMiddleName = gBorrowerMiddleName;
            BOPSReq.BorrowerLastName = gBorrowerLastName;
            BOPSReq.BorrowerName = gBorrowerName;
            BOPSReq.BorrowerMaritalStatus = gBorrowerMaritalStatus;

            BOPSReq.BorrowerFirstName2 = gBorrowerFirstName2;
            BOPSReq.BorrowerMiddleName2 = gBorrowerMiddleName2;
            BOPSReq.BorrowerLastName2 = gBorrowerLastName2;
            BOPSReq.BorrowerName2 = gBorrowerName2;
            BOPSReq.BorrowerMaritalStatus2 = gBorrowerMaritalStatus2;

            BOPSReq.BorrowerFirstName3 = gBorrowerFirstName3;
            BOPSReq.BorrowerMiddleName3 = gBorrowerMiddleName3;
            BOPSReq.BorrowerLastName3 = gBorrowerLastName3;
            BOPSReq.BorrowerName3 = gBorrowerName3;
            BOPSReq.BorrowerMaritalStatus3 = gBorrowerMaritalStatus3;

            BOPSReq.SellerFirstName = gSellerFirstName;
            BOPSReq.SellerMiddleName = gSellerMiddleName;
            BOPSReq.SellerLastName = gSellerLastName;
            BOPSReq.SellerName = gSellerName;
            BOPSReq.SellerMaritalStatus = gSellerMaritalStatus;

            BOPSReq.SellerFirstName2 = gSellerFirstName2;
            BOPSReq.SellerMiddleName2 = gSellerMiddleName2;
            BOPSReq.SellerLastName2 = gSellerLastName2;
            BOPSReq.SellerName2 = gSellerName2;
            BOPSReq.SellerMaritalStatus2 = gSellerMaritalStatus2;

            BOPSReq.SellerFirstName3 = gSellerFirstName3;
            BOPSReq.SellerMiddleName3 = gSellerMiddleName3;
            BOPSReq.SellerLastName3 = gSellerLastName3;
            BOPSReq.SellerName3 = gSellerName3;
            BOPSReq.SellerMaritalStatus3 = gSellerMaritalStatus3;


            BOPSReq.dCoveredParties.Clear();
            BOPSReq.dCoveredParties.Add("TransactionType", gTransactionType);
            BOPSReq.dCoveredParties.Add("BusinessSegment", gBusinessSegment);

            try
            {
                AgentNetHelper helper = null;
                AGENTNET_TYPE_DATAS_MULTI Prod = new AGENTNET_TYPE_DATAS_MULTI();
                helper = new AgentNetHelper(ANUtils.GetConfig("DefaultUserId"), ANUtils.GetConfig("DefaultPassword"));
                //Prod = helper.GetBOProductsAndPropertyTypesPost("6402539", "FL", "FATIC", "1003", "1051", "Lee", "33913");
                logFile("ANBOPSProductIds: Start");
                Prod = helper.GetBOProductsAndPropertyTypesPost(officeId: gOfficeId, stateCode: gStateCode, underWriterCode: gUnderWriterCode, transactionType: gTransactionType, businessSegment: gBusinessSegment, county: gCounty, zip: gZip);
                BOPSReq.dCoveredParties.Add("ANBOPSProductIds", Prod.AGENTNET_TYPE_DATAS_COLL[0].AGENTNET_TYPE_DATA[0].TypeCode);
                logFile("ANBOPSProductIds: Complete");
            }
            catch (Exception ex)
            {
                logFile("Error: ANBOPSProductIds - " + ex.Message);
                Console.WriteLine(ex.Message);
            }
            BOPSReq.dCoveredParties.Add("PropertyType", ANUtils.GetConfig("PropertyType"));
            BOPSReq.dCoveredParties.Add("BOPSNotificationEmailAddress", ANUtils.GetConfig("BOPSNotificationEmailAddress"));
            BOPSReq.dCoveredParties.Add("BOPSFileNotes", gTaskDescription);
            BOPSReq.dCoveredParties.Add("IsDisclaimerAccepted", "False");
            BOPSReq.Lender_company_name = gLender_company_name;
            BOPSReq.Lender_Address = gLender_Address;
            BOPSReq.Lender_city = gLender_city;
            BOPSReq.Lender_state = gLender_state;
            BOPSReq.Lender_zip_code = gLender_zip_code;

            BOPSReq.CPL_Type_ID = "1";
            BOPSReq.CPL_Type_Desc = "BackOfficeService";

            StringBuilder sb = new StringBuilder();
           DEALRequest m_Req = makeBOP_DEALRequest(BOPSReq);

            MESSAGE reqToSend = null;
            reqToSend = m_Req.MESSAGE;


            string fname = gFileNumber + "_NewBOPS_In_" + gGUID;
            string xml1 = ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(reqToSend);
            ApiCalllogger(fname, xml1);

            MESSAGE resp = null;
            InterfaceAgentNet agentNet = new InterfaceAgentNet(reqToSend);
            resp = agentNet.HTTPPost();

            if (resp == null)
            {
                //errors
                string err = "Error: " + agentNet.errMessage;
                logFile(err);


                Console.WriteLine(err);
                return false;
            }

            DEALResponse m_Resp = null;
            m_Resp = new DEALResponse(resp);

            fname = gFileNumber + "_NewBOPS_Out_" + gGUID;
            string xml2 = ANUtils.FormatXML(ConverterMISMOObjects.ConvertToMISMO_MESSAGE_XML(m_Resp.MESSAGE));
            ApiCalllogger(fname, xml2);

            bool IsResponseSuccess = m_Resp.IsResponseSuccess;

            STATUS[] statuses = m_Resp.getAllStatus_ZZ();

            bool bHasError = false;

            sb = new StringBuilder();
            foreach (STATUS status in statuses)
            {
                string[] vals = new string[3];
                vals[0] = status.StatusCode;
                vals[1] = status.StatusConditionDescription;
                vals[2] = status.StatusDescription;

                sb.Append(vals[0] + ", " + vals[2]);
                sb.Append(Environment.NewLine);
                sb.Append(Environment.NewLine);

                if (status.StatusConditionDescription.ToLower().Contains("error") || status.StatusCode == "F4101")
                {
                    bHasError = true;
                }
            }

            if (bHasError)
            {
                string str = "Error: BOPS call. " + sb.ToString();
                logFile(str);

                Console.WriteLine(sb.ToString());

                return false;
            }
            else
            {
                string str = "BOPS call OK.  " + " " + sb.ToString();
                logFile(str);

                Console.WriteLine(sb.ToString());
            }
            //-----

            TimiosAPI obj = new TimiosAPI();
            obj.CompanyId = gCompanyId;
            obj.TitleNo = gTitleNo;//order_no
            obj.OrderNo = gOrderNo;//order_no
            obj.RequestType = "Search";
            obj.OfficeId = m_Resp.DEAL.SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_TITLE_SERVICE_DETAIL.OrderNumber;
            obj.LenderName = BOPSReq.Lender_company_name;
            obj.ResponseId = m_Resp.DEAL.SERVICES.SERVICE[0].SERVICE_PRODUCT.SERVICE_PRODUCT_RESPONSE.EXTENSION.OTHER.AGENTNET_PRODUCT_RESPONSE.AGENTNET_PRODUCT_DETAIL_RESPONSE.AGENTNET_TITLE_SERVICE_DETAIL.OrderId;

            try
            {
                string xmlobj = XmlConverter<TimiosAPI>.ToXML(obj);
                //string fname = @"c:\temp\cpl_" + obj.DocName + ".xml";
                //File.WriteAllText(fname, xmlobj);

                string str = "callGatorUrlSet(), ResponseId = " + obj.ResponseId;
                logFile(str);

                bool b = callGatorUrlSet(xmlobj);

                if (b == false)
                {
                    string err = "Error: Post request failure.";
                    logFile(err);


                    Console.WriteLine(err);
                    return false;
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            logFile("BOPSSearch(): Complete");
            return true;
        }

        public bool loadGatorOrder(string GatorsOrderNo)
        {
            logFile("loadGatorOrder()-Start");



            gGatorsOrderNo = GatorsOrderNo;

            logFile("gGatorsOrderNo = " + gGatorsOrderNo);

            var arr = gGatorsOrderNo.Split('-');
            if (arr == null || arr.Length != 2)
            {
                Console.WriteLine("Error: GatorsOrderNo " + gGatorsOrderNo + " is incorrect.");
                return false;
            }

            gOrderNo = arr[1];

            string url = ANUtils.GetConfig("GatorUrl_Get");
            string xml2 = string.Empty;

            try
            {

                //call fiorano callbacks process
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("text/xml")
                      );

                    client.Timeout = TimeSpan.FromSeconds(60);

                    string xml1 = string.Format(xmlgators1, gGatorsOrderNo);

                    string fname = gGatorsOrderNo + "_GatorUrl_Get_In_" + gGUID;
                    ApiCalllogger(fname, xml1);

                    var content = new StringContent(xml1, System.Text.Encoding.Default, "text/xml");

                    HttpResponseMessage response = client.PostAsync(url, content).Result;
                    xml2 = response.Content.ReadAsStringAsync().Result;

                    fname = gGatorsOrderNo + "_GatorUrl_Get_Out_" + gGUID;
                    ApiCalllogger(fname, xml2);


                    if (response.IsSuccessStatusCode)
                    {


                    }
                    else
                    {
                        logFile("Error: loadGatorOrder() Not response.IsSuccessStatusCode. " + gFileNumber);

                        Console.WriteLine("Error: Call Fiorano API failed.");


                        return false;

                    }
                }
            }
            catch (Exception ex)
            {
                logFile("Error: loadGatorOrder()" + ex.Message + ",  " + gFileNumber);

                Console.WriteLine(ex.Message);
                return false;
            }

            if (xml2 == null || string.IsNullOrWhiteSpace(xml2))
            {
                logFile("Error: loadGatorOrder() xml2 is empty");

                Console.WriteLine("Error: Call Fiorano API Failed.");
                return false;
            }

            bool b = setupGatorsInfo(xml2);

            if (b == false)
            {
                string str = "Error: setupGatorsInfo() return false.";
                logFile(str);



                return false;
            }


            logFile("loadGatorOrder()-Complete");
            return true;
        }

        public static DateTime PacificDT()
        {
            return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, "Pacific Standard Time");
        }

        private DEALRequest makeBOP_DEALRequest(TCPLRequest mycplreq)
        {

            MESSAGE req = null;
            DEALRequest m_Req = new DEALRequest(req);

            AgentNetHelper helper = null;

            logFile("makeBOP_DEALRequest: Start");

            try
            {
                helper = new AgentNetHelper(ANUtils.GetConfig("DefaultUserId"), ANUtils.GetConfig("DefaultPassword"));

                m_Req.LoginId = ANUtils.GetConfig("DefaultUserId");
                m_Req.LoginPassword = ANUtils.GetConfig("DefaultPassword");


                PROPERTY prop = m_Req.GetProperty();
                prop.ADDRESS.AddressLineText = mycplreq.AddressLine1;
                prop.ADDRESS.AddressAdditionalLineText = mycplreq.AddressLine2;
                prop.ADDRESS.CityName = mycplreq.City;
                prop.ADDRESS.StateCode = mycplreq.StateCode;
                prop.ADDRESS.PostalCode = mycplreq.Zip;
                prop.ADDRESS.CountyName = mycplreq.County;

                m_Req.AddSalesPriceAmount(prop, mycplreq.PurchasePrice);

                m_Req.FileNumber = mycplreq.FileNumber;

                m_Req.ActionType = mycplreq.ActionType;
                m_Req.ClientFileId = mycplreq.ClientFileId;
                m_Req.ClientFileStatusCode = mycplreq.ClientFileStatus;
                m_Req.UnderWriterCode = mycplreq.UnderWriterCode;
                m_Req.OfficeId = mycplreq.OfficeId;

                AGENTNET_NAME_VALUE nv = new AGENTNET_NAME_VALUE();

                nv.Name = AgentNetNameValueEnum.FullVestingBorrower;
                nv.Value = "";
                m_Req.AddNamedValueToRequest(nv);

                AGENTNET_NAME_VALUE nv1 = new AGENTNET_NAME_VALUE();
                nv1 = new AGENTNET_NAME_VALUE();
                nv1.Name = "FirmID";
                nv1.Value = mycplreq.FirmPartyId;
                m_Req.AddNamedValueToRequest(nv1);

                AGENTNET_NAME_VALUE nv2 = new AGENTNET_NAME_VALUE();
                nv2.Name = "FirmName";
                nv2.Value = mycplreq.FirmPartyName;
                m_Req.AddNamedValueToRequest(nv2);

                m_Req.GetAgentNetRequest().PropertyTypeCode = mycplreq.PropertyType;

                addBorrower(mycplreq.BorrowerFirstName, mycplreq.BorrowerMiddleName, mycplreq.BorrowerLastName, mycplreq.BorrowerName, mycplreq.BorrowerMaritalStatus, m_Req);
                addBorrower(mycplreq.BorrowerFirstName2, mycplreq.BorrowerMiddleName2, mycplreq.BorrowerLastName2, mycplreq.BorrowerName2, mycplreq.BorrowerMaritalStatus2, m_Req);
                addBorrower(mycplreq.BorrowerFirstName3, mycplreq.BorrowerMiddleName3, mycplreq.BorrowerLastName3, mycplreq.BorrowerName3, mycplreq.BorrowerMaritalStatus3, m_Req);

                addSeller(mycplreq.SellerFirstName, mycplreq.SellerMiddleName, mycplreq.SellerLastName, mycplreq.SellerName, mycplreq.SellerMaritalStatus, m_Req);
                addSeller(mycplreq.SellerFirstName2, mycplreq.SellerMiddleName2, mycplreq.SellerLastName2, mycplreq.SellerName2, mycplreq.SellerMaritalStatus2, m_Req);
                addSeller(mycplreq.SellerFirstName3, mycplreq.SellerMiddleName3, mycplreq.SellerLastName3, mycplreq.SellerName3, mycplreq.SellerMaritalStatus3, m_Req);

                //create a loan
                Random s_Random = new Random();

                LOAN loan = new LOAN();
                int next = s_Random.Next();
                loan.xlinklabel = next.ToString();
                loan.LOAN_IDENTIFIERS = new LOAN_IDENTIFIERS();
                loan.LOAN_IDENTIFIERS.LOAN_IDENTIFIER = new LOAN_IDENTIFIER[1];
                loan.LOAN_IDENTIFIERS.LOAN_IDENTIFIER[0] = new LOAN_IDENTIFIER();
                loan.TERMS_OF_LOAN = new TERMS_OF_LOAN();
                loan.TERMS_OF_LOAN.NoteDate = PacificDT();

                loan.CLOSING_INFORMATION = new CLOSING_INFORMATION();
                loan.CLOSING_INFORMATION.CLOSING_INFORMATION_DETAIL = new CLOSING_INFORMATION_DETAIL();

                LoanHelper l = new LoanHelper(loan);
                decimal amount = decimal.Parse(mycplreq.NoteAmount);

                DateTime now = PacificDT();
                l.Update(mycplreq.LoanNumber, mycplreq.LoanType, mycplreq.MortgageType, amount, now, mycplreq.ClosingDate, mycplreq.ClosingDate, mycplreq.OrderNumber);


                m_Req.AddLoan(loan);

                SERVICE m_Service = null;
                m_Service = m_Req.CreateNewServiceProduct(AgentNetProductTypeEnum.BOPSDynamic, mycplreq.CPL_Type_ID, mycplreq.CPL_Type_Desc, "");
                mycplreq.ServiceRequestId = m_Service.xlinklabel;
                m_Req.AddService(m_Service);

                PARTY lender = m_Req.CreateLenderParty(mycplreq.Lender_company_name, mycplreq.Lender_Address,
                                    mycplreq.Lender_city, mycplreq.Lender_state, mycplreq.Lender_zip_code, "");

                lender.ROLES.ROLE[0].ROLE_DETAIL.PartyRoleType = PartyRoleTypeEnumerated.Lender;

                MISMOHelper.SetPartyRoleIdentifier(lender, mycplreq.SelectedMyLenderPartyId);

                lender.ADDRESSES.ADDRESS[0].AddressAdditionalLineText = mycplreq.Lender_Address2;

                m_Req.AddParty(lender);


                List<AGENTNET_NAME_VALUE> namedvalues = new List<AGENTNET_NAME_VALUE>();

                foreach (KeyValuePair<string, string> item in mycplreq.dCoveredParties)
                {
                    AGENTNET_NAME_VALUE mynv = new AGENTNET_NAME_VALUE();
                    mynv.Name = item.Key;
                    mynv.Value = item.Value;
                    namedvalues.Add(mynv);
                }

                m_Req.AddNamedValuesToService(m_Service, namedvalues);


            }

            catch (Exception ex)
            {
                logFile("Error: makeBOP_DEALRequest - " + ex.Message);
                Console.WriteLine(ex.Message);
            }

            logFile("makeBOP_DEALRequest: Complete");
            return m_Req;

        }

        void addBorrower(string fname, string mname, string lname, string name, string BorrowerMaritalStatus, DEALRequest req)
        {
            try
            {

                if (string.IsNullOrWhiteSpace(fname) && string.IsNullOrWhiteSpace(lname))
                {
                    return;
                }

                string entityname = getLegalEntityName(fname, lname);

                if (entityname != string.Empty)
                {
                    PARTY borrower = req.CreateBorrowerEntityParty(entityname);
                    req.AddParty(borrower);
                }
                else
                {
                    PARTY borrower = req.CreateBorrowerIndividualParty(fname, mname, lname, name, BorrowerMaritalStatus);
                    req.AddParty(borrower);
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        void addSeller(string fname, string mname, string lname, string name, string BorrowerMaritalStatus, DEALRequest req)
        {

            try
            {
                if (string.IsNullOrWhiteSpace(fname) && string.IsNullOrWhiteSpace(lname))
                {
                    return;
                }

                string entityname = getLegalEntityName(fname, lname);

                if (entityname != string.Empty)
                {
                    PARTY seller = req.CreateSellerEntityParty(entityname);
                    req.AddParty(seller);
                }
                else
                {
                    PARTY seller = req.CreateSellerIndividualParty(fname, mname, lname, name, BorrowerMaritalStatus);
                    req.AddParty(seller);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        string getLegalEntityName(string fname, string lname)
        {

            try
            {
                string[] lst = new string[]
                {
"LLC",
"LLC.",
"INC",
"INC.",
"CORP",
"CORP.",
"CORPORATION",
"TRUSTEE",
"N.A.",
"NATIONAL ASSOCIATION",
"NATIONAL ASSOC.",
"HOLDINGS",
"GROUP",
"LTD",
"LTD.",
"LIABILIT"
                };

                string name = string.Empty;
                if (fname.Equals(lname))
                {
                    name = lname.Trim();
                }
                else
                {
                    name = fname.Trim() + " " + lname.Trim();
                }

                foreach (string str in lst)
                {
                    if (name.Trim().ToUpper().EndsWith(str.ToUpper()))
                    {
                        return name;
                    }
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return string.Empty;
        }

        private bool setupGatorsInfo(string xml)
        {
            logFile("setupGatorsInfo(): Start");
            try
            {
                XDocument domXml = XDocument.Parse(xml);

                gFirmPartyName = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/firm_name");
                gFirmPartyId = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/firm_id");

                gCompanyId = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/company_id");
                string company_id = gCompanyId.PadLeft(2, '0');

                //??? gTitleNo, order_no confusing
                gTitleNo = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/order_no");

                if (gTitleNo == "0")
                {
                    Console.WriteLine("No loan for this number!");
                    return false;
                }

                gFileNumber = company_id + "-" + gTitleNo;
                gClientFileId = gFileNumber;

                gActionType = "UPDATE";
                gClientFileStatus = "Open";

                gLoanNumber = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/loan_no");
                gLoanType = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/loan_type");

                gMortgageType = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/mortgage_type");
                string strNoteAmount = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/loan_amt");
                try
                {
                    gNoteAmount = decimal.Parse(strNoteAmount);
                    gNoteAmount = decimal.Round(gNoteAmount, 2, MidpointRounding.AwayFromZero);
                }
                catch (Exception)
                {
                    gNoteAmount = 0;
                }

                gClosingDate = DateTime.MinValue;
                gEstClosingDate = DateTime.MinValue;

                gOrderNumber = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/order_no");

                gOfficeId = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/office_id");
                gOffiecName = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/office_name");


                gAddressLine1 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/property_address");
                gAddressLine2 = "";
                gCity = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/property_city");
                gStateCode = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/property_state");
                gZip = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/property_zip_code");
                gCounty = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/property_county");


                string type = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/property_type");
                gPropertyType = "";

                if (type == "Commercial")
                {
                    gPropertyType = "Residential(1-4 family)";
                }
                else if (type == "Investment" || type == "Private Lender")
                {
                    gPropertyType = "Non-Residential";
                }
                else if (type == "Primary Residence" || type == "Secondary Residence")
                {
                    gPropertyType = "Residential(1-4 family)";
                }


                gUnderWriterCode = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/underwriter_code");

                gBorrowerFirstName = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/borrower_1_first_name");
                gBorrowerMiddleName = "";
                gBorrowerLastName = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/borrower_1_last_name");
                gBorrowerName = "";
                gBorrowerMaritalStatus = "";

                gBorrowerFirstName2 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/borrower_2_first_name");
                gBorrowerMiddleName2 = "";
                gBorrowerLastName2 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/borrower_2_last_name");
                gBorrowerName2 = "";
                gBorrowerMaritalStatus2 = "";

                gBorrowerFirstName3 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/borrower_3_first_name");
                gBorrowerMiddleName3 = "";
                gBorrowerLastName3 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/borrower_3_last_name");
                gBorrowerName3 = "";
                gBorrowerMaritalStatus3 = "";

                gSellerFirstName = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/seller_1_first_name");
                gSellerMiddleName = "";
                gSellerLastName = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/seller_1_last_name");
                gSellerName = "";
                gSellerMaritalStatus = "";


                gSellerFirstName2 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/seller_2_first_name");
                gSellerMiddleName2 = "";
                gSellerLastName2 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/seller_2_last_name");
                gSellerName2 = "";
                gSellerMaritalStatus2 = "";

                gSellerFirstName3 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/seller_3_first_name");
                gSellerMiddleName3 = "";
                gSellerLastName3 = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/seller_3_last_name");
                gSellerName3 = "";
                gSellerMaritalStatus3 = "";

                gLender_company_name = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/company_name");
                gLender_Address = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/address");
                gLender_city = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/city");
                gLender_state = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/state");
                gLender_zip_code = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/zip_code");

                //AZ: Code Block - Start
                string TitleCode = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/title_code");
                if (TitleCode == "2")
                {
                    gTransactionType = "1001";
                }
                else if (TitleCode == "2" && gNoteAmount == 0)
                {
                    gTransactionType = "1002";
                }
                else if (TitleCode == "3")
                {
                    gTransactionType = "1003";
                }

                string BusinessSegment = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/occupancy_status");
                if (BusinessSegment == "C")
                {
                    gBusinessSegment = "1051";
                }
                else if (BusinessSegment == "P" || BusinessSegment == "S")
                {
                    gBusinessSegment = "1053";
                }

                gTaskDescription = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/task_description");

                string strPurchasePrice = XMLUtil.getXMLDoxElementValueByXPath(domXml, @"/TimiosAPI/GetData/purchase_price");
                try
                {
                    gPurchasePrice = decimal.Parse(strPurchasePrice);
                    gPurchasePrice = decimal.Round(gPurchasePrice, 2, MidpointRounding.AwayFromZero);
                }
                catch (Exception)
                {
                    gPurchasePrice = 0;
                }
                //AZ: Code Block - end

                string str = "setupGatorsInfo() - Complete: " + gAddressLine1 + ", " + gCity + ", " + gStateCode + ", " + gZip + ", " + gCounty
                    + ", gOfficeId = " + gOfficeId;
                logFile(str);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return true;
        }

        private void logFile(string msg)
        {
            try
            {
                string LogFolder = ANUtils.GetConfig("LogFolder");

                DateTime now = PacificDT();
                string timestamp = now.ToString("yyyy/MM/dd HH:mm:ss ffff");

                string fn = LogFolder + now.ToString("yyyyMMdd") + "_log.txt";

                string str = Environment.NewLine +
                    timestamp + " guid = " + gGUID + "  " + gFileNumber + "   " + msg;


                File.AppendAllText(fn, str);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static public void ApiCalllogger(string fileName, string content)
        {
            string isON = ANUtils.GetConfig("call_log_on");

            if (String.IsNullOrWhiteSpace(isON) || isON.ToUpper().Trim() != "ON")
            {
                return;
            }

            DateTime now = PacificDT();
            string timestamp = now.ToString("yyyyMMdd_HHmmss_ffff");
            string date = now.ToString("yyyyMMdd");
            string fname = ANUtils.GetConfig("LogFolder") + date + @"\" + timestamp + "_" + fileName + ".xml";


            try
            {
                FileInfo fileinfo = new System.IO.FileInfo(fname);
                fileinfo.Directory.Create();


                File.WriteAllText(fname, content);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private bool callGatorUrlSet(string xml)
        {
            string url = ANUtils.GetConfig("GatorUrl_Save");
            string xml2 = string.Empty;

            try
            {
                string str = "callGatorUrlSet()-Start ";
                logFile(str);

                //call fiorano callbacks process
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("text/xml")
                      );

                    client.Timeout = TimeSpan.FromSeconds(60);

                    string fname = gGatorsOrderNo + "_GatorUrl_Save_In_" + gGUID;
                    ApiCalllogger(fname, xml);

                    var content = new StringContent(xml, System.Text.Encoding.Default, "text/xml");

                    HttpResponseMessage response = client.PostAsync(url, content).Result;
                    xml2 = response.Content.ReadAsStringAsync().Result;

                    fname = gGatorsOrderNo + "_GatorUrl_Save_Out_" + gGUID;
                    ApiCalllogger(fname, xml2);

                    if (response.IsSuccessStatusCode)
                    {

                        if (XMLUtil.getXMLDoxElementValueByXPath(XDocument.Parse(xml2), @"/TimiosAPI/Status") == "File Missing")
                        {
                            str = "Error: File Missing";
                            logFile(str);

                            Console.WriteLine(str);
                            return false;
                        }

                        else
                        {
                            str = "callGatorUrlSet(): Post request succeeded.";
                            logFile(str);
                        }
                        

                    }
                    else
                    {
                        str = "Error: callGatorUrlSet() not response.IsSuccessStatusCode.";
                        logFile(str);

                        Console.WriteLine("Error: Call Fiorano Set API failed.");
                        return false;

                    }
                }


            }
            catch (Exception ex)
            {
                string str = "Error: callGatorUrlSet()  " + ex.Message;
                logFile(str);

                Console.WriteLine("Error: Call Fiorano Set API failed.  " + ex.Message, "Error");
            }
            return true;
        }

    }
}

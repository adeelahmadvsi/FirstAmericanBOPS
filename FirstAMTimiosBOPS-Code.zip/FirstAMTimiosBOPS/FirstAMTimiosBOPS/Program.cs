﻿using System;
using System.Collections.Generic;

namespace FirstAMTimiosBOPS
{
    class Program
    {

        static string GatorOrderNo = null;
        enum Status
        {
            InvalidGatorOrderNo = 0,
            GatorOrderNotLoaded = 1,
            BOPSearchFailed = 2,
            Success = 100
        }

        static int Main(string[] arg)
        {

            //Comment this condition if checking the code without simulator and provide hard coded Gator order number as done below this codition.
            if (arg.Length != 0)
            {
                GatorOrderNo = arg[0];
            }
            else
            {
                return (int)Status.InvalidGatorOrderNo;
            }

            //Provide Gator Order Number this way it checking without simulator project.
            //GatorOrderNo = "08-01649622";
            //GatorOrderNo = "08-01600797";
            //GatorOrderNo = "08-01600799";

            clsBOPSSearch objBOPSSearch = new clsBOPSSearch();

            bool b = objBOPSSearch.loadGatorOrder(GatorOrderNo);

            if (!b)
            {
                Console.WriteLine("Gator order could not be loaded. Make sure you are connected to internet and Timios services are working.");
                Console.ReadKey();
                return (int)Status.GatorOrderNotLoaded;
            }

            b = objBOPSSearch.BOPSSearch();
            if (!b)
            {
                Console.WriteLine("BOPS Search failed!");
                Console.ReadKey();
                return (int)Status.BOPSearchFailed;
            }

            return (int)Status.Success;
        }

 

    }
}
